LINGONUT — BẢN DỊCH BÀI 086–090

40 bản dịch mới, gồm Pháp, Đức, Tây Ban Nha, Nhật, Hàn, Trung giản thể, Việt và Thái.
Bài 086 và 089 có 7 đoạn; bài 087, 088 và 090 có 8 đoạn.
Tất cả khớp từng đoạn với bản tiếng Anh: tổng cộng 304 đoạn dịch mới.
Sau cập nhật: bài 001–090 có đủ 8 ngôn ngữ, tổng cộng 720 bản dịch.

CẬP NHẬT TRÊN ĐIỆN THOẠI
1. Tải nguyên Lingonut-Update-086-090.zip qua link chữ, không giải nén và không đổi tên.
2. Mở https://github.com/9852917330/9538468790LI9852917330NUT/upload/main
3. Chọn nguyên ZIP này, chờ upload xong và Commit changes vào nhánh main.
4. Giữ các ZIP 056–060, 061–065, 066–070, 071–075, 076–080 và 081–085 trong gốc repo.
5. Workflow Lingonut - Upload ZIP tự kiểm tra, build và triển khai web.

Các bài mới: Cách mạng Pháp; động đất và sóng thần Lisbon năm 1755;
Đại khủng hoảng; Cái Chết Đen; Nam Phi năm 1994.
Bản dịch giữ nguyên nội dung và mức độ chắc chắn của bài tiếng Anh.
Gói bổ sung bản dịch và báo cáo phông chữ; giữ nguyên bài tiếng Anh và audio.
Dùng Action hiện tại đã nhận ZIP; không cần sửa YAML và không cần upload vào Releases.
