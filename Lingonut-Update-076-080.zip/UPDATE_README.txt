LINGONUT — BẢN DỊCH BÀI 076–080

40 bản dịch mới, gồm Pháp, Đức, Tây Ban Nha, Nhật, Hàn, Trung giản thể, Việt và Thái.
Mỗi bài có 8 đoạn, khớp từng đoạn với nội dung tiếng Anh hiện tại: tổng cộng 320 đoạn mới.
Sau cập nhật: bài 001–080 có đủ 8 ngôn ngữ, tổng cộng 640 bản dịch.

CẬP NHẬT TRÊN ĐIỆN THOẠI
1. Tải nguyên Lingonut-Update-076-080.zip qua link chữ, không giải nén và không đổi tên.
2. Mở https://github.com/9852917330/9538468790LI9852917330NUT/upload/main
3. Chọn nguyên ZIP này, chờ upload xong và Commit changes vào nhánh main.
4. Giữ các ZIP 056–060, 061–065, 066–070 và 071–075 trong gốc repo.
5. Workflow Lingonut - Upload ZIP tự kiểm tra, build và triển khai web.

Các bài mới: khủng hoảng Suez 1956; Đại hỏa hoạn London 1666;
sóng thần Ấn Độ Dương 2004; nhật thực 1919 và thuyết Einstein; tầng ozone.
Bản dịch giữ nguyên nội dung và các mốc thời gian của bài tiếng Anh.
Gói chỉ bổ sung bản dịch và báo cáo phông chữ; không thay đổi bài tiếng Anh hoặc audio.
Dùng Action hiện tại đã nhận ZIP; không cần sửa YAML và không cần upload vào Releases.
