(function () {
  var colors = { light: '#ffffff', oatmeal: '#f3eee4', dark: '#17191d' };
  var theme = 'light';
  try {
    var saved = localStorage.getItem('english-unicorn-theme');
    if (Object.prototype.hasOwnProperty.call(colors, saved)) theme = saved;
  } catch (_) {}
  document.documentElement.dataset.theme = theme;
  var meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', colors[theme]);
})();
