# Lingonut — progress through lesson 115

English remains the primary learning language. Collection target: 1,000 lessons.
Lessons 001–115 have complete text, vocabulary, six exercises per lesson and matching English recordings.
Eight supporting translation languages: French, German, Spanish, Japanese, Korean, Simplified Chinese, Vietnamese and Thai.
The current batch is 111–115. All 115 lessons have eight supporting translations: 920 bundles and 7,320 translated paragraphs.
The current batch adds five lessons, 40 vocabulary entries, 30 questions, 23 new pronunciation clips and 40 translation bundles.

Publication is handled by the owner uploading the latest cumulative ZIP to the GitHub repository.
No GitHub push or live deployment was performed during local content preparation.
Audio validation: complete generated subtitle match, script hash match and successful MP3 decoding. Pronunciation was not independently reviewed by a human listener.
The next content batch is 116–120. Additional primary learning languages are deferred until 1,000 English lessons are complete.
