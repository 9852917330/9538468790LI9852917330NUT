import { StrictMode, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import LearningApp from "@/components/learning-app";
import { PageHeader } from "@/components/site-chrome";
import { applyTheme, readTheme } from "@/lib/theme";
import { registerPwa } from "@/lib/pwa";
import { TranslationProvider } from "@/components/translation-provider";
import type { Catalog } from "@/lib/lesson";
import "./fonts";
import "./styles.css";

function App() {
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [failed, setFailed] = useState(false);
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    setFailed(false);
    fetch("./data/index.json", { signal: controller.signal, cache: "no-cache" })
      .then(response => { if (!response.ok) throw new Error("Catalog unavailable"); return response.json(); })
      .then(data => { if (!Array.isArray(data.lessons) || !data.settings) throw new Error("Invalid catalog"); setCatalog(data); })
      .catch(error => { if (error.name !== "AbortError") setFailed(true); });
    return () => controller.abort();
  }, [attempt]);
  if (!catalog) return <div className="shell"><PageHeader /><main className="py-12" aria-live="polite">{failed ? <><p>The lessons could not load. Please check your connection.</p><button className="text-primary underline mt-4" onClick={() => setAttempt(n => n + 1)}>Try again</button></> : <p>Loading lessons…</p>}</main></div>;
  return <LearningApp lessons={catalog.lessons} settings={catalog.settings} titleTranslationUrls={catalog.titleTranslationUrls} initialId={new URLSearchParams(location.search).get("lesson") || ""} />;
}

applyTheme(readTheme());
createRoot(document.getElementById("root")!).render(<StrictMode><TranslationProvider><App /></TranslationProvider></StrictMode>);
registerPwa();
