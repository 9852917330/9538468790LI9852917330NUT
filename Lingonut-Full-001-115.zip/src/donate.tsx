import { StrictMode, useState } from "react";
import { createRoot } from "react-dom/client";
import { ArrowLeft, Check, Copy, ExternalLink, Heart } from "lucide-react";
import { PageFooter, PageHeader } from "@/components/site-chrome";
import { applyTheme, readTheme } from "@/lib/theme";
import { registerPwa } from "@/lib/pwa";
import { TranslationProvider } from "@/components/translation-provider";
import settings from "@/content/settings.json";
import "./fonts";
import "./styles.css";

function DonatePage() {
  const [copyStatus, setCopyStatus] = useState<"idle" | "copied" | "failed">("idle");
  const copyAddress = async () => {
    try { await navigator.clipboard.writeText(settings.usdtTronAddress); setCopyStatus("copied"); }
    catch { setCopyStatus("failed"); }
  };
  return <div className="shell">
    <a href="#main" className="skip-link">Skip to content</a><PageHeader />
    <main id="main" className="donate-page">
      <a className="inline-flex items-center gap-2 text-sm muted hover:text-primary" href="./"><ArrowLeft size={16} aria-hidden="true" />All lessons</a>
      <div className="donate-intro"><p className="eyebrow">Keep learning free</p><h1>Support Lingonut</h1><p className="muted">Lingonut is free to use. If these stories help you learn languages, you can support the project with a voluntary donation.</p></div>
      <div className="donation-note"><Heart size={20} aria-hidden="true" /><p><strong>No paywall, no rewards.</strong> A donation does not unlock content, features, badges or any other benefit. Every lesson remains free.</p></div>
      <section className="donation-grid" aria-label="Donation options">
        <article className="donation-card"><p className="eyebrow">Card / wallet payment</p><h2>Buy Me a Coffee</h2><p className="muted">Scan the QR code or use the button below to contribute.</p>
          <a className="qr-link" href={settings.donationUrl} target="_blank" rel="noopener noreferrer" aria-label="Open Buy Me a Coffee"><img className="donation-qr" src="./donations/buy-me-coffee-qr.png" width="200" height="200" alt="Buy Me a Coffee donation QR code" /></a>
          <a className="donate-button donation-pay" href={settings.donationUrl} target="_blank" rel="noopener noreferrer"><span>🥐 Buy me a croissant</span><ExternalLink size={16} aria-hidden="true" /></a>
        </article>
        <article className="donation-card"><p className="eyebrow">Crypto</p><h2>USDT — TRON (TRC20)</h2><p className="muted">Send only USDT on the TRON (TRC20) network.</p>
          <img className="donation-qr" src="./donations/usdt-tron-qr.jpg" width="200" height="200" alt="USDT TRON (TRC20) donation QR code" />
          <code className="wallet-address">{settings.usdtTronAddress}</code>
          <button className="wallet-copy-button" type="button" onClick={() => void copyAddress()}>{copyStatus === "copied" ? <Check size={16} aria-hidden="true" /> : <Copy size={16} aria-hidden="true" />}{copyStatus === "copied" ? "Copied" : "Copy address"}</button>
          <p className="copy-status" role="status">{copyStatus === "copied" ? "Wallet address copied." : copyStatus === "failed" ? "Copy is unavailable. Select and copy the wallet address above." : ""}</p>
        </article>
      </section>
      <p className="donation-policy">Crypto transfers are irreversible. For USDT, use the TRON (TRC20) network only and verify the wallet address before sending. Buy Me a Coffee payments are processed by Buy Me a Coffee; Lingonut does not collect payment details.</p>
    </main><PageFooter />
  </div>;
}

applyTheme(readTheme());
createRoot(document.getElementById("root")!).render(<StrictMode><TranslationProvider><DonatePage /></TranslationProvider></StrictMode>);
registerPwa();
