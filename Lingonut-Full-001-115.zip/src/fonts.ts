// Import each stylesheet as a Vite module so its WOFF2 URLs are bundled
// relative to the package, rather than rebased by Tailwind's CSS imports.
import "@fontsource-variable/nunito";
import "@fontsource-variable/chiron-goround-tc";
import "@fontsource/zen-maru-gothic/400.css";
import "@fontsource/zen-maru-gothic/700.css";
import "@fontsource/nanum-gothic/400.css";
import "@fontsource/nanum-gothic/700.css";
import "@fontsource/mitr/400.css";
import "@fontsource/mitr/500.css";
import "@fontsource/mitr/700.css";
