import type { Phrase } from "@/lib/lesson";

export function VocabularyForms({ entry }: { entry: Phrase }) {
  return <div className="vocabulary-details">
    {entry.partOfSpeech && <p className="vocabulary-kind">{entry.partOfSpeech}{entry.verbForms ? ` · ${entry.verbForms.irregular ? "Irregular" : "Regular"}` : ""}</p>}
    {entry.verbForms && <div className="vocabulary-forms"><p className="vocabulary-label">Base - Past - Past participle</p><p>{entry.verbForms.base} - {entry.verbForms.past} - {entry.verbForms.pastParticiple}</p></div>}
    {entry.pluralForm && <p className="vocabulary-plural">Plural: {entry.pluralForm}</p>}
    {entry.usageNote && <p className="vocabulary-note">{entry.usageNote}</p>}
  </div>;
}
