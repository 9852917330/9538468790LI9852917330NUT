import { useEffect, useRef, useState } from "react";
import type { LessonSummary } from "@/lib/lesson";
import { parseTitleTranslations, type TitleTranslations, type TitleTranslationUrls } from "@/lib/title-translation";
import type { ReadingLanguage } from "@/lib/translation-preferences";

export function useTitleTranslations(lessons: LessonSummary[], urls: TitleTranslationUrls | undefined, language: ReadingLanguage, enabled: boolean) {
  const [loaded, setLoaded] = useState<{ url: string; bundle: TitleTranslations } | null>(null);
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const cache = useRef(new Map<string, TitleTranslations>());
  const url = language === "en" ? undefined : urls?.[language];
  const bundle = loaded?.url === url ? loaded?.bundle : undefined;
  const failed = Boolean(url && failedUrl === url);
  useEffect(() => {
    const controller = new AbortController();
    setFailedUrl(null);
    if (!enabled || !url || language === "en") return () => controller.abort();
    const saved = cache.current.get(url);
    if (saved) { setLoaded({ url, bundle: saved }); return () => controller.abort(); }
    fetch(`./${url}`, { signal: controller.signal })
      .then(response => { if (!response.ok) throw new Error("Titles unavailable"); return response.json(); })
      .then(value => {
        const parsed = parseTitleTranslations(value, language, lessons);
        if (controller.signal.aborted) return;
        cache.current.set(url, parsed); setLoaded({ url, bundle: parsed });
      })
      .catch(error => { if (!controller.signal.aborted && error.name !== "AbortError") setFailedUrl(url); });
    return () => controller.abort();
  }, [enabled, url, language, lessons, attempt]);
  return { failed, unavailable: Boolean(enabled && language !== "en" && !url), loading: Boolean(enabled && url && !bundle && !failed), retry: () => setAttempt(value => value + 1), titles: new Map(bundle?.titles.map(item => [item.lessonId, item.title])) };
}
