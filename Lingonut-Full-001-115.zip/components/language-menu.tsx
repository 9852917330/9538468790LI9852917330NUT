import { useState } from "react";
import { Popover } from "radix-ui";
import { Check, ChevronLeft, ChevronRight, Languages } from "lucide-react";
import { translationLanguages, type TranslationLanguage } from "@/lib/translation";
import type { ReadingLanguage, TranslationView } from "@/lib/translation-preferences";

type Props = {
  label: string; language: ReadingLanguage;
  languages: readonly { code: TranslationLanguage; label: string }[];
  view?: TranslationView;
  onSelect: (language: ReadingLanguage, view?: TranslationView) => void;
  className?: string;
};

export function LanguageMenu({ label, language, languages, view, onSelect, className = "" }: Props) {
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState<TranslationLanguage | null>(null);
  const activeLabel = translationLanguages.find(item => item.code === language)?.label ?? "English Only";
  const choose = (next: ReadingLanguage, nextView?: TranslationView) => { onSelect(next, nextView); setOpen(false); };
  return <Popover.Root open={open} onOpenChange={value => { setOpen(value); if (value) setPending(null); }}>
    <Popover.Trigger asChild><button type="button" className={`translation-trigger ${language !== "en" ? "is-active" : ""} ${className}`} aria-label={`${label}: ${activeLabel}`} title={`${label}: ${activeLabel}`}><Languages size={19} aria-hidden="true" /></button></Popover.Trigger>
    <Popover.Portal><Popover.Content className="language-menu" align="end" sideOffset={8} collisionPadding={16} aria-label={label}>
      {pending && view ? <>
        <button type="button" className="language-menu-back" onClick={() => setPending(null)} aria-label="Back to languages"><ChevronLeft size={16} aria-hidden="true" /><span lang={pending}>{languages.find(item => item.code === pending)?.label}</span></button>
        <div className="language-menu-options">
          <button type="button" className="language-menu-choice" onClick={() => choose(pending, "paragraphs")}><span>Paragraph by paragraph<small>Original + translation</small></span>{language === pending && view === "paragraphs" && <Check size={16} aria-hidden="true" />}</button>
          <button type="button" className="language-menu-choice" onClick={() => choose(pending, "whole")}><span>Whole text<small>Translation only</small></span>{language === pending && view === "whole" && <Check size={16} aria-hidden="true" />}</button>
        </div>
      </> : <>
        <div className="language-menu-label">{label}</div>
        <button type="button" className="language-menu-choice" onClick={() => choose("en")}><span>English Only</span>{language === "en" && <Check size={16} aria-hidden="true" />}</button>
        <div className="language-menu-options">{languages.map(item => <button key={item.code} type="button" className="language-menu-choice" onClick={() => { if (view) setPending(item.code); else choose(item.code); }}><span lang={item.code}>{item.label}</span>{view ? <ChevronRight size={16} aria-hidden="true" /> : language === item.code ? <Check size={16} aria-hidden="true" /> : null}</button>)}</div>
      </>}
    </Popover.Content></Popover.Portal>
  </Popover.Root>;
}
