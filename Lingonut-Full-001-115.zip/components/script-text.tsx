import { Fragment, useRef, useState } from "react";
import { Dialog } from "radix-ui";
import { X } from "lucide-react";
import { phraseMatches, type Phrase } from "@/lib/lesson";
import { VocabularyForms } from "@/components/vocabulary-forms";
import { PronunciationButton } from "@/components/pronunciation-button";
import { scriptParagraphs, type LessonTranslation } from "@/lib/translation";

export function ScriptText({ script, phrases, onPronounce, translation, translationOnly = false }: { script: string; phrases: Phrase[]; onPronounce?: () => void; translation?: LessonTranslation; translationOnly?: boolean }) {
  const [activePhrase, setActivePhrase] = useState<Phrase | null>(null);
  const sourceTrigger = useRef<HTMLElement | null>(null);
  const openPhrase = (phrase: Phrase, source: HTMLElement) => { sourceTrigger.current = source; setActivePhrase(phrase); };

  return <Dialog.Root open={activePhrase !== null} onOpenChange={open => { if (!open) setActivePhrase(null); }}>
    {scriptParagraphs(script).map((paragraph, index) => <Fragment key={index}>
      {(!translation || !translationOnly) && <p lang="en" className={translation ? "bilingual-original" : undefined}>
      {paragraph.split(/(\*\*.+?\*\*)/g).map((part, i) => {
        if (!part.startsWith("**") || !part.endsWith("**")) return part;
        const text = part.slice(2, -2);
        const phrase = phrases.find(item => phraseMatches(item, text));
        if (!phrase) return <strong key={i}>{text}</strong>;
        return <span key={i} role="button" tabIndex={0} className="phrase-trigger" aria-haspopup="dialog" aria-label={`Show meaning: ${text}`} onClick={event => openPhrase(phrase, event.currentTarget)} onKeyDown={event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); openPhrase(phrase, event.currentTarget); } }}><strong>{text}</strong></span>;
      })}
      </p>}
      {translation && <p lang={translation.language} className={`translated-paragraph${translationOnly ? " translation-only" : ""}`}>{translation.paragraphs[index]}</p>}
    </Fragment>)}
    <Dialog.Portal>
      <Dialog.Overlay className="phrase-dialog-overlay" />
      <Dialog.Content className="phrase-dialog" onCloseAutoFocus={event => { event.preventDefault(); sourceTrigger.current?.focus({ preventScroll: true }); }}>
        <Dialog.Close className="phrase-dialog-close" aria-label="Close meaning" title="Close"><X size={21} aria-hidden="true" /></Dialog.Close>
        <p className="eyebrow">Meaning</p>
        <div className="phrase-dialog-heading"><Dialog.Title className="phrase-dialog-title">{activePhrase?.phrase}</Dialog.Title>{activePhrase && <PronunciationButton key={activePhrase.phrase} entry={activePhrase} onStart={onPronounce} />}</div>
        {activePhrase && <VocabularyForms entry={activePhrase} />}
        <Dialog.Description className="phrase-dialog-meaning">{activePhrase?.meaning}</Dialog.Description>
        {activePhrase?.example && <div className="phrase-dialog-example"><p className="phrase-example-label">Example</p><p>“{activePhrase.example}”</p></div>}
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>;
}
