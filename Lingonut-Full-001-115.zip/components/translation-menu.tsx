import { LanguageMenu } from "@/components/language-menu";
import { useTranslationPreferences } from "@/components/translation-provider";
import { translationLanguages } from "@/lib/translation";

export function TranslationMenu() {
  const { preferences, select } = useTranslationPreferences();
  return <LanguageMenu label="Translation" language={preferences.language} view={preferences.view} languages={translationLanguages} onSelect={select} />;
}
