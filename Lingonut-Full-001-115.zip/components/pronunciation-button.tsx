import { useEffect, useRef, useState } from "react";
import { Headphones } from "lucide-react";
import { type Phrase } from "@/lib/lesson";

let activePronunciation: HTMLAudioElement | null = null;

export function PronunciationButton({ entry, onStart }: { entry: Phrase; onStart?: () => void }) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [status, setStatus] = useState<"idle" | "loading" | "playing" | "error">("idle");
  useEffect(() => {
    const audio = audioRef.current;
    return () => { audio?.pause(); if (activePronunciation === audio) activePronunciation = null; };
  }, []);
  const play = () => {
    const audio = audioRef.current;
    if (!audio || !entry.pronunciationUrl) { setStatus("error"); return; }
    onStart?.();
    if (activePronunciation !== audio) activePronunciation?.pause();
    activePronunciation = audio;
    setStatus("loading");
    audio.currentTime = 0;
    void audio.play().catch(error => { if (error.name !== "AbortError") setStatus("error"); });
  };
  return <span className="pronunciation-control">
    <button type="button" className="pronunciation-button" data-status={status} onClick={play}
      aria-label={`Hear pronunciation: ${entry.phrase}`} aria-busy={status === "loading"}
      title="Listen to pronunciation"><Headphones size={22} aria-hidden="true" /></button>
    <audio ref={audioRef} className="pronunciation-source" data-pronunciation={entry.phrase} preload="none"
      src={entry.pronunciationUrl ? `./${entry.pronunciationUrl}` : undefined}
      onPlaying={() => setStatus("playing")} onWaiting={() => setStatus("loading")}
      onEnded={() => setStatus("idle")} onPause={() => setStatus("idle")} onError={() => setStatus("error")} />
    <span role="status" className={status === "error" ? "pronunciation-error" : "sr-only"}>
      {status === "error" ? "Could not play. Tap to retry." : status === "loading" ? "Loading pronunciation" : status === "playing" ? `Pronouncing ${entry.phrase}` : ""}
    </span>
  </span>;
}
