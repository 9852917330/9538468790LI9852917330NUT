import { useEffect, useRef, useState } from "react";
import type { Lesson } from "@/lib/lesson";
import { parseTranslation, scriptParagraphs, type LessonTranslation } from "@/lib/translation";
import { ScriptText } from "@/components/script-text";
import { AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { useTranslationPreferences } from "@/components/translation-provider";

export function LessonScript({ lesson, onPronounce }: { lesson: Lesson; onPronounce?: () => void }) {
  const { preferences: { language, view } } = useTranslationPreferences();
  const [loaded, setLoaded] = useState<{ url: string; bundle: LessonTranslation } | null>(null);
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const cache = useRef(new Map<string, LessonTranslation>());
  const url = language === "en" ? undefined : lesson.translationUrls?.[language];
  const translation = loaded?.url === url ? loaded?.bundle : undefined;
  const failed = Boolean(url && failedUrl === url);
  useEffect(() => {
    const controller = new AbortController();
    setFailedUrl(null);
    if (!url || language === "en" || !lesson.translationSourceSha256) return () => controller.abort();
    const saved = cache.current.get(url);
    if (saved) { setLoaded({ url, bundle: saved }); return () => controller.abort(); }
    fetch(`./${url}`, { signal: controller.signal })
      .then(response => { if (!response.ok) throw new Error("Translation unavailable"); return response.json(); })
      .then(value => {
        const bundle = parseTranslation(value, { lessonId: lesson.id, language, sourceScriptSha256: lesson.translationSourceSha256!, sourceTitle: lesson.title, paragraphCount: scriptParagraphs(lesson.script).length });
        if (controller.signal.aborted) return;
        cache.current.set(url, bundle);
        setLoaded({ url, bundle });
      })
      .catch(error => { if (!controller.signal.aborted && error.name !== "AbortError") setFailedUrl(url); });
    return () => controller.abort();
  }, [url, language, lesson, attempt]);
  return <AccordionItem value="script">
    <AccordionTrigger className="section-trigger"><span className="flex gap-4 items-baseline"><span className="text-xs font-normal muted tracking-wide">01</span>Script</span><span className="ml-auto text-xs muted font-normal hidden sm:inline">Read along</span></AccordionTrigger>
    <AccordionContent className="section-content script-text">
      <div role="status" aria-live="polite" className="translation-status">{language !== "en" && !url ? "Translation is not available yet for this lesson. Showing the English script." : url && !translation ? (failed ? <>The translation could not load. The English script is available below. <button type="button" onClick={() => setAttempt(value => value + 1)}>Try again</button></> : "Loading translation… The English script is available below.") : null}</div>
    {translation && <h3 className="translation-title" lang={translation.language}>{translation.title}</h3>}
    <ScriptText script={lesson.script} phrases={lesson.phrases} onPronounce={onPronounce} translation={translation} translationOnly={view === "whole"} />
    </AccordionContent>
  </AccordionItem>;
}
