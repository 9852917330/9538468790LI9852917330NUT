import { useEffect, useState } from "react";
import { Heart, Moon, Sun, Wheat } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { applyTheme, readTheme, saveTheme, themes, type Theme } from "@/lib/theme";
import { TranslationMenu } from "@/components/translation-menu";

export function Brand() {
  return <a href="./" className="brand" aria-label="Lingonut home"><img className="brand-emoji" src="./peanut.svg" width="30" height="30" alt="" aria-hidden="true" /><span className="brand-copy"><span>Lingonut</span><span className="brand-slogan">Go Nut for Languages with Real Stories</span></span></a>;
}

function ThemePicker() {
  const [theme, setTheme] = useState<Theme>(readTheme);
  useEffect(() => {
    applyTheme(theme);
    const sync = (event: StorageEvent) => {
      if (event.key === "english-unicorn-theme" || event.key === null) setTheme(readTheme());
    };
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, [theme]);
  const Icon = theme === "dark" ? Moon : theme === "oatmeal" ? Wheat : Sun;
  return <Select value={theme} onValueChange={value => { const next = value as Theme; setTheme(next); saveTheme(next); }}>
    <SelectTrigger aria-label={`Theme: ${theme}`} title="Change theme" className="theme-trigger"><Icon size={18} aria-hidden="true" /><span className="sr-only"><SelectValue /></span></SelectTrigger>
    <SelectContent position="popper" align="end">{themes.map(item => <SelectItem key={item.value} value={item.value}><span className={`theme-swatch theme-swatch-${item.value}`} aria-hidden="true" />{item.label}</SelectItem>)}</SelectContent>
  </Select>;
}

export function DonateLink({ className = "" }: { className?: string }) {
  return <a className={`donate-button ${className}`} href="./donate.html"><Heart size={17} aria-hidden="true" /><span>Donate</span></a>;
}

export function PageHeader({ onHome }: { onHome?: () => void }) {
  return <header className="masthead masthead-with-translation"><Brand /><nav aria-label="Main navigation" className="header-actions">
    {onHome ? <button className="nav-link hidden sm:block" onClick={onHome}>Lessons</button> : <a className="nav-link hidden sm:block" href="./">Lessons</a>}
    <TranslationMenu /><ThemePicker /><DonateLink className="header-donate" />
  </nav></header>;
}

export function PageFooter() {
  return <footer className="page-footer"><DonateLink /><p>Copyright © {new Date().getFullYear()} Lingonut</p></footer>;
}
