"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { flushSync } from "react-dom";
import { ArrowLeft, ArrowRight, Search, Headphones, RotateCcw, Repeat, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { type Lesson, type LessonSummary, type SiteSettings, grade } from "@/lib/lesson";
import { PageFooter, PageHeader } from "@/components/site-chrome";
import { LessonScript } from "@/components/lesson-script";
import { VocabularyForms } from "@/components/vocabulary-forms";
import { PronunciationButton } from "@/components/pronunciation-button";
import { useTranslationPreferences } from "@/components/translation-provider";
import { useTitleTranslations } from "@/components/use-title-translations";
import type { TitleTranslationUrls } from "@/lib/title-translation";

function QuestionFeedback({ correct }: { correct: boolean | undefined }) {
  if (correct === undefined) return null;
  const Icon = correct ? Check : X;
  return <p className="question-feedback"><Icon size={18} strokeWidth={2.5} aria-hidden="true" />{correct ? "Correct" : "Incorrect"}</p>;
}

type Tool = { name: string; title: string; description: string; inputSchema: object; annotations: { readOnlyHint: boolean; untrustedContentHint: boolean }; execute: (input: unknown) => unknown };
type ToolDocument = Document & { modelContext?: { registerTool: (tool: Tool, options: { signal: AbortSignal }) => void | Promise<void> } };

export default function LearningApp({ lessons, initialId, titleTranslationUrls }: { lessons: LessonSummary[]; settings: SiteSettings; initialId: string; titleTranslationUrls?: TitleTranslationUrls }) {
  const resolveId = (value: string) => lessons.find(lesson => lesson.id === value || lesson.order === Number(value))?.id || value;
  const [selected, setSelected] = useState(() => resolveId(initialId));
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All topics");
  const entry = lessons.find(l => l.id === selected);
  const { preferences: translationPreferences } = useTranslationPreferences();
  const titleTranslations = useTitleTranslations(lessons, titleTranslationUrls, translationPreferences.language, !entry);
  const [loaded, setLoaded] = useState<Lesson | null>(null);
  const [lessonError, setLessonError] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const cache = useRef(new Map<string, Lesson>());
  const current = entry && loaded?.id === selected ? loaded : null;
  useEffect(() => {
    const controller = new AbortController();
    setLessonError(false);
    if (!entry) { setLoaded(null); return () => controller.abort(); }
    const saved = cache.current.get(entry.dataUrl);
    if (saved) { setLoaded(saved); return () => controller.abort(); }
    setLoaded(null);
    fetch(`./${entry.dataUrl}`, { signal: controller.signal })
      .then(response => { if (!response.ok) throw new Error("Lesson unavailable"); return response.json(); })
      .then((data: Lesson) => { if (data.id !== entry.id || !Array.isArray(data.questions)) throw new Error("Invalid lesson"); cache.current.set(entry.dataUrl, data); setLoaded(data); })
      .catch(error => { if (error.name !== "AbortError") setLessonError(true); });
    return () => controller.abort();
  }, [entry, attempt]);
  useEffect(() => { document.title = entry ? `${entry.title} — Lingonut` : "Lingonut — Go Nut for Languages with Real Stories"; }, [entry]);
  const selectedRef = useRef(selected); selectedRef.current = selected;
  const navigate = useCallback((id: string) => {
    setSelected(id);
    window.history.pushState(null, "", `${window.location.pathname}${id ? `?lesson=${encodeURIComponent(id)}` : ""}`);
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);
  useEffect(() => { const back = () => { const value = new URLSearchParams(window.location.search).get("lesson") || ""; setSelected(lessons.find(lesson => lesson.id === value || lesson.order === Number(value))?.id || value); }; window.addEventListener("popstate", back); return () => window.removeEventListener("popstate", back); }, [lessons]);
  useEffect(() => {
    const context = (document as ToolDocument).modelContext; if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    const options = { signal: lifecycle.signal };
    const register = (tool: Tool) => { try { void Promise.resolve(context.registerTool(tool, options)).catch(() => {}); } catch { /* Optional browser support. */ } };
    register({ name: "list_lessons", title: "List Lingonut lessons", description: "Read the available lesson titles, IDs and audio availability, plus the currently open lesson.", inputSchema: { type: "object", properties: {}, additionalProperties: false }, annotations: { readOnlyHint: true, untrustedContentHint: false }, execute(input) { if (input && (typeof input !== "object" || Object.keys(input).length)) throw new Error("No parameters are accepted."); return { currentLessonId: selectedRef.current || null, lessons: lessons.map(l => ({ id: l.id, title: l.title, category: l.category, hasAudio: Boolean(l.audioUrl) })) }; } });
    register({ name: "open_lesson", title: "Open a listening lesson", description: "Open a lesson by ID in the same learning interface. Does not play audio or submit answers.", inputSchema: { type: "object", properties: { lessonId: { type: "string" } }, required: ["lessonId"], additionalProperties: false }, annotations: { readOnlyHint: false, untrustedContentHint: false }, execute(input) { if (!input || typeof input !== "object" || Object.keys(input).some(k => k !== "lessonId") || !("lessonId" in input) || typeof input.lessonId !== "string") throw new Error("A lessonId string is required."); const lesson = lessons.find(l => l.id === input.lessonId); if (!lesson) throw new Error("Lesson not found."); flushSync(() => navigate(lesson.id)); return { id: lesson.id, title: lesson.title, opened: true }; } });
    return () => lifecycle.abort();
  }, [lessons, navigate]);
  const categories = ["All topics", ...new Set(lessons.map(l => l.category))];
  const filtered = lessons.filter(l => (category === "All topics" || l.category === category) && `${String(l.order).padStart(3, "0")} ${l.id} ${l.title} ${titleTranslations.titles.get(l.id) ?? ""} ${l.summary} ${l.category}`.toLowerCase().includes(query.trim().toLowerCase()));
  return <div className="shell">
    <a href="#main" className="skip-link">Skip to content</a>
    <PageHeader onHome={() => navigate("")} />
    <main id="main">
      {entry && !current ? <section className="lesson-page py-12" aria-live="polite"><button className="text-sm muted" onClick={() => navigate("")}>All lessons</button>{lessonError ? <div className="mt-6"><p>The lesson could not load. Please check your connection.</p><button className="text-primary underline mt-4" onClick={() => setAttempt(n => n + 1)}>Try again</button></div> : <p className="mt-6">Loading lesson…</p>}</section> : current ? <LessonView key={current.id} lesson={current} lessons={lessons} navigate={navigate} /> : <>
        {selected && <p role="alert" className="mt-5 text-primary">This lesson is unavailable. Choose another lesson below.</p>}
        <section className="lesson-library" aria-label="Lesson library">
          <div className="library-heading"><h1>Lessons</h1><span>{lessons.length} / 1,000 lessons</span></div>
          <p className="muted mb-5 text-sm">{lessons.length} scripts · {lessons.filter(l => l.audioUrl).length} audio recordings</p>
          <div className="library-controls">
            <div className="relative min-w-0 flex-1"><Search className="absolute left-3 top-3 text-muted-foreground" size={18} aria-hidden="true" /><Input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search by number, title or topic" aria-label="Search lessons" className="pl-10 h-11 text-base rounded-md" /></div>
            <Select value={category} onValueChange={setCategory}><SelectTrigger aria-label="Filter by topic" className="h-11! w-[168px] text-sm"><SelectValue /></SelectTrigger><SelectContent>{categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select>
          </div>
          <div role="status" aria-live="polite" className="title-translation-status">{titleTranslations.loading ? "Loading translated titles… Showing English titles for now." : titleTranslations.unavailable ? "Translated titles are not available for this language yet. Showing English titles." : titleTranslations.failed ? <>Translated titles could not load. Showing English titles. <button type="button" onClick={titleTranslations.retry}>Try again</button></> : null}</div>
          {filtered.length ? <ol className="lesson-list" aria-label="Lessons in order">{filtered.map(lesson => { const translated = titleTranslations.titles.get(lesson.id); const hasTranslation = translationPreferences.language !== "en" && Boolean(translated); const whole = hasTranslation && translationPreferences.view === "whole"; return <li key={lesson.id} value={lesson.order}><a href={`?lesson=${encodeURIComponent(lesson.id)}`} onClick={event => { if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return; event.preventDefault(); navigate(lesson.id); }}><span className="list-number">{String(lesson.order).padStart(3, "0")}.</span><span className="lesson-list-titles"><span className="lesson-title" lang={whole ? translationPreferences.language : "en"}>{whole ? translated : lesson.title}</span>{hasTranslation && !whole && <span className="lesson-title-translation" lang={translationPreferences.language}>{translated}</span>}</span></a></li>; })}</ol> : <div className="py-12 text-center"><h2 className="text-lg font-medium">No lessons found</h2><p className="muted mt-2">Try another topic or search term.</p><Button className="mt-5" variant="outline" onClick={() => {setQuery(""); setCategory("All topics");}}>Clear filters</Button></div>}
        </section>
      </>}
    </main><PageFooter />
  </div>;
}

export function LessonView({ lesson, lessons, navigate }: { lesson: Lesson; lessons: LessonSummary[]; navigate: (id: string) => void }) {
  const [sections, setSections] = useState<string[]>([]);
  const [answers, setAnswers] = useState<string[]>(Array(6).fill(""));
  const [result, setResult] = useState<boolean[] | null>(null);
  const [rate, setRate] = useState("1");
  const [repeat, setRepeat] = useState(false);
  const [audioError, setAudioError] = useState(false);
  const [audioObjectUrl, setAudioObjectUrl] = useState<string | null>(null);
  const [audioAttempt, setAudioAttempt] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);
  // A complete local Blob makes the native seek bar independent of host Range support.
  // Fetch only the open lesson, never the whole collection, and release it on navigation.
  useEffect(() => {
    if (!lesson.audioUrl) return;
    const controller = new AbortController();
    const audio = audioRef.current;
    let objectUrl: string | undefined;
    setAudioError(false);
    setAudioObjectUrl(null);
    fetch(`./${lesson.audioUrl}`, { signal: controller.signal, cache: "force-cache" })
      .then(response => { if (!response.ok) throw new Error("Audio unavailable"); return response.arrayBuffer(); })
      .then(bytes => {
        if (controller.signal.aborted) return;
        objectUrl = URL.createObjectURL(new Blob([bytes], { type: "audio/mpeg" }));
        setAudioObjectUrl(objectUrl);
      })
      .catch(error => { if (error.name !== "AbortError") setAudioError(true); });
    return () => { controller.abort(); audio?.pause(); if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [lesson.audioUrl, audioAttempt]);
  const pauseLesson = () => audioRef.current?.pause();
  const index = lessons.findIndex(l => l.id === lesson.id);
  const answered = answers.filter(a => a.trim()).length;
  const answer = (i: number, value: string) => {setAnswers(a => a.map((v, n) => n === i ? value : v)); setResult(null);};
  const trigger = (n: string, title: string, suffix: string) => <AccordionTrigger className="section-trigger"><span className="flex gap-4 items-baseline"><span className="text-xs font-normal muted tracking-wide">{n}</span>{title}</span><span className="ml-auto text-xs muted font-normal hidden sm:inline">{suffix}</span></AccordionTrigger>;
  return <article className="lesson-page">
    <div className="flex items-center justify-between gap-4"><button onClick={() => navigate("")} className="inline-flex gap-2 items-center text-sm muted hover:text-primary"><ArrowLeft size={16} /> All lessons</button><span className="text-xs muted">{index + 1} of {lessons.length}</span></div>
    <div className="lesson-heading"><p className="eyebrow">Lesson {String(lesson.order).padStart(3, "0")} <span className="mx-2 muted">/</span> {lesson.category}</p><h1>{lesson.title}</h1><p className="muted">{lesson.summary}</p><div className="mt-5 flex flex-wrap gap-4 items-center text-sm"><span className="border border-border rounded px-2 py-0.5">{lesson.level}</span><span className="muted">3 multiple choice + 3 one-word answers</span></div></div>
    <section className="audio-panel" aria-label="Lesson audio"><div className="flex flex-wrap gap-4 justify-between items-center"><h2 className="font-medium flex gap-3 items-center"><Headphones size={21} className="text-primary" /> Listen to the lesson</h2>{lesson.audioUrl && <Select value={rate} onValueChange={v => {setRate(v); if(audioRef.current) audioRef.current.playbackRate = Number(v);}}><SelectTrigger aria-label="Playback speed" className="w-25 bg-card"><SelectValue /></SelectTrigger><SelectContent>{["0.75","1","1.25","1.5"].map(v => <SelectItem key={v} value={v}>{v}× speed</SelectItem>)}</SelectContent></Select>}</div>
      {lesson.audioUrl ? <>
        <audio key={lesson.audioUrl} ref={audioRef} controls loop={repeat} preload="auto" src={audioObjectUrl ?? undefined} onLoadedMetadata={() => { if (audioRef.current) audioRef.current.playbackRate = Number(rate); }} onError={() => { if (audioObjectUrl) setAudioError(true); }} aria-label={`Audio for ${lesson.title}`} />
        <div className="mt-3 flex flex-wrap justify-between items-center gap-x-4 gap-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <Button type="button" variant="ghost" size="sm" className="h-11" disabled={!audioObjectUrl} onClick={() => {if(audioRef.current) audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - 10);}}><RotateCcw size={14} aria-hidden="true" /> Back 10 seconds</Button>
            <Button type="button" variant={repeat ? "default" : "outline"} size="sm" className="h-11" aria-label="Repeat lesson" aria-pressed={repeat} title="Repeat this lesson when the audio ends" onClick={() => setRepeat(active => !active)}><Repeat size={14} aria-hidden="true" /> Repeat <span className="text-xs" aria-hidden="true">{repeat ? "On" : "Off"}</span></Button>
          </div>
          <span className="text-xs muted" role="status">{!audioObjectUrl && !audioError ? "Preparing audio…" : "Listen once before opening the script."}</span>
        </div>
        {audioError && <p role="alert" className="mt-3 text-primary text-sm">The audio could not load. <button className="underline" onClick={() => {setAudioAttempt(n => n + 1);}}>Try again</button>.</p>}
      </> : <div className="mt-4"><p className="text-sm muted">Audio is not available yet. You can read the script and practise below.</p></div>}
    </section>
    <Accordion type="multiple" value={sections} onValueChange={setSections} className="lesson-sections">
      <LessonScript key={lesson.id} lesson={lesson} onPronounce={pauseLesson} />
      <AccordionItem value="phrases">{trigger("02", "Words and Phrases", `${lesson.phrases.length} entries`)}<AccordionContent className="section-content">{lesson.phrases.map((p,i) => <div className="phrase-row" key={i}><div className="phrase-row-heading"><h3 className="font-semibold">{p.phrase}</h3><PronunciationButton entry={p} onStart={pauseLesson} /></div><VocabularyForms entry={p} /><p>{p.meaning}</p><p className="muted italic mt-3 text-[15px]">“{p.example}”</p></div>)}</AccordionContent></AccordionItem>
      <AccordionItem value="questions">{trigger("03", "Questions", "Put your listening to work")}<AccordionContent className="section-content"><form onSubmit={e => { e.preventDefault(); if(answered === 6) setResult(grade(lesson, answers)); }}>
        <h3 className="font-medium">Questions 1–3</h3><p className="text-sm muted mt-1 mb-1">Choose the correct answer: A, B or C.</p>
        {lesson.questions.slice(0,3).map((q,i) => <fieldset className="question" data-result={result === null ? undefined : result[i] ? "correct" : "incorrect"} key={i}>
          <legend className="sr-only">Question {i+1}: {q.prompt}</legend>
          <p id={`question-${i}`} className="question-label mb-4"><span className="question-number">{i+1}.</span>{q.prompt}</p>
          <RadioGroup value={answers[i]} onValueChange={v => answer(i,v)} aria-labelledby={`question-${i}`} className="gap-3">
            {q.options.map((o,n) => { const letter = String.fromCharCode(65+n);return <label className="option-label" key={letter} htmlFor={`q${i}-${letter}`}><RadioGroupItem value={letter} id={`q${i}-${letter}`} className="mt-1 shrink-0 border-[#999]" /><span><span className="font-semibold mr-2">{letter}.</span>{o}</span></label>; })}
          </RadioGroup>
          <QuestionFeedback correct={result?.[i]} />
        </fieldset>)}
        <div className="mt-8 mb-2"><h3 className="font-medium">Questions 4–6</h3><p className="text-sm muted mt-1">Complete the notes. Write <strong>ONE WORD ONLY</strong> for each answer.</p></div>
        {lesson.questions.slice(3).map((q,n) => {const i=n+3;return <div className="question" data-result={result === null ? undefined : result[i] ? "correct" : "incorrect"} key={i}>
          <label className="question-label" htmlFor={`gap-${i}`}><span className="question-number">{i+1}.</span><span>{q.prompt.replace("___", "__________")}</span></label>
          <Input className="answer-input mt-4 h-12 max-w-sm text-base" id={`gap-${i}`} value={answers[i]} onChange={e => answer(i,e.target.value)} placeholder="One word" autoComplete="off" spellCheck={false} maxLength={80} aria-describedby={`gap-hint-${i}`} aria-invalid={result?.[i] === false || undefined} />
          <span id={`gap-hint-${i}`} className="sr-only">Write one word from the recording.</span>
          <QuestionFeedback correct={result?.[i]} />
        </div>;})}
        <div className="pt-6 flex flex-wrap items-center gap-4"><Button type="submit" className="h-12 text-base px-6" disabled={answered !== 6}><Check size={17} /> Check answers</Button><span className="text-sm muted">{answered} of 6 answered</span><Button type="button" variant="ghost" onClick={() => {setAnswers(Array(6).fill(""));setResult(null);}} className="ml-auto">Reset</Button></div>
        {result && <div role="status" className="border border-border p-5 mt-5"><p className="text-xl font-semibold">{result.filter(Boolean).length} / 6 correct</p><p className="text-sm muted mt-2">Open Answer Key below to review the answers and explanations.</p></div>}
      </form></AccordionContent></AccordionItem>
      <AccordionItem value="answers">{trigger("04", "Answer Key", "Answers & explanations")}<AccordionContent className="section-content">{lesson.questions.map((q,i) => <div className="answer-row" key={i}><h3 className="font-semibold"><span className="text-primary mr-3">{i+1}.</span>{q.type === "mcq" ? `${q.answer}. ${q.options[q.answer.charCodeAt(0)-65]}` : q.answer}</h3><blockquote>“{q.evidence}”</blockquote><p className="text-[15px]">{q.explanation}</p></div>)}</AccordionContent></AccordionItem>
    </Accordion>
    <nav aria-label="Lesson navigation" className="mt-8 flex justify-between gap-4"><Button variant="ghost" disabled={index === 0} onClick={() => navigate(lessons[index-1].id)}><ArrowLeft /> Previous lesson</Button><Button variant="ghost" disabled={index === lessons.length-1} onClick={() => navigate(lessons[index+1].id)}>Next lesson <ArrowRight /></Button></nav>
  </article>;
}
