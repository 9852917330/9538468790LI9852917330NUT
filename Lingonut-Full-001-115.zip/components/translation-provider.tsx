import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { defaultTranslationPreferences, readTranslationPreferences, saveTranslationPreferences, translationPreferenceKey, type ReadingLanguage, type TranslationPreferences, type TranslationView } from "@/lib/translation-preferences";

type ContextValue = { preferences: TranslationPreferences; select: (language: ReadingLanguage, view?: TranslationView) => void };
const TranslationContext = createContext<ContextValue | null>(null);
const readBrowserPreferences = () => {
  try { return readTranslationPreferences(window.localStorage); }
  catch { return { ...defaultTranslationPreferences }; }
};
export function TranslationProvider({ children }: { children: ReactNode }) {
  const [preferences, setPreferences] = useState<TranslationPreferences>(readBrowserPreferences);
  useEffect(() => {
    try { saveTranslationPreferences(window.localStorage, preferences); } catch { /* Storage access may be blocked. */ }
  }, [preferences]);
  useEffect(() => {
    const sync = (event: StorageEvent) => {
      if (event.key !== translationPreferenceKey && event.key !== null) return;
      const next = readBrowserPreferences();
      setPreferences(previous => previous.language === next.language && previous.view === next.view ? previous : next);
    };
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, []);
  const select = useCallback((language: ReadingLanguage, view?: TranslationView) => {
    setPreferences(previous => {
      const nextView = view ?? previous.view;
      return previous.language === language && previous.view === nextView ? previous : { version: 1, language, view: nextView };
    });
  }, []);
  return <TranslationContext.Provider value={{ preferences, select }}>{children}</TranslationContext.Provider>;
}
export function useTranslationPreferences() {
  const context = useContext(TranslationContext);
  if (!context) throw new Error("TranslationProvider is required.");
  return context;
}
