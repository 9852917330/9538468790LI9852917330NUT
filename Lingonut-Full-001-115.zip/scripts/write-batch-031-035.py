"""Source-reviewed original overviews for English Unicorn 031–035."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(31, 'smallpox-vaccination-eradication', 'Smallpox Vaccination: From Discovery to Eradication', 'Science',
      'Earlier protection methods, Jenner’s experiment and a worldwide campaign helped turn a deadly disease into a public health victory.',
'''For centuries, smallpox killed large numbers of people and left many survivors with deep **scars**. Communities had already developed ways to reduce the danger. One practice, **variolation**, deliberately exposed people to smallpox material. It could provide protection, but it could also cause deadly illness and spread the disease.

In England, the doctor Edward Jenner investigated an observation that others had also noticed: people who had caught **cowpox** often seemed protected from smallpox. In 1796, he tested this idea using cowpox material on an eight-year-old boy, James Phipps. Later exposure to smallpox did not produce the disease in the boy.

The experiment put a child at risk. Its result was important, but the method would not meet modern standards for research involving children. Jenner's published work helped a new approach spread, building on knowledge that had developed before him.

**Vaccination** gradually replaced variolation. It could build **immunity** without deliberately giving people smallpox. Methods improved over time, and later vaccines used a related virus called vaccinia. Producing reliable supplies and reaching communities remained major challenges.

In 1967, the World Health Organization intensified a global **eradication** program. Better vaccines and large vaccination campaigns were important, but so was careful **surveillance**. Health workers searched for cases, arranged to **isolate** infected people and vaccinated their contacts. This targeted approach helped stop each **outbreak** from spreading further.

The work depended on local knowledge, international cooperation and health workers reaching people who were difficult to find. A scientific discovery could not protect everyone unless it became a practical public health effort.

The last naturally acquired case of smallpox occurred in Somalia in 1977. A later laboratory-associated case showed why that wording mattered. On May 8, 1980, the World Health Assembly declared smallpox eradicated worldwide.

The achievement took almost two centuries after Jenner's experiment. It belonged to generations of researchers, health workers and communities whose combined efforts had broken the chain of natural transmission.''',
[
v('scar', 'A mark left on the skin after an injury or disease has healed.', 'A small scar remained after the wound healed.', 'Noun', form='scars', plural='scars'),
v('variolation', 'A historical practice of exposing a person to smallpox material in an attempt to produce protection.', 'Variolation carried a risk of causing and spreading smallpox.', 'Uncountable noun'),
v('cowpox', 'An infectious disease that affects cattle and some other animals and can also infect humans.', 'Jenner studied the connection between cowpox and protection from smallpox.', 'Uncountable noun'),
v('vaccination', 'The administration of a vaccine to help the body develop protection against a disease.', 'Vaccination helped control the outbreak.', 'Noun', form='Vaccination', plural='vaccinations'),
v('immunity', 'The body’s ability to resist a particular infection or disease.', 'The study examined how long immunity lasted.', 'Uncountable noun'),
v('eradication', 'The complete ending of a disease’s natural occurrence worldwide.', 'The campaign aimed at the eradication of the disease.', 'Uncountable noun'),
v('surveillance', 'The systematic collection and checking of information to monitor events or detect problems.', 'Disease surveillance helped health workers identify new cases.', 'Uncountable noun'),
v('isolate', 'To keep someone or something separate from others, especially to prevent infection from spreading.', 'The clinic could isolate infected patients safely.', 'Verb', verb=('isolate','isolated','isolated',False)),
v('outbreak', 'A sudden increase in cases of a disease in a particular place or group.', 'The outbreak affected several neighboring towns.', 'Noun', plural='outbreaks')
],
[
m('What was a major danger of variolation?', ['It could never produce protection of any kind.', 'It could cause deadly smallpox and spread the disease.', 'It required no contact with smallpox material.'], 'B', 'It could provide protection, but it could also cause deadly illness and spread the disease.', 'The earlier practice offered some protection while carrying serious risks.'),
m('What helped the global campaign stop outbreaks?', ['Reliable vaccines, case finding, isolation and vaccination of contacts.', 'Only publishing Jenner’s original experiment again.', 'Ending all surveillance as soon as vaccination began.'], 'A', 'Health workers searched for cases, arranged to isolate infected people and vaccinated their contacts.', 'The campaign combined vaccination with active work to find and contain cases.'),
m('Which distinction does the story make about the final cases?', ['Every smallpox case in history occurred after 1980.', 'No smallpox case of any kind occurred after 1977.', 'The last naturally acquired case differed from a later laboratory-associated case.'], 'C', 'The last naturally acquired case of smallpox occurred in Somalia in 1977. A later laboratory-associated case showed why that wording mattered.', 'Naturally acquired specifies the type of case, rather than claiming that no later laboratory infection occurred.'),
g('Jenner tested the cowpox approach in ___.', '1796', 'In 1796, he tested this idea using cowpox material on an eight-year-old boy, James Phipps.', '1796 was the year of the experiment described.'),
g('The last naturally acquired case occurred in ___.', 'Somalia', 'The last naturally acquired case of smallpox occurred in Somalia in 1977.', 'Somalia identifies the country where the final naturally acquired case occurred.'),
g('The World Health Assembly declared eradication in ___.', '1980', 'On May 8, 1980, the World Health Assembly declared smallpox eradicated worldwide.', '1980 was the year of the global declaration.')
],
[
'CDC — Smallpox, variolation, Jenner’s experiment, later vaccinia vaccines, 1967 campaign and final cases: https://www.cdc.gov/smallpox/about/history.html',
'WHO — Global mass vaccination, case finding and vaccination of contacts: https://www.who.int/news-room/feature-stories/detail/smallpox-vaccines',
'WHO — Disease overview and 1980 eradication declaration: https://www.who.int/health-topics/smallpox',
'WHO — Historical vaccination account, including earlier observations and practices: https://www.who.int/news-room/spotlight/history-of-vaccination/history-of-smallpox-vaccination',
'Open University — Jenner’s experiment and the research standards problem: https://www.open.edu/openlearn/mod/oucontent/view.php?id=28151&section=2.7'
],
[
'The broad discovery-to-eradication scope includes the disease burden, earlier variolation, Jenner’s experiment, gradual vaccine development, delivery challenges, global public health strategy and final certification.',
'Jenner is not credited with inventing every form of immunization or being the first person to notice cowpox-associated protection. His experiment involving a child is not endorsed as a modern research method.',
'Variolation uses smallpox material; vaccination is distinct. Later eradication-era vaccines used vaccinia rather than simply weakened smallpox or a claim that all vaccines contained cowpox.',
'1977 is explicitly the last naturally acquired case, not the last case of any kind. The laboratory-associated case occurred in Britain in 1978; global eradication was declared May 8, 1980.',
'Mechanism explanations support the historical narrative. No current vaccination recommendation or procedural instructions are given.'
])

draft(32, 'bhopal-gas-disaster-1984', 'Bhopal 1984: A Gas Disaster and Its Long Aftermath', 'Industrial Disasters',
      'A toxic release from a pesticide factory exposed failures in industrial safety, emergency communication and protection for nearby communities.',
'''In Bhopal, a city in central India, a large factory produced **pesticides** for agriculture. It was operated by Union Carbide India Limited. The plant stored dangerous chemicals close to densely populated neighborhoods, bringing industrial risks into the lives of nearby families.

During the night of December 2 and the early hours of December 3, 1984, water entered a tank containing methyl isocyanate. The resulting chemical **reaction** generated intense heat and pressure. A large quantity of **toxic** gas escaped and spread beyond the factory.

Safety systems that should have prevented or limited the release were inadequate or not working effectively. Residents did not receive a clear warning in time. How the water entered the tank became part of a dispute over responsibility, but the danger extended far beyond that single question.

Many people were asleep when the gas reached their homes. They woke with burning eyes, coughing and difficulty breathing. Families fled through confusion, often without knowing which direction was safe. Hospitals faced a sudden flood of patients, while medical staff lacked enough information about the chemical **exposure**.

Thousands died, and hundreds of thousands were affected. Estimates of the total death toll differ, especially when later deaths are included. Many **survivors** experienced lasting breathing problems and eye injuries. Illness, lost relatives and reduced ability to work placed further pressure on already vulnerable households.

The disaster was followed by a long struggle for treatment, **compensation** and accountability. In 1989, India's Supreme Court approved a settlement of 470 million US dollars. Many survivors argued that the compensation was inadequate. Legal proceedings and disputes over responsibility continued.

Environmental **contamination** around the factory also became a major concern. Questions about waste, water and cleanup joined the continuing struggle over health and **livelihoods**.

Bhopal became a warning about the consequences of weak industrial **safeguards**. Protecting a community required more than storing chemicals inside a factory fence: it also depended on maintenance, honest communication, effective regulation and preparation for an emergency.''',
[
v('pesticide', 'A substance used to control insects, weeds or other organisms that damage crops or property.', 'The farmer followed the rules for storing a pesticide.', 'Noun', form='pesticides', plural='pesticides'),
v('reaction', 'A process in which substances interact and undergo a chemical change.', 'The reaction produced heat inside the container.', 'Noun', plural='reactions'),
v('toxic', 'Poisonous or capable of causing serious harm to living things.', 'The damaged container held a toxic substance.', 'Adjective'),
v('exposure', 'Contact with a substance or condition that may affect health or safety.', 'The study examined exposure to factory fumes.', 'Noun', plural='exposures'),
v('survivor', 'A person who remains alive after a dangerous event.', 'The survivor described the community’s search for support.', 'Noun', form='survivors', plural='survivors'),
v('compensation', 'Money or other support provided for loss, injury or harm.', 'The family applied for compensation after the accident.', 'Uncountable noun'),
v('contamination', 'The presence of a harmful or unwanted substance in something.', 'Tests detected contamination in the soil.', 'Uncountable noun'),
v('livelihood', 'The way a person earns the money or obtains the resources needed to live.', 'The injury threatened the worker’s livelihood.', 'Noun', form='livelihoods', plural='livelihoods'),
v('safeguard', 'A measure intended to prevent harm or protect against a risk.', 'An independent inspection was an important safeguard.', 'Noun', form='safeguards', plural='safeguards')
],
[
m('What sequence produced the gas release?', ['Water entered a chemical tank, causing a reaction that raised heat and pressure.', 'A successful warning emptied every nearby neighborhood before the incident.', 'The factory safely removed all dangerous chemicals before the night began.'], 'A', 'During the night of December 2 and the early hours of December 3, 1984, water entered a tank containing methyl isocyanate. The resulting chemical reaction generated intense heat and pressure. A large quantity of toxic gas escaped and spread beyond the factory.', 'The reaction inside the tank led to a dangerous release beyond the plant.'),
m('Why was the emergency difficult for nearby residents and hospitals?', ['Everyone knew the chemical and a safe escape route immediately.', 'Clear warnings were delayed, and medical staff lacked enough chemical information.', 'Only workers inside the factory could be affected.'], 'B', 'Hospitals faced a sudden flood of patients, while medical staff lacked enough information about the chemical exposure.', 'Poor communication complicated an emergency affecting people beyond the factory.'),
m('What does the aftermath show?', ['The settlement immediately ended every health and legal issue.', 'Only damage to the factory buildings mattered.', 'Health problems, compensation disputes and environmental concerns lasted beyond the release.'], 'C', 'Environmental contamination around the factory also became a major concern. Questions about waste, water and cleanup joined the continuing struggle over health and livelihoods.', 'The consequences extended across health, income, legal responsibility and the environment.'),
g('The factory produced ___ for agriculture.', 'pesticides', 'In Bhopal, a city in central India, a large factory produced pesticides for agriculture.', 'Pesticides identifies the type of product made at the plant.'),
g('The chemical reaction generated heat and ___.', 'pressure', 'The resulting chemical reaction generated intense heat and pressure.', 'Pressure rose inside the tank as the reaction developed.'),
g('The Supreme Court approved a settlement in ___.', '1989', "In 1989, India's Supreme Court approved a settlement of 470 million US dollars.", '1989 was the year of the settlement described.')
],
[
'US Department of Health and Human Services, CHEMM — Factory, release mechanism, safety and warning failures, exposure and hospital response: https://chemm.hhs.gov/practice/case-studies/the-bhopal-methyl-isocyanate-disaster',
'Supreme Court of India, original judgment — 1989 settlement and legal proceedings: https://api.sci.gov.in/jonew/judis/7916.pdf',
'Supreme Court of India, March 14, 2023 — Historical settlement, subsequent litigation and compensation arguments: https://api.sci.gov.in/supremecourt/2010/60172/60172_2010_2_1501_42809_Judgement_14-Mar-2023.pdf',
'Original Indian environmental health cohort research — Respiratory outcomes over 1986–2016: https://pubmed.ncbi.nlm.nih.gov/32750505/',
'International Labour Organization — Industrial safety and environmental consequences: https://www.ilo.org/resource/statement/decent-work-must-be-safe-work',
'Amnesty International, original 2004 investigation with survivor accounts — Compensation, contamination and long aftermath: https://www.amnesty.org/en/wp-content/uploads/2024/03/ASA200152004ENGLISH.pdf'
],
[
'Whole-event overview includes the industrial and neighborhood setting, reaction and gas escape, multiple safety and communication failures, community exposure, hospital response, deaths, long-term illness, livelihoods, compensation and environmental concerns.',
'Water entry and the heat-producing reaction are distinguished from disputed claims about precisely how water entered. No specific worker or alleged saboteur is identified as a proven sole cause.',
'Broad casualty wording avoids combining inconsistent immediate and cumulative death estimates. Long-term respiratory harm is supported by original cohort research.',
'The 1989 civil settlement is not presented as ending every criminal or civil proceeding. Historical environmental concerns are included without asserting the precise cleanup status in 2026.',
'The narrative gives no clinical treatment instructions or current legal advice.'
])

draft(33, 'cuban-missile-crisis-1962', 'The Cuban Missile Crisis: Confrontation and Compromise', 'History',
      'Soviet missiles in Cuba brought a Cold War confrontation close to nuclear conflict before public and secret negotiations produced an agreement.',
'''In the early 1960s, the United States and the Soviet Union competed for power during the Cold War. Both possessed **nuclear weapons**. Cuba, led by Fidel Castro, had become a Soviet ally close to the American mainland.

A US-backed invasion at the Bay of Pigs failed in 1961. Castro feared another attack. In 1962, Soviet leader Nikita Khrushchev secretly agreed to **deploy** nuclear missiles in Cuba. The confrontation had a wider setting: American nuclear missiles were already based in Turkey, within reach of Soviet territory.

On October 14, an American **reconnaissance** aircraft photographed missile sites in Cuba. President John F. Kennedy was briefed two days later. Advisers debated air strikes and invasion, but these options risked a much larger war.

On October 22, Kennedy announced a **naval** quarantine intended to prevent further offensive weapons from reaching Cuba. He also demanded removal of the missiles already there. American ships moved into position, while military preparations increased on both sides.

Public pressure and private **negotiations** developed together. The danger of **escalation** was real. On October 27, a US reconnaissance plane was shot down over Cuba, killing its pilot. Even as the risk grew, messages and secret talks continued.

On October 28, Khrushchev announced agreement to remove the Soviet missiles. The public arrangement included an American **assurance** against invading Cuba. Privately, Washington also agreed to remove its Jupiter missiles from Turkey. Those missiles were withdrawn in the following months.

The agreement did not remove every weapon overnight. Further talks and the Soviet **withdrawal** followed, and the naval quarantine ended on November 20. The immediate confrontation had been resolved through a combination of pressure and **compromise**.

In 1963, the superpowers established a direct link for written messages and agreed to limit certain nuclear tests. These measures sought to reduce danger, although the arms race continued. The crisis revealed how quickly military moves, uncertainty and delayed communication could bring rival states close to catastrophe.''',
[
v('nuclear weapon', 'A weapon that releases enormous energy through reactions involving atomic nuclei.', 'The treaty aimed to limit the spread of nuclear weapons.', 'Noun phrase', form='nuclear weapons', plural='nuclear weapons'),
v('deploy', 'To position military personnel or equipment for use.', 'The command decided to deploy ships near the coast.', 'Verb', verb=('deploy','deployed','deployed',False)),
v('reconnaissance', 'The gathering of information about an area or an opponent, especially for military purposes.', 'The aircraft carried out reconnaissance over the island.', 'Uncountable noun'),
v('naval', 'Connected with a country’s military ships and forces at sea.', 'The exercise involved several naval vessels.', 'Adjective'),
v('negotiation', 'A discussion intended to reach an agreement.', 'The negotiation continued after the public meeting ended.', 'Noun', form='negotiations', plural='negotiations'),
v('escalation', 'An increase in the intensity, seriousness or scale of a conflict or problem.', 'The leaders tried to prevent further escalation.', 'Noun', plural='escalations'),
v('assurance', 'A statement intended to give confidence that something will or will not happen.', 'The agreement included an assurance that civilians would be protected.', 'Noun', plural='assurances'),
v('withdrawal', 'The act of removing military forces or equipment from a place.', 'The withdrawal of troops took several weeks.', 'Noun', plural='withdrawals'),
v('compromise', 'An agreement reached when different sides accept changes to some of their demands.', 'The two governments reached a compromise after long talks.', 'Noun', plural='compromises')
],
[
m('Which background factor helped explain Cuba’s concern?', ['Cuba had no connection with either superpower.', 'Kennedy had already ended the Cold War.', 'A US-backed invasion had failed in 1961, and Castro feared another attack.'], 'C', 'A US-backed invasion at the Bay of Pigs failed in 1961. Castro feared another attack.', 'The earlier invasion was part of the security context behind Cuba’s Soviet alliance.'),
m('What did the October 22 quarantine aim to do?', ['Prevent further offensive weapons from reaching Cuba.', 'Remove every existing missile instantly without negotiations.', 'Stop all communication between the leaders.'], 'A', 'On October 22, Kennedy announced a naval quarantine intended to prevent further offensive weapons from reaching Cuba.', 'The quarantine targeted further deliveries; Kennedy separately demanded removal of existing missiles.'),
m('Which statement best describes the settlement?', ['Only the Soviet Union made concessions of any kind.', 'It combined Soviet withdrawal, an American non-invasion assurance and a private Turkey agreement.', 'It immediately ended all future nuclear competition.'], 'B', 'Privately, Washington also agreed to remove its Jupiter missiles from Turkey. Those missiles were withdrawn in the following months.', 'Public and private arrangements formed part of the compromise, and implementation took time.'),
g('The missile sites were photographed on October ___, 1962.', '14', 'On October 14, an American reconnaissance aircraft photographed missile sites in Cuba.', '14 identifies the day of the reconnaissance photographs.'),
g('The private agreement concerned American missiles in ___.', 'Turkey', 'Privately, Washington also agreed to remove its Jupiter missiles from Turkey.', 'Turkey was the location of the American missiles in the private arrangement.'),
g('The naval quarantine ended on November ___.', '20', 'Further talks and the Soviet withdrawal followed, and the naval quarantine ended on November 20.', '20 identifies the date when the quarantine ended.')
],
[
'US Department of State, Office of the Historian — Cold War setting, Bay of Pigs, deployment, quarantine, negotiations and implementation: https://history.state.gov/milestones/1961-1968/cuban-missile-crisis',
'JFK Library, original October 16 meeting transcript — Kennedy briefed October 16 after October 14 photographs: https://microsites.jfklibrary.org/cmc/oct16/doc2.html',
'JFK Library, original October 22 address — Quarantine and public demands: https://www.jfklibrary.org/learn/about-jfk/historic-speeches/address-during-the-cuban-missile-crisis',
'JFK Library, October 27 records — Aircraft shootdown, military pressure and secret diplomacy: https://microsites.jfklibrary.org/cmc/oct27/',
'Khrushchev’s confidential October 28 letter — Private Turkey understanding and implementation period: https://history.state.gov/historicaldocuments/frus1961-63v06/d70',
'JFK Library — Public settlement, continuing arms race and written teletype hotline: https://www.jfklibrary.org/learn/about-jfk/jfk-in-history/cuban-missile-crisis'
],
[
'Full crisis overview includes competing powers, Cuban security fears, missiles in Cuba and Turkey, reconnaissance, policy options, quarantine, escalation, public and private negotiations, implementation and aftermath.',
'October 14 photographs and October 16 briefing are distinguished. October 28 is an agreement, not instant completion of missile removal.',
'The private American concession concerning Turkey is included; the outcome is not framed as an unconditional surrender by only one side.',
'No claim is made that UN ground inspectors supervised the actual withdrawal. The hotline is described as a written-message link rather than a red telephone.',
'The 1963 test limitation is stated without the incorrect July 25 signing date found in one overview. The narrative does not imply that the arms race ended.'
])

draft(34, 'human-genome-project', 'The Human Genome Project: Reading DNA Together', 'Science',
      'An international effort produced a shared human DNA reference, transformed research and raised questions about the use of genetic information.',
'''Human DNA carries biological information passed from one generation to the next. Its billions of chemical letters influence how bodies develop and function. Reading their order could help researchers investigate disease, but the scale of the task was enormous.

In 1990, the Human Genome Project began an international effort to **sequence** the human **genome**. Research centers across six countries shared the work. The project brought together biologists, engineers and computer specialists rather than depending on one laboratory or one discovery.

Scientists read sections of DNA and used overlapping information to assemble longer stretches. Better machines and computer methods made the process faster and more accurate. The international **consortium** also developed tools and studied other organisms to help make human DNA easier to understand.

A major decision concerned access. Researchers released sequence information rapidly into public **databases**. The Bermuda Principles, agreed in 1996, helped establish this practice. Scientists elsewhere could use the information without waiting for the entire project to finish.

A working draft was announced in June 2000, and its first analysis was published in 2001. A separate private effort by Celera also produced a human genome sequence. Public attention grew as the possibility of reading human DNA became a visible scientific achievement.

On April 14, 2003, the international project announced completion. Its **reference sequence** covered about 92 percent of the whole genome, with difficult gaps remaining. It combined DNA from several anonymous **donors**. It was a shared research guide, not a claim that every person's DNA was identical.

The resource helped scientists investigate genes, compare genetic differences and study disease. However, reading DNA did not immediately explain every biological process or produce a cure for every illness.

The project also studied **privacy**, informed **consent** and the danger of genetic **discrimination**. Information that could support medicine could also be misused. Its lasting contribution included both a foundation for further discoveries and a model of international cooperation and open scientific data.''',
[
v('sequence', 'To determine the order of the chemical units in DNA or another biological molecule.', 'The laboratory developed a faster method to sequence DNA.', 'Verb', verb=('sequence','sequenced','sequenced',False)),
v('genome', 'The complete set of genetic material in an organism or cell.', 'Researchers compared the genome with an existing reference.', 'Noun', plural='genomes'),
v('consortium', 'A group of organizations working together on a shared project.', 'The consortium included universities from several countries.', 'Noun', plural='consortia'),
v('database', 'An organized collection of information that can be stored, searched and updated.', 'The results were added to a public database.', 'Noun', form='databases', plural='databases'),
v('reference sequence', 'An established DNA sequence used as a guide for comparison and analysis.', 'The team compared a sample with the reference sequence.', 'Noun phrase', plural='reference sequences'),
v('donor', 'A person who provides material, money or other resources for someone else’s use.', 'The donor agreed to provide a sample for research.', 'Noun', form='donors', plural='donors'),
v('privacy', 'Control over access to personal information and freedom from unwanted intrusion.', 'The study used strict rules to protect privacy.', 'Uncountable noun'),
v('consent', 'Permission or agreement given for something to happen.', 'Participants gave informed consent before joining the study.', 'Uncountable noun'),
v('discrimination', 'Unfair treatment of people because of a personal characteristic or group membership.', 'The policy prohibited discrimination in employment.', 'Uncountable noun')
],
[
m('How was the project organized?', ['One person read all the DNA without any outside help.', 'Research centers shared a large task across countries and disciplines.', 'It involved only announcing a discovery that was already complete in 1990.'], 'B', 'Research centers across six countries shared the work.', 'The project depended on international teams and different kinds of expertise.'),
m('What did completion in 2003 mean?', ['Every remaining DNA gap had been filled.', 'The project had proved that all people have identical DNA.', 'A highly useful reference covered most of the genome, while difficult gaps remained.'], 'C', 'Its reference sequence covered about 92 percent of the whole genome, with difficult gaps remaining.', 'Completion described the project’s achievement with the technology then available, rather than a perfectly gap-free genome.'),
m('Which wider issue did the project address?', ['How genetic information could help medicine while also creating privacy and discrimination risks.', 'How to prevent every scientist from accessing its data.', 'How to guarantee a cure for every illness immediately.'], 'A', 'The project also studied privacy, informed consent and the danger of genetic discrimination.', 'The project considered the responsible use of genetic information alongside scientific progress.'),
g('The Human Genome Project began in ___.', '1990', 'In 1990, the Human Genome Project began an international effort to sequence the human genome.', '1990 identifies the beginning of the international project.'),
g('The first working draft was announced in June ___.', '2000', 'A working draft was announced in June 2000, and its first analysis was published in 2001.', '2000 was the year of the draft announcement; publication followed in 2001.'),
g('The reference combined DNA from several anonymous ___.', 'donors', 'It combined DNA from several anonymous donors.', 'Donors provided the material used to build the reference.')
],
[
'National Human Genome Research Institute — Project scope, countries, donor origins, gaps, Bermuda Principles and ethical issues: https://www.genome.gov/about-genomics/educational-resources/fact-sheets/human-genome-project',
'Original April 14, 2003 consortium announcement — Completion, methods, open data, model organisms and limitations: https://www.genome.gov/11006929/2003-release-international-consortium-completes-hgp',
'Original 2001 announcement — Draft publication and separate Celera effort: https://www.genome.gov/10002192/2001-release-first-analysis-of-human-genome',
'Original international consortium research paper — Sequencing and analysis: https://www.genome.gov/Pages/Newsroom/Webcasts/2010ScienceReportersWorkshop/Panel1_InitalSequencing_and_Analysis_%20of_the_Human_Genome.pdf'
],
[
'Overview covers the biological background, 1990 launch, collaborative methods, tools and other organisms, public data, draft and private effort, 2003 result, medical value, limitations and ethical consequences.',
'The sequence covered about 92 percent of the whole genome in 2003. The separate figure of about 99 percent refers to gene-containing regions and is not substituted for whole-genome coverage.',
'The reference combined multiple donors and is not described as one universal person’s genome or every person having identical DNA.',
'Reading sequence is distinguished from understanding all biological function or curing every illness. Later gap-filling projects are not merged into the 1990–2003 project.',
'The explanation concerns the history of research and does not provide personal genetic or medical guidance.'
])

draft(35, 'chile-miners-rescue-2010', 'Chile 2010: The Rescue of 33 Trapped Miners', 'Rescue Stories',
      'A mine collapse led to weeks of survival underground and a rescue combining drilling, medical planning and international cooperation.',
'''On August 5, 2010, a **collapse** at the San José copper and gold mine in northern Chile cut off the normal way out. Thirty-three men were trapped roughly 700 meters beneath the Atacama Desert. Above them lay a huge barrier of rock.

The miners gathered in an underground **shelter** and shared their limited supplies. They had to **ration** food while facing heat, uncertainty and isolation. On the surface, families waited as rescue teams drilled narrow holes into the mountain, unsure whether anyone had survived.

On August 22, after 17 days without contact, a drill reached the trapped men. A message brought back to the surface confirmed that all 33 were alive. The discovery changed the operation from a search for survivors into a long effort to bring them home.

The first **boreholes** were too narrow for a person. They allowed supplies and communication to pass between the mine and the surface. Food, water, medical advice and contact with families helped support the men while engineers worked on a larger escape route.

Chile led the operation with assistance from specialists abroad. Teams pursued several drilling plans because no single route was certain to succeed. Supporting life underground and creating a safe rescue **shaft** had to happen together.

Medical teams planned nutrition and psychological support for people living in a **confined** space. NASA shared advice from its experience with isolation and difficult environments. Chilean engineers and builders developed a narrow rescue **capsule**, called Fénix, with international technical input.

Once a suitable passage was ready, rescuers went down to help prepare the men. On October 13, a cable system **hoisted** the miners to the surface one at a time. All 33 emerged alive after 69 days underground, reuniting with families as the world watched.

The operation succeeded through the miners' endurance and careful **coordination** above and below ground. The celebration also drew attention to the dangers of mining. A remarkable rescue showed what cooperation could achieve, while the collapse remained a reminder of the need to protect workers before an emergency.''',
[
v('collapse', 'A sudden falling down or inward of a structure or mass of material.', 'The collapse blocked the tunnel entrance.', 'Noun', plural='collapses'),
v('shelter', 'A place that provides protection from danger or difficult conditions.', 'The workers gathered in an emergency shelter.', 'Noun', plural='shelters'),
v('ration', 'To limit and carefully control the amount of something that each person can use.', 'The group had to ration its remaining food.', 'Verb', verb=('ration','rationed','rationed',False)),
v('borehole', 'A narrow hole drilled into the ground to explore, obtain resources or provide access.', 'The borehole allowed equipment to reach the underground chamber.', 'Noun', form='boreholes', plural='boreholes'),
v('shaft', 'A long narrow passage, often vertical, used for access in a mine or building.', 'The rescue team inspected the shaft before lowering equipment.', 'Noun', plural='shafts'),
v('confined', 'Limited in space or kept within a small area.', 'The team trained for working in a confined space.', 'Adjective'),
v('capsule', 'A small enclosed compartment designed to carry or protect a person or equipment.', 'The capsule carried one person at a time.', 'Noun', plural='capsules'),
v('hoist', 'To lift something heavy using ropes, cables or lifting equipment.', 'The crew used a cable to hoist the platform.', 'Verb', form='hoisted', verb=('hoist','hoisted','hoisted',False)),
v('coordination', 'The organization of different people or activities so that they work effectively together.', 'Good coordination kept the rescue teams informed.', 'Uncountable noun')
],
[
m('What changed on August 22?', ['All miners immediately reached the surface through the first hole.', 'The original collapse happened for the first time.', 'Contact confirmed that all 33 men had survived.'], 'C', 'On August 22, after 17 days without contact, a drill reached the trapped men. A message brought back to the surface confirmed that all 33 were alive.', 'Confirmation that the men were alive allowed the operation to focus on supporting and extracting them.'),
m('Why did rescue work continue after contact was established?', ['The first boreholes allowed supplies through but were too narrow for a person.', 'The miners had already returned home and no longer needed help.', 'Communication was impossible through every drilled opening.'], 'A', 'The first boreholes were too narrow for a person. They allowed supplies and communication to pass between the mine and the surface.', 'Teams needed to maintain support while creating a passage wide enough for extraction.'),
m('How were the miners finally brought out?', ['They walked out through the original entrance without assistance.', 'A capsule and cable system lifted them through a prepared passage one at a time.', 'NASA flew a spacecraft directly into the mine.'], 'B', 'On October 13, a cable system hoisted the miners to the surface one at a time.', 'The rescue combined a drilled passage, a narrow capsule and controlled lifting.'),
g('The collapse happened on August 5, ___.', '2010', 'On August 5, 2010, a collapse at the San José copper and gold mine in northern Chile cut off the normal way out.', '2010 identifies the year of the collapse and rescue.'),
g('The first boreholes were too ___ for a person.', 'narrow', 'The first boreholes were too narrow for a person.', 'Narrow explains why a larger passage was needed for the rescue capsule.'),
g('The miners emerged after ___ days underground.', '69', 'All 33 emerged alive after 69 days underground, reuniting with families as the world watched.', '69 is the duration of the ordeal described in the story.')
],
[
'NASA — Historical overview, depth, contact after 17 days, international advice and rescue after 69 days: https://www.nasa.gov/history/history-publications-and-resources/oral-histories/chilean-miners-rescue/',
'NASA rescue team leader, contemporary presentation — Rescue date, medical planning and engineering contribution: https://scicolloq.gsfc.nasa.gov/Duncan.html',
'NASA physician Michael Duncan, firsthand oral history — Contact, supply boreholes, parallel drilling plans and Chilean capsule authorship: https://www.nasa.gov/wp-content/uploads/2024/11/duncanjm-8-3-11.pdf',
'NASA engineer Clinton Cragg, firsthand oral history — Technical advice, capsule requirements and coordination: https://www.nasa.gov/wp-content/uploads/2024/11/craggch-6-23-11.pdf',
'Chilean government heritage publication — Collapse, message, rescue capsule and chronology: https://cdn.digital.gob.cl/filer_public/17/a6/17a695a5-a1c3-4ea5-8d7c-9a8115d0027c/legado_bicentenario.pdf',
'Smithsonian National Museum of Natural History capsule exhibition — Fénix design, drilling and extraction: https://www.smithsonianmag.com/innovation/the-capsule-that-saved-the-chilean-miners-5620851/'
],
[
'Whole operation is covered: collapse, survival with limited resources, exploratory drilling, contact, sustained support, parallel rescue plans, medical and psychological preparation, Chilean-led engineering, extraction and worker-safety significance.',
'Seventeen days without contact is not described as seventeen days with absolutely no food or water. No invented ration quantities or private conversations are included.',
'The men are called miners in Chile rather than all Chilean nationals. The depth is approximate because measurements differ between accounts.',
'NASA’s advisory role is distinguished from Chilean leadership and capsule design/build. All 33 were rescued on October 13 after 69 days, without claiming that all physical or psychological consequences ended immediately.',
'The closing safety point does not invent a specific legal reform or assert current mining conditions.'
])
