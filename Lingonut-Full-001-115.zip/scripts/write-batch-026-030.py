"""Source-reviewed original overviews for English Unicorn 026–030."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(26, 'otto-warmbier-north-korea', 'Otto Warmbier: Detention in North Korea and Its Aftermath', 'World Events',
      'An American student’s arrest, prolonged detention, medical return and death became a major case between two countries.',
'''In late December 2015, Otto Warmbier, an American university student, traveled to North Korea on a **guided tour**. The country tightly controlled foreign visitors, and its relations with the United States were already strained. A short holiday soon became a prolonged international case.

On January 2, 2016, North Korean officials **detained** Warmbier at the airport as he prepared to leave. They accused him of trying to remove a political poster from his hotel. That was the authorities' **accusation**, rather than an independently established fact about what happened that night.

After a one-day trial in March, a North Korean court sentenced him to 15 years of **hard labor**. His family and American officials sought his return. Limited access to him made it difficult to establish what was happening during his imprisonment.

Following **diplomatic** efforts, American officials secured his **release** in June 2017. He arrived in Cincinnati on June 13 after more than 17 months in North Korean custody. He was alive but **unresponsive**, unable to communicate with his family.

Doctors found severe **brain damage** associated with a loss of oxygen and blood supply. The precise event that caused this injury remained unclear. Warmbier died on June 19, aged 22, only six days after returning to the United States.

His parents demanded accountability and later brought a lawsuit. In 2018, a US civil court held North Korea **liable** for torture, hostage-taking and his death. North Korea did not defend the case, and the judgment did not resolve every medical question.

The case also intensified concern about the treatment of foreign prisoners. From September 1, 2017, the United States introduced passport **restrictions** on travel to North Korea, with special permission required.

For Warmbier's family and university community, the public dispute was also a personal loss. His story connected tourism, detention, diplomacy and human rights, while leaving important questions about his time in custody unanswered.''',
[
v('guided tour', 'An organized visit led by someone who shows visitors around.', 'The students joined a guided tour of the museum.', 'Noun phrase', plural='guided tours'),
v('detain', 'To keep someone in official custody and prevent them from leaving.', 'Police may detain a suspect while checking the facts.', 'Verb', form='detained', verb=('detain','detained','detained',False)),
v('accusation', 'A statement claiming that someone has done something wrong.', 'The lawyer asked for evidence supporting the accusation.', 'Noun', plural='accusations'),
v('hard labor', 'Physically demanding work imposed as a punishment.', 'The court sentenced the prisoner to hard labor.', 'Uncountable noun phrase'),
v('diplomatic', 'Connected with official relations or negotiations between countries.', 'Diplomatic talks continued for several weeks.', 'Adjective'),
v('release', 'To allow someone to leave imprisonment or official custody.', 'The agreement required both sides to release prisoners.', 'Verb', verb=('release','released','released',False)),
v('unresponsive', 'Not reacting to speech, touch or other attempts to communicate.', 'The medical team treated an unresponsive patient.', 'Adjective'),
v('brain damage', 'Injury that harms the brain and affects how it works.', 'A lack of oxygen can cause brain damage.', 'Uncountable noun phrase'),
v('liable', 'Legally responsible for harm or an obligation.', 'The court found the company liable for the damage.', 'Adjective', note='Often followed by “for”: liable for the harm.'),
v('restriction', 'An official rule that limits an activity or a freedom.', 'The restriction required visitors to obtain permission.', 'Noun', form='restrictions', plural='restrictions')
],
[
m('What does the story establish about the poster?', ['Independent investigators proved that Warmbier stole it.', 'The poster was found in his luggage after his return.', 'North Korean authorities accused him of trying to remove it.'], 'C', "They accused him of trying to remove a political poster from his hotel. That was the authorities' accusation, rather than an independently established fact about what happened that night.", 'The narrative distinguishes the official accusation from a proven account of the incident.'),
m('What happened when Warmbier returned home?', ['He was unresponsive and died six days later.', 'He immediately explained every detail of his imprisonment.', 'He returned without a serious medical condition.'], 'A', 'Warmbier died on June 19, aged 22, only six days after returning to the United States.', 'He returned with severe brain damage and could not communicate with his family.'),
m('Which statement describes the aftermath accurately?', ['No family lawsuit or travel restrictions followed.', 'A US court held North Korea liable, while medical questions remained.', 'The court judgment explained the exact cause of the original brain injury.'], 'B', 'North Korea did not defend the case, and the judgment did not resolve every medical question.', 'The legal finding and uncertainty over the precise medical sequence are separate issues.'),
g('Warmbier was detained at the ___ as he prepared to leave.', 'airport', 'On January 2, 2016, North Korean officials detained Warmbier at the airport as he prepared to leave.', 'Airport identifies the place where officials prevented him from leaving.'),
g('The sentence was 15 years of hard ___.', 'labor', 'After a one-day trial in March, a North Korean court sentenced him to 15 years of hard labor.', 'Labor completes the phrase describing the imposed punishment.'),
g('He arrived in Cincinnati on ___ 13, 2017.', 'June', 'He arrived in Cincinnati on June 13 after more than 17 months in North Korean custody.', 'June was the month of his medical return.')
],
[
'University of Virginia — Arrest, allegation, one-day trial, university community and death: https://archive.news.virginia.edu/content/university-mourns-death-student-otto-warmbier/',
'US Senate resolution, agreed June 18, 2020 — Guided tour, exact dates, detention, return and legal aftermath: https://www.govinfo.gov/content/pkg/BILLS-116sres623ats/html/BILLS-116sres623ats.htm',
'Hamilton County Coroner, original report reproduced by WLWT — Anoxic/ischemic brain injury with an unknown initiating event: https://htv-prod-media.s3.amazonaws.com/files/coroner-report-otto-warmbier-1506537558.pdf',
'US District Court, December 24, 2018 — Original civil default judgment, legal findings and diplomatic context: https://www.govinfo.gov/content/pkg/USCOURTS-dcd-1_18-cv-00977/pdf/USCOURTS-dcd-1_18-cv-00977-0.pdf',
'Readable reproduction of the original judicial opinion: https://law.justia.com/cases/federal/district-courts/district-of-columbia/dcdce/1%3A2018cv00977/195966/25/',
'Federal Register — Historical passport restriction effective September 1, 2017: https://www.federalregister.gov/documents/2017/08/02/2017-16287/united-states-passports-invalid-for-travel-to-in-or-through-the-democratic-peoples-republic-of-korea'
],
[
'Whole-case overview covers tourism and political context, arrest and allegation, trial, prolonged detention, diplomatic release, medical condition, death, family litigation and policy consequences.',
'Poster removal is explicitly an accusation, not a proven theft. No invented prison scenes or unsupported physical-injury claims are included.',
'Medical cause is separated from legal responsibility: the coroner identified oxygen/blood-supply-related brain injury but not the initiating event. The 2018 default judgment found North Korea liable; it did not establish every medical detail.',
'The passport rule is dated historically and does not purport to give current travel advice. No current diplomatic status is asserted.'
])

draft(27, 'japan-earthquake-tsunami-2011', 'Japan 2011: Earthquake, Tsunami and Recovery', 'Natural Disasters',
      'A huge offshore earthquake sent waves across northeastern Japan, devastating coastal communities and triggering a nuclear accident.',
'''Japan lies where large sections of the Earth's outer layer meet. Their movement makes earthquakes a familiar danger. Buildings, warning systems and practice drills offered protection, but the disaster of March 11, 2011, exceeded many expectations.

At 2:46 in the afternoon, a magnitude 9 earthquake struck beneath the Pacific Ocean off northeastern Japan. A sudden movement of the **seabed** pushed a huge amount of water out of place. A series of **tsunami** waves spread outward, with devastating effects along the Tohoku coast.

Warnings were issued, and many people escaped to **higher ground**. However, some waves rose above sea walls and rushed far **inland**. They swept away houses, vehicles and entire neighborhoods. Roads and railways were broken, while electricity and water supplies failed across large areas.

Thousands died, and thousands more were reported missing. Hundreds of thousands of people had to leave their homes. **Survivors** faced cold weather, lost relatives and urgent shortages of basic supplies. Emergency workers, volunteers and teams from abroad helped with rescue and relief.

At the Fukushima Daiichi nuclear power station, operating reactors shut down when the earthquake struck. Tsunami flooding then disabled power and **cooling systems**. Fuel in three reactor cores overheated and melted. **Radioactive** material escaped, and nearby communities were evacuated. This added a long nuclear emergency to the destruction along the coast.

The damage also interrupted factories and transport, affecting **supply chains** beyond Japan. Rebuilding meant restoring homes, ports, roads and local businesses. For displaced communities, recovery involved more than replacing buildings: families had to rebuild livelihoods and social connections.

The disaster led to improvements in tsunami warnings, evacuation planning and nuclear safety. It also exposed the limits of relying on a single protective wall or an earlier estimate of danger.

The earthquake, tsunami and nuclear accident were connected parts of one national emergency. Their consequences continued through years of **reconstruction**, environmental work and efforts to preserve the memory of communities that had been lost.''',
[
v('seabed', 'The ground at the bottom of a sea or ocean.', 'The survey mapped a valley on the seabed.', 'Noun', plural='seabeds'),
v('tsunami', 'A series of large ocean waves caused by a sudden displacement of water, often during an undersea earthquake.', 'The earthquake generated a tsunami that reached the coast.', 'Noun', plural='tsunamis'),
v('higher ground', 'Land above the level of the surrounding area.', 'Residents moved to higher ground before the flood arrived.', 'Uncountable noun phrase'),
v('inland', 'Away from the coast and toward the interior of a country or region.', 'The storm carried heavy rain far inland.', 'Adverb'),
v('survivor', 'A person who remains alive after a dangerous event.', 'The survivor described how the neighbors helped.', 'Noun', form='Survivors', plural='survivors'),
v('cooling system', 'Equipment that removes heat and keeps a machine or process at a safe temperature.', 'Engineers inspected the cooling system before restarting the machine.', 'Noun phrase', form='cooling systems', plural='cooling systems'),
v('radioactive', 'Emitting radiation from unstable atomic nuclei.', 'The team used special equipment to handle radioactive material.', 'Adjective'),
v('supply chain', 'The connected businesses and processes that produce and deliver goods.', 'A damaged port disrupted the supply chain.', 'Noun phrase', form='supply chains', plural='supply chains'),
v('reconstruction', 'The process of building again after serious damage or destruction.', 'Reconstruction included new homes and repaired roads.', 'Uncountable noun')
],
[
m('How did the earthquake generate the tsunami?', ['Movement of the seabed displaced a huge amount of water.', 'A nuclear reactor pushed water across the entire Pacific.', 'Strong winds alone lifted the ocean floor.'], 'A', 'A sudden movement of the seabed pushed a huge amount of water out of place.', 'The movement transferred energy to the water, producing a series of waves.'),
m('Why did the emergency at Fukushima develop?', ['The reactors continued operating normally throughout the disaster.', 'There was no flooding near the power station.', 'Tsunami flooding disabled power and cooling after the reactors shut down.'], 'C', 'Tsunami flooding then disabled power and cooling systems. Fuel in three reactor cores overheated and melted.', 'Shutdown did not remove the need to keep hot reactor fuel cool.'),
m('Which description best represents the wider recovery?', ['Only a single factory needed to be repaired.', 'Homes, infrastructure, livelihoods and community connections had to be rebuilt.', 'All consequences ended as soon as the waves withdrew.'], 'B', 'Rebuilding meant restoring homes, ports, roads and local businesses. For displaced communities, recovery involved more than replacing buildings: families had to rebuild livelihoods and social connections.', 'Recovery affected both physical infrastructure and the lives of displaced communities.'),
g('The earthquake struck on March 11, ___.', '2011', 'Buildings, warning systems and practice drills offered protection, but the disaster of March 11, 2011, exceeded many expectations.', '2011 identifies the year of the disaster.'),
g('Many people escaped to higher ___.', 'ground', 'Warnings were issued, and many people escaped to higher ground.', 'Ground completes the phrase for land above the surrounding area.'),
g('Fuel melted in ___ reactor cores.', 'three', 'Fuel in three reactor cores overheated and melted.', 'Three refers to the reactor cores affected by melting.')
],
[
'US Geological Survey — Earthquake, plate boundary, seabed displacement and tsunami; magnitude revised from 9.0 to 9.1: https://www.usgs.gov/centers/pcmsc/news/japan-lashed-powerful-earthquake-devastating-tsunami',
'Japan Reconstruction Agency — Overall destruction, casualties, evacuation and infrastructure: https://www.reconstruction.go.jp/english/topics/GEJE/',
'Japan Meteorological Agency — Exact local date, time and Japanese magnitude estimate: https://www.jma.go.jp/jma/en/2011_Earthquake/2011_Earthquake.html',
'Japan Meteorological Agency — Warning limitations and improvements introduced in 2013: https://www.data.jma.go.jp/svd/eqev/data/en/tsunami/LessonsLearned_Improvements_brochure.pdf',
'OECD Nuclear Energy Agency — Shutdown, tsunami power/cooling loss, three core melts, releases and recovery: https://oecd-nea.org/jcms/pl_27411/fukushima-daiichi-nuclear-accident',
'World Bank and Japan disaster research — Preparedness, communities, global supply chains and reconstruction: https://www.worldbank.org/en/news/feature/2021/03/11/learning-from-megadisasters-a-decade-of-lessons-from-the-great-east-japan-earthquake-drmhubtokyo'
],
[
'Earthquake and coastal tsunami destruction are the main story. One paragraph explains Fukushima as a connected consequence; it does not replace the event-wide overview.',
'Magnitude 9 avoids false precision between JMA 9.0 and the USGS revised 9.1 estimate. The time is local Japan time.',
'Broad casualty wording avoids combining changing counts or direct and disaster-related deaths. No unsupported exact death toll or wave height is asserted.',
'Reactor shutdown preceded tsunami flooding. Core melting and radioactive releases are described without suggesting a nuclear-bomb explosion.',
'The final sections include relief, disrupted supply chains, livelihoods, reconstruction and subsequent preparedness improvements.'
])

draft(28, 'global-financial-crisis', 'The Global Financial Crisis: Housing, Banks and the World Economy', 'Economics',
      'Risky housing loans and weaknesses across an interconnected financial system turned into a worldwide economic emergency.',
'''During the early 2000s, house prices rose rapidly in the United States. Many buyers expected prices to keep climbing. Lenders expanded the supply of **mortgages**, including loans to people who might struggle to repay them. The housing boom created profits and encouraged more borrowing.

These loans did not stay with the original lenders. Banks bundled them into financial products and sold them to **investors** around the world. Some products received high safety ratings, even though their value depended on risky loans. The risks became harder to see as the products passed through a complex financial system.

Many financial institutions also borrowed heavily to increase their investments. This left them with a limited cushion against losses. Weak risk controls and gaps in **oversight** allowed problems to grow across an increasingly connected system.

When American house prices fell, more borrowers missed payments. **Foreclosures** increased, and investments linked to mortgages lost value. During 2007, financial institutions began reporting serious trouble. Banks became uncertain about one another's losses and less willing to lend.

The emergency intensified in September 2008. Lehman Brothers filed for **bankruptcy** on September 15, while other major firms needed rescue. **Confidence** collapsed, and funding became difficult to obtain. A housing problem had spread into a broad crisis of credit and trust.

The damage reached far beyond banks. Businesses struggled to borrow, consumers reduced spending, and international trade fell sharply. Companies cut jobs and investment. Millions of people faced unemployment, lost savings or the loss of their homes as the world economy entered a severe **downturn**.

Governments supported banks and introduced spending measures to protect economic activity. Central banks supplied emergency funds, lowered **interest rates** and bought financial assets. These actions helped stabilize the system, but recovery was slow and uneven.

Later reforms sought stronger banks and closer supervision. The crisis left lasting arguments about **bailouts**, responsibility and the costs borne by ordinary households. It showed how weaknesses in lending, investment and regulation could spread across national borders.''',
[
v('mortgage', 'A loan used to buy property, with the property serving as security for repayment.', 'They applied for a mortgage to buy their first home.', 'Noun', form='mortgages', plural='mortgages'),
v('investor', 'A person or organization that puts money into something hoping to earn a return.', 'The investor studied the company’s financial reports.', 'Noun', form='investors', plural='investors'),
v('oversight', 'The work of monitoring an activity to ensure that it is managed properly.', 'The report called for stronger oversight of lenders.', 'Uncountable noun'),
v('foreclosure', 'A legal process in which a lender takes or sells property after the borrower fails to repay a loan.', 'The family sought help to avoid foreclosure.', 'Noun', form='Foreclosures', plural='foreclosures'),
v('bankruptcy', 'A legal process for dealing with debts that a person or business cannot pay.', 'The airline continued operating during bankruptcy proceedings.', 'Noun', plural='bankruptcies'),
v('confidence', 'Trust that someone or something is reliable or likely to succeed.', 'Clear information helped restore public confidence.', 'Uncountable noun'),
v('downturn', 'A period when economic or business activity becomes weaker.', 'The downturn reduced demand for new cars.', 'Noun', plural='downturns'),
v('interest rate', 'The percentage charged for borrowing money or paid on savings over a stated period.', 'A lower interest rate reduced the cost of the loan.', 'Noun phrase', form='interest rates', plural='interest rates'),
v('bailout', 'Financial help intended to prevent a company or institution from failing.', 'The bailout came with conditions on how the bank could operate.', 'Noun', form='bailouts', plural='bailouts')
],
[
m('How did housing-loan risks spread beyond the original lenders?', ['Every loan remained with one local bank.', 'Banks bundled loans into products sold to investors around the world.', 'All risky loans were removed before any products were sold.'], 'B', 'Banks bundled them into financial products and sold them to investors around the world.', 'Selling products linked to the loans spread exposure across institutions and countries.'),
m('Why were financial institutions vulnerable?', ['They had no connection with one another.', 'They could never lose money on their investments.', 'Heavy borrowing, limited cushions and weak oversight amplified losses.'], 'C', 'Many financial institutions also borrowed heavily to increase their investments. This left them with a limited cushion against losses.', 'Borrowing increased exposure while leaving less protection when investments lost value.'),
m('How did the crisis affect the wider economy?', ['Borrowing and spending weakened, trade fell and companies cut jobs.', 'Only housing sellers were affected, with no consequences abroad.', 'All countries recovered immediately without government action.'], 'A', 'Businesses struggled to borrow, consumers reduced spending, and international trade fell sharply. Companies cut jobs and investment.', 'Financial disruption reduced activity and employment beyond the banking sector.'),
g('Lehman Brothers filed for bankruptcy in ___ 2008.', 'September', 'Lehman Brothers filed for bankruptcy on September 15, while other major firms needed rescue.', 'September identifies the month when the emergency intensified.'),
g('Banks became less willing to ___.', 'lend', "Banks became uncertain about one another's losses and less willing to lend.", 'Lend describes providing money that must later be repaid.'),
g('Central banks lowered interest ___.', 'rates', 'Central banks supplied emergency funds, lowered interest rates and bought financial assets.', 'Rates completes the phrase for the cost of borrowing.')
],
[
'Federal Reserve History — Housing expansion, mortgage products, financial losses, recession, response and reforms: https://www.federalreservehistory.org/essays/great-recession-and-its-aftermath',
'Ben Bernanke, testimony to the Financial Crisis Inquiry Commission, September 2, 2010 — Triggers, heavy borrowing, funding vulnerability, risk controls and regulatory gaps: https://www.federalreserve.gov/newsevents/testimony/bernanke20100902a.htm',
'Federal Reserve History — Lehman bankruptcy on September 15, 2008, and support for other institutions: https://www.federalreservehistory.org/essays/support-for-specific-institutions',
'International Monetary Fund, World Economic Outlook April 2009 — Worldwide contraction, trade, employment and policy response: https://www.imf.org/en/publications/weo/issues/2016/12/31/world-economic-outlook-april-2009-crisis-and-recovery-22575'
],
[
'Overview follows housing expansion, risky lending and distribution of risk, institutional borrowing and weak oversight, falling prices, financial panic, global real-economy harm, policy response and uneven recovery.',
'Lehman bankruptcy intensified an existing crisis; it is not presented as the sole cause or the beginning of all financial stress.',
'Responsibility is not assigned only to low-income borrowers. Lenders, investors, institutions and regulation appear in the causal chain.',
'The lesson does not assign the US December 2007–June 2009 recession dates to all countries, and contains no current investment advice or unsupported numerical loss estimates.'
])

draft(29, 'mh370-disappearance', 'MH370: Disappearance, Evidence and the Search for Answers', 'World Events',
      'A passenger flight disappeared in 2014, leaving investigators to reconstruct its route from radar, satellite records and recovered debris.',
'''Shortly after midnight on March 8, 2014, Malaysia Airlines flight MH370 left Kuala Lumpur for Beijing. The Boeing 777 carried 239 passengers and crew. It was expected to follow a routine international route, but it never reached its destination.

Less than an hour after departure, radio contact stopped, and the aircraft's identifying signal disappeared from civilian **radar**. Later analysis of military radar showed that it had turned back across the Malay Peninsula, away from its planned route.

The aircraft also exchanged automatic signals with a **satellite** system for several more hours. These records were not a continuous map of its position. Specialists used the timing and characteristics of the signals to estimate possible paths. Their analysis pointed toward a remote part of the southern Indian Ocean.

Search efforts first focused near the original route before shifting as the evidence developed. Malaysia, Australia, China and other countries took part. Ships mapped enormous areas of the **seabed**, while specialized equipment searched for **wreckage** in deep water. Distance, difficult weather and the size of the possible area made the work exceptionally demanding.

In July 2015, a piece of the right wing was found on Réunion, an island in the western Indian Ocean. Investigators **confirmed** that it came from MH370. Other pieces of **debris** were found later, although not all could be identified with the same certainty. The discoveries supported an ocean crash but did not explain its cause.

Malaysia's 2018 **investigation** could not determine why the flight disappeared. The main wreckage and flight recorders had not been recovered. Claims about a particular person's responsibility went beyond what the investigation established.

Further searches followed. An official update in March 2026 reported no confirmed location for the main wreckage from the latest search operations. The case also prompted international efforts to improve aircraft **tracking**.

For families, the missing information prolonged grief and **uncertainty**. The search was both a technical challenge and an effort to establish what happened to the people on board.''',
[
v('radar', 'A system that uses radio waves to detect objects and help determine their position or movement.', 'Radar showed a storm approaching the airport.', 'Uncountable noun'),
v('satellite', 'An object placed in orbit around the Earth or another body, often used for communication or observation.', 'The satellite transmitted weather images.', 'Noun', plural='satellites'),
v('seabed', 'The ground at the bottom of a sea or ocean.', 'The research vessel mapped the seabed.', 'Noun', plural='seabeds'),
v('wreckage', 'The broken remains of a vehicle, ship, aircraft or other structure.', 'The team photographed the wreckage before moving any pieces.', 'Uncountable noun'),
v('confirm', 'To establish that something is true or correct by checking evidence.', 'The laboratory will confirm the result with another test.', 'Verb', form='confirmed', verb=('confirm','confirmed','confirmed',False)),
v('debris', 'Scattered pieces left after something is damaged or destroyed.', 'Workers cleared debris from the road.', 'Uncountable noun'),
v('investigation', 'A careful examination intended to discover facts or explain an event.', 'The investigation compared records from several sources.', 'Noun', plural='investigations'),
v('tracking', 'The process of following the position or movement of someone or something.', 'Improved tracking helped locate the delivery vehicle.', 'Uncountable noun', note='A noun here, formed from the verb “track”.'),
v('uncertainty', 'A state in which something is unknown, unclear or not certain.', 'The delay created uncertainty for the families.', 'Uncountable noun')
],
[
m('What did the satellite records provide?', ['An uninterrupted video of the entire flight.', 'A confirmed explanation of who changed the aircraft’s route.', 'Data that specialists used to estimate possible flight paths.'], 'C', 'Specialists used the timing and characteristics of the signals to estimate possible paths.', 'The records supported analysis of possible routes, rather than continuous position tracking.'),
m('What did the confirmed wing piece establish?', ['That the flight had landed safely at another airport.', 'That material from MH370 had reached the western Indian Ocean, without explaining the cause.', 'That every later piece of debris belonged to the aircraft.'], 'B', 'The discoveries supported an ocean crash but did not explain its cause.', 'Identifying debris strengthened evidence of a crash but did not settle why it happened.'),
m('Which statement matches the investigation and later search history?', ['The 2018 investigation could not determine the cause, and later searches followed.', 'The 2018 report identified a proven culprit and recovered the recorders.', 'All search work permanently ended immediately after the first radar analysis.'], 'A', "Malaysia's 2018 investigation could not determine why the flight disappeared.", 'The narrative separates confirmed evidence from speculation and describes subsequent search efforts.'),
g('MH370 was traveling from Kuala Lumpur to ___.', 'Beijing', 'Shortly after midnight on March 8, 2014, Malaysia Airlines flight MH370 left Kuala Lumpur for Beijing.', 'Beijing was the intended destination.'),
g('The aircraft carried ___ passengers and crew.', '239', 'The Boeing 777 carried 239 passengers and crew.', '239 is the total number of people on board.'),
g('The right-wing piece was found in July ___.', '2015', 'In July 2015, a piece of the right wing was found on Réunion, an island in the western Indian Ocean.', '2015 was the year of the confirmed wing-piece discovery.')
],
[
'Malaysia Ministry of Transport — Final 2018 safety investigation, timeline, radar, satellite records, debris identification and limits of conclusions: https://www.mot.gov.my/en/MH370%20Investigation%20Report/01-Report/MH370SafetyInvestigationReport.pdf',
'Malaysia Ministry of Transport — Official investigation briefing: https://www.mot.gov.my/en/Laporan%20MH%20370/MH%20370%20Safety%20Investigation%20Report%20Slides.pdf',
'Australian Transport Safety Bureau — Search history, modelling, debris and underwater challenges: https://www.atsb.gov.au/mh370-search-overview',
'Malaysia Ministry of Transport, March 8, 2026 — Dated 2025/2026 search update to families; no confirmed main-wreckage location: https://www.mot.gov.my/en/Kenyataan%20Media/Year%202026/MH370%20Search%20Operation%202025-2026%20-%20Update%20to%20Families.pdf',
'Ocean Infinity, March 8, 2026 — Search results and willingness to return: https://oceaninfinity.com/news/conclusion-of-the-search-for-malaysian-airlines-flight-mh370/',
'International Civil Aviation Organization — Aircraft tracking initiatives following MH370: https://www.icao.int/operational-safety/aircrafttracking'
],
[
'Overview covers the planned flight, disappearance, route reconstruction, international search, confirmed debris, unresolved cause, later efforts, tracking improvements and families.',
'Satellite signal analysis is an inference about possible paths, not continuous GPS tracking. The lesson assigns no proven culprit or motive.',
'The Réunion right-wing flaperon is confirmed; other recovered debris has differing confidence levels. No claim is made that no pieces were ever found.',
'The 2026 search result is explicitly dated to the official March update. Later reporting described a June 2026 contract extension; the narrative does not claim all searches ended permanently or promise future results. Status research checked October 21, 2026.',
'239 includes passengers and crew. Flight recorders and main wreckage are distinct from recovered fragments.'
])

draft(30, 'cultural-revolution-china', 'China’s Cultural Revolution: Power, Upheaval and Lasting Loss', 'History',
      'A political campaign launched by Mao Zedong reshaped daily life, brought widespread persecution and disrupted a generation’s education.',
'''In 1966, Mao Zedong launched the Cultural Revolution in China. He was the Communist Party's chairman, but earlier economic disasters had weakened his position. He opposed policies followed by other leaders and claimed that capitalist thinking threatened the revolution.

The campaign combined an ideological struggle with a fight for political power. Mao encouraged young people to challenge established authorities. Groups calling themselves Red Guards formed in schools and universities, presenting themselves as defenders of his ideas.

Mass rallies and **propaganda** promoted loyalty to Mao. Red Guards attacked what they called old ideas, culture, customs and habits. Books, religious sites and historic objects were destroyed. Teachers, officials and ordinary citizens faced public **humiliation**, beatings and imprisonment. A person's family background or supposed political beliefs could make them a target.

Schools and universities closed during the early **upheaval**, interrupting education. Government offices and workplaces also became sites of struggle. Rival **factions**, each claiming to represent the revolution, fought for control. Violence spread beyond student groups and reached towns and rural communities.

The army took a larger role in rebuilding state control, but **persecution** continued. Millions of young people from cities were sent to the countryside to live and work. Many lost years of formal study and opportunities, while rural families also experienced the campaign's pressures.

The movement continued through changing political struggles for a decade. Mao died in September 1976. The following month, the Gang of Four, including his wife Jiang Qing, was arrested. Their fall marked the end of the Cultural Revolution, but responsibility extended beyond these four leaders.

Later leaders reversed many wrongful **accusations**, restored educational institutions and moved toward economic reform. In 1981, the Communist Party officially condemned the Cultural Revolution and assigned Mao chief responsibility.

The human consequences lasted much longer. Families had lost relatives, **livelihoods** and trust. Cultural treasures could not simply be replaced. The decade left deep **trauma** and difficult questions about political power, personal responsibility and the damage caused when public loyalty became a test of survival.''',
[
v('propaganda', 'Information designed to influence political beliefs or behavior, often by presenting only one side.', 'The archive contains propaganda posters from the campaign.', 'Uncountable noun'),
v('humiliation', 'The experience of being made to feel deeply ashamed or stripped of dignity.', 'The public humiliation caused lasting distress.', 'Uncountable noun'),
v('upheaval', 'A major disruption or sudden change in society or ordinary life.', 'The political upheaval interrupted normal schooling.', 'Noun', plural='upheavals'),
v('faction', 'A group within a larger organization or movement that has its own interests or leadership.', 'A rival faction challenged the committee’s authority.', 'Noun', form='factions', plural='factions'),
v('persecution', 'Cruel or unfair treatment directed at people because of their identity, beliefs or background.', 'The testimony described persecution based on political beliefs.', 'Uncountable noun'),
v('accusation', 'A statement claiming that someone has done something wrong.', 'The records showed that the accusation had no reliable support.', 'Noun', form='accusations', plural='accusations'),
v('livelihood', 'The way a person earns the money or obtains the resources needed to live.', 'The closure threatened the family’s livelihood.', 'Noun', form='livelihoods', plural='livelihoods'),
v('trauma', 'Lasting emotional harm caused by deeply distressing or disturbing experiences.', 'Survivors spoke about the trauma of losing their homes.', 'Noun', plural='traumas', note='Usually uncountable when referring to emotional harm in general.')
],
[
m('What was the campaign’s political background?', ['It combined Mao’s ideological claims with a struggle against other leaders.', 'It began after Mao had permanently retired from public life.', 'It was only a campaign to build more museums.'], 'A', 'The campaign combined an ideological struggle with a fight for political power.', 'The movement concerned both ideas and control within the political system.'),
m('What happened as the campaign spread?', ['Normal education continued everywhere without interruption.', 'Only four national leaders were affected.', 'Persecution, rival factions and violence disrupted schools, institutions and communities.'], 'C', 'Government offices and workplaces also became sites of struggle. Rival factions, each claiming to represent the revolution, fought for control.', 'The upheaval expanded beyond its early student groups into wider society.'),
m('Which statement describes the aftermath?', ['Every loss was repaired immediately in October 1976.', 'Wrongful accusations were reversed, but personal and cultural damage lasted.', 'The Communist Party officially praised the entire campaign in 1981.'], 'B', 'Later leaders reversed many wrongful accusations, restored educational institutions and moved toward economic reform.', 'Institutional changes followed the campaign, while families continued to experience its consequences.'),
g('Mao launched the Cultural Revolution in ___.', '1966', 'In 1966, Mao Zedong launched the Cultural Revolution in China.', '1966 marks the beginning of the decade-long movement.'),
g('Millions of young people were sent from cities to the ___.', 'countryside', 'Millions of young people from cities were sent to the countryside to live and work.', 'Countryside identifies the rural areas where they were sent.'),
g('The Gang of ___ was arrested after Mao’s death.', 'Four', 'The following month, the Gang of Four, including his wife Jiang Qing, was arrested.', 'Four completes the name of the political group arrested in October 1976.')
],
[
'Columbia University, Asia for Educators — Original 1966 Sixteen Points and historical introduction on Mao, ideology and political rivals: https://afe.easia.columbia.edu/main_pop/ps/ps_china-sixteen-points.htm',
'Wilson Center, Swiss diplomatic eyewitness records — Early closures, propaganda, attacks on culture and persecution: https://www.wilsoncenter.org/blog-post/the-swiss-witnesses-to-chinas-cultural-revolution',
'Youqin Wang, original interview research — Attacks on teachers and schools: https://ywang.uchicago.edu/history/docs/2001_03_05.pdf',
'Andrew Walder and Yang Su, original county-annals research, 2003 — Rural violence and later state-led repression: https://www.cambridge.org/core/journals/china-quarterly/article/cultural-revolution-in-the-countryside-scope-timing-and-human-impact/B73551DF800FF32A05C7C898DEEC5CC3',
'Chinese Communist Party, resolution adopted June 27, 1981 — Primary retrospective political account of later phases, Mao’s death, Gang of Four, reversals and official assessment: https://www.marxists.org/subject/china/documents/cpc/history/01.htm',
'IISH / Chinese Posters, primary poster collection — Sent-down youth: https://chineseposters.net/themes/up-to-the-mountains'
],
[
'Whole-decade overview distinguishes background, Mao’s ideological claims and power struggle, Red Guard mobilization, cultural destruction, persecution, factional violence, army intervention, sent-down youth, the 1976 endpoint and lasting consequences.',
'Capitalist influence is presented as Mao’s claim. The account neither adopts political accusations as facts nor blames only four individuals.',
'Army intervention is not presented as an end to persecution. Original rural research documents major later violence after the early mass-rebellion phase.',
'Early school closures are distinguished from the entire decade; no claim is made that every school remained closed for ten years. No precise disputed death toll is asserted.',
'The 1981 resolution is identified as the Party’s retrospective judgment, not a neutral explanation accepted without comparison to eyewitness records and original research.'
])
