"""Source-reviewed, distinct-event overviews for English Unicorn 036–040."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(36, 'amazon-children-survival-2023', 'Amazon 2023: Four Children Survive and Are Found', 'Survival Stories',
      'Four Indigenous siblings survived a plane crash and weeks in Colombia’s rainforest before a joint search operation found them alive.',
'''On May 1, 2023, a small plane crashed in a **remote** part of the Amazon forest in southern Colombia. Three adults, including the children's mother, died. Four Indigenous **siblings** survived: three girls and a boy. The eldest was 13, and the youngest was still an **infant**.

Surviving the crash was only the beginning. The children faced hunger, heavy rain and the challenge of moving through dense forest. Caring for the youngest made an already difficult situation more demanding. There was no easy route to a town or a road.

Relatives credited the children's knowledge of forest foods and the eldest child's care for the others. Skills learned in their community helped them cope with conditions that would have been dangerous for many adults. However, early accounts did not establish every detail of their daily survival.

Meanwhile, a large search developed under the name Operation Hope. Indigenous **trackers** worked with Colombian military teams. They brought knowledge of the landscape and ways of reading small signs, while the military provided helicopters, equipment and other support.

The thick forest **canopy** limited visibility from the air. Searchers moved through difficult ground, looking for **footprints** and other clues. Signs that the children might still be alive encouraged teams to continue, even as the weeks passed.

On June 9, Indigenous searchers found all four children alive within the joint operation. Their ordeal had lasted 40 days. They were **evacuated** to receive care and taken to the Military Hospital in Bogotá.

Finding them began another stage of the story. Medical treatment, nutrition and psychological support helped their **recovery**. Child protection officials worked with family members and Indigenous organizations, emphasizing the children's needs, culture and **privacy**.

The rescue brought relief after a disaster that had also caused deep family loss. It showed the value of learned survival skills, local knowledge and cooperation between different search teams. Returning alive was the start of recovery from an extraordinary ordeal.''',
[
v('remote', 'Far from towns, services or places that are easy to reach.', 'The village was in a remote mountain valley.', 'Adjective'),
v('sibling', 'A brother or sister.', 'Each sibling helped care for the youngest child.', 'Noun', form='siblings', plural='siblings'),
v('infant', 'A very young child or baby.', 'The nurse checked the infant’s health.', 'Noun', plural='infants'),
v('tracker', 'A person who follows signs such as footprints to locate people or animals.', 'The tracker noticed a mark beside the stream.', 'Noun', form='trackers', plural='trackers'),
v('canopy', 'The layer of leaves and branches forming the upper cover of a forest.', 'The forest canopy blocked much of the sunlight.', 'Noun', plural='canopies'),
v('footprint', 'A mark left by a foot on a surface.', 'A footprint in the mud helped the search team.', 'Noun', form='footprints', plural='footprints'),
v('evacuate', 'To move someone away from danger to a safer place.', 'The team used a helicopter to evacuate the injured walker.', 'Verb', form='evacuated', verb=('evacuate','evacuated','evacuated',False)),
v('recovery', 'The process of returning to health or normal functioning after harm or difficulty.', 'Recovery continued after the patient left hospital.', 'Noun', plural='recoveries'),
v('privacy', 'Control over access to personal information and freedom from unwanted intrusion.', 'The family asked visitors to respect their privacy.', 'Uncountable noun')
],
[
m('What helped explain the children’s survival, according to relatives?', ['A complete daily record proved they always had plenty of food.', 'Knowledge learned in their community and care for one another helped.', 'They reached a nearby town immediately after the crash.'], 'B', "Relatives credited the children's knowledge of forest foods and the eldest child's care for the others.", 'The account attributes this explanation to relatives and avoids inventing a detailed daily itinerary.'),
m('How was the search organized?', ['Only aircraft were used, without any searchers on the ground.', 'All local knowledge was excluded from the operation.', 'Indigenous trackers and military teams combined different knowledge and resources.'], 'C', 'Indigenous trackers worked with Colombian military teams.', 'Local tracking skills and military equipment supported the joint effort.'),
m('What followed the discovery?', ['Evacuation, hospital care and attention to recovery and child protection.', 'An immediate end to every physical and emotional consequence.', 'A decision that the children no longer needed any support.'], 'A', "Child protection officials worked with family members and Indigenous organizations, emphasizing the children's needs, culture and privacy.", 'The rescue was followed by medical, psychological and protective support.'),
g('The crash happened on May 1, ___.', '2023', 'On May 1, 2023, a small plane crashed in a remote part of the Amazon forest in southern Colombia.', '2023 identifies the year of the crash and search.'),
g('Searchers found the children on ___ 9.', 'June', 'On June 9, Indigenous searchers found all four children alive within the joint operation.', 'June was the month of their discovery.'),
g('The ordeal lasted ___ days.', '40', 'Their ordeal had lasted 40 days.', '40 is the duration used in official accounts of the ordeal.')
],
[
'Colombia Interior Ministry, May 25, 2023 — Crash date, ages, adult deaths and Indigenous participation: https://www.mininterior.gov.co/noticias/gobierno-nacional-intensifica-esfuerzos-en-la-busqueda-de-los-ninos-indigenas-desaparecidos-tras-accidente-aereo/',
'Colombian armed forces — Joint Operation Hope, June 9 discovery and 40-day ordeal: https://www.cgfm.mil.co/es/multimedia/noticias/fuerzas-militares-lanzan-su-libro-operacion-esperanza-ejemplar-que-narra-la',
'Colombian armed forces, contemporary footprint report — Search clues: https://www.cgfm.mil.co/es/multimedia/noticias/fuerzas-militares-e-indigenas-localizan-nueva-huella-en-la-zona-de-busqueda-de',
'Colombian Presidency, June 13, 2023 — Indigenous discovery within joint operation and medical/psychological care: https://petro.presidencia.gov.co/prensa/Paginas/ICBF-garantizara-el-mejor-entorno-y-la-recuperacion-integral-a-ninos-que-po-230613.aspx',
'ICBF, June 11, 2023 — Hospital care, family and Indigenous coordination, cultural support and privacy: https://www.icbf.gov.co/noticias/icbf-acompana-el-proceso-de-atencion-los-ninos-rescatados-de-la-selva',
'National Indigenous Organization of Colombia, original June 10 statement — Learned Indigenous knowledge, joint search and family loss: https://www.onic.org.co/comunicado-a-la-opinion-publica-de-4-menores-que-fueron-encontrados-en-la-selva-despues-de-accidente-aereo-en-amazonia-colombiana/',
'Reuters, June 12, 2023, reporting the grandfather’s account in Defense Ministry videos — Attributed role of the eldest child; reproduction: https://kfgo.com/2023/06/12/eldest-of-rescued-colombian-children-pulled-sister-from-plane-wreckage/'
],
[
'Complete overview covers the crash, family composition, survival challenges, attributed knowledge and care, joint search, clues, discovery, evacuation, recovery and child protection.',
'The four were three girls and a boy, not four sisters. Infant avoids inconsistent rescue-day ages. The mother is among the adults who died, without claiming her precise time of death.',
'No invented daily route, food quantities, conversations or claim that the children ate dropped supplies is included. Survival explanations are attributed and early uncertainty is explicit.',
'Indigenous searchers and communities receive clear credit within a joint military operation. Neither a dog nor one child replaces the whole-event overview.',
'Topic 036 was compared with 001–035 and 037–040. The Amazon 2023 event is distinct from the Chile mine rescue and Thailand cave rescue; its identity and alternative names are registered in content/topics.json.'
])

draft(38, 'princess-diana-death-1997', 'Diana: Public Life, Death and Its Aftermath', 'World Events',
      'A princess known for humanitarian work died in a Paris crash, prompting public mourning, investigations and debate about privacy.',
'''Diana Spencer became Princess of Wales when she married Prince Charles in 1981. They had two sons, William and Harry. Her royal role brought enormous public attention, while her personal life became a constant subject of press coverage. The marriage ended in divorce in 1996.

Her public importance also grew through **charity** work. She supported children, homeless people and people living with HIV. Her contact with HIV patients challenged **stigma** at a time of widespread fear. In 1997, her visit to Angola helped draw attention to the suffering caused by **landmines**.

Fame also brought persistent **intrusion**. Photographers followed her movements, and stories about her relationships attracted intense interest. By the summer of 1997, she was spending time with Dodi Fayed, whose family owned the Ritz Hotel in Paris.

Early on August 31, their car crashed in the Alma **underpass** in Paris. Dodi and the driver, Henri Paul, died at the scene. Diana died later in hospital, aged 36. Bodyguard Trevor Rees-Jones survived with serious injuries.

Investigations examined the car's speed, the following vehicles and the driver's condition. Evidence showed that Paul was **impaired** by alcohol. Failure to wear seat belts also contributed to the deaths.

The news prompted widespread **mourning**. Flowers and messages gathered outside royal residences, and her funeral took place at Westminster Abbey on September 6. Public grief also raised questions about the relationship between the royal family, the press and ordinary people.

Official inquiries continued for years. The 2006 Operation Paget police report found no evidence supporting allegations of a murder conspiracy. A separate British inquest in 2008 concluded that grossly **negligent** driving by Paul and following vehicles had unlawfully caused Diana and Dodi's deaths.

Her death became part of a wider debate about celebrity and privacy. Her humanitarian **legacy** also continued through charities and public memory. The story joined personal loss, public service, media pressure and a long effort to establish what had happened.''',
[
v('charity', 'Work or an organization that provides help to people or causes in need.', 'The charity supported families without stable housing.', 'Noun', plural='charities'),
v('stigma', 'Negative judgment or shame attached unfairly to a person, condition or group.', 'The campaign challenged the stigma surrounding the illness.', 'Noun', plural='stigmas'),
v('landmine', 'An explosive device placed on or under the ground that can injure people long after fighting ends.', 'The team cleared a landmine near the village.', 'Noun', form='landmines', plural='landmines'),
v('intrusion', 'An unwanted interference in someone’s private life or space.', 'The family complained about repeated intrusion into their privacy.', 'Noun', plural='intrusions'),
v('underpass', 'A road or passage that goes beneath another road or structure.', 'The car entered the underpass beside the river.', 'Noun', plural='underpasses'),
v('impaired', 'Having an ability reduced or weakened so that normal functioning is affected.', 'The driver’s judgment was impaired by alcohol.', 'Adjective'),
v('mourning', 'Sadness and the expression of grief after someone has died.', 'The community gathered in mourning after the loss.', 'Uncountable noun'),
v('negligent', 'Failing to take proper care when there is a responsibility to do so.', 'The inquiry examined whether the operator had been negligent.', 'Adjective'),
v('legacy', 'A lasting effect, influence or contribution that remains after someone dies or an event ends.', 'The school preserved the teacher’s legacy.', 'Noun', plural='legacies')
],
[
m('What was important about Diana’s public work?', ['It consisted entirely of reporting on other celebrities.', 'She used her public role to support people and draw attention to neglected problems.', 'It began only after her death.'], 'B', 'She supported children, homeless people and people living with HIV.', 'Her work involved humanitarian causes as well as the attention surrounding royal life.'),
m('Which account matches the crash and its immediate consequences?', ['Diana died later in hospital, while the bodyguard survived with serious injuries.', 'Everyone in the car survived without injury.', 'The crash occurred in London after the funeral.'], 'A', 'Diana died later in hospital, aged 36. Bodyguard Trevor Rees-Jones survived with serious injuries.', 'The account distinguishes the people who died from the seriously injured survivor.'),
m('What did the later official inquiries conclude?', ['Operation Paget proved an assassination conspiracy.', 'The police report and the inquest were the same inquiry held on one day.', 'The police report found no supporting evidence for a murder conspiracy, and the inquest addressed negligent driving.'], 'C', 'The 2006 Operation Paget police report found no evidence supporting allegations of a murder conspiracy. A separate British inquest in 2008 concluded that grossly negligent driving by Paul and following vehicles had unlawfully caused Diana and Dodi\'s deaths.', 'The two inquiries had different roles and dates; their findings do not establish a murder plot.'),
g('Diana’s marriage ended in divorce in ___.', '1996', 'The marriage ended in divorce in 1996.', '1996 was the year of the divorce described.'),
g('The fatal crash happened in ___.', 'Paris', 'Early on August 31, their car crashed in the Alma underpass in Paris.', 'Paris was the location of the crash.'),
g('Her funeral took place at Westminster ___.', 'Abbey', 'Flowers and messages gathered outside royal residences, and her funeral took place at Westminster Abbey on September 6.', 'Abbey completes the name of the funeral venue.')
],
[
'Royal household biography — Marriage, family, divorce, public work, death, mourning and funeral: https://www.royal.uk/diana-princess-wales',
'Original 2006 Metropolitan Police Operation Paget report, reproduced by BBC — Paris local date, crash sequence, deaths, survivor, alcohol, seat belts and conspiracy investigation: https://downloads.bbc.co.uk/news/nol/shared/bsp/hi/pdfs/14_12_06_diana_report.pdf',
'National AIDS Trust, its own former patron — HIV advocacy and stigma: https://nat.org.uk/views/diana-hiv-we-remember-our-patron-20-years-on/',
'HALO Trust, its own history — Diana’s 1997 Angola visit and landmine awareness: https://www.halotrust.org/about-us/history/',
'Reuters, original contemporary court reporting, April 7, 2008 — Inquest verdict and jury findings: https://www.reuters.com/article/world/diana-unlawfully-killed-inquest-rules-idUSL04508177/'
],
[
'Overview includes family and public role, humanitarian work, press attention, the Paris crash and casualties, immediate mourning, separate official investigations and lasting legacy.',
'The crash is dated early August 31 in Paris local time. The 2006 police report is distinguished from the 2008 British inquest; unlawful killing based on negligent driving is not treated as proof of a planned assassination.',
'The bodyguard is not claimed to have survived because he wore a seat belt. The original report says no occupant wore one. No graphic injuries or unsupported audience totals are included.',
'Allegations remain allegations; no unsupported pregnancy, engagement or secret-service plot is asserted.',
'Topic 038 was reviewed against the entire ledger. Diana’s death and its public context form one central event, rather than splitting her crash, inquiry and public mourning into new lesson numbers.'
])

draft(39, 'germanwings-9525-crash-2015', 'Germanwings 9525: A Deliberate Crash and Aviation Safety', 'Aviation',
      'The loss of a passenger flight in the French Alps led investigators to examine deliberate action, medical reporting and safeguards in aviation.',
'''On March 24, 2015, Germanwings flight 9525 left Barcelona for Düsseldorf. The Airbus A320 carried 144 passengers and six crew members. It crashed in the French Alps, killing all 150 people on board. Families across several countries faced the sudden loss of relatives and friends.

The French aviation investigation established that the **co-pilot**, Andreas Lubitz, had deliberately caused the crash while alone in the **cockpit**. The captain had been unable to regain access. Investigators reached their conclusion from recordings, technical evidence and the wider examination of the flight.

The mountain location made recovery work difficult. Emergency teams and investigators worked to recover remains, identify victims and secure evidence. The aircraft's **flight recorders** became central to understanding events that had initially been unclear.

The investigation also examined the co-pilot's **medical fitness**. His condition had deteriorated before the crash, and he had consulted doctors. Some medical certificates stating that he should not work were not passed to the airline. Relevant aviation medical authorities had not received the information needed to intervene.

The final report, published in March 2016, examined how the reporting system could fail. It considered reliance on pilots reporting their own condition, fear of losing employment and uncertainty about when medical **confidentiality** should give way to public safety.

Its findings led to recommendations about medical **assessment**, support for pilots and clearer reporting rules. Cockpit security also came under review. The challenge was to strengthen **safeguards** while encouraging people to seek help and disclose serious health problems.

In 2018, new European rules introduced requirements including pilot **support programs** and psychological assessment before airline employment. These measures formed part of the broader response to the disaster.

For the families, safety changes could not replace those who had died. The case left a lasting responsibility to remember the victims and learn from the failures identified. A **deliberate** act had caused the crash, and the investigation sought ways to make the surrounding safety system more effective.''',
[
v('co-pilot', 'A qualified pilot who shares the work of operating an aircraft with the captain.', 'The co-pilot checked the flight information.', 'Noun', plural='co-pilots'),
v('cockpit', 'The part of an aircraft where the pilots sit and operate the controls.', 'The crew reported the problem to the cockpit.', 'Noun', plural='cockpits'),
v('flight recorder', 'A protected device that records flight data or cockpit sound to help investigators understand an incident.', 'Investigators recovered a flight recorder from the wreckage.', 'Noun phrase', form='flight recorders', plural='flight recorders'),
v('medical fitness', 'The state of health required to perform a particular task safely.', 'The examination assessed medical fitness for the role.', 'Uncountable noun phrase'),
v('confidentiality', 'The duty or practice of keeping sensitive information private.', 'The agreement protected the confidentiality of personal records.', 'Uncountable noun'),
v('assessment', 'A careful evaluation of a condition, ability or risk.', 'The team completed an assessment before making its decision.', 'Noun', plural='assessments'),
v('safeguard', 'A measure intended to prevent harm or protect against a risk.', 'The new safeguard required an independent review.', 'Noun', form='safeguards', plural='safeguards'),
v('support program', 'An organized service that helps people deal with difficulties or obtain assistance.', 'The employer introduced a confidential support program.', 'Noun phrase', form='support programs', plural='support programs'),
v('deliberate', 'Done intentionally and with awareness, rather than by chance.', 'The review found that the omission was deliberate.', 'Adjective')
],
[
m('What conclusion did the investigation reach about the crash?', ['The co-pilot had deliberately caused it.', 'All passengers survived the impact.', 'There was no recording or technical evidence to examine.'], 'A', 'The French aviation investigation established that the co-pilot, Andreas Lubitz, had deliberately caused the crash while alone in the cockpit.', 'The finding came from the investigation and is distinguished from early uncertainty.'),
m('What weakness in medical reporting did the investigation examine?', ['Every relevant medical certificate had reached the airline immediately.', 'Pilots never needed medical assessment at any stage.', 'Important information about deteriorating fitness had not reached the airline and aviation medical authorities.'], 'C', 'Some medical certificates stating that he should not work were not passed to the airline. Relevant aviation medical authorities had not received the information needed to intervene.', 'The investigation considered how relevant health information failed to reach people responsible for flight safety.'),
m('What was part of the later response?', ['Ending all pilot support and medical assessment.', 'Pilot support programs, psychological assessment and efforts to improve safeguards.', 'A declaration that the disaster required no changes to aviation safety.'], 'B', 'In 2018, new European rules introduced requirements including pilot support programs and psychological assessment before airline employment.', 'The response included both assessment and support, alongside wider safety recommendations.'),
g('The aircraft crashed in the French ___.', 'Alps', 'It crashed in the French Alps, killing all 150 people on board.', 'Alps completes the name of the mountain range where the crash occurred.'),
g('All ___ people on board died.', '150', 'It crashed in the French Alps, killing all 150 people on board.', '150 includes passengers and crew.'),
g('The final report was published in March ___.', '2016', 'The final report, published in March 2016, examined how the reporting system could fail.', '2016 identifies the year of the final safety report.')
],
[
'French BEA, original final report published March 2016 — Flight, casualties, deliberate action, evidence, medical/system findings and safety recommendations: https://bea.aero/fileadmin/uploads/tx_elydbrapports/BEA2015-0125.en-LR.pdf',
'French BEA, official investigation summary — Medical reporting, cockpit security and eleven recommendations: https://bea.aero/en/investigation-reports/notified-events/detail/accident-to-the-airbus-a320-211-registered-d-aipx-and-operated-by-germanwings-flight-gwi18g-on-03-24-15-at-prads-haute-bleone/',
'EASA, original 2018 announcement — Pilot support programs and pre-employment psychological assessment: https://www.easa.europa.eu/en/newsroom-and-events/news/easa-welcomes-new-rules-mental-fitness-air-crew',
'EASA, original Opinion 14/2016 — Regulatory response to the crash: https://www.easa.europa.eu/en/document-library/opinions/opinion-142016'
],
[
'Whole-event account covers the route and all victims, established deliberate cause, recovery and evidence, medical reporting, confidentiality and employment concerns, recommendations, later rules and family consequences.',
'The intentional act is described at a high level. No control settings, door procedures, descent timings or other actionable suicide/crash details are included.',
'The narrative does not treat mental illness in general as a predictor of violence. It describes the specific investigation and emphasizes help-seeking, assessment and support alongside safety.',
'It does not claim that nobody knew any earlier medical history. The relevant failure concerned reporting the recent deterioration in fitness. The BEA safety report is not misrepresented as a criminal court judgment.',
'The 2018 rules are described historically without asserting a current implementation date or that temporary cockpit staffing rules remain universal.',
'Topic 039 is a distinct, identified flight event. It was checked against other aviation topics including 001, 010, 011, 014, 017 and 029; a shared aviation theme is not a duplicate event.'
])

draft(40, 'essex-lorry-deaths-2019', 'Essex 2019: The Deaths of 39 Vietnamese People', 'World Events',
      'A fatal Channel crossing in a sealed trailer exposed an organized smuggling network and left families grieving in Vietnam and abroad.',
'''In the early hours of October 23, 2019, 39 people were discovered dead inside a lorry trailer in Grays, Essex, in England. All were Vietnamese. They were aged 15 to 44, and two were only 15. Behind the number were families who had expected their relatives to return or build new lives abroad.

The journey formed part of an organized **people-smuggling** operation. A network arranged transport across Europe and charged large sums for passage to Britain. Those traveling depended on promises that the organizers would bring them safely to their destination.

On October 22, the refrigerated **trailer** had crossed by ship from Zeebrugge in Belgium to Purfleet in Essex. Its refrigeration unit was switched off. The people inside were sealed into an **airtight** space with no means of escape.

Without adequate **ventilation**, oxygen levels fell, **carbon dioxide** accumulated and the temperature rose. The fatal conditions caused suffocation, poisoning and overheating. The deaths occurred during the crossing, before the trailer was collected in England and the bodies were discovered.

The discovery led to a large police investigation. Establishing the victims' identities required cooperation with Vietnamese authorities and families. Investigators also examined transport records, communications and financial links to understand the network behind the journey.

Authorities in Britain and other European countries worked together. The evidence connected drivers, organizers and other participants across borders. The case concerned profitable criminal activity that had placed people in lethal conditions while promising safe passage.

Major court proceedings resulted in four men being sentenced in January 2021 for 39 counts of **manslaughter**. Other defendants were punished for immigration-related conspiracy offences. Further **prosecutions** and efforts to recover criminal money followed.

For the families, legal **accountability** could not remove the loss. Their **grief** continued beyond the trial and the headlines. The disaster exposed the human cost of trusting an organized smuggling network, and the investigation sought responsibility for a journey that had ended in the deaths of everyone inside the trailer.''',
[
v('people smuggling', 'The organized assistance of people to cross a national border unlawfully, usually for payment.', 'The investigation uncovered a people smuggling network.', 'Uncountable noun phrase', form='people-smuggling', note='Hyphenated in the script because it modifies “operation”.'),
v('trailer', 'A wheeled vehicle pulled by a lorry or another vehicle to carry a load.', 'The driver collected the trailer at the port.', 'Noun', plural='trailers'),
v('airtight', 'Sealed so that air cannot easily enter or escape.', 'The container had an airtight seal.', 'Adjective'),
v('ventilation', 'The movement or replacement of air in an enclosed space.', 'The room needed better ventilation.', 'Uncountable noun'),
v('carbon dioxide', 'A gas produced by breathing, burning and other processes that can be harmful at high concentrations.', 'The monitor measured carbon dioxide in the enclosed room.', 'Uncountable noun phrase'),
v('manslaughter', 'The unlawful killing of a person in circumstances legally distinguished from murder.', 'The court sentenced the defendant for manslaughter.', 'Uncountable noun'),
v('prosecution', 'Legal proceedings brought against someone accused of a criminal offence.', 'The investigation led to a prosecution.', 'Noun', form='prosecutions', plural='prosecutions'),
v('accountability', 'Responsibility for actions and the obligation to answer for their consequences.', 'The families continued to demand accountability.', 'Uncountable noun'),
v('grief', 'Deep sadness caused by a death or other serious loss.', 'Friends supported the family in its grief.', 'Uncountable noun')
],
[
m('What did the transport arrangement involve?', ['An ordinary passenger service with open access to fresh air.', 'An organized network charging for passage and placing people in a sealed trailer.', 'A rescue mission sent to collect people already safe at home.'], 'B', 'A network arranged transport across Europe and charged large sums for passage to Britain.', 'The journey was part of an organized smuggling operation rather than a normal passenger crossing.'),
m('What caused the fatal conditions inside?', ['The refrigeration system froze everyone while fresh air circulated normally.', 'The trailer remained open and the people could leave whenever they wished.', 'Poor ventilation allowed oxygen to fall, carbon dioxide to accumulate and temperature to rise.'], 'C', 'Without adequate ventilation, oxygen levels fell, carbon dioxide accumulated and the temperature rose.', 'The story describes suffocation, poisoning and overheating inside a sealed space.'),
m('What followed the discovery?', ['An international investigation, prosecutions and continuing grief for families.', 'A finding that the victims were all from unrelated countries.', 'An immediate end to every legal and personal consequence.'], 'A', 'Authorities in Britain and other European countries worked together. The evidence connected drivers, organizers and other participants across borders.', 'The investigation crossed national borders and led to court proceedings; families continued to live with the loss.'),
g('The victims were discovered in Grays, ___.', 'Essex', 'In the early hours of October 23, 2019, 39 people were discovered dead inside a lorry trailer in Grays, Essex, in England.', 'Essex identifies the English county where the discovery was made.'),
g('The trailer crossed from Zeebrugge in ___.', 'Belgium', 'On October 22, the refrigerated trailer had crossed by ship from Zeebrugge in Belgium to Purfleet in Essex.', 'Belgium was the country of departure for that crossing.'),
g('Four men were sentenced for manslaughter in January ___.', '2021', 'Major court proceedings resulted in four men being sentenced in January 2021 for 39 counts of manslaughter.', '2021 identifies the year of the major sentencing described.')
],
[
'Original judiciary publication, January 22, 2021 — Sentencing and defendants: https://www.judiciary.uk/judgments/r-v-hughes-and-ors-sentencing-remarks/',
'Original sentencing remarks reproduced by UNODC — October 22 deaths, airtight trailer, medical causes, network and smuggling classification: https://www.unodc.org/cld/uploads/res/case-law-doc/migrantsmugglingcrimetype/gbr/2021/r_v_nica_hughes_and_others__html/Nica-Hughes-and-Others-Sentencing-Remarks_1.pdf',
'UNODC case-law record — Refrigeration off, fatal conditions and international investigation: https://sherloc.unodc.org/cld/case-law-doc/migrantsmugglingcrimetype/gbr/2021/r_v_nica_hughes_and_others_.html',
'Essex Police statement reproduced by official Police Commissioner — October 23 discovery, all Vietnamese, families and investigation: https://www.essex.pfcc.police.uk/news/two-guilty-for-the-manslaughter-of-39-vietnamese-men-women-and-children',
'Official Police Commissioner sentencing account — Two 15-year-olds, January sentencing and family impact: https://www.essex.pfcc.police.uk/news/92-years-for-men-involved-in-death-of-39-vietnamese-nationals',
'Crown Prosecution Service, July 2025 — Later financial accountability proceedings: https://www.cps.gov.uk/cps/news/essex-lorry-deaths-ringleader-people-smuggling-operation-has-time-added-sentence-failing'
],
[
'Full overview includes victims and family context, organized paid passage, the Channel crossing, fatal conditions, discovery, identification, international investigation, prosecution and grief.',
'Deaths during the October 22 crossing are distinguished from discovery in Grays on October 23. Refrigeration was off: the victims did not freeze to death.',
'All 39 were Vietnamese, aged 15–44. The narrative uses respectful language and does not turn one final message into the whole story.',
'The original judge distinguishes smuggling from trafficking in this prosecution. The lesson does not label all victims as proven trafficking victims or describe them as illegal people.',
'January 22, 2021 sentencing is supported by the original judiciary publication. A later CPS page’s discrepant reference to February is not repeated. The text does not claim all offenders were caught or all families compensated.',
'Topic 040 was checked against all registered events and alternative names. It is a distinct case, not a retelling of an earlier transport disaster.'
])

draft(37, 'tham-luang-cave-rescue-2018', 'Thailand 2018: The Tham Luang Cave Rescue', 'Rescue Stories',
      'A football team trapped by flooding was brought out through a Thai-led operation combining expert diving, medical care and community support.',
'''On June 23, 2018, 12 boys from the Wild Boars football team and their assistant coach entered the Tham Luang cave system in northern Thailand. Heavy **monsoon** rain flooded passages behind them. Their exit was cut off, and the group became trapped underground.

Thai authorities organized a search supported by local **volunteers** and specialists from abroad. Engineers **pumped** water and worked to divert incoming flows. Soldiers, medical teams and experienced cave **divers** brought different skills to an operation that grew increasingly urgent.

On July 2, two British cave divers found all 13 alive. The discovery brought relief, but reaching the group was different from bringing them out. Much of the route remained underwater, and the boys had little diving experience.

Narrow passages, strong **currents** and poor **visibility** made movement dangerous even for experts. More rain could worsen the flooding. Teams had to maintain supplies and care for the group while preparing an evacuation that could work in these conditions.

The plan combined specialist diving with close medical supervision. Doctors used **anesthesia** as part of the operation, and experienced divers guided the group through **submerged** sections. Other rescuers supported movement and care along the route. Each stage depended on equipment, preparation and communication between teams.

Between July 8 and July 10, all 12 boys and their coach were brought out alive. They went to hospital for assessment and recovery. Families and supporters around the world celebrated the outcome after days of uncertainty.

The effort also involved loss. Former Thai Navy diver Saman Kunan died during preparations. The Thai Navy later reported that another diver, Beirut Pakbara, died in 2019 from an infection contracted during the rescue work.

The operation showed how different forms of expertise could support one another under extreme pressure. Thai leadership, local knowledge, international specialists and community support all mattered. Its successful **evacuation** became a widely remembered example of cooperation, while the rescuers' sacrifices remained part of the story.''',
[
v('monsoon', 'A seasonal pattern of winds that brings a period of heavy rain in some regions.', 'Heavy rain arrived with the summer monsoon.', 'Noun', plural='monsoons'),
v('volunteer', 'A person who offers time or work willingly, usually without payment.', 'A volunteer helped organize food for the rescue teams.', 'Noun', form='volunteers', plural='volunteers'),
v('pump', 'To move liquid or gas using a machine.', 'Workers used equipment to pump water out of the tunnel.', 'Verb', form='pumped', verb=('pump','pumped','pumped',False)),
v('diver', 'A person who goes underwater using suitable breathing or swimming equipment.', 'The diver inspected the flooded passage.', 'Noun', form='divers', plural='divers'),
v('current', 'A flow of water or air moving in a particular direction.', 'A strong current made swimming dangerous.', 'Noun', form='currents', plural='currents'),
v('visibility', 'How far or how clearly someone can see in particular conditions.', 'Muddy water reduced visibility.', 'Uncountable noun'),
v('anesthesia', 'A medically controlled loss of sensation or awareness used during a procedure.', 'Specialist doctors monitored the patient during anesthesia.', 'Uncountable noun'),
v('submerged', 'Covered by water or below its surface.', 'The lower section of the tunnel was submerged.', 'Adjective'),
v('evacuation', 'The organized movement of people away from danger to safety.', 'The evacuation required careful planning.', 'Noun', plural='evacuations')
],
[
m('Why was the group trapped?', ['They were waiting for a football match to begin inside the cave.', 'The cave had no passages leading toward the entrance.', 'Heavy rain flooded passages and cut off the exit.'], 'C', 'Heavy monsoon rain flooded passages behind them. Their exit was cut off, and the group became trapped underground.', 'Flooding changed the conditions after the group entered the cave.'),
m('Why did finding the group not immediately solve the rescue?', ['The route remained dangerous and underwater, and the boys lacked diving experience.', 'Every flooded section had already become dry and easy to walk through.', 'The rescuers had decided that supplies and medical support were unnecessary.'], 'A', 'Much of the route remained underwater, and the boys had little diving experience.', 'Extraction required a separate plan for people who could not simply follow expert divers out.'),
m('What best describes the operation’s outcome?', ['Only the coach survived and no rescuers faced danger.', 'All 13 were rescued, while the wider effort also involved rescuers’ deaths.', 'The discovery on July 2 ended the operation that same day.'], 'B', 'Between July 8 and July 10, all 12 boys and their coach were brought out alive.', 'The successful extraction occurred over three days; the story also recognizes the rescuers who died.'),
g('The group entered the cave on June 23, ___.', '2018', 'On June 23, 2018, 12 boys from the Wild Boars football team and their assistant coach entered the Tham Luang cave system in northern Thailand.', '2018 identifies the year of the rescue.'),
g('Divers found all 13 alive on ___ 2.', 'July', 'On July 2, two British cave divers found all 13 alive.', 'July was the month in which the group was located and rescued.'),
g('Muddy water and darkness contributed to poor ___.', 'visibility', 'Narrow passages, strong currents and poor visibility made movement dangerous even for experts.', 'Visibility describes how clearly the divers could see.')
],
[
'Australian Department of Foreign Affairs and Trade — Timeline, Thai leadership, international support and successful rescue: https://www.dfat.gov.au/crisis-hub/thailand-cave-rescue',
'Australian Home Affairs, official 2018 rescue symposium — Flooding, multidisciplinary operation, medical supervision and extraction: https://www.homeaffairs.gov.au/emergency/files/thai-cave-rescue-report-web.pdf',
'British Cave Rescue Council, July 6, 2018 — Saman Kunan’s death and rescue hazards: https://www.caverescue.org.uk/tham-luang-nang-non-cave-thailand-update-5/',
'British Cave Rescue Council, July 8, 2018 — Evacuation preparations, medical assessment and coordinated teams: https://www.caverescue.org.uk/key-phase-of-the-rescue-operation-to-bring-the-boys-out-of-tham-luang-nang-non-cave-begins/',
'UK government, July 10, 2018 — All rescued, Thai cooperation and remembrance: https://www.gov.uk/government/news/minister-for-asia-praises-successful-thai-caves-rescue-mission',
'Thai Navy spokesman’s December 27, 2019 statement reproduced by Thai Rath — Beirut Pakbara’s death after rescue-related infection: https://www.thairath.co.th/news/local/bangkok/1736128'
],
[
'Full overview includes entry and flooding, Thai-led search, water management and support, discovery, underwater hazards, high-level medical/diving plan, three-day extraction, recovery and sacrifices.',
'Anesthesia is described only at a high level. No drug names, doses, administration techniques or actionable cave-diving instructions are given.',
'The discovery on July 2 is separated from extraction on July 8–10. No conflicting precise cave distance is asserted.',
'Saman Kunan died during preparations; the later 2019 death of Beirut Pakbara is explicitly separated from the extraction dates. DFAT’s discrepant date for Saman is not repeated.',
'Topic 037 is distinct from 035 Chile and 036 Amazon despite a shared rescue theme. Central event and alternative names were compared with all other registered topics.'
])
