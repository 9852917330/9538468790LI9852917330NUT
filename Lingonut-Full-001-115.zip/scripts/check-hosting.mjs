import { readdir, stat, readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { createHash } from "node:crypto";
import { parseTranslation, plainScript, scriptParagraphs, translationCodes } from "../lib/translation.ts";
import { parseTitleTranslations } from "../lib/title-translation.ts";
const root = fileURLToPath(new URL("../dist/", import.meta.url));
const files = [];
async function scan(dir) {
  for (const item of await readdir(dir, { withFileTypes: true })) {
    const file = path.join(dir, item.name);
    if (item.isDirectory()) await scan(file); else if (item.isFile()) files.push(file);
  }
}
await scan(root);
if (files.length > 20000) throw new Error("This build exceeds the Cloudflare Pages Free limit of 20,000 files.");
let bytes = 0;
for (const file of files) {
  const size = (await stat(file)).size; bytes += size;
  if (size > 25 * 1024 * 1024) throw new Error(`${path.relative(root, file)} exceeds 25 MiB.`);
}
// Dev-server font resolution can hide broken production CSS URLs. Every local
// font URL in the built CSS must point to a nonempty file in the site archive.
const fontAssets = new Set();
for (const file of files.filter(file => file.endsWith(".css"))) {
  const css = await readFile(file, "utf8");
  for (const match of css.matchAll(/url\(["']?([^\s)"']+)["']?\)/g)) {
    const url = match[1];
    if (!/\.(?:woff2?|ttf|otf)(?:[?#]|$)/i.test(url) || /^(?:data:|https?:|\/\/)/i.test(url)) continue;
    const font = path.resolve(path.dirname(file), decodeURIComponent(url.split(/[?#]/)[0]));
    if (!font.startsWith(root) || !(await stat(font)).size) throw new Error(`Missing packaged font: ${url}`);
    fontAssets.add(font);
  }
}
if (fontAssets.size < 5) throw new Error("Multilingual fonts were not included in the site archive.");
const catalog = JSON.parse(await readFile(path.join(root, "data/index.json"), "utf8"));
for (const [language, url] of Object.entries(catalog.titleTranslationUrls ?? {})) {
  if (!translationCodes.includes(language) || !/^data\/titles\/[A-Za-z0-9.-]+\.json$/.test(url)) throw new Error(`Invalid title translation reference: ${language}`);
  parseTitleTranslations(JSON.parse(await readFile(path.join(root, url), "utf8")), language, catalog.lessons);
}
for (const item of catalog.lessons) {
  const lesson = JSON.parse(await readFile(path.join(root, item.dataUrl), "utf8"));
  if (lesson.id !== item.id || lesson.questions.length !== 6) throw new Error(`Invalid lesson output: ${item.id}`);
  if (lesson.audioUrl) await stat(path.join(root, lesson.audioUrl));
  for (const [language, url] of Object.entries(lesson.translationUrls ?? {})) {
    if (!translationCodes.includes(language) || !/^data\/translations\/[A-Za-z0-9.-]+\.json$/.test(url)) throw new Error(`Invalid translation reference: ${item.id}/${language}`);
    const sourceScriptSha256 = createHash("sha256").update(plainScript(lesson.script)).digest("hex");
    if (lesson.translationSourceSha256 !== sourceScriptSha256) throw new Error(`Invalid translation source: ${item.id}`);
    parseTranslation(JSON.parse(await readFile(path.join(root, url), "utf8")), { lessonId: lesson.id, language, sourceScriptSha256, sourceTitle: lesson.title, paragraphCount: scriptParagraphs(lesson.script).length });
  }
  for (const entry of lesson.phrases) {
    if (!entry.pronunciationUrl?.startsWith("pronunciation/")) throw new Error(`Missing pronunciation: ${item.id}/${entry.phrase}`);
    await stat(path.join(root, entry.pronunciationUrl));
  }
}
console.log(`Hosting check: ${files.length} files, ${(bytes / 1024 / 1024).toFixed(2)} MiB. ${files.length <= 1000 ? "Cloudflare dashboard upload is available." : "Use Wrangler for upload (dashboard limit: 1,000 files)."}`);
