"""Source-checked new English lessons, with reusable editorial records."""
from importlib.machinery import SourceFileLoader
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent
helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
helpers.DATE = '2026-11-22'
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

identities = [
    (106, 'boston-tea-party-1773', 'The Boston Tea Party: Tea, Tax and Imperial Power', ['Boston Tea Party 1773', 'Boston destruction of tea December 1773']),
    (107, 'discovery-insulin-1921-1922', 'The Discovery of Insulin: From Laboratory Work to Lifesaving Treatment', ['Discovery of insulin Toronto 1921 1922', 'Banting Best Macleod Collip insulin']),
    (108, 'carrington-solar-storm-1859', 'The Carrington Event: A Solar Storm Meets the Telegraph Age', ['Carrington Event 1859', 'Great geomagnetic storm September 1859']),
    (109, 'velvet-revolution-czechoslovakia-1989', 'The Velvet Revolution: How Czechoslovakia Ended One-Party Rule', ['Velvet Revolution 1989', 'Czechoslovakia November revolution 1989']),
    (110, 'darwin-wallace-natural-selection-1858-1859', 'Darwin and Wallace: Explaining Evolution by Natural Selection', ['Darwin Wallace natural selection 1858', 'Origin of Species publication 1859']),
]
ledger_path = ROOT / 'content/topics.json'
ledger = json.loads(ledger_path.read_text())
for number, key, label, aliases in identities:
    row = {'order': number, 'eventKey': key, 'label': label, 'aliases': aliases,
           'reviewedAgainstThrough': number - 1, 'reviewedOn': helpers.DATE}
    existing = next((x for x in ledger['topics'] if x['order'] == number), None)
    if existing is None:
        ledger['topics'].append(row)
    else:
        assert existing == row
ledger_path.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n')

draft(106, 'boston-tea-party-1773', identities[0][2], 'Wars and Historical Turning Points',
      'A dispute over tea and political authority brought destruction in Boston Harbor, British punishment and wider colonial cooperation on the road to revolution.',
'''In 1773, Britain's American colonies were arguing with Parliament over taxation and political power. Many colonists said that Parliament should not tax them without **representation**. British leaders maintained their authority to govern the empire.

The Tea Act helped the financially troubled East India Company sell tea more cheaply. It kept an existing colonial tea duty rather than creating a new tax. Opponents also feared the company's privileged position and near **monopoly**.

Three ships carrying tea arrived in Boston: Dartmouth, Eleanor and Beaver. Protesters prevented the **cargo** from being unloaded. Governor Thomas Hutchinson refused to let the ships leave without following customs rules. Public meetings failed to resolve this **stalemate**.

On December 16, 1773, another large meeting ended without a solution. That evening, protesters boarded the ships. Some wore clothing intended to **disguise** them as Indigenous people. The group broke open 342 chests and threw the tea into the harbour.

This was deliberate destruction of commercial property. The protesters attacked a product associated with Parliament's disputed taxing power. Their disguises did not mean that Indigenous communities had organised the action.

British **retaliation** followed in 1774. Laws known as the **Coercive** Acts closed Boston's port until compensation was made and restricted self-government in Massachusetts. British authorities hoped punishment would restore control and discourage further defiance.

Instead, the measures encouraged other colonies to support Massachusetts. Delegates met at the First Continental Congress in September 1774. Armed fighting began at Lexington and Concord in April 1775; the declaration of independence followed in July 1776.

The tea protest was one turning point in a longer crisis. It connected trade disputes, political rights and imperial authority. Destruction, punishment and growing **resistance** helped push that crisis towards revolution, although the protest alone did not determine everything that followed.''',
[
v('representation', 'The act of speaking or making decisions on behalf of other people in a political body.', 'The settlers demanded representation in decisions about taxation.', 'Uncountable noun'),
v('monopoly', 'Exclusive control, or a dominant position that greatly restricts competition, in a market.', 'Merchants feared that the company would gain a monopoly.', 'Noun', plural='monopolies'),
v('cargo', 'Goods carried by a ship, aircraft or other vehicle.', 'The ship carried a cargo of tea.', 'Noun', plural='cargoes'),
v('stalemate', 'A situation in which opposing sides cannot make progress or reach agreement.', 'The talks ended in a stalemate.', 'Noun', plural='stalemates'),
v('disguise', 'To change an appearance so that someone or something is harder to recognise.', 'They tried to disguise themselves before boarding the ship.', 'Verb', verb=('disguise','disguised','disguised',False)),
v('retaliation', 'An action taken against someone in response to an earlier attack or injury.', 'Officials threatened retaliation after the destruction of property.', 'Uncountable noun'),
v('coercive', 'Using pressure, threats or force to make people obey.', 'The coercive measures restricted local political freedom.', 'Adjective', form='Coercive'),
v('resistance', 'Opposition to an authority, policy or attempt to control people.', 'Resistance spread after the port was closed.', 'Uncountable noun')
],
[
m('Why did the Tea Act cause opposition despite cheaper tea?', ['It introduced the first tax ever imposed on tea in the colonies.', 'It retained a disputed duty and gave one company commercial privileges.', 'It required colonial merchants to buy their tea from Dutch suppliers.'], 'B', 'It kept an existing colonial tea duty rather than creating a new tax.', 'The surrounding sentences also describe representation and concern about the company’s privileged position.'),
m('What created the standoff in Boston?', ['Parliament had ordered all ships to return before their cargo could be inspected.', 'The governor agreed to send the tea back but the merchants refused to leave.', 'Protesters blocked unloading while the governor refused departure outside customs rules.'], 'C', 'Protesters prevented the cargo from being unloaded.', 'The next sentence explains Hutchinson’s refusal, leaving the ships caught between opposing demands.'),
m('What was an important result of Britain’s punitive measures?', ['Other colonies became more willing to cooperate in support of Massachusetts.', 'Massachusetts gained greater self-government in exchange for paying compensation.', 'The colonies declared independence immediately after Boston’s port closed.'], 'A', 'Instead, the measures encouraged other colonies to support Massachusetts.', 'The passage places the Congress, fighting and declaration at later stages of a continuing crisis.'),
g('The protesters destroyed ___ chests of tea.', '342', 'The group broke open 342 chests and threw the tea into the harbour.', 'The number refers to the tea cargo destroyed on the three ships.'),
g('The First Continental Congress met in September ___.', '1774', 'Delegates met at the First Continental Congress in September 1774.', 'The meeting followed the British response to the destruction of tea.'),
g('The declaration of independence followed in July ___.', '1776', 'Armed fighting began at Lexington and Concord in April 1775; the declaration of independence followed in July 1776.', 'The declaration came after armed fighting had begun.')
],
[
'US National Park Service, Boston Tea Party Timeline — Three ships, customs standoff, public meetings, disguises and 342 chests: https://www.nps.gov/articles/000/boston-tea-party-in-real-time.htm',
'US Library of Congress, The Colonies Move Toward Open Rebellion, 1773 to 1774 — Existing duty, company privileges, cheaper tea, representation and punishment leading to wider solidarity; indexed text consulted when direct access returned 403: https://www.loc.gov/classroom-materials/united-states-history-primary-source-timeline/american-revolution-1763-1783/colonies-rebellion-1773-1774/',
'UK National Archives, The Boston Tea Party — Tea Act text and primary records; port closure until compensation: https://www.nationalarchives.gov.uk/education/teaching-resources/boston-tea-party/',
'US National Archives, America’s Founding Documents — Declaration dated July 4, 1776: https://www.archives.gov/founding-docs/declaration-transcript'
],
[
'Compared with all 105 published events, aliases and all four other new subjects. The 1773 tea destruction is distinct from the 1863 Emancipation Proclamation and the wider French Revolution.',
'The Tea Act retained an existing colonial duty; lower prices did not resolve representation or market-privilege objections. Disguises do not attribute the protest to Indigenous communities.',
'The narrative distinguishes the 1773 destruction, 1774 punishment and Congress, 1775 fighting and 1776 declaration. It makes no claim that all colonists agreed or that a single protest inevitably caused the war.',
'342 follows the US primary-record custodians; some UK introductory wording uses 340 while its reproduced contemporary record says 342. No precise participant count is asserted.'
])

draft(107, 'discovery-insulin-1921-1922', identities[1][2], 'Science and Medical Discoveries',
      'Research in Toronto turned pancreatic extracts into an effective treatment, but purification, clinical testing and reliable production were essential parts of the breakthrough.',
'''Before insulin treatment, people with severe diabetes often faced early death. This was especially true of children with what is now called type 1 diabetes. Extremely restricted diets sometimes prolonged life but could not replace the missing **hormone**, insulin.

Researchers had already connected diabetes with the **pancreas**. In 1921, Frederick Banting and Charles Best began experiments at the University of Toronto, using laboratory facilities and guidance provided by physiologist John Macleod.

The researchers tested a pancreatic **extract** in dogs and found that it could lower blood sugar. Producing a preparation suitable for people was harder. Impurities and inconsistent strength made earlier extracts difficult or dangerous to use.

Biochemist James Collip joined the work and improved the preparation. His **purified** extract became crucial to clinical success. Doctors, laboratory workers and patients also contributed; the discovery was not the work of one person alone.

Fourteen-year-old Leonard Thompson received an **injection** in Toronto on January 11, 1922. The first preparation produced limited benefit and unwanted effects. Treatment with Collip's improved extract began on January 23 and brought clear improvement.

Success in one patient did not immediately create a dependable supply. Toronto's Connaught Laboratories and the company Eli Lilly helped develop ways to **manufacture** insulin in larger quantities. Consistent strength, safety and availability remained important challenges.

The 1923 Nobel Prize in Physiology or Medicine went to Banting and Macleod. Banting shared his prize money with Best, and Macleod shared his with Collip. These arrangements reflected both cooperation and disagreement over credit for the **breakthrough**.

Insulin transformed the outlook for people who needed it. It became an ongoing **treatment**, not a cure that removed the need for further care. The story shows how laboratory findings, purification, clinical observation and production must work together before a discovery can change patients' lives.''',
[
v('hormone', 'A chemical messenger produced in the body that helps control particular functions.', 'Insulin is a hormone involved in controlling blood sugar.', 'Noun', plural='hormones'),
v('pancreas', 'An organ that produces digestive substances and hormones including insulin.', 'Researchers studied the connection between the pancreas and diabetes.', 'Noun', plural='pancreases'),
v('extract', 'A substance obtained by removing certain components from another material.', 'The laboratory tested an extract from animal tissue.', 'Noun', plural='extracts'),
v('purify', 'To remove unwanted or harmful substances from a material.', 'The team needed to purify the preparation before clinical use.', 'Verb', form='purified', verb=('purify','purified','purified',False)),
v('injection', 'The introduction of a substance into the body using a needle.', 'The doctors observed the patient after the injection.', 'Noun', plural='injections'),
v('manufacture', 'To make a product, especially on a large scale.', 'The company developed a method to manufacture the medicine reliably.', 'Verb', verb=('manufacture','manufactured','manufactured',False)),
v('breakthrough', 'An important discovery or advance that makes further progress possible.', 'The breakthrough followed years of experimental work.', 'Noun', plural='breakthroughs'),
v('treatment', 'Medical care given to manage, relieve or address an illness.', 'The patient required continuing treatment and monitoring.', 'Noun', plural='treatments')
],
[
m('Why was Collip’s contribution important?', ['He improved the purity of the preparation used successfully in clinical treatment.', 'He first established the existence of the pancreas before diabetes research began.', 'He replaced insulin with a restricted diet that permanently cured diabetes.'], 'A', 'His purified extract became crucial to clinical success.', 'The passage explains that impurities and inconsistent strength had limited earlier preparations.'),
m('Which statement best describes Thompson’s early treatment?', ['The first and second preparations had identical effects on his condition.', 'The first preparation gave limited benefit; an improved extract later brought clear improvement.', 'He received a fully effective preparation in 1921 before the Toronto experiments.'], 'B', 'The first preparation produced limited benefit and unwanted effects.', 'The following sentence distinguishes the improved January 23 preparation from the January 11 test.'),
m('Why did manufacturing matter after the initial clinical success?', ['It removed the need for patients to receive further treatment.', 'It allowed the Nobel committee to award the prize before the experiments began.', 'Patients needed a dependable supply with consistent strength and safety.'], 'C', 'Success in one patient did not immediately create a dependable supply.', 'The paragraph identifies larger-scale production and quality as necessary parts of practical treatment.'),
g('Banting and Best began the Toronto experiments in ___.', '1921', 'In 1921, Frederick Banting and Charles Best began experiments at the University of Toronto, using laboratory facilities and guidance provided by physiologist John Macleod.', 'Their experiments preceded the clinical treatments in January 1922.'),
g('The young patient’s surname was ___.', 'Thompson', 'Fourteen-year-old Leonard Thompson received an injection in Toronto on January 11, 1922.', 'The passage identifies the patient and the date of the initial injection.'),
g('Banting and Macleod received the Nobel Prize in ___.', '1923', 'The 1923 Nobel Prize in Physiology or Medicine went to Banting and Macleod.', 'Best and Collip received shares of the winners’ prize money, not separate Nobel awards.')
],
[
'University of Toronto, The Discovery and Early Development of Insulin, From a Patient’s Point of View — Original patient records, Thompson’s age and January 11/23 preparations, early supply constraints and clinics: https://collections.library.utoronto.ca/explore/insulin/about/patients',
'University of Toronto, Biography of James Bertram Collip — Purification and the successful January 23 preparation: https://collections.library.utoronto.ca/explore/insulin/about/collip',
'US FDA History Office, 100 Years of Insulin — Earlier pancreas research, restricted diets, Toronto team, clinical studies, production, Nobel award and prize sharing: https://www.fda.gov/about-fda/fda-history-exhibits/100-years-insulin',
'University of Toronto, Biography of Charles Herbert Best — 1921 experiments, Eli Lilly collaboration and Canadian production: https://collections.library.utoronto.ca/explore/insulin/about/best'
],
[
'Compared with all 105 earlier topics and the four new subjects. Insulin discovery is distinct from vaccination, penicillin, heart transplantation and the Theranos fraud story.',
'Earlier pancreas research is acknowledged. Banting, Best, Macleod and Collip have different contributions, alongside clinical and technical teams; the Nobel winners and recipients of shared prize money are distinguished.',
'January 11 is not portrayed as an immediately complete clinical triumph. The improved preparation on January 23 is distinguished from the earlier test.',
'The historical narrative offers no dosage or personal treatment advice. Insulin is described as continuing treatment rather than a cure, and production and safety are part of the story.'
])

draft(108, 'carrington-solar-storm-1859', identities[2][2], 'Science and Natural Phenomena',
      'Bright solar observations, unusual auroras and disrupted telegraph lines revealed connections between the Sun, Earth’s magnetic field and human technology.',
'''In late August and early September 1859, unusual lights appeared in the sky and telegraph systems behaved strangely. These events became part of the story of a major solar storm, later known as the Carrington Event.

On September 1, English **astronomer** Richard Carrington was studying **sunspots** through a projected telescope image. He saw an intense, brief brightening. Richard Hodgson independently observed the same event, now recognised as a solar **flare**.

A flare releases radiation. A related but different solar event, a coronal mass ejection, sends magnetised **plasma** into space. Material reaching Earth can disturb its magnetic field. Scientists now use this distinction to explain the storm's physical processes.

During the powerful disturbances around September 1 and 2, **auroras** were visible unusually far from the poles, including the Caribbean. These lights occur when energetic particles interact with gases high in Earth's atmosphere. Observers described spectacular colours and brightness.

Rapid changes in the magnetic field **induced** electrical currents in long wires. The **telegraph**, a major communication technology of the period, was vulnerable. Operators reported interrupted messages, sparks and electric shocks. Equipment did not respond normally to its usual power supply.

On some lines, operators disconnected their batteries and briefly exchanged messages using the storm-induced current. This was an exceptional and unstable effect, not a reliable new source of power or a condition shared by every line.

Magnetic observatory records and contemporary reports allow researchers to reconstruct the storm. However, nineteenth-century measurements were incomplete. Its exact strength and comparison with other extreme events still involve uncertainty.

The event showed that activity on the Sun could disturb technology on Earth. Such storms can affect modern **infrastructure**, including power grids, satellites and communications. Studying 1859 helps assess these risks; it does not identify the date or precise consequences of a future storm.''',
[
v('astronomer', 'A scientist who studies objects and events beyond Earth’s atmosphere.', 'The astronomer recorded changes on the Sun.', 'Noun', plural='astronomers'),
v('sunspot', 'A relatively cool, dark-looking region on the Sun’s visible surface associated with magnetic activity.', 'A group of sunspots appeared in the telescope image.', 'Noun', form='sunspots', plural='sunspots'),
v('flare', 'A sudden release of energy and radiation from a region of the Sun.', 'The instruments detected a powerful solar flare.', 'Noun', plural='flares'),
v('plasma', 'A state of matter containing electrically charged particles.', 'The eruption sent magnetised plasma into space.', 'Uncountable noun'),
v('aurora', 'A natural light display caused by energetic particles interacting with gases in the upper atmosphere.', 'An aurora was visible much farther south than usual.', 'Noun', form='auroras', plural='auroras'),
v('induce', 'To cause a particular effect or process to occur.', 'A changing magnetic field can induce an electrical current.', 'Verb', form='induced', verb=('induce','induced','induced',False)),
v('telegraph', 'A system for sending coded messages over long distances using electrical signals.', 'The telegraph connected distant towns before telephones became common.', 'Noun', plural='telegraphs'),
v('infrastructure', 'The basic systems and facilities that a society or organisation needs to operate.', 'The storm damaged communication infrastructure.', 'Uncountable noun')
],
[
m('How does the passage distinguish a flare from a coronal mass ejection?', ['A flare is a light display in Earth’s atmosphere; an ejection occurs inside a telegraph wire.', 'They are two names for exactly the same solar process.', 'A flare releases radiation, while an ejection sends magnetised material into space.'], 'C', 'A flare releases radiation.', 'The next sentence describes a coronal mass ejection, keeping the related phenomena distinct.'),
m('Why could telegraph wires carry unusual currents?', ['Rapid magnetic-field changes induced currents in long conductors.', 'The auroras permanently replaced the batteries on all telegraph lines.', 'Operators deliberately increased the power supply to photograph the Sun.'], 'A', 'Rapid changes in the magnetic field induced electrical currents in long wires.', 'The effects followed magnetic disturbances, rather than a normal change in the batteries.'),
m('What can researchers conclude from studying the event?', ['Its exact strength and all future effects can be calculated without uncertainty.', 'Solar activity can affect technology, but the old records have limits.', 'Only nineteenth-century telegraphs can be affected by solar storms.'], 'B', 'However, nineteenth-century measurements were incomplete.', 'The final paragraphs connect evidence about 1859 with modern risks while preserving uncertainty.'),
g('The storm described in the passage occurred in ___.', '1859', 'In late August and early September 1859, unusual lights appeared in the sky and telegraph systems behaved strangely.', 'The opening sentence establishes the historical setting.'),
g('The astronomer after whom the event was named was Richard ___.', 'Carrington', 'On September 1, English astronomer Richard Carrington was studying sunspots through a projected telescope image.', 'Hodgson independently observed the same brightening.'),
g('The major communication system disrupted was the ___.', 'telegraph', 'The telegraph, a major communication technology of the period, was vulnerable.', 'The passage describes electrical signals carried through long wires.')
],
[
'British Geological Survey, The Carrington Event — Original London magnetic observations, September flare effects, historical reconstructions and uncertainty: https://www.geomag.bgs.ac.uk/education/carrington',
'Natural Resources Canada, Chronology of effects — Contemporary accounts of telegraph shocks, sparks, interruptions and battery-disconnected operation: https://www.spaceweather.gc.ca/tech/se-chr-en.php',
'NOAA NESDIS / NASA Space Place, What Was the Carrington Event? — Solar origin, low-latitude auroras and infrastructure exposure; simple recurrence estimates are not repeated: https://www.nesdis.noaa.gov/about/k-12-education/space-weather/what-was-the-carrington-event',
'NASA Science, Solar Flares FAQs — Radiation from flares and distinction from coronal mass ejections: https://science.nasa.gov/blogs/solar-cycle-25/2022/06/10/solar-flares-faqs/'
],
[
'Reviewed against all 105 existing events and the four new subjects. This space-weather event is distinct from the 1919 eclipse, Sputnik and the Higgs discovery.',
'A solar flare and a coronal mass ejection are related but distinct; visible aurora is not itself the electrical current in a telegraph wire. Carrington viewed a projected image, not the Sun directly.',
'Reports of lines operating with batteries disconnected describe temporary, local effects. No assertion is made that every telegraph failed or worked in the same way.',
'No precise storm-ranking number, fixed recurrence interval, present-day cost estimate or prediction of inevitable global collapse is asserted. Old instrument coverage limits comparisons.'
])

draft(109, 'velvet-revolution-czechoslovakia-1989', identities[3][2], 'World Events and Political Change',
      'Student protests grew into demonstrations, a general strike and negotiations that ended Communist Party dominance and opened a democratic transition in Czechoslovakia.',
'''For decades, Czechoslovakia's Communist Party controlled political life. After the reform movement of 1968 was crushed, **censorship** and repression restricted public debate. **Dissidents**, including playwright Václav Havel, continued to demand respect for human rights.

By 1989, communist governments across Eastern Europe were facing growing challenges. Changes in Soviet policy reduced the prospect of intervention to preserve them. In Czechoslovakia, frustration with political restrictions helped create pressure for change.

On November 17, police attacked a peaceful student march in Prague. This **crackdown** brought wider anger rather than silence. Students and actors organised strikes, and large crowds gathered to demand an investigation and political reform.

On November 19, opposition figures formed Civic Forum, with Havel becoming a leading voice. Public Against Violence emerged in Slovakia. These movements brought different groups into a broad **coalition** and helped organise dialogue with the authorities.

Workers joined the pressure. A two-hour general **strike** on November 27 demonstrated support beyond universities and theatres. Mass demonstrations and **negotiations** weakened the leadership's ability to maintain one-party control.

On November 29, the Federal Assembly removed the **constitutional** guarantee of the Communist Party's leading role. A new government followed in December, and President Gustáv Husák resigned. Institutional change accompanied the protests in the streets.

On December 29, the Federal Assembly elected Havel president. Free parliamentary elections followed in June 1990. Building democratic institutions and changing the economy required further work; the removal of one-party rule did not settle every social problem.

The name Velvet Revolution refers to the largely peaceful transfer of power. It does not erase the violence against demonstrators that helped trigger it. The movement depended on collective action as well as prominent leaders. Czechoslovakia's peaceful division into two states in January 1993 was a later, separate development in the region's **transition**.''',
[
v('censorship', 'The suppression or control of material that people may publish, read, see or hear.', 'Censorship limited public criticism of the government.', 'Uncountable noun'),
v('dissident', 'A person who openly disagrees with an established political system or official policy.', 'The dissident continued to campaign for civil rights.', 'Noun', form='Dissidents', plural='dissidents'),
v('crackdown', 'A forceful action by authorities to stop or control an activity or group.', 'The crackdown on the march caused public outrage.', 'Noun', plural='crackdowns'),
v('coalition', 'An alliance of different groups working together towards a shared purpose.', 'The coalition united students, workers and opposition leaders.', 'Noun', plural='coalitions'),
v('strike', 'An organised refusal to work as a form of protest.', 'Workers joined the strike to demand political change.', 'Noun', plural='strikes'),
v('negotiation', 'Discussion intended to reach an agreement between different sides.', 'The negotiation produced a plan for political reform.', 'Noun', form='negotiations', plural='negotiations'),
v('constitutional', 'Relating to a country’s basic legal rules and institutions.', 'The assembly approved a constitutional change.', 'Adjective'),
v('transition', 'The process of changing from one condition or system to another.', 'The transition to democracy involved many institutions.', 'Noun', plural='transitions')
],
[
m('What effect did the police attack on November 17 have?', ['It ended public protest by persuading students to accept one-party rule.', 'It brought wider anger and encouraged protests and strikes.', 'It immediately created two independent states.'], 'B', 'This crackdown brought wider anger rather than silence.', 'The next sentence describes students, actors and large crowds taking action.'),
m('What does the general strike show about the movement?', ['Support extended beyond students and actors to include workers.', 'Negotiations were unnecessary because every institution had already changed.', 'Only members of Civic Forum took part in the movement.'], 'A', 'A two-hour general strike on November 27 demonstrated support beyond universities and theatres.', 'The strike is presented as part of a broader coalition and pressure for change.'),
m('Why does the passage qualify the term Velvet Revolution?', ['The name refers to an election held after the state split in 1993.', 'The transfer was peaceful because police never used force against protesters.', 'The transfer was largely peaceful, although violence helped trigger the movement.'], 'C', 'It does not erase the violence against demonstrators that helped trigger it.', 'The passage distinguishes the character of the transfer from the police attack at the beginning.'),
g('The student march attacked by police took place in ___.', 'Prague', 'On November 17, police attacked a peaceful student march in Prague.', 'The city was an important centre of the protests.'),
g('The general strike took place on November ___.', '27', 'A two-hour general strike on November 27 demonstrated support beyond universities and theatres.', 'The strike followed the student march and formation of opposition movements.'),
g('The Federal Assembly elected ___ president on December 29.', 'Havel', 'On December 29, the Federal Assembly elected Havel president.', 'The election preceded free parliamentary elections in June 1990.')
],
[
'Museum of Prague, The Velvet Revolution — Original posters and documentation: November 17 violence, November 19 Civic Forum, November 27 strike, November 29 constitutional change, December government, Havel and June elections: https://www.muzeumprahy.cz/en/for-schools-museum-on-line-on-line-exhibitions-the-velvet-revolution/',
'Czech Ministry of Foreign Affairs, In the Footsteps of Václav Havel in Prague — Police violence, demonstrations, dialogue and free elections: https://mzv.gov.cz/stockholm/en/information_about_the_czech_republic/tourist_information/news/in_the_footsteps_of_vaclav_havel_in.html',
'Czech Ministry of Foreign Affairs, Václav Havel biography — Federal Assembly election December 29 and subsequent free elections: https://mzv.gov.cz/file/750626/VaclavHavelBio.pdf',
'Czech Historical Atlas, November 1989 — Czech and Slovak movements, Public Against Violence and the later January 1993 state division: https://cha.fsv.cvut.cz/en/mapp.php?map=6Cd'
],
[
'Compared against the complete topic ledger. The 1989 end of one-party rule is distinct from lesson 099’s 1968 Prague Spring and from the fall of the Berlin Wall.',
'Czechoslovakia is the country of the events, not the later Czech Republic alone. Slovak participation remains explicit. No disputed exact crowd size or strike-participation percentage is repeated.',
'The largely peaceful transfer does not deny the November 17 police violence. The false report of a student death is omitted rather than repeated as fact.',
'The Federal Assembly elected Havel; he was not chosen in a December popular presidential vote. The 1990 elections and January 1993 division are later developments, not events on the night of the first march.'
])

draft(110, 'darwin-wallace-natural-selection-1858-1859', identities[4][2], 'Science and Major Discoveries',
      'Long observation and two independent lines of thinking brought natural selection into public debate, followed by Darwin’s influential book and later scientific development.',
'''In the early nineteenth century, fossils and geology raised questions about the history of life. Many people regarded species as fixed. Charles Darwin's voyage on HMS Beagle from 1831 to 1836 gave him observations that challenged simple explanations of nature.

Darwin studied fossils, collected **specimens** and compared related organisms in different places. Back in Britain, he investigated breeding and **variation** for many years. His explanation developed gradually, rather than arriving fully formed during one visit to an island.

Within a population, individuals differ, and some differences are **inherited**. More **offspring** are produced than can all survive and **reproduce**. In particular conditions, individuals with certain inherited traits may leave more descendants. Over generations, those traits can become more common.

This process is natural selection. It can produce **adaptation** to a local environment. Individuals do not acquire whatever trait they need simply by wishing or trying. Success depends on reproductive outcomes in particular conditions, not on being strongest in every possible situation.

Naturalist Alfred Russel Wallace independently developed a related explanation while working in the Malay Archipelago. In 1858, he sent an essay to Darwin. Material from both men was presented at the Linnean Society in London on July 1.

On November 24, 1859, Darwin published On the Origin of Species. The book assembled evidence for species changing through time and descending from common **ancestors**. Natural selection offered a **mechanism** explaining how important changes could accumulate.

The arguments produced scientific and public debate. Acceptance was neither immediate nor uniform, and important questions remained. Darwin did not know genes and DNA as they are understood today. Later genetics helped explain inheritance and expanded evolutionary theory.

The publication transformed biology, but it was part of a continuing investigation. Modern evolutionary science includes several processes as well as natural selection. The story combines long observation, independent contributions, evidence and revision; it does not describe a ladder on which every organism advances towards perfection.''',
[
v('specimen', 'An individual object, organism or sample collected for examination or study.', 'The researcher compared each specimen with the museum collection.', 'Noun', form='specimens', plural='specimens'),
v('variation', 'Differences in characteristics among members of a group.', 'The population showed variation in size and colour.', 'Uncountable noun'),
v('inherit', 'To receive a characteristic or genetic material from parents or earlier generations.', 'An animal may inherit a trait that affects its survival.', 'Verb', form='inherited', verb=('inherit','inherited','inherited',False)),
v('offspring', 'The young produced by an organism.', 'Some birds produced more surviving offspring than others.', 'Noun', plural='offspring', note='The singular and plural forms are the same.'),
v('reproduce', 'To produce new living organisms of the same kind.', 'The plants must survive long enough to reproduce.', 'Verb', verb=('reproduce','reproduced','reproduced',False)),
v('adaptation', 'An inherited feature, or the process of evolutionary change, that makes organisms better suited to particular conditions.', 'The adaptation helped the population survive in a dry environment.', 'Noun', plural='adaptations'),
v('ancestor', 'An organism or person from which a later organism or person is descended.', 'The two species share a common ancestor.', 'Noun', form='ancestors', plural='ancestors'),
v('mechanism', 'A process or system through which an effect is produced.', 'The theory proposed a mechanism for evolutionary change.', 'Noun', plural='mechanisms')
],
[
m('How does the passage explain natural selection?', ['Individuals develop any useful trait because they need it during their lives.', 'Inherited traits can become more common when their carriers leave more descendants.', 'Every species moves towards the same final and perfect form.'], 'B', 'Over generations, those traits can become more common.', 'The preceding sentences link inherited differences with unequal reproductive outcomes.'),
m('What role did Wallace play?', ['He collected Darwin’s book after publication and first supplied its evidence in 1859.', 'He showed that related organisms could never descend from common ancestors.', 'He developed a related explanation independently, and material from both men was presented in 1858.'], 'C', 'Naturalist Alfred Russel Wallace independently developed a related explanation while working in the Malay Archipelago.', 'The next sentences describe his essay and the joint presentation at the Linnean Society.'),
m('How does the passage place Darwin’s book within later science?', ['It was transformative, while later evidence and genetics developed the theory further.', 'It supplied a complete account of DNA and ended debate about inheritance.', 'It established natural selection as the only possible process in evolution.'], 'A', 'Later genetics helped explain inheritance and expanded evolutionary theory.', 'The final paragraph also recognises several evolutionary processes and continuing investigation.'),
g('Material from Darwin and Wallace was presented in ___.', '1858', 'In 1858, he sent an essay to Darwin. Material from both men was presented at the Linnean Society in London on July 1.', 'The essay and presentation are placed in the same year.'),
g('On the Origin of Species was published in ___.', '1859', 'On November 24, 1859, Darwin published On the Origin of Species.', 'The book followed the earlier public presentation.'),
g('Darwin’s independent counterpart was Alfred Russel ___.', 'Wallace', 'Naturalist Alfred Russel Wallace independently developed a related explanation while working in the Malay Archipelago.', 'The passage recognises Wallace’s independent contribution.')
],
[
'Cambridge University, Darwin Correspondence Project, Darwin timeline — Beagle voyage, years of work, 1858 announcement and November 24, 1859 publication: https://www.darwinproject.ac.uk/learning-resources/timeline',
'The Linnean Society, Alfred Russel Wallace — Independent work in the Malay Archipelago, essay and joint July 1, 1858 paper: https://www.linnean.org/the-society/history-of-science/alfred-russel-wallace',
'Darwin and Wallace, 1858 original paper, Darwin Online — Primary text of the explanations and joint presentation: https://darwin-online.org.uk/converted/published/1858_species_F350.html',
'Darwin, 1859, On the Origin of Species, first edition, Darwin Online — Original book: variation, struggle, natural selection, ancestry and limits of contemporary inheritance knowledge: https://darwin-online.org.uk/converted/published/1859_Origin_F373/1859_Origin_F373.html'
],
[
'Compared with all earlier topics. This explanation and publication event is distinct from the DNA double helix, Human Genome Project, cloning and Higgs discovery.',
'Darwin did not formulate the complete theory instantly in the Galápagos. Wallace developed a related explanation independently; joint presentation in 1858 and book publication in 1859 are distinct.',
'Variation, inheritance, unequal reproduction and population change over generations are kept separate from an individual acquiring needed traits. Evolution has no inevitable ladder or goal of perfection.',
'Natural selection is not asserted to be the only evolutionary process. Modern genetics is later knowledge; no modern DNA mechanism is attributed to Darwin’s 1859 book.'
])
