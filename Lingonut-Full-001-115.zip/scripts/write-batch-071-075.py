"""Source-reviewed biographies, national history and world events for 071–075."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(71, 'napoleon-life-waterloo-and-exile', 'Napoleon: Rise, Waterloo and Final Exile', 'Lives and Historical Turning Points',
      'Napoleon rose from army officer to emperor, reshaped French institutions, fought costly wars across Europe and ended his rule after Waterloo and a second exile.',
'''Napoleon Bonaparte was born in 1769 on Corsica, an island that had recently come under French control. He attended military schools and became an **artillery** officer. The French Revolution disrupted the old political order, creating opportunities for his rise. Victories in Italy established his military reputation.

In 1799, Napoleon helped overthrow the government in a **coup**. He became First Consul and concentrated power in his own hands. In 1804, he became Emperor of the French, turning military and political success into personal imperial rule.

His government introduced important **reforms** in administration, education and finance. Working with legal experts, he helped establish the Civil Code, which brought common rules to areas such as property and family life. It influenced laws beyond France, but restricted married women's independence.

Napoleon also imposed **censorship**, limited opposition and restored slavery in parts of the French colonial empire. His institutions combined lasting changes with strong personal authority and unequal rights.

War expanded French influence across Europe. Napoleon placed relatives and supporters on foreign thrones, while European powers formed **coalitions** against him. His victories spread some French institutions, but the campaigns brought destruction and heavy demands on soldiers and civilians.

The invasion of Russia in 1812 ended disastrously, with enormous losses. Further defeats weakened his position. In 1814, he **abdicated** and was sent into **exile** on Elba, near Italy.

Napoleon returned to France in 1815 and briefly regained power. On June 18, his army faced Wellington's multinational allied force at Waterloo, in present-day Belgium. Wellington held his position until Prussian **reinforcements** under Blücher joined the battle. The French army was defeated.

Napoleon gave up power again. British authorities sent him to Saint Helena, a remote island in the South Atlantic. He died there on May 5, 1821.

His **legacy** extended beyond his empire's defeat. Legal and administrative changes survived, while memories of conquest, slavery and concentrated power shaped judgments of his rule. Waterloo ended his return to power, but understanding his life requires both the institutions he changed and the human costs of his ambition.''',
[
v('artillery', 'Large military guns and the units that operate them.', 'The museum displayed equipment used by an artillery unit.', 'Uncountable noun'),
v('coup', 'A sudden seizure of government power outside the usual legal or constitutional process.', 'The coup removed the existing government.', 'Noun', plural='coups'),
v('reform', 'A change intended to improve or reorganize a system, law or institution.', 'The reform changed the way local officials were appointed.', 'Noun', form='reforms', plural='reforms'),
v('censorship', 'The control or suppression of information, writing or other expression by an authority.', 'Censorship prevented some newspapers from publishing criticism.', 'Uncountable noun'),
v('coalition', 'An alliance of separate groups or countries working toward a shared aim.', 'Several countries joined the coalition.', 'Noun', form='coalitions', plural='coalitions'),
v('abdicate', 'To formally give up a position as king, queen or another sovereign ruler.', 'The ruler decided to abdicate after losing support.', 'Verb', form='abdicated', verb=('abdicate','abdicated','abdicated',False)),
v('exile', 'A condition of being forced or required to live away from one’s own country or home.', 'He spent his final years in exile.', 'Uncountable noun'),
v('reinforcement', 'An additional person or group sent to strengthen an existing force or team.', 'The arrival of reinforcements changed the balance of the battle.', 'Noun', form='reinforcements', plural='reinforcements', note='Usually plural when referring to additional troops.'),
v('legacy', 'A lasting effect, achievement or problem left by a person or event.', 'The ruler’s legacy included laws and institutions that survived him.', 'Noun', plural='legacies')
],
[
m('Which description best represents Napoleon’s domestic rule?', ['It combined institutional reforms with censorship, unequal rights and personal power.', 'It removed centralized government and gave full independence to every region.', 'It dealt only with military affairs and introduced no lasting legal changes.'], 'A', 'His institutions combined lasting changes with strong personal authority and unequal rights.', 'The Civil Code and administrative changes coexisted with restrictions and colonial slavery.'),
m('Which forces contributed to Napoleon’s defeat at Waterloo?', ['The French army and a Russian army defending Elba.', 'Wellington’s multinational army and Blücher’s Prussian reinforcements.', 'A British army fighting alone, without any allied forces.'], 'B', "Wellington held his position until Prussian reinforcements under Blücher joined the battle.", 'The preceding sentence identifies Wellington’s multinational allied force.'),
m('What was Napoleon’s final fate?', ['He returned from Saint Helena to become emperor again.', 'He died on Elba before Waterloo took place.', 'He was sent to Saint Helena and died there in 1821.'], 'C', 'British authorities sent him to Saint Helena, a remote island in the South Atlantic. He died there on May 5, 1821.', 'Elba was the first exile; Saint Helena followed the final defeat.'),
g('Napoleon was born on the island of ___.', 'Corsica', 'Napoleon Bonaparte was born in 1769 on Corsica, an island that had recently come under French control.', 'Corsica was his birthplace before his military career in France.'),
g('The disastrous invasion of Russia took place in ___.', '1812', 'The invasion of Russia in 1812 ended disastrously, with enormous losses.', 'Further defeats followed before his first abdication.'),
g('Napoleon’s first island of exile was ___.', 'Elba', 'In 1814, he abdicated and was sent into exile on Elba, near Italy.', 'He returned from Elba in 1815 before the final defeat.')
],
[
'Fondation Napoléon, Consulate and First Empire chronology — Birth, military education, rise, coup, empire, Russia, two abdications and exiles: https://www.napoleon.org/en/young-historians/napodoc/timeline-consulate1st-french-empire/',
'Fondation Napoléon, Civil Code historical overview — Legal experts, scope, influence and married women’s restricted position: https://www.napoleon.org/en/history-of-the-two-empires/articles/the-french-civil-code-or-code-civil-21-march-1804-an-overview/',
'French National Assembly, historical account — Restoration and maintenance of colonial slavery, with regional differences: https://www.assemblee-nationale.fr/dyn/histoire-et-patrimoine/consulat-et-premier-empire/retablissement-progressif-de-l-esclavage',
'Bibliothèque nationale de France, original 1810 press-control report — Censorship and newspaper restrictions: https://presselocaleancienne.bnf.fr/html/rapport-1810-journaux',
'National Army Museum, Battle of Waterloo — June 18, 1815, multinational allied force, Prussian arrival and French defeat: https://www.nam.ac.uk/explore/battle-waterloo',
'Palace of Versailles, Napoleon biography — Public life and institutional legacy, corroborating the chronology: https://en.chateauversailles.fr/discover/history/great-characters/napoleon-i'
],
[
'Explicitly requested whole-life overview includes Corsican origins and military rise, power and reforms, authoritarian and colonial policies, European warfare, Russia, first fall, return and Waterloo, final exile and death. Waterloo is substantial but does not displace the broader life.',
'Elba in 1814 and Saint Helena after 1815 are separate exiles. Waterloo is June 18, 1815, not a British-only victory. Wellington’s multinational force and Blücher’s Prussians both appear.',
'The Civil Code was developed with legal experts; Napoleon did not personally write every provision. Unequal rights for women and colonial slavery qualify any supposed universal equality.',
'No exact aggregate war-death total, sole weather explanation for Russia, disputed poisoning diagnosis or battle instructions. His death date and place stand without a speculative medical cause.',
'Compared with all 001–070 and the other new subjects. Napoleon’s incidental appearance in the Rosetta Stone context is not a prior biography; this lesson now owns the rise–Waterloo–exile life arc and must not be retold as a new biography. Identity and aliases are registered in content/topics.json.'
])

draft(72, 'qin-shi-huang-unification-and-rule', 'Qin Shi Huang: Unification and the Cost of Empire', 'Lives and Historical Turning Points',
      'China’s first emperor united rival kingdoms, imposed common systems and concentrated power, while harsh punishments and compulsory labor burdened the population.',
'''Qin Shi Huang was born Ying Zheng in 259 BCE, when the lands of ancient China were divided among competing states. He became king of Qin at thirteen. The kingdom already possessed strong institutions and military resources, which helped him pursue control over its rivals.

By 221 BCE, Qin armies had **conquered** six rival kingdoms. Their territories were **unified** under a new imperial government. Zheng adopted the title Qin Shi Huang, the First Emperor of Qin. His victory changed the political structure of the region.

Power became highly **centralized**. Officials appointed by the imperial government administered local regions. Common **standards** for writing, money, weights and measures helped connect territories that had previously used different systems. Roads supported movement and government communication.

These changes came with heavy demands on ordinary people. Large projects required **compulsory** labor, including work on roads, defensive walls and the emperor's burial complex. Laws imposed severe **punishments**, and the state demanded obedience. Resentment grew under these burdens.

Control also extended to ideas. In 213 BCE, the emperor approved measures to **suppress** certain writings and rival historical traditions. Private copies of selected texts were ordered destroyed. This did not mean that every kind of book disappeared. Later accounts also accused him of killing scholars, but historians debate the details.

The emperor sought ways to escape death, while preparing an enormous **mausoleum**. Its surrounding complex included the Terracotta Army, thousands of clay figures intended to accompany him after death. The central burial chamber has not been excavated.

He died in 210 BCE while travelling. Struggles over power and widespread rebellion followed. By 206 BCE, the Qin **dynasty** had fallen, despite its founder's ambition to create an enduring imperial order.

Later rulers retained important elements of centralized government and common administration. Qin Shi Huang's reign therefore left institutions that outlasted his dynasty. His reputation also reflects the coercion, loss of cultural material and suffering associated with his rule. The contrast between an enduring imperial system and a short-lived dynasty remains central to assessments of his reign.''',
[
v('conquer', 'To take control of a place or people by military force.', 'The army attempted to conquer the neighboring kingdom.', 'Verb', form='conquered', verb=('conquer','conquered','conquered',False)),
v('unify', 'To bring separate groups or territories together under one system or authority.', 'The ruler tried to unify the competing states.', 'Verb', form='unified', verb=('unify','unified','unified',False)),
v('centralize', 'To bring power, control or activities under one main authority or location.', 'The government decided to centralize tax administration.', 'Verb', form='centralized', verb=('centralize','centralized','centralized',False)),
v('standard', 'An established rule, model or measure used as a common reference.', 'The common standard made measurements easier to compare.', 'Noun', form='standards', plural='standards'),
v('compulsory', 'Required by a rule or authority rather than left to personal choice.', 'The state introduced compulsory service.', 'Adjective'),
v('punishment', 'A penalty imposed on someone for breaking a law or rule.', 'The law introduced a severe punishment for the offense.', 'Noun', form='punishments', plural='punishments'),
v('suppress', 'To use authority or force to prevent an activity, idea or opposition from spreading.', 'The authorities tried to suppress public criticism.', 'Verb', verb=('suppress','suppressed','suppressed',False)),
v('mausoleum', 'A large building or monument containing or intended to contain a tomb.', 'The mausoleum formed part of a larger burial complex.', 'Noun', plural='mausoleums'),
v('dynasty', 'A succession of rulers from the same family.', 'The dynasty remained in power for several generations.', 'Noun', plural='dynasties')
],
[
m('What helped connect the previously separate territories?', ['Removing all officials and leaving every local system unchanged.', 'Common standards and administration under the imperial government.', 'Allowing the six defeated kingdoms to remain fully independent.'], 'B', 'Common standards for writing, money, weights and measures helped connect territories that had previously used different systems.', 'The new political structure also placed regions under centrally appointed officials.'),
m('Which description of the book policy is supported by the account?', ['Every book of every kind was destroyed across China.', 'Only the emperor’s own burial records were restricted.', 'Selected writings were targeted, while later scholar-killing accounts remain debated.'], 'C', 'Private copies of selected texts were ordered destroyed.', 'The next two sentences reject total destruction and acknowledge disputed later accounts.'),
m('What happened to the Qin dynasty and its institutions?', ['The dynasty fell quickly, but important administrative ideas survived.', 'The dynasty continued without interruption until modern times.', 'All forms of centralized government disappeared after the emperor’s death.'], 'A', 'Later rulers retained important elements of centralized government and common administration.', 'The earlier paragraph distinguishes the fall of the dynasty from its longer institutional influence.'),
g('Qin completed its conquest of the six rival kingdoms by ___ BCE.', '221', 'By 221 BCE, Qin armies had conquered six rival kingdoms.', '221 BCE marks the change from rival kingdoms to the new imperial order.'),
g('The clay figures in the burial complex are known as the Terracotta ___.', 'Army', 'Its surrounding complex included the Terracotta Army, thousands of clay figures intended to accompany him after death.', 'The figures belong to the surrounding complex; the central chamber remains unexcavated.'),
g('Qin Shi Huang died in ___ BCE.', '210', 'He died in 210 BCE while travelling.', 'His death was followed by struggles over power and rebellion.')
],
[
'Art Gallery of New South Wales, First Emperor education notes — Birth, age at kingship, imperial life and death: https://media.artgallery.nsw.gov.au/downloads/files/First-Emperor-education-notes.pdf',
'National Museum of China, Qin and Han historical overview — Six conquests, 221 BCE, central administration, standards, labor, punishments, rebellion and 206 BCE: https://www.chnmuseum.cn/portals/0/web/zt/gudai/detail4.html',
'National Museum of China, inscribed decree plate — Archaeological evidence of the 221 BCE common weights-and-measures order: https://www.chnmuseum.cn/zp/zpml/csp/202008/t20200826_247416.shtml',
'Columbia University, Li Si memorials as recorded by Sima Qian — Selected book destruction and source cautions about later Han perspectives: https://afe.easia.columbia.edu/main_pop/ps/ps_china-lisi-legalist-memorials.htm',
'UCLA, historian Anthony Barbieri-Low — Well-supported book policy distinguished from the debated allegation of buried Confucian scholars: https://international.ucla.edu/asc/article/110226',
'UNESCO, Mausoleum of the First Qin Emperor — Imperial burial complex and Terracotta Army: https://whc.unesco.org/en/list/441/',
'National Museum of Australia, current exhibition — Search for immortality and unopened central chamber: https://www.nma.gov.au/warriors',
'Metropolitan Museum of Art, Qin dynasty — Institutional legacy; its erroneous age-nine accession detail is not used: https://www.metmuseum.org/essays/qin-dynasty-221-206-b-c'
],
[
'Requested harsh-ruler biography is framed around unification and its human costs, not an unprovable objective cruelest-emperor ranking. It covers origins, kingship, conquest, centralization, standards, coercion, ideas, death, collapse and legacy.',
'King of Qin at thirteen is distinct from emperor in 221 BCE. By 206 BCE accommodates differing institutional endpoints for the short dynasty. China is not described as permanently united or identical to its modern boundaries.',
'Common standards were imposed and extended; he did not invent all writing, money or measurement. No claim that he built the entire surviving Great Wall.',
'Book policy targeted selected texts; not every book was destroyed. Killing-scholars allegations remain explicitly debated, without repeating a disputed exact number or method as established fact.',
'The Terracotta Army belongs to the surrounding burial complex, not an excavated central chamber. No mercury-poisoning death diagnosis, elixir formula, precise forced-labor death total or sensational tomb claim.',
'Compared with all 001–071 and the other new subjects. Qin imperial unification and this ruler’s life are distinct from the Cultural Revolution and earlier archaeological discoveries. Identity and aliases are registered in content/topics.json.'
])

draft(73, 'genghis-khan-life-mongol-unification-and-conquests', 'Genghis Khan: From Divided Tribes to an Expanding Empire', 'Lives and Historical Turning Points',
      'Temujin united steppe peoples, founded the Mongol Empire and launched conquests whose political and cultural consequences were inseparable from widespread destruction.',
'''Genghis Khan was born Temujin in northeastern Mongolia during the 12th century. His exact birth year is uncertain. Many families in the region followed a **nomadic** way of life, moving with their animals across grasslands. Different groups formed **alliances**, traded and fought over power and resources.

Accounts of Temujin's childhood describe his father's death and years of hardship for his family. Much of this early story survives in later narratives that combine history with legend. His rise began within a world of shifting loyalties and powerful **rivals**.

Temujin gained followers through alliances and victories over competing leaders. In 1206, an **assembly** of nobles recognized his authority and gave him the title Genghis Khan. Uniting many steppe peoples provided the foundation for a state capable of much wider expansion.

His armies then fought beyond Mongolia. They attacked states in northern China, taking the city now known as Beijing in 1215. From 1219, they invaded the Khwarazmian Empire in Central Asia. These **conquests** destroyed cities, killed civilians and caused widespread **displacement**. Their human cost cannot be reliably reduced to a single precise death total.

Ruling the conquered territories required more than military power. Genghis Khan encouraged written records and drew on people with administrative skills. He supported **merchants** and craftspeople, whose work served the growing state. His policies generally permitted different religious traditions, although this **tolerance** existed alongside demands for obedience and violent conquest.

He died in 1227 during a campaign against Western Xia, a state in northwestern China. The precise cause of his death remains uncertain. His **successors** continued expanding the empire well beyond the territory he had personally controlled.

The later Mongol Empire became the largest continuous land empire in history, connecting much of Asia with parts of Europe. These connections moved goods, knowledge and people across great distances, sometimes through cooperation and sometimes through coercion.

Genghis Khan's life reshaped Mongolia and the wider world. The state he founded created new political and cultural connections, while its expansion left deep suffering in many conquered societies.''',
[
v('nomadic', 'Moving from place to place rather than living permanently in one location.', 'The nomadic families moved with their herds.', 'Adjective'),
v('alliance', 'An agreement or relationship in which people or groups cooperate for a shared purpose.', 'The leaders formed an alliance against a common rival.', 'Noun', form='alliances', plural='alliances'),
v('rival', 'A person or group competing with another for the same goal or advantage.', 'The two rivals competed for political support.', 'Noun', form='rivals', plural='rivals'),
v('assembly', 'A gathering of people for discussion, decisions or a shared purpose.', 'The assembly recognized the new leader.', 'Noun', plural='assemblies'),
v('conquest', 'The act or result of taking control of a place by military force.', 'The conquest changed the political leadership of the region.', 'Noun', form='conquests', plural='conquests'),
v('displacement', 'The forced movement of people from their homes or usual places of residence.', 'The fighting caused displacement across the region.', 'Uncountable noun'),
v('merchant', 'A person whose work is buying and selling goods, often in large quantities.', 'The merchant carried goods between several cities.', 'Noun', form='merchants', plural='merchants'),
v('tolerance', 'Acceptance of beliefs or practices different from one’s own.', 'Religious tolerance allowed several communities to continue their traditions.', 'Uncountable noun'),
v('successor', 'A person who takes a position or role after someone else.', 'The ruler’s successor continued some of his policies.', 'Noun', form='successors', plural='successors')
],
[
m('Why was the unification of steppe peoples important?', ['It ended all further wars outside Mongolia.', 'It placed every Asian kingdom under his control immediately.', 'It provided a foundation for a state capable of wider expansion.'], 'C', 'Uniting many steppe peoples provided the foundation for a state capable of much wider expansion.', 'The later campaigns followed the consolidation of his authority.'),
m('Which description best represents the government’s broader policies?', ['It supported records, trade and religious traditions while demanding obedience.', 'It rejected writing and prevented all merchant activity.', 'Religious tolerance meant conquered populations faced no violence or coercion.'], 'A', 'His policies generally permitted different religious traditions, although this tolerance existed alongside demands for obedience and violent conquest.', 'The paragraph also describes written records, administrators, merchants and craftspeople.'),
m('How did the empire develop after his death?', ['It immediately disappeared without any further expansion.', 'His successors expanded it beyond the territory he had personally controlled.', 'He personally led its later expansion into Europe.'], 'B', 'His successors continued expanding the empire well beyond the territory he had personally controlled.', 'The later maximum extent should not be attributed to his own lifetime alone.'),
g('Genghis Khan’s birth name was ___.', 'Temujin', 'Genghis Khan was born Temujin in northeastern Mongolia during the 12th century.', 'The title Genghis Khan came later in his rise.'),
g('The assembly recognized him as Genghis Khan in ___.', '1206', 'In 1206, an assembly of nobles recognized his authority and gave him the title Genghis Khan.', 'This followed his consolidation of authority among steppe peoples.'),
g('He died during a campaign in ___.', '1227', 'He died in 1227 during a campaign against Western Xia, a state in northwestern China.', 'The year and campaign are identified, while the cause of death remains uncertain.')
],
[
'David O. Morgan, Encyclopaedia Iranica, Chingiz Khan — Scholar-authored biography and campaigns: https://www.iranicaonline.org/articles/cengiz-khan/',
'Columbia University, Mongols in World History, early life — Uncertain birth year, childhood sources and steppe setting: https://afe.easia.columbia.edu/mongols/figures/figures.htm',
'Columbia University, Mongol unity — Temujin, alliances and the 1206 assembly: https://afe.easia.columbia.edu/mongols/figures/figu_geng_unity.htm',
'Columbia University, governing legacy — Written language, merchants, craftspeople and religious policies: https://afe.easia.columbia.edu/mongols/figures/figu_geng_legacy.htm',
'Columbia University, main campaigns — Northern China, Beijing in 1215, Central Asia and destruction: https://afe.easia.columbia.edu/mongols/conquests/conquests_2c.htm',
'Metropolitan Museum of Art, The Legacy of Genghis Khan — Later expansion under descendants, government and cultural exchange; loose largest-ever wording is qualified as continuous land empire: https://www.metmuseum.org/essays/the-legacy-of-genghis-khan',
'Peter Jackson, Encyclopaedia Iranica, Yasa — Cautions against treating a complete surviving written law code as established: https://www.iranicaonline.org/articles/yasa-law-code/',
'Columbia University, death and burial traditions — Used only to identify the 1227 death and later legendary accounts; its return-from-Central-Asia wording is not the campaign chronology followed here. Morgan supplies the Western Xia campaign chronology: https://afe.easia.columbia.edu/mongols/figures/figu_geng_death.htm'
],
[
'Explicitly requested whole-life overview covers the steppe setting and uncertain early history, alliances and unification, 1206 title, major expansion, civilian destruction, administration, trade, religious policies, death and later imperial consequences.',
'The birth year is not fixed at a disputed exact value and no exercise tests an exact age. Later narrative sources are identified as combining history and legend. The 1206 assembly is not described as a modern democratic election.',
'The narrative does not credit him with all China, the later capture of Baghdad, European campaigns or the empire’s maximum extent. Later expansion belongs explicitly to successors.',
'The qualified continuous land empire describes the later Mongol Empire, not the largest empire of every kind. Trade and cultural connections do not excuse conquest, civilian deaths or coerced movement.',
'No exact aggregate death toll, confirmed medical cause of death, complete surviving Great Yasa, military tactics or glorification of mass violence.',
'Compared with all 001–072 and the other new subjects. This is the Mongol founder’s life and state-building arc, distinct from Qin imperial unification and modern Chinese history. Identity and aliases are registered in content/topics.json.'
])

draft(74, 'north-korea-division-and-three-generation-rule', 'North Korea: Division, War and Three Generations of Rule', 'Countries and Historical Turning Points',
      'Colonial rule, Cold War division and war shaped North Korea, followed by three generations of Kim family leadership and continuing political, security and humanitarian concerns.',
'''North Korea occupies the northern part of the Korean **Peninsula**, with Pyongyang as its capital. Officially called the Democratic People's Republic of Korea, it shares a long Korean history with the country to its south. Its separate state emerged from the upheavals of the 20th century.

Korea was under Japanese **colonial** rule from 1910 to 1945. After Japan's defeat in World War II, Soviet troops occupied the north and American troops the south. Cold War **rivalry** and failed negotiations prevented a united government. Two separate states were established in 1948.

In June 1950, North Korea invaded South Korea. A United States-led UN force supported the South, while China entered on the North's side. The war devastated communities and separated families. An **armistice** stopped the fighting in July 1953, but no permanent peace treaty followed.

Kim Il Sung led North Korea from 1948 until his death in 1994, first as premier and later as president. His son, Kim Jong Il, led from 1994 to 2011 through party and defense positions. Political power remained concentrated around the ruling party and its leader.

Kim Jong Il's son, Kim Jong Un, has led since 2011. As of October 2026, he is general secretary of the Workers' Party of Korea and president of state affairs. Official positions changed across this **hereditary** **succession**; the three men did not hold an identical presidential office.

Economic crisis and food shortages caused severe suffering in the 1990s. The state still directs much economic activity, while markets help families obtain goods and income. The World Food Programme reports continuing food and **nutrition** problems.

The UN human rights office has reported severe **restrictions** on expression, information and movement. Nuclear and missile development have brought international **sanctions** and security tensions. In September 2026, the International Atomic Energy Agency expressed serious concern about continuing nuclear activity.

North Korea's history connects the unfinished division of the peninsula with concentrated family power and everyday struggles over livelihoods. Limited outside access makes many details of daily life difficult to verify.''',
[
v('peninsula', 'An area of land surrounded by water on most sides but connected to a larger land area.', 'The peninsula lies between two seas.', 'Noun', form='Peninsula', plural='peninsulas'),
v('colonial', 'Connected with a country’s control over another territory and its people.', 'The documents describe life under colonial rule.', 'Adjective'),
v('rivalry', 'Competition between people, groups or countries seeking similar goals or influence.', 'Political rivalry complicated the negotiations.', 'Noun', plural='rivalries'),
v('armistice', 'An agreement between opposing sides to stop fighting, without necessarily reaching a permanent peace settlement.', 'The armistice stopped major fighting along the front.', 'Noun', plural='armistices'),
v('hereditary', 'Passed from a parent or family member to another member of the same family.', 'The system concentrated hereditary power in one family.', 'Adjective'),
v('succession', 'The process by which one person takes a position or authority after another.', 'The succession brought a new generation to leadership.', 'Noun', plural='successions'),
v('nutrition', 'The process of obtaining and using food for health and growth, or the quality of that nourishment.', 'The program supported better nutrition for children.', 'Uncountable noun'),
v('restriction', 'A rule or action that limits what someone can do.', 'The restriction limited travel between regions.', 'Noun', form='restrictions', plural='restrictions'),
v('sanction', 'An official restrictive measure used to pressure a country, organization or person to change behavior.', 'The sanction limited certain financial transactions.', 'Noun', form='sanctions', plural='sanctions', note='Usually plural when referring to international economic restrictions.')
],
[
m('Why did a united Korean government fail to emerge after 1945?', ['Japan continued governing the entire peninsula after the war.', 'Cold War rivalry and failed negotiations reinforced the occupation division.', 'The 1953 armistice had already created two states.'], 'B', 'Cold War rivalry and failed negotiations prevented a united government.', 'Soviet and American occupation zones became the setting for separate state formation.'),
m('What did the 1953 agreement achieve?', ['A permanent peace treaty and immediate political reunification.', 'The transfer of both states to one shared government.', 'An end to the fighting through an armistice, without a permanent peace treaty.'], 'C', 'An armistice stopped the fighting in July 1953, but no permanent peace treaty followed.', 'An armistice stops fighting; the political division and unresolved settlement continued.'),
m('How should the three Kim leaders be described?', ['Three generations of family leadership whose formal offices differed.', 'Three presidents who held exactly the same office throughout.', 'Unrelated leaders chosen at three different international conferences.'], 'A', 'Official positions changed across this hereditary succession; the three men did not hold an identical presidential office.', 'The text distinguishes leadership continuity from changes in institutional titles.'),
g('North Korea’s capital is ___.', 'Pyongyang', 'North Korea occupies the northern part of the Korean Peninsula, with Pyongyang as its capital.', 'The opening identifies the capital and geographical setting.'),
g('The two separate states were established in ___.', '1948', 'Two separate states were established in 1948.', 'This followed the 1945 occupation division and preceded the Korean War.'),
g('Kim Jong Un has led the country since ___.', '2011', "Kim Jong Il's son, Kim Jong Un, has led since 2011.", 'His leadership began then, while particular formal appointments and titles changed later.')
],
[
'South Korean Ministry of Unification, regime establishment, August 2026 — Colonial and occupation setting, 1948 state and premier: https://nkinfo.unikorea.go.kr/nkp/pge/view.do?menuId=PO004',
'U.S. Office of the Historian, Korean War — Division, failed negotiations, North Korean invasion and international intervention: https://history.state.gov/milestones/1945-1952/korean-war',
'United Nations Command, historical account — July 1953 armistice and absence of a permanent peace treaty: https://www.unc.mil/history/1950-1953-korean-war-active-conflict/',
'South Korean Ministry of Unification, political system formation — Kim Il Sung’s premiership and presidency, 1994 death, changed state offices and 2011 succession: https://nkinfo.unikorea.go.kr/nkp/pge/view.do?menuId=PO005',
'South Korean Ministry of Unification, February 23, 2026 briefing — Reelection as Workers’ Party general secretary: https://www.unikorea.go.kr/web/eng_unikorea/bbs/bbs_0000000000000035/54795',
'South Korean Ministry of Unification, October 19, 2026 briefing — Current president of state affairs title: https://www.unikorea.go.kr/web/eng_unikorea/bbs/bbs_0000000000000035/54936',
'South Korean Ministry of Unification, state institutions — March 22, 2026 reelection and state-affairs office; Korean text checked because automatic translations carry a warning: https://nkinfo.unikorea.go.kr/nkp/pge/view.do?menuId=PO007',
'Joint FAO/WFP assessment, June 29, 1999 — Economic slowdown, disasters and severe food insecurity in the 1990s: https://www.fao.org/4/x2437e/x2437e00.htm',
'World Food Programme, country overview — Continuing food and nutrition concerns and household market activity; older statistics are not relabeled as 2026 totals: https://www.wfp.org/countries/democratic-peoples-republic-korea',
'UN human rights chief, March 16, 2026 statement — Restrictions on expression, information and movement; direct retrieval blocked, official UN index and institutional findings cross-checked: https://www.ohchr.org/en/statements-and-speeches/2026/03/high-commissioner-turk-urges-international-community-keep-dprk',
'UN OHCHR, September 12, 2025 — Reported restrictions and everyday economic pressures: https://www.ohchr.org/en/stories/2025/09/blocking-peoples-eyes-and-ears-human-rights-violations-democratic-peoples-republic',
'IAEA director general, September 7, 2026 — Attributed concern about continuing nuclear activity, not a detailed weapons assessment: https://www.iaea.org/newscenter/statements/iaea-director-generals-introductory-statement-to-the-board-of-governors-7-september-2026'
],
[
'Explicitly requested national-history overview covers geography and shared history, Japanese rule, occupation and Cold War causes of division, 1948 statehood, war and armistice, all three leadership generations, changing titles, economy, human rights and current security concerns.',
'Leadership spans are distinct from individual formal offices. Kim Il Sung was initially premier and later president; Kim Jong Il led through party and defense institutions; Kim Jong Un’s general-secretary and president-of-state-affairs titles are verified with 2026 primary material through October 19.',
'As of October 2026 dates the current-office statement. There is no invented fourth successor, unverified health or death rumor, or claim that the 2026 constitutional changes restored Kim Il Sung’s former presidency.',
'The 1950 invasion, US-led UN response and Chinese involvement are clear. The armistice stopped fighting, rather than providing a permanent peace treaty or reunification.',
'Rights findings and nuclear concerns are attributed to the relevant UN institutions. No claim all citizens think alike, everybody is starving, nobody has internet, or a specific current population or weapons total.',
'The 1990s crisis is historical context with no unverified mortality estimate. Market activity, food concerns and outside-access limits prevent reducing the population to its leadership alone.',
'Compared with all 001–073 and the remaining candidate. The country’s division and governing history are distinct from lesson 026’s specific Warmbier detention case, which is not retold. Identity and aliases are registered in content/topics.json.'
])

draft(75, 'russian-revolutions-1917', 'Russia 1917: Two Revolutions and a New Political Order', 'Revolutions and World History',
      'War, shortages and a crisis of authority brought down Russia’s monarchy, then its temporary government, opening the way to Bolshevik rule and civil war.',
'''In 1917, Russia experienced two revolutions that transformed its government and influenced politics around the world. The country was fighting in World War I under Emperor Nicholas II. Beneath the **monarchy**, many workers and peasants faced poor conditions and had little influence over political decisions.

Military defeats, rising prices and food **shortages** weakened confidence in the government. In Petrograd, now Saint Petersburg, women workers joined protests over bread supplies. **Strikes** and demonstrations spread, and soldiers began refusing orders to suppress the crowds.

Nicholas **abdicated**, ending centuries of Romanov rule. A **provisional** government took office, while workers' and soldiers' **councils**, known as soviets, also claimed authority. The first revolution had removed the emperor without creating an agreed solution to the country's problems.

The new government continued the war. Land reform moved too slowly for many peasants, and the economy deteriorated. Different political groups competed for support. Vladimir Lenin returned from exile and argued for peace, land redistribution and power for the soviets. His Bolshevik party gained influence among urban workers and soldiers.

Later that year, Bolshevik-led forces **seized** important locations in Petrograd and overthrew the provisional government. Lenin became head of the new government. The February and October Revolutions took place in March and November under today's calendar; their familiar names follow the calendar then used in Russia.

The Bolsheviks issued decrees on land and sought an end to the fighting. In March 1918, they accepted the Treaty of Brest-Litovsk, ending Russia's participation in World War I at a heavy territorial cost.

Peace abroad did not bring peace at home. **Civil war** involved the Bolsheviks, rival political and military groups, independence movements and foreign intervention. Fighting and economic breakdown brought enormous suffering. Bolshevik rule also became increasingly **repressive**, including the closure of an elected assembly.

The Soviet Union was established in 1922. The revolutions had opened hopes of social change while producing a new concentration of political power. Their consequences shaped communist movements, international rivalries and arguments about revolution throughout the 20th century.''',
[
v('monarchy', 'A system of government in which a king or queen is the head of state.', 'The revolution brought an end to the monarchy.', 'Noun', plural='monarchies'),
v('shortage', 'A situation in which there is not enough of something that people need.', 'The shortage of flour caused long queues outside bakeries.', 'Noun', form='shortages', plural='shortages'),
v('strike', 'A period when workers stop working together to demand changes.', 'The strike spread to several factories.', 'Noun', form='Strikes', plural='strikes'),
v('abdicate', 'To formally give up a position as king, queen or another sovereign ruler.', 'The king agreed to abdicate after losing political support.', 'Verb', form='abdicated', verb=('abdicate','abdicated','abdicated',False)),
v('provisional', 'Temporary and intended to last until a permanent arrangement is made.', 'A provisional government took office during the transition.', 'Adjective'),
v('council', 'A group of people chosen to discuss matters, make decisions or represent others.', 'The workers elected a council to represent them.', 'Noun', form='councils', plural='councils'),
v('seize', 'To take control of something suddenly or by force.', 'The forces attempted to seize control of the capital.', 'Verb', form='seized', verb=('seize','seized','seized',False)),
v('civil war', 'A war between organized groups within the same country.', 'The civil war divided communities and disrupted food supplies.', 'Noun phrase', form='Civil war', plural='civil wars'),
v('repressive', 'Using force or strict controls to limit people’s freedoms.', 'The government introduced increasingly repressive measures.', 'Adjective')
],
[
m('Why did the first revolution fail to settle Russia’s crisis?', ['The emperor immediately returned to full power.', 'Competing authorities and unresolved war, land and economic problems remained.', 'The soviets refused to participate in any political activity.'], 'B', "The first revolution had removed the emperor without creating an agreed solution to the country's problems.", 'The following paragraph identifies the continuing war, slow land reform and economic deterioration.'),
m('Who overthrew the provisional government later in 1917?', ['Nicholas II and a restored royal government.', 'The military forces that later signed the 1918 peace treaty with Russia.', 'Bolshevik-led forces under Lenin’s political leadership.'], 'C', 'Later that year, Bolshevik-led forces seized important locations in Petrograd and overthrew the provisional government.', 'The second revolution brought Lenin and the Bolsheviks to government.'),
m('What followed Russia’s withdrawal from World War I?', ['Civil war involving several internal groups and foreign intervention.', 'Immediate peace across the country under a restored monarchy.', 'The creation of the Soviet Union in March 1918.'], 'A', 'Civil war involved the Bolsheviks, rival political and military groups, independence movements and foreign intervention.', 'Ending participation in the international war did not end conflict within Russia.'),
g('The city at the center of the revolutions was called ___.', 'Petrograd', 'In Petrograd, now Saint Petersburg, women workers joined protests over bread supplies.', 'Petrograd was the contemporary name of the capital.'),
g('Lenin returned to Russia from ___.', 'exile', 'Vladimir Lenin returned from exile and argued for peace, land redistribution and power for the soviets.', 'His return occurred after the first revolution.'),
g('The Soviet Union was established in ___.', '1922', 'The Soviet Union was established in 1922.', 'This was a later outcome, rather than an event completed during 1917 itself.')
],
[
'Virginia Tech Digital History Reader, introduction and context — Social and wartime pressures, women workers, strikes, dual authority, land, Lenin’s return and Bolshevik influence: https://www.dhr.history.vt.edu/modules/eu/mod03_1917/index.html',
'Virginia Tech historical context, document-supported teaching module — February developments and political crisis: https://www.dhr.history.vt.edu/modules/eu/mod03_1917/pdfs/context.pdf',
'U.S. Holocaust Memorial Museum, Russian Revolution 1917 — Distinct February and October revolutions and the two governments: https://encyclopedia.ushmm.org/content/en/article/the-russian-revolution-1917',
'University of Warwick Modern Records Centre, archival collection — Calendar correspondence, Brest-Litovsk, varied civil-war forces and foreign intervention: https://warwick.ac.uk/services/library/mrc/collections/digital/russia/civil_war/',
'U.S. Office of the Historian, original diplomatic documents — January 1918 Constituent Assembly and its dissolution: https://history.state.gov/historicaldocuments/frus1918Russiav01/papers',
'Rice University OpenStax, Formation of the Soviet Union — 1922 founding and consolidation of political control: https://openstax.org/books/world-history-volume-2/pages/12-2-the-formation-of-the-soviet-union',
'Library of Congress, Revelations from the Russian Archives — International consequences and early Soviet relations: https://www.loc.gov/exhibits/archives/sovi.html'
],
[
'Whole-event overview covers imperial society and World War I, popular protest and abdication, competing authorities, unresolved land and war questions, Lenin and the second seizure of power, withdrawal, civil war, repression and global consequences.',
'February and October are the conventional Julian-calendar labels, explicitly related to March and November in the Gregorian calendar. The two revolutions are not merged into a single Bolshevik overthrow of the tsar.',
'Lenin returned after the first revolution; Bolsheviks overthrew the provisional government. Growing support among urban workers and soldiers is not treated as a proven majority mandate from the entire population.',
'March 1918 withdrawal and the 1922 Soviet founding are separate later outcomes. Civil-war factions and foreign intervention are acknowledged without a false simple two-sided or instant nationwide control narrative.',
'An elected assembly’s closure and growing repression are distinguished from promises of reform. No graphic violence, revolutionary instructions, propaganda slogans presented as achieved fact, or ideological praise.',
'Compared with all 001–074, including the new national-history overview. This is the 1917 revolutionary transition in Russia, distinct from later Soviet-era crises and the Berlin events. Identity and aliases are registered in content/topics.json.'
])
