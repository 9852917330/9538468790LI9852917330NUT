"""Reviewed editorial drafts; run before applying each matching recording."""
import runpy
from pathlib import Path
globals().update(runpy.run_path(str(Path(__file__).with_name('overview-revision.py'))))

draft(2,'The 1983 Soviet Nuclear False Alarm','The Cold War setting, alert, assessment, technical error and wider risks of the 1983 warning.',
'''In 1983, the United States and the Soviet Union faced each other with large nuclear arsenals. Each feared a sudden attack that could destroy its ability to respond. Warning systems were meant to detect enemy launches quickly, but a mistaken warning could create a crisis of its own.

Relations were especially tense that September. Earlier in the month, Soviet forces had shot down a South Korean passenger aircraft. Against this background, officers monitoring possible American attacks worked **under pressure**.

Shortly after midnight on September 26, an alarm sounded at a warning center near Moscow. A computer reported an American missile launch, followed by 4 more. The information came from **satellites** watching for signs of launches. Stanislav Petrov, the officer **on duty**, had to assess the report and communicate with his superiors.

Several details gave him reasons to doubt it. A major American first strike would probably involve far more than 5 **missiles**. The system was relatively new, and its confident display did not guarantee that its conclusion was **reliable**. Other available checks had not confirmed a real attack.

Petrov judged the warning to be a **false alarm** and reported that assessment. He could not order a nuclear launch himself; any such decision belonged higher in the **chain of command**. The danger lay in how incomplete information might influence those decisions.

No incoming missiles arrived. Investigators later linked the error to sunlight **reflected** from high clouds. A rare alignment of the Sun, clouds and satellite had produced a signal that the system mistook for launches.

The incident remained secret for years. Once known, it became an important example of the risks within nuclear warning systems. It cannot be proved that a different report would have caused war. What is clear is that technical errors, political tension and very limited decision time had combined to create a potentially disastrous situation.''',[
mcq('Why could a false warning create a serious crisis?',['It could influence decisions about a nuclear response.','It would prevent every satellite from working.','It would immediately destroy the warning center.'],'A','The danger lay in how incomplete information might influence those decisions.','A false report could affect decisions higher in the command structure.'),
mcq('Which detail made Petrov doubt the report?',['The equipment had completely stopped working.','Only a few launches were reported, rather than a large first strike.','Investigators had already identified the sunlight error.'],'B','A major American first strike would probably involve far more than 5 missiles.','The reported scale did not fit his expectation of a major attack.'),
mcq('What does the full incident illustrate?',['Petrov could personally launch Soviet weapons.','War would certainly have followed a different report.','Technical errors, political tension and time pressure can combine dangerously.'],'C','What is clear is that technical errors, political tension and very limited decision time had combined to create a potentially disastrous situation.','The episode demonstrates combined risks without proving an alternative outcome.'),
gap('The launch reports came from ___.','satellites','The information came from satellites watching for signs of launches.','The system used space-based observation.'),
gap('Petrov had to communicate his assessment to his ___.','superiors','Stanislav Petrov, the officer on duty, had to assess the report and communicate with his superiors.','He reported to officers above him.'),
gap('The alarm was later linked to sunlight reflected from high ___.','clouds','Investigators later linked the error to sunlight reflected from high clouds.','Reflected sunlight was mistaken for launches.')
],['https://www.chathamhouse.org/sites/default/files/field/field_document/20140428TooCloseforComfortNuclearUseLewisWilliamsPelopidasAghlani.pdf','https://www.aps.org/apsnews/2026/09/1983-averting-potential-nuclear-war','https://www.brightstarsound.com/world_hero/the_moscow_news.html'],['Strategic and immediate political context, alert sequence, reporting, cause, outcome and significance. No personal launch authority or certain counterfactual war claim.'])

draft(3,'Apollo 11: The First Moon Landing','The space-race goal, journey, lunar exploration and safe return of the first Moon landing.',
'''In July 1969, Apollo 11 carried out the first human landing on the Moon. The mission grew from the Cold War space race between the United States and the Soviet Union. In 1961, President John F. Kennedy had set a goal: land a person on the Moon and return safely before the decade ended.

Reaching that goal required years of engineering, earlier missions and practice. On July 16, a Saturn V rocket launched Neil Armstrong, Buzz Aldrin and Michael Collins from Florida. Their spacecraft traveled toward the Moon, carrying both the equipment to land and the means to come home.

On July 20, Armstrong and Aldrin entered the **lunar module**, Eagle, and separated from Columbia. Collins stayed in **orbit**, operating the spacecraft they would need for their return to Earth.

During the **descent**, computer alarms interrupted the landing. Ground specialists confirmed that essential guidance programs were still working. Near the surface, Armstrong guided Eagle beyond a rocky **crater** to find safer ground. With **fuel** running low, Eagle **touched down** in the Sea of Tranquility.

Later, Armstrong climbed down onto the surface, becoming the first person to walk on the Moon. Aldrin joined him. Television pictures allowed people around the world to follow the achievement. The astronauts took photographs, collected rock and soil **samples**, and set up scientific **instruments**. Their work turned a brief visit into a source of evidence about another world.

The return was as important as the landing. Eagle's upper section lifted off and rejoined Columbia. All 3 astronauts then traveled back to Earth, **splashing down** in the Pacific Ocean on July 24.

Apollo 11 achieved Kennedy's goal and gave the United States a major success in the space race. It also began a series of human lunar explorations. Behind the famous first steps stood a much larger achievement: scientists, engineers, controllers and astronauts had made a complete journey to the Moon and back possible.''',[
mcq('What was the complete mission goal?',['To reach the Moon before any uncrewed craft.','To land people on the Moon and bring them safely home.','To build a permanent lunar settlement.'],'B','In 1961, President John F. Kennedy had set a goal: land a person on the Moon and return safely before the decade ended.','A safe return was part of the goal.'),
mcq('Why did Collins remain in orbit?',['He operated the spacecraft needed for the return to Earth.','He waited to make a separate landing.','He controlled the television stations on Earth.'],'A','Collins stayed in orbit, operating the spacecraft they would need for their return to Earth.','Columbia was needed after Eagle returned from the surface.'),
mcq('What did the crew accomplish beyond the first steps?',['A permanent base was completed.','A second crew arrived to replace them.','Scientific observations, experiments and sample collection.'],'C','The astronauts took photographs, collected rock and soil samples, and set up scientific instruments.','The visit provided material and evidence for scientific study.'),
gap('The mission launched from ___ on July 16.','Florida','On July 16, a Saturn V rocket launched Neil Armstrong, Buzz Aldrin and Michael Collins from Florida.','Florida was the launch location.'),
gap('Eagle landed in the Sea of ___.','Tranquility','With fuel running low, Eagle touched down in the Sea of Tranquility.','This is a lunar place name.'),
gap('The crew returned to Earth in the ___ Ocean.','Pacific','All 3 astronauts then traveled back to Earth, splashing down in the Pacific Ocean on July 24.','The crew returned with an ocean landing.')
],['https://www.nasa.gov/mission/apollo-11/','https://www.nasa.gov/wp-content/uploads/static/history/alsj/a11/a11.landing.html','https://www.nasa.gov/wp-content/uploads/static/history/alsj/a11/a11.1201-pa.html'],['Complete mission overview, with alarms and terrain hazards restricted to one supporting paragraph. Avoid ambiguous UTC/U.S. calendar dating of the first step.'],extras=[v('lunar module','The part of an Apollo spacecraft designed to land on the Moon and return to lunar orbit.','Two astronauts traveled in the lunar module.','Noun phrase',plural='lunar modules'),v('splash down','To land in water after a spaceflight.','The capsule splashed down in the ocean.','Phrasal verb','splashing down',('splash','splashed','splashed',False))])

draft(4,'The Berlin Wall: From Division to Reunification','Why Berlin was divided, how its border controlled daily life and how political pressure brought it open.',
'''After World War II, Germany became divided between a communist East and a democratic West. Berlin, located deep inside East German territory, was also split. West Berlin remained linked to the Western powers, creating an escape route for East Germans who wanted to leave.

Millions departed over the following years. East Germany's government feared losing workers and control. On August 13, 1961, it began sealing the border around West Berlin with **barbed wire**. Walls, fences and armed guards followed. Streets were blocked, and families found themselves **cut off** from relatives nearby.

For most East Germans, crossing freely was impossible. People needed official permission, and attempts to escape could be deadly. The border became a symbol of the Cold War, dividing daily life as well as political systems.

By 1989, that system was weakening. Political reforms elsewhere in Eastern Europe encouraged demands for change. Large **protests** challenged the East German government, while many citizens left through other countries. Leaders prepared to ease travel **restrictions**.

On November 9, official Günter Schabowski announced new rules at a televised **press conference**. Asked when they would apply, he said **immediately**, although guards had not received instructions. News reports encouraged crowds to gather at the **checkpoints**, expecting to cross.

Guards faced growing pressure and unclear orders. At Bornholmer Strasse, the **barrier** was finally raised at about 11:30 p.m., and normal passport checks stopped. Other crossings opened during the night. People entered West Berlin, met relatives and celebrated together.

The wall did not physically disappear that evening. More crossings opened, and much of the structure was removed later. Germany was reunited on October 3, 1990.

The opening resulted from more than a confused announcement. Public protest, people leaving and wider political change had already undermined the system. The Berlin Wall's fall became a powerful symbol of the end of Europe's Cold War division.''',[
mcq('Why did East Germany close the border?',['To stop people leaving through West Berlin.','To prevent tourists entering East Germany.','To make Berlin a single capital.'],'A',"East Germany's government feared losing workers and control.",'Departures threatened the government’s workforce and authority.'),
mcq('What weakened the system before November 9?',['All concrete sections had been removed.','Every guard had left work.','Protests, departures and wider political changes.'],'C','Public protest, people leaving and wider political change had already undermined the system.','The opening followed pressures beyond the announcement.'),
mcq('What followed the opening of the crossings?',['The wall vanished immediately.','Later demolition and German reunification.','An end to all contact between the two sides.'],'B','More crossings opened, and much of the structure was removed later. Germany was reunited on October 3, 1990.','Opening, removal and reunification were separate developments.'),
gap('The first barriers in August 1961 used barbed ___.','wire','On August 13, 1961, it began sealing the border around West Berlin with barbed wire.','Wire barriers came before the expanded wall system.'),
gap('Schabowski announced the rules at a press ___.','conference','On November 9, official Günter Schabowski announced new rules at a televised press conference.','The announcement was made at a televised meeting with journalists.'),
gap('At Bornholmer Strasse, normal ___ checks stopped.','passport','At Bornholmer Strasse, the barrier was finally raised at about 11:30 p.m., and normal passport checks stopped.','Normal document checks were abandoned as people crossed.')
],['https://www.stiftung-berliner-mauer.de/en/topics/berlin-wall','https://www.berlin.de/en/history/8482274-8619314-opening-and-fall-of-the-berlin-wall.en.html','https://www.bundesregierung.de/breg-en/service/archive/archive/the-chancellor-who-reunited-germany-413888'],['Postwar geography, construction, human costs, political pressures, opening, demolition and reunification. Do not explain the whole change as a mistaken word.'],extras=[v('protest','An action or public gathering expressing opposition.','A peaceful protest took place outside the offices.','Noun','protests',plural='protests'),v('restriction','A rule or limit on what someone can do.','The council lifted the restriction on travel.','Noun','restrictions',plural='restrictions')])

draft(5,'Tambora and the Year Without a Summer','The eruption, local destruction, atmospheric cooling and the wider food crisis that followed.',
'''In April 1815, Mount Tambora **erupted** on Sumbawa, an island in what is now Indonesia. The strongest explosions came on April 10 and 11. They devastated nearby communities and sent material high into the sky, beginning a disaster whose effects would reach far beyond the volcano.

Fast-moving flows of hot gas and rock swept down the mountain, destroying villages. **Ash** buried fields and homes, while some flows entering the sea caused tsunamis. People who survived the eruption then faced hunger, damaged water supplies and the loss of their livelihoods.

Tambora also changed the **atmosphere**. It released large amounts of **sulfur dioxide**, which formed tiny acid **droplets** high above the ground. Winds spread them widely. Unlike much of the heavier ash, these droplets could stay aloft long enough to reflect sunlight back into space, reducing the energy warming Earth's surface.

In 1816, parts of Europe and North America experienced unusually cold conditions. Summer snow and **frost** damaged crops in New England. Cold, wet weather made farming difficult in parts of Europe. The year became known as the Year Without a Summer, although conditions varied between regions.

Poor **harvests** led to food **shortages** and helped **drive up** prices. Families already living on little money were especially exposed. Hunger and disease spread, and some farming families moved to seek better conditions. A volcanic eruption had become a problem of food, health and survival thousands of kilometers away.

The unusual weather also affected cultural life. During a rainy stay near Lake Geneva, Mary Shelley began the story that became Frankenstein.

Eventually, the volcanic droplets left the atmosphere and the cooling gradually weakened, though the oceans prolonged some effects. Tambora showed how a local geological event could disrupt climate, agriculture and societies across distant regions. Natural weather patterns also influenced where the damage was greatest.''',[
mcq('Which description covers local and distant effects?',['Only nearby buildings were damaged.','Villages were destroyed while atmospheric changes harmed distant farms.','Lava directly covered farms in Europe.'],'B','They devastated nearby communities and sent material high into the sky, beginning a disaster whose effects would reach far beyond the volcano.','Local destruction was followed by atmospheric and agricultural effects.'),
mcq('Why did the eruption reduce surface warming?',['Droplets reflected some sunlight back into space.','All oceans stopped absorbing sunlight.','Ash covered the whole planet permanently.'],'A',"these droplets could stay aloft long enough to reflect sunlight back into space, reducing the energy warming Earth's surface.",'Less solar energy was available to warm the ground.'),
mcq('How should Year Without a Summer be understood?',['Every country had identical weather.','Warm seasons permanently disappeared.','Severe conditions affected some regions more than others.'],'C','The year became known as the Year Without a Summer, although conditions varied between regions.','The label describes a severe crisis rather than uniform global weather.'),
gap('Sumbawa is in what is now ___.','Indonesia','In April 1815, Mount Tambora erupted on Sumbawa, an island in what is now Indonesia.','This is the present-day location.'),
gap('In New England, summer snow and ___ damaged crops.','frost','Summer snow and frost damaged crops in New England.','Freezing conditions affected growing crops.'),
gap('Poor harvests helped push food ___ higher.','prices','Poor harvests led to food shortages and helped drive up prices.','Lower supplies made food more expensive.')
],['https://www.usgs.gov/observatories/hvo/news/volcano-watch-infamous-mount-tambora-rumbling-again','https://www.usgs.gov/programs/VHP/volcanoes-can-affect-climate','https://scied.ucar.edu/learning-zone/how-climate-works/mount-tambora-and-year-without-summer','https://news.ucar.edu/129827/future-volcanic-eruptions-could-cause-more-climate-disruption','https://www.research.ed.ac.uk/en/publications/disentangling-the-causes-of-the-1816-european-year-without-a-summ/'],['Balance local destruction, climate mechanism, regional weather, food, health, migration and culture. No exact uncertain global death or temperature total. Distinguish ash from sulfate droplets.'])
