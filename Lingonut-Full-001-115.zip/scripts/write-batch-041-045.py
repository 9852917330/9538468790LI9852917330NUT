"""Source-reviewed, distinct-event overviews for English Unicorn 041–045."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(41, 'my-lai-massacre-1968', 'Mỹ Lai 1968: A Massacre, Its Exposure and Its Legacy', 'World Events',
      'American soldiers killed hundreds of Vietnamese civilians; survivors, witnesses and investigations exposed the massacre and its concealment.',
'''During the Vietnam War, the United States supported South Vietnam against communist forces. Fighting often took place near farming communities, where civilians faced danger from several sides. American units searched for enemy fighters in areas where they had suffered losses from mines and other attacks.

On March 16, 1968, American soldiers entered settlements in Sơn Mỹ village, in central Vietnam's Quảng Ngãi province. The best-known killings took place at Mỹ Lai. The troops expected to find enemy forces, but encountered no armed resistance there.

Soldiers killed hundreds of **unarmed** civilians, including women, children and older people. They also destroyed homes, food and livestock. Different investigations and memorial records give different death totals. The scale of the killing and the civilian status of the victims are firmly established.

Military briefings had encouraged soldiers to treat the area as an enemy stronghold. Poor leadership, revenge and failures to protect civilians helped create the conditions for the **massacre**. Soldiers remained responsible for their actions, and commanders for their duties.

Helicopter pilot Hugh Thompson and crew members Glenn Andreotta and Lawrence Colburn **intervened** after seeing the attacks. They helped protect and **evacuate** some survivors. Their actions showed that people within the same operation could recognize the crimes and act against them.

The initial military account presented the operation as a victory. Reports of civilian deaths were **suppressed**, delaying a full investigation. Former soldier Ron Ridenhour later sent information to officials, and journalist Seymour Hersh's reporting helped bring the massacre to public attention in 1969. Photographs provided further **evidence**.

The Army investigated both the killings and the **cover-up**. Lieutenant William Calley was the only person convicted for crimes connected with Mỹ Lai. His punishment was later reduced, and the limited **accountability** caused lasting controversy.

The massacre deepened debate about the war and the treatment of civilians. Survivors and memorials preserved the victims' memory, while military teaching returned to the duty to reject **unlawful orders**.''',
[
v('unarmed', 'Not carrying a weapon.', 'The unarmed residents waited beside their homes.', 'Adjective'),
v('massacre', 'The killing of many people, especially people unable to defend themselves.', 'The memorial records the names of people killed in the massacre.', 'Noun', plural='massacres'),
v('intervene', 'To become involved in a situation to change what is happening.', 'The officer decided to intervene to protect the family.', 'Verb', form='intervened', verb=('intervene','intervened','intervened',False)),
v('evacuate', 'To move people away from danger to a safer place.', 'Rescuers worked to evacuate the injured residents.', 'Verb', verb=('evacuate','evacuated','evacuated',False)),
v('suppress', 'To prevent information or an activity from becoming known or continuing.', 'The inquiry examined attempts to suppress the report.', 'Verb', form='suppressed', verb=('suppress','suppressed','suppressed',False)),
v('evidence', 'Information or material that helps establish what happened.', 'The photograph became important evidence in the investigation.', 'Uncountable noun'),
v('cover-up', 'An attempt to hide a crime, mistake or other wrongdoing.', 'The investigation examined both the incident and the cover-up.', 'Noun', plural='cover-ups'),
v('accountability', 'The responsibility to explain actions and face consequences for them.', 'The families continued to demand accountability.', 'Uncountable noun'),
v('unlawful order', 'An instruction that requires an act against the law.', 'Military training explained the duty to reject an unlawful order.', 'Noun phrase', form='unlawful orders', plural='unlawful orders')
],
[
m('What happened when the troops entered Mỹ Lai?', ['They encountered a large force defending the settlement.', 'They encountered no armed resistance and killed civilians.', 'They evacuated the entire settlement before any violence.'], 'B', 'The troops expected to find enemy forces, but encountered no armed resistance there.', 'The account describes the killing of unarmed civilians during an operation that met no armed resistance at Mỹ Lai.'),
m('What did Thompson and his crew do?', ['They helped protect people and move some survivors to safety.', 'They led the later newspaper investigation.', 'They wrote the initial report calling the operation a victory.'], 'A', 'They helped protect and evacuate some survivors.', 'The helicopter crew intervened during the attacks and assisted survivors.'),
m('What was a major issue after the massacre became public?', ['No Army investigation ever took place.', 'Every commander received the same sentence.', 'The limited criminal accountability caused controversy.'], 'C', 'His punishment was later reduced, and the limited accountability caused lasting controversy.', 'The legal outcome left lasting questions about responsibility for the killings and concealment.'),
g('The massacre happened in March ___.', '1968', "On March 16, 1968, American soldiers entered settlements in Sơn Mỹ village, in central Vietnam's Quảng Ngãi province.", '1968 was the year of the massacre.'),
g('Hersh’s reporting helped bring public attention to the massacre in ___.', '1969', "Former soldier Ron Ridenhour later sent information to officials, and journalist Seymour Hersh's reporting helped bring the massacre to public attention in 1969.", 'The public exposure described here occurred the following year.'),
g('___ provided further evidence.', 'Photographs', 'Photographs provided further evidence.', 'Images supported the public account of what had happened.')
],
[
'U.S. Army Peers Inquiry, government report reproduced by University of Houston — Setting, operation, absence of resistance, civilian killings and suppression: https://www.digitalhistory.uh.edu/active_learning/explorations/vietnam/peers_report.cfm',
'U.S. Department of Veterans Affairs — Thompson, Andreotta, Colburn and the intervention: https://news.va.gov/111176/america250-army-veteran-hugh-thompson-jr/',
'Library of Congress — Calley as the only person convicted, initial sentence and courtroom record: https://www.loc.gov/exhibitions/drawing-justice-courtroom-illustrations/about-this-exhibition/federal-and-special-courts/only-one-officer-found-guilty-of-my-lai-attrocities/',
'PBS American Experience, documentary history and eyewitness accounts — Ridenhour, Hersh, photographs, exposure and punishment: https://www.pbs.org/wgbh/americanexperience/features/vietnam-my-lai-massacre/',
'CIPDH, Argentine government human-rights memorial project — Sơn Mỹ memorial, victims and remembrance: https://www.cipdh.gob.ar/memorias-situadas/en/lugar-de-memoria/son-my-vestige-site/'
],
[
'Overview covers war setting, expectations and killings, enabling failures, intervention, concealment, public exposure, legal accountability and memory. Thompson supports rather than replaces the wider story.',
'Sơn Mỹ is the village; Mỹ Lai is the best-known killing site within the operation. Hundreds avoids conflating the narrower Army estimate with the Vietnamese memorial total of 504.',
'No graphic details or invented conversations. Context explains conditions without removing individual or command responsibility.',
'Calley was the only person convicted in connection with the event; his initial life sentence and subsequent reductions are not presented as broad successful prosecution.',
'Compared manually with all 001–040 and the other four candidates. This 1968 massacre is distinct from the Holocaust, Tiananmen and Khmer Rouge rule; identity and aliases are recorded in content/topics.json.'
])

draft(42, 'khmer-rouge-rule-cambodia-1975-1979', 'Cambodia Under the Khmer Rouge: Revolution and Mass Death', 'World Events',
      'The Khmer Rouge seized power after civil war, imposed a violent transformation of Cambodian society and left mass death and decades of consequences.',
'''Cambodia entered the 1970s under growing pressure from the Vietnam War. A coup removed Prince Sihanouk in 1970, and civil war followed. The Khmer Rouge, a communist movement led by Pol Pot, gained strength through alliances, foreign support and the destruction surrounding the conflict. American bombing also devastated parts of the countryside.

On April 17, 1975, Khmer Rouge forces captured Phnom Penh, the capital. Many residents hoped the fighting had ended. Within hours, the new rulers began forcing people out of the city, including hospital patients. Families joined huge columns moving toward the countryside.

The movement sought to remake Cambodia around farming and total political control. It **abolished** money, closed ordinary schools and restricted religion. People were sent to rural **cooperatives** and building projects, where officials controlled work, food and daily life. Families were separated, and many children were placed in separate groups.

Long hours of **forced labor**, inadequate food and poor medical care caused widespread illness and **starvation**. Officials pursued unrealistic production goals and punished people accused of disobedience. Former government workers, religious communities and people considered political enemies faced **persecution**. Ethnic Vietnamese and Cham Muslims were among the groups specifically targeted.

Prisons became centers of interrogation and **execution**. At S-21 in Phnom Penh, prisoners were tortured and forced to confess to invented conspiracies. Fear also spread within the movement as leaders attacked supposed enemies in their own ranks.

An estimated 1.5 to 2 million people died during Khmer Rouge rule, though the exact total remains uncertain. Death came through killing, hunger, disease and exhausting work.

After worsening border conflict, Vietnamese forces invaded in December 1978. Vietnamese forces captured Phnom Penh in January 1979, ending the regime's control of the capital. Fighting and **displacement** continued for years, while survivors struggled to rebuild families and communities.

Decades later, a Cambodian court supported by the United Nations convicted senior figures of crimes against humanity and, in some cases, **genocide** against Vietnamese and Cham groups. Survivor **testimony**, records and memorials helped preserve a history whose consequences continued across generations.''',
[
v('abolish', 'To officially end a system, practice or institution.', 'The new law would abolish the old restriction.', 'Verb', form='abolished', verb=('abolish','abolished','abolished',False)),
v('cooperative', 'An organization or group whose members work together and share resources.', 'The farming cooperative shared equipment among its members.', 'Noun', form='cooperatives', plural='cooperatives', note='Under Khmer Rouge rule, rural cooperatives were controlled by the regime; participation was not freely chosen.'),
v('forced labor', 'Work that people are made to do against their will.', 'The inquiry documented the use of forced labor.', 'Uncountable noun phrase'),
v('starvation', 'Severe lack of food that can cause illness or death.', 'The emergency food deliveries helped prevent starvation.', 'Uncountable noun'),
v('persecution', 'Cruel or unfair treatment because of a person’s identity, beliefs or membership of a group.', 'Many families fled religious persecution.', 'Uncountable noun'),
v('execution', 'The deliberate killing of someone by an authority or armed group, often as a punishment.', 'The court examined records of the prisoner’s execution.', 'Noun', plural='executions'),
v('displacement', 'The forced movement of people away from their homes.', 'The conflict caused widespread displacement.', 'Uncountable noun'),
v('genocide', 'Acts committed with the intention of destroying a national, ethnic, racial or religious group, in whole or in part.', 'The tribunal examined evidence of genocide against the community.', 'Noun'),
v('testimony', 'A formal account of what someone knows or experienced, especially in court.', 'The survivor’s testimony helped establish the sequence of events.', 'Noun', plural='testimonies')
],
[
m('What followed the capture of Phnom Penh?', ['All residents were allowed to remain at home.', 'The new rulers restored normal city life immediately.', 'Residents, including hospital patients, were forced into the countryside.'], 'C', 'Within hours, the new rulers began forcing people out of the city, including hospital patients.', 'The capture was quickly followed by the forced evacuation of the capital.'),
m('Which combination explains the scale of the deaths?', ['A single prison fire and no wider shortages.', 'Killing, hunger, disease and exhausting work.', 'Only fighting after the capital changed hands in 1979.'], 'B', 'Death came through killing, hunger, disease and exhausting work.', 'The account describes several connected forms of mass harm under the regime.'),
m('What happened after Vietnamese forces captured the capital?', ['All conflict and displacement ended immediately.', 'The regime lost control of the capital, but fighting and displacement continued.', 'The Khmer Rouge first came to power in Phnom Penh.'], 'B', "Vietnamese forces captured Phnom Penh in January 1979, ending the regime's control of the capital.", 'The following sentence explains that the end of rule in the capital did not bring an immediate end to the wider conflict.'),
g('Khmer Rouge forces captured Phnom Penh in April ___.', '1975', 'On April 17, 1975, Khmer Rouge forces captured Phnom Penh, the capital.', '1975 marks the start of Khmer Rouge rule over the capital.'),
g('The new rulers abolished ___.', 'money', 'It abolished money, closed ordinary schools and restricted religion.', 'Ending the use of money was part of the imposed transformation.'),
g('Vietnamese forces captured the capital in ___ 1979.', 'January', "Vietnamese forces captured Phnom Penh in January 1979, ending the regime's control of the capital.", 'January identifies the month in which the capital fell.')
],
[
'United States Holocaust Memorial Museum — War, coup and the rise of the movement: https://www.ushmm.org/genocide-prevention/countries/cambodia/war-closes-in',
'United States Holocaust Memorial Museum — Alliances, foreign support and bombing context: https://www.ushmm.org/genocide-prevention/countries/cambodia/the-khmer-rouge-gain-strength',
'United States Holocaust Memorial Museum — April 17 capture and evacuation: https://www.ushmm.org/genocide-prevention/countries/cambodia/day-one',
'United States Holocaust Memorial Museum — Policies, forced work and persecution: https://www.ushmm.org/genocide-prevention/countries/cambodia/khmer-rouge-revolution',
'United States Holocaust Memorial Museum — S-21 and the end of rule in Phnom Penh: https://www.ushmm.org/genocide-prevention/countries/cambodia/s-21',
'Extraordinary Chambers in the Courts of Cambodia, Understanding the ECCC — Estimated deaths, jurisdiction, findings and individual convictions: https://www.eccc.gov.kh/sites/default/files/publications/Understanding%20the%20ECCC_EN.pdf',
'ECCC — Current institutional history, completed judicial proceedings and residual functions: https://www.eccc.gov.kh/en'
],
[
'Complete arc covers wartime rise, takeover, forced evacuation, rural social transformation, persecution and deaths, overthrow, continuing conflict and delayed justice.',
'The 1.5–2 million estimate follows ECCC educational material and is explicitly uncertain. Bombing is one part of the wartime context, not a single-cause explanation.',
'Genocide findings concern protected Vietnamese and Cham groups and particular defendants; the lesson does not imply every death received the same legal classification.',
'Pol Pot is identified as the movement leader, not falsely presented as a defendant convicted by the ECCC. No claim that all conflict ended in 1979.',
'Compared with all 001–041 and the remaining candidates. The Cambodian regime is distinct from China’s Cultural Revolution and the Holocaust. Registered in content/topics.json.'
])

draft(43, 'sewol-ferry-disaster-2014', 'Sewol 2014: A Ferry Disaster and the Search for Accountability', 'Disasters and Safety',
      'A South Korean ferry sank with hundreds aboard, exposing linked failures in ship safety, evacuation and the public emergency response.',
'''On April 16, 2014, the ferry Sewol was travelling from Incheon to Jeju Island in South Korea. It carried 476 passengers and crew, including students from Danwon High School on a school trip. Near Jindo, the ship began to tilt during a turn.

The ferry already had serious safety problems. Changes to its upper structure had reduced its **stability**. It carried too much **cargo** and too little **ballast** water low in the ship to help keep it balanced. Much of the cargo was also poorly secured.

As the vessel **listed**, cargo moved to one side, increasing the tilt. Water entered the ship, and flooding spread. These connected failures made recovery increasingly difficult. Later investigations differed over details of the initial turn, but documented major problems with the ship's condition and operation.

Inside, many passengers followed announcements telling them to put on life jackets and stay where they were. They trusted the crew to organize their escape. As the ship leaned further, moving through its passages became harder, and people were trapped inside.

The captain and other senior crew members left without organizing an effective **evacuation**. Rescue boats, helicopters and nearby fishing vessels saved people who reached exposed parts of the ship or the water. The response failed to bring out many of those waiting inside.

Only 172 people survived. The disaster claimed 304 lives, including many Danwon students. Families waited through a long search and **recovery** effort, while the loss caused national grief and anger.

Criminal trials examined the conduct of the crew and others responsible for safety. Captain Lee Joon-seok received a **life sentence** for murder through his failure to rescue passengers. This finding concerned his failure to act when lives were in danger.

The sinking led to changes in ferry **oversight**, inspections and emergency training. Families continued to call for truth and **accountability**. Yellow ribbons became a symbol of remembrance, keeping attention on the people lost and the failures that had placed them in danger.''',
[
v('stability', 'The ability to remain balanced or return to a balanced position.', 'The engineers checked the ship’s stability before departure.', 'Uncountable noun'),
v('cargo', 'Goods transported by a ship, aircraft or other vehicle.', 'The crew checked that the cargo was secured.', 'Noun', plural='cargoes'),
v('ballast', 'Heavy material or water carried low in a vessel to improve balance and stability.', 'The vessel needed enough ballast for the voyage.', 'Uncountable noun'),
v('list', 'To lean to one side, especially when describing a ship.', 'The damaged vessel began to list.', 'Verb', form='listed', verb=('list','listed','listed',False)),
v('evacuation', 'The organized movement of people away from danger.', 'The crew practised an emergency evacuation.', 'Noun', plural='evacuations'),
v('recovery', 'The process of finding and bringing back people or objects after a disaster.', 'The recovery effort continued after the search for survivors ended.', 'Noun', plural='recoveries', note='Here recovery refers to retrieving victims or objects, rather than returning to health.'),
v('life sentence', 'A prison sentence that can last for the rest of a person’s life.', 'The court imposed a life sentence for the crime.', 'Noun phrase', plural='life sentences'),
v('oversight', 'The work of checking and supervising an activity or organization.', 'The report called for stronger safety oversight.', 'Uncountable noun'),
v('accountability', 'The responsibility to explain actions and face consequences for them.', 'The families asked for greater accountability after the disaster.', 'Uncountable noun')
],
[
m('What made the ferry vulnerable before the turn?', ['Reduced stability, excessive cargo, insufficient ballast and poorly secured loads.', 'An absence of passengers and cargo.', 'A recent decision to stop all ferry services.'], 'A', 'It carried too much cargo and too little ballast water low in the ship to help keep it balanced.', 'Structural changes and loading problems combined to reduce the ferry’s safety.'),
m('Why did many passengers remain inside?', ['They had all been told the ship had reached port.', 'They could not hear any announcements.', 'They followed instructions to stay where they were and trusted the crew.'], 'C', 'Inside, many passengers followed announcements telling them to put on life jackets and stay where they were.', 'The announcements encouraged passengers to wait while the danger increased.'),
m('What did the captain’s murder conviction concern?', ['His failure to rescue passengers when he had a duty to act.', 'A finding that he deliberately sank the ferry.', 'His decision to carry no cargo at all.'], 'A', 'Captain Lee Joon-seok received a life sentence for murder through his failure to rescue passengers.', 'The legal finding concerned failure to rescue, rather than a deliberate sinking.'),
g('The Sewol disaster happened in April ___.', '2014', 'On April 16, 2014, the ferry Sewol was travelling from Incheon to Jeju Island in South Korea.', '2014 identifies the year of the sinking.'),
g('Only ___ people survived.', '172', 'Only 172 people survived.', '172 is the number of survivors among the 476 people aboard.'),
g('___ ribbons became a symbol of remembrance.', 'Yellow', 'Yellow ribbons became a symbol of remembrance, keeping attention on the people lost and the failures that had placed them in danger.', 'The ribbon’s color became associated with remembrance of the disaster.')
],
[
'Korean Maritime Safety Tribunal, Central Decision 2026-001, January 28, 2026 — Latest reviewed findings on combined causes, chronology, victims and rescue failures: https://www.kmst.go.kr/web/atch/atchFileDownload.do?atchId=102396&fileSn=1',
'Ministry of Oceans and Fisheries, December 2014 report announcement — Modifications, cargo, ballast and cargo securing: https://www.mof.go.kr/doc/ko/selectDoc.do?bbsSeq=10&docSeq=2526&menuSeq=971',
'Supreme Court of Korea, 2015Do6809, November 12, 2015 — Announcements, continuing rescue duty and murder by omission: https://sc.scourt.go.kr/eng/supreme/decisions/NewDecisionsView.work?mode=6&pageIndex=1&searchWord=&seq=1260',
'Constitutional Court decision, paragraph 1(b) — Captain’s final life sentence: https://law.go.kr/detcInfoP.do?detcSeq=57750',
'Ministry of Oceans and Fisheries, September 2014 — Ferry oversight, inspection, crew and emergency reforms: https://www.mof.go.kr/doc/ko/selectDoc.do?bbsSeq=10&docSeq=2220&menuSeq=971',
'Gyeonggi Office of Education, 2026 remembrance programme — Commemoration and yellow ribbons: https://www.goe.go.kr/goe/na/ntt/selectNttInfo.do?nttSn=2344689'
],
[
'Whole-event overview covers voyage and people aboard, connected safety failures, unfolding sinking, instructions and evacuation, rescue, casualties, prosecution and lasting demands for accountability.',
'2026 KMST decision checked; no claim that one inexperienced officer or a steering malfunction was the sole settled cause. Loading estimates are omitted because successive investigations revised them.',
'304 includes five unrecovered victims; 476 aboard and 172 survivors follow the 2026 decision. No inaccurate claim that all victims were children.',
'The captain’s murder conviction is explicitly explained as failure to rescue, not intentionally sinking the ship. No speculative political or conspiracy explanation.',
'Compared against 001–042 and the other candidates. Distinct from Titanic, Japan’s tsunami and the Itaewon disaster; registered in content/topics.json.'
])

draft(44, 'alcatraz-escape-1962', 'Alcatraz 1962: The Escape and the Unanswered Question', 'Mysteries and Investigations',
      'Three prisoners disappeared from an island prison, prompting a long investigation and an enduring mystery about whether they survived.',
'''Alcatraz stood on an island in San Francisco Bay, surrounded by cold water and strong **currents**. It became a federal prison in 1934 and held men considered dangerous, difficult to manage or likely to escape. Strict routines and isolation gave it a powerful reputation for security.

Prisoners had tried to escape before. Most were caught or died, and the water presented a serious obstacle even after someone left the buildings. The prison's location made the nearby city visible while keeping ordinary contact with the outside world tightly controlled.

In 1962, Frank Morris and brothers John and Clarence Anglin prepared an escape with another **inmate**, Allen West. The group spent months making preparations and hiding their activity from guards. Investigators later reconstructed much of the plan from physical evidence and West's account.

On the night of June 11, Morris and the Anglin brothers left the prison buildings and reached the water. West remained behind. The three men had prepared a homemade **raft**, but their journey after leaving the island was never firmly established.

Their absence was discovered during a morning check on June 12. The prison went into **lockdown**, and an extensive search began. Prison authorities, the Coast Guard and the FBI examined the island, surrounding water and possible leads elsewhere.

Searchers found personal items and pieces of equipment associated with the escape. These **clues** helped explain the preparations, but did not establish what had happened to the men. Cold water and difficult conditions supported the possibility that they had drowned.

The FBI reported finding no **credible** evidence of survival during its investigation. In 1979, it closed its case and transferred responsibility to the U.S. Marshals Service. The men's **fate** remained unresolved.

Alcatraz had already closed as a prison in March 1963 because of high operating and **maintenance** costs. It later opened to visitors, while films and repeated claims of sightings kept the escape famous. Its enduring **mystery** rests on the gap between leaving a prison and proving survival afterward.''',
[
v('current', 'A continuous movement of water or air in a particular direction.', 'The strong current carried the boat away from the shore.', 'Noun', form='currents', plural='currents'),
v('inmate', 'A person kept in a prison or similar institution.', 'The inmate was transferred to another prison.', 'Noun', plural='inmates'),
v('raft', 'A flat floating structure used to travel on water.', 'The rescue team found an empty raft near the coast.', 'Noun', plural='rafts'),
v('lockdown', 'A period when movement into, out of or within a place is tightly restricted for security.', 'The prison entered lockdown after the alarm.', 'Noun', plural='lockdowns'),
v('clue', 'A piece of information that helps explain an event or solve a mystery.', 'The photograph offered a new clue to the investigators.', 'Noun', form='clues', plural='clues'),
v('credible', 'Believable and supported by enough reason or evidence.', 'The witness gave a credible account of the journey.', 'Adjective'),
v('fate', 'What eventually happens to a person or thing.', 'The missing ship’s fate remained unknown.', 'Noun', plural='fates'),
v('maintenance', 'Work needed to keep a building, machine or system in good condition.', 'The old building required expensive maintenance.', 'Uncountable noun'),
v('mystery', 'An event or situation that has not been fully explained.', 'The disappearance became a lasting mystery.', 'Noun', plural='mysteries')
],
[
m('What made the island difficult to leave?', ['It was surrounded by a desert.', 'It was far from any sea or river.', 'Cold water and strong currents created serious danger.'], 'C', 'Alcatraz stood on an island in San Francisco Bay, surrounded by cold water and strong currents.', 'The surrounding water added a major obstacle beyond the prison buildings.'),
m('What did investigators establish about the three men’s fate?', ['Their fate remained unresolved despite the evidence and search.', 'All three were recaptured the next morning.', 'A film confirmed that all three had survived.'], 'A', "The men's fate remained unresolved.", 'The investigation did not produce a confirmed account of either survival or death.'),
m('Why did Alcatraz close as a prison in 1963?', ['No prisoners had ever attempted an escape.', 'Its operation and maintenance were too expensive.', 'The missing men returned and bought the island.'], 'B', 'Alcatraz had already closed as a prison in March 1963 because of high operating and maintenance costs.', 'The closure reflected costs; it should not be attributed simply to the escape.'),
g('The three men left on the night of ___ 11.', 'June', 'On the night of June 11, Morris and the Anglin brothers left the prison buildings and reached the water.', 'The escape occurred in June 1962.'),
g('Allen ___ remained behind.', 'West', 'West remained behind.', 'West participated in the planning but did not leave with the three men.'),
g('The FBI closed its case in ___.', '1979', 'In 1979, it closed its case and transferred responsibility to the U.S. Marshals Service.', '1979 marks the transfer of investigative responsibility described in the lesson.')
],
[
'FBI, Alcatraz Escape — Participants, dates, search, recovered items, assessment and 1979 transfer: https://www.fbi.gov/history/cases-and-criminals/alcatraz-escape',
'Federal Bureau of Prisons, Alcatraz history — Prison purpose, earlier attempts, water hazards, costs, 1963 closure and 1973 visitor opening: https://www.bop.gov/about/history/alcatraz.jsp',
'U.S. Marshals Service — Frank Morris fugitive profile: https://www.usmarshals.gov/what-we-do/fugitive-apprehension/profiled-fugitives/frank-lee-morris',
'U.S. Marshals Service — John Anglin fugitive profile: https://www.usmarshals.gov/what-we-do/fugitive-apprehension/profiled-fugitives/john-william-anglin',
'U.S. Marshals Service — Clarence Anglin fugitive profile: https://www.usmarshals.gov/what-we-do/fugitive-apprehension/profiled-fugitives/clarence-anglin'
],
[
'Overview covers prison setting, participants, departure and discovery, search and evidence, uncertain outcome, institutional closure and cultural memory.',
'No assertion of confirmed drowning or confirmed successful survival. FBI assessment is attributed. Wanted profiles do not prove the men survived.',
'Historical description remains at a high level, omitting practical route, tools, construction instructions and security-bypass procedures.',
'Closure is attributed to costs in accordance with the Bureau of Prisons. No claim that the escape caused the closure.',
'Compared with all 001–043 and the Fortaleza candidate. No earlier prison-escape event is in the collection; identity registered in content/topics.json.'
])

draft(45, 'banco-central-fortaleza-heist-2005', 'Fortaleza 2005: The Banco Central Tunnel Heist', 'Crime and Investigations',
      'A huge cash theft from Brazil’s central bank led to a long investigation into the group behind it and the movement of the stolen money.',
'''Fortaleza is a major city in northeastern Brazil. In 2005, its branch of Banco Central, Brazil's central bank, stored large amounts of banknotes. The institution helped manage the country's cash supply, making its **vault** a place where an enormous sum could be held together.

A criminal group prepared to steal that money. Members rented a nearby property associated with an apparent business and spent months preparing an underground connection to the bank. The operation depended on coordinated planning and people taking different roles, including financing and carrying out the theft.

Over an early-August weekend, the group entered the vault through a tunnel and removed about 164.8 million Brazilian reais in cash. The loss was discovered on Monday, August 8. The scale of the theft quickly drew national and international attention.

The discovery started a major **investigation** by the Federal Police. Officials examined the property, the tunnel and the movement of people and money. The challenge extended beyond identifying those who had entered the bank. Investigators also needed to establish who had funded the operation and who later handled its **proceeds**.

As the case developed, authorities arrested suspects and **seized** cash, vehicles and property. Some proceedings concerned **money laundering**, as stolen funds passed through purchases and transactions intended to hide their criminal origin. Other cases involved crimes linked to people connected with the theft.

Recovery took years. In a 2011 account, Banco Central reported around 26 million reais recovered through police action, court orders and the sale of seized assets. That dated figure represented only part of the original loss.

The **prosecutions** produced many **convictions**, but legal outcomes varied. **Appeals** changed some decisions and sentences, and some defendants were acquitted. Accusation, conviction and a final judgment were different stages of the process.

The case became famous for its tunnel, yet its aftermath revealed a much wider network of finance and criminal activity. It showed how a single theft could lead to years of work tracing money, recovering **assets** and establishing individual responsibility.''',
[
v('vault', 'A strongly protected room used to store money or valuables.', 'The bank kept its cash reserves in a vault.', 'Noun', plural='vaults'),
v('investigation', 'A careful examination of facts to establish what happened.', 'The investigation continued after the first arrests.', 'Noun', plural='investigations'),
v('proceeds', 'Money obtained from an activity, sale or crime.', 'The court examined what happened to the proceeds of the theft.', 'Plural noun', note='Used in the plural in this meaning.'),
v('seize', 'To take possession of something using official or legal authority.', 'Police obtained an order to seize the vehicle.', 'Verb', form='seized', verb=('seize','seized','seized',False)),
v('money laundering', 'The process of hiding the criminal origin of money so that it appears legitimate.', 'The financial investigation uncovered evidence of money laundering.', 'Uncountable noun phrase'),
v('prosecution', 'The legal process of bringing a criminal case against someone.', 'The prosecution depended on evidence linking the suspect to the theft.', 'Noun', form='prosecutions', plural='prosecutions'),
v('conviction', 'A formal decision by a court that someone is guilty of a crime.', 'The conviction was later reviewed on appeal.', 'Noun', form='convictions', plural='convictions'),
v('appeal', 'A request for a higher court to review a legal decision.', 'The defendant filed an appeal against the sentence.', 'Noun', form='Appeals', plural='appeals'),
v('asset', 'Something valuable that a person or organization owns.', 'The investigators traced the purchase of each asset.', 'Noun', form='assets', plural='assets')
],
[
m('What was taken from the bank?', ['Customer passwords from a public website.', 'About 164.8 million Brazilian reais in cash.', 'Only a collection of historical documents.'], 'B', 'Over an early-August weekend, the group entered the vault through a tunnel and removed about 164.8 million Brazilian reais in cash.', 'The case concerned a large physical cash theft from the central bank branch.'),
m('Why did the investigation extend beyond those who entered the bank?', ['Every suspect had already returned all the cash.', 'No financing or later transactions were involved.', 'Investigators also needed to trace funding and the later handling of the money.'], 'C', 'Investigators also needed to establish who had funded the operation and who later handled its proceeds.', 'The investigation followed the wider network supporting the theft and handling its proceeds.'),
m('What does the lesson say about the court proceedings?', ['Every accusation led to an identical final sentence.', 'There were no appeals in any of the cases.', 'There were many convictions, alongside changed decisions and some acquittals.'], 'C', 'Appeals changed some decisions and sentences, and some defendants were acquitted.', 'Different legal stages produced varied outcomes for individual defendants.'),
g('The loss was discovered on Monday, August ___.', '8', 'The loss was discovered on Monday, August 8.', 'August 8 was the discovery date in 2005.'),
g('The stolen currency was Brazilian ___.', 'reais', 'Over an early-August weekend, the group entered the vault through a tunnel and removed about 164.8 million Brazilian reais in cash.', 'Reais is the plural name of Brazil’s currency.'),
g('Banco Central reported the recovery figure in a ___ account.', '2011', 'In a 2011 account, Banco Central reported around 26 million reais recovered through police action, court orders and the sale of seized assets.', 'The year is essential because this is a historical recovery figure, not a current total.')
],
[
'Federal Justice of Ceará, trial judgment, 2007 — Theft on the night of August 5–6, discovery August 8, amount and rented property background: https://www.jfce.jus.br/consultaProcessual/resimprsentintegra.asp?CodDoc=2177598',
'Banco Central, August 12, 2005 — Confirmed R$164,755,150 stolen: https://www.bcb.gov.br/detalhenoticia/12984/nota',
'Federal Public Prosecutor’s Office historical timeline — Participants across planning, financing, execution and laundering, prosecutions and convictions: https://linhadotempo.mpf.mp.br/www/linha-do-tempo-pr-ce/furto-ao-banco-central',
'Banco Central, July 2011 recovery interview, questions 11–16 — Recovery around R$26 million, asset sales, associated crimes and different stages of criminal proceedings: https://www.bcb.gov.br/pec/appron/apres/Isaac_Sidney_Entrevista_Recuperacao_de_Creditos_07-07-2011.pdf',
'Federal Regional Court, Fifth Region, appellate judgment, 2008 — Changes to decisions and sentences: https://www4.trf5.jus.br/data/2008/10/200581000145860_20081022.pdf'
],
[
'Overview covers central-bank cash context, group preparation, theft and discovery, investigation of the wider network, money laundering, recovery, legal outcomes and significance.',
'Early-August weekend avoids the frequently repeated but less precise August 6–7 date; the trial judgment dates the theft to the night of August 5–6. August 8 discovery and rounded R$164.8 million are retained.',
'R$26 million recovery is explicitly dated to Banco Central’s 2011 account and includes court-blocked funds and asset sales. No unverified current recovery or conviction total is asserted.',
'High-level history omits tunnel dimensions, construction methods, equipment, security vulnerabilities and evasion instructions. The crime is not presented as a practical guide.',
'Compared with all 001–044. This is distinct from the 1962 prison escape and the global financial crisis; identity and aliases registered in content/topics.json.'
])
