"""Source-reviewed, distinct-event overviews for English Unicorn 066–070."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(66, 'krakatoa-eruption-1883', 'Krakatoa 1883: Eruption, Tsunamis and a Changing Island', 'Disasters and the Natural World',
      'A volcanic eruption in the Sunda Strait destroyed coastal communities through powerful tsunamis and produced effects observed around the world.',
'''Krakatoa, also called Krakatau, was a volcanic island in the Sunda **Strait**, between Java and Sumatra. In 1883, this region belonged to the Dutch East Indies, in what is now Indonesia. Ships used the surrounding waters, and communities lived along the nearby coasts.

Volcanic activity returned in May. Over the following months, ships reported explosions and clouds above the island. The activity became much more violent on August 26 and 27, when a series of powerful **eruptions** transformed the area.

Huge explosions threw **ash** and rock into the sky. Hot mixtures of gas and volcanic material spread outward. Much of the island **collapsed**, leaving a large underwater depression. The eruption and collapse disturbed the surrounding sea and generated destructive **tsunamis**.

Waves struck the shores of Java and Sumatra, destroying **coastal** towns and villages. Some reached heights of around 40 meters. The disaster killed about 36,000 people, most of them through the tsunamis. The scale of the loss extended far beyond the volcano itself, across many separate **settlements**.

Effects were also detected far away. Explosions were heard thousands of kilometers from the island, and instruments around the world recorded changes in air pressure. Telegraph connections helped news travel rapidly, bringing international attention to the disaster.

Material carried high into the **atmosphere** produced striking sunsets in distant countries. Sulfur gases formed tiny particles that reflected sunlight and contributed to temporary global cooling. The longer climate effect came mainly from these particles, rather than heavy ash remaining overhead for years.

The landscape continued to change after 1883. During the 1920s, renewed eruptions began building a new volcanic island within the area of collapse. It became known as Anak Krakatau, or Child of Krakatau.

Reports from ships, measurements and later investigations made the eruption an important case in the study of volcanoes. Krakatoa showed how volcanic activity could combine explosions, sea waves and atmospheric effects. Its history also demonstrated why **monitoring** an island volcano involves studying both the mountain and the surrounding sea.''',
[
v('strait', 'A narrow passage of water connecting two larger areas of sea.', 'Ships crossed the strait between the islands.', 'Noun', form='Strait', plural='straits'),
v('eruption', 'An event in which a volcano releases gas, ash or melted rock.', 'The eruption covered nearby fields with ash.', 'Noun', form='eruptions', plural='eruptions'),
v('ash', 'Fine particles of rock and other material released by a volcano, or powder left after burning.', 'Volcanic ash reduced visibility near the island.', 'Uncountable noun'),
v('collapse', 'To fall down or inward because support has been lost.', 'Part of the structure began to collapse.', 'Verb', form='collapsed', verb=('collapse','collapsed','collapsed',False)),
v('tsunami', 'A series of large sea waves caused by a sudden movement of water, often after an earthquake or volcanic event.', 'The tsunami damaged several coastal villages.', 'Noun', form='tsunamis', plural='tsunamis'),
v('coastal', 'Located on or near the coast.', 'The coastal road connected several fishing towns.', 'Adjective'),
v('settlement', 'A place where people have established a community.', 'The settlement grew around a small harbor.', 'Noun', form='settlements', plural='settlements'),
v('atmosphere', 'The layer of gases surrounding a planet.', 'The instruments measured conditions in the atmosphere.', 'Noun', plural='atmospheres'),
v('monitoring', 'The regular observation or measurement of something to identify changes.', 'Continuous monitoring helped researchers follow the activity.', 'Uncountable noun', note='The noun monitoring refers to an ongoing process of observation.')
],
[
m('What caused most of the deaths in the disaster?', ['The loss of telegraph connections.', 'The tsunamis that struck nearby coasts.', 'A new volcanic island growing decades later.'], 'B', 'The disaster killed about 36,000 people, most of them through the tsunamis.', 'The greatest loss of life occurred across the surrounding coasts, beyond the island itself.'),
m('What contributed to the longer climate effect?', ['Heavy ash stayed directly overhead for many years.', 'The oceans stopped moving after the eruption.', 'Tiny particles formed from sulfur gases reflected sunlight.'], 'C', 'Sulfur gases formed tiny particles that reflected sunlight and contributed to temporary global cooling.', 'The account distinguishes these particles from heavier ash.'),
m('What happened in the area during the 1920s?', ['Renewed eruptions began building a new volcanic island.', 'The original island returned immediately to its earlier shape.', 'All volcanic activity permanently ended.'], 'A', 'During the 1920s, renewed eruptions began building a new volcanic island within the area of collapse.', 'Anak Krakatau formed through later volcanic activity.'),
g('The main disaster occurred in ___.', '1883', 'In 1883, this region belonged to the Dutch East Indies, in what is now Indonesia.', '1883 is the year of the eruption described in the account.'),
g('Krakatoa lay between Java and ___.', 'Sumatra', 'Krakatoa, also called Krakatau, was a volcanic island in the Sunda Strait, between Java and Sumatra.', 'These islands border the Sunda Strait.'),
g('Instruments recorded changes in air ___.', 'pressure', 'Explosions were heard thousands of kilometers from the island, and instruments around the world recorded changes in air pressure.', 'The atmospheric disturbance could be measured far from the volcano.')
],
[
'Smithsonian Global Volcanism Program, Krakatau profile — Location, collapse, volcanic flows, tsunami and later cone growth: https://volcano.si.edu/volcano.cfm?vn=262000',
'NOAA NCEI, updated August 16, 2023 — May activity, coastal destruction, approximate overall deaths, distant observations, telegraph reporting and Anak Krakatau: https://www.ncei.noaa.gov/news/day-historic-krakatau-eruption-1883',
'NOAA JetStream, volcanic tsunami generation — August 27 climax and approximately 41-meter waves affecting Java and Sumatra: https://www.noaa.gov/jetstream/tsunamis/tsunami-generation-volcanoes',
'USGS, Volcanoes Can Affect Climate — Sulfur-derived sulfate particles rather than persistent heavy ash explain longer cooling; specifically discusses Krakatau: https://www.usgs.gov/programs/VHP/volcanoes-can-affect-climate',
'USGS, Krakatau 1883, Simkin and Fiske — Globally recorded effects; its online abstract has an obvious August 17 date typo, not used for chronology: https://pubs.usgs.gov/publication/70168593'
],
[
'Whole-event overview covers location and colonial setting, months of activity, August climax, explosions and collapse, tsunamis and community losses, worldwide observations, atmospheric effects, later land formation and scientific significance.',
'About 36,000 is an approximate overall death toll, with most deaths from tsunamis. Around 40 meters is an approximate local wave height, not a uniform height at every coast.',
'No loudest-ever or deadliest-ever ranking, exact decibel estimate or single definitive tsunami mechanism. Eruption and collapse are described together without resolving debated contributions.',
'The climate paragraph uses USGS aerosol science rather than repeating the older NOAA shorthand attributing years of cooling to heavy ash. No precise disputed temperature or duration claim.',
'Compared with all 001–065 and the other candidates. This is the 1883 Krakatoa event, distinct from Tambora 1815; Anak Krakatau is a brief aftermath, not a retelling of its 2018 disaster. Identity and aliases are registered in content/topics.json.'
])

draft(67, 'panama-canal-construction-opening-1914', 'The Panama Canal: Building a Route Between Oceans', 'Engineering and Global Trade',
      'Years of engineering, disease control and difficult labor created a shipping route across Panama, with major commercial benefits and a high human cost.',
'''A **canal** across Panama promised to shorten journeys between the Atlantic and Pacific oceans. Ships using it could avoid the long voyage around South America. However, the narrow strip of land contained hills, rivers and tropical conditions that made construction difficult.

French builders attempted the project in the 1880s. They faced heavy rain, unstable ground, disease and rising costs. The first company went **bankrupt**, leaving an unfinished route and thousands of workers dead.

In 1903, Panama became independent from Colombia with support from the United States. A **treaty** gave the United States extensive rights to build and operate the waterway. The American construction effort began in 1904, combining commercial aims with an interest in moving naval ships between oceans.

Progress required more than digging. Health teams improved **sanitation** and reduced mosquito breeding, helping control yellow fever and malaria. Engineers reorganized rail transport so that supplies could reach work sites and trains could remove enormous quantities of earth and rock.

The **excavation** through the hills was especially demanding. Heavy rain and **landslides** repeatedly disrupted work. Builders also constructed a **dam** that created Gatun Lake, providing an elevated route across part of the country.

Sets of **locks** raised ships from sea level to the lake and lowered them toward the other ocean. This design allowed vessels to cross the land without requiring the entire canal to be dug down to sea level.

Workers came from many countries, especially Caribbean islands. Their contribution was essential, but racial **discrimination** affected pay, housing and access to services. Disease and accidents killed thousands during construction. Local communities also lost homes as land was cleared or flooded.

On August 15, 1914, the ship Ancon made the canal's first official transit. World War I had begun in Europe, reducing the planned celebrations. The opening created a major new route for international shipping.

The canal demonstrated how engineering, transport organization and public health could support a vast project. Its achievement also depended on workers whose difficult conditions and unequal treatment formed an important part of its history.''',
[
v('canal', 'An artificial waterway built for boats, irrigation or moving water.', 'The canal connected two larger bodies of water.', 'Noun', plural='canals'),
v('bankrupt', 'Unable to pay debts and formally recognized as being in that financial condition.', 'The company went bankrupt before the work was finished.', 'Adjective', note='Go bankrupt means to enter this financial condition.'),
v('treaty', 'A formal agreement between countries.', 'The treaty established rights and responsibilities for both countries.', 'Noun', plural='treaties'),
v('sanitation', 'Systems and conditions that protect health through clean water and safe handling of waste.', 'Better sanitation reduced illness in the town.', 'Uncountable noun'),
v('excavation', 'The process of removing earth or rock to make a hole, passage or construction site.', 'Excavation continued despite the difficult ground.', 'Uncountable noun'),
v('landslide', 'A mass of earth or rock moving down a slope.', 'The landslide blocked the road after heavy rain.', 'Noun', form='landslides', plural='landslides'),
v('dam', 'A barrier built across a river to hold back or control water.', 'The dam created a large reservoir.', 'Noun', plural='dams'),
v('lock', 'A section of a canal with gates and a changing water level that raises or lowers boats.', 'The ship entered the lock before being raised to the next level.', 'Noun', form='locks', plural='locks'),
v('discrimination', 'Unfair treatment of people because of characteristics such as race, sex or religion.', 'The workers challenged discrimination in pay and housing.', 'Uncountable noun')
],
[
m('Why was a canal across Panama valuable for shipping?', ['It could shorten journeys between the Atlantic and Pacific.', 'It would remove the need for ships to carry goods.', 'It would connect Europe directly to Asia without crossing an ocean.'], 'A', 'Ships using it could avoid the long voyage around South America.', 'The route offered a shorter connection across the American continent.'),
m('How did the locks support the canal’s design?', ['They kept all ships permanently at sea level.', 'They raised ships to Gatun Lake and lowered them toward the other ocean.', 'They replaced the lake with a dry railway.'], 'B', 'Sets of locks raised ships from sea level to the lake and lowered them toward the other ocean.', 'The waterway used an elevated lake route rather than a continuous sea-level channel.'),
m('Which statement best represents the workers’ experience?', ['The work involved no serious illness or accidents.', 'Workers from every background received identical treatment.', 'Essential labor came with deaths, difficult conditions and racial discrimination.'], 'C', 'Their contribution was essential, but racial discrimination affected pay, housing and access to services.', 'The following sentences also describe deaths and the loss of local homes.'),
g('The American construction effort began in ___.', '1904', 'The American construction effort began in 1904, combining commercial aims with an interest in moving naval ships between oceans.', 'The 1903 treaty preceded the construction effort.'),
g('The elevated route crossed ___ Lake.', 'Gatun', 'Builders also constructed a dam that created Gatun Lake, providing an elevated route across part of the country.', 'The lake was a central part of the chosen design.'),
g('The ship that made the first official transit was ___.', 'Ancon', "On August 15, 1914, the ship Ancon made the canal's first official transit.", 'This refers to the official opening, rather than every earlier passage.')
],
[
'U.S. Office of the Historian, Building the Panama Canal — French failure, commercial and naval goals, 1903 independence and treaty; historical page now retired from maintenance: https://history.state.gov/milestones/1899-1913/panama-canal',
'Panama Canal Authority, American Canal Construction — 1904 start, disease control, railways, design and displacement: https://pancanal.com/en/american-canal-construction/',
'Panama Canal Authority, operation and history — Elevated Gatun Lake route and locks: https://pancanal.com/en/history-of-the-panama-canal/',
'Panama Canal Authority, End of the Construction — August 15 opening, Ancon first official transit, earlier January passage, wartime celebrations and incomplete death records: https://pancanal.com/en/end-of-the-construction/',
'U.S. National Archives, The African American Experience — Evidence from canal employment records of racially unequal pay, housing and services: https://www.archives.gov/publications/prologue/1997/summer/panama-canal',
'UNESCO Memory of the World, Silver Men — Essential labor and migration of West Indian workers: https://www.unesco.org/en/memory-world/lac/silver-men-west-indian-labourers-panama-canal-1880-1914'
],
[
'Whole-event overview includes the shipping goal, French attempt, political setting, health and rail logistics, excavation and landslides, dam and lock design, workforce and displaced communities, opening and wider impact.',
'Ancon made the first official transit at the August 15, 1914 opening, not the first-ever passage. Earlier trial and construction passages are not denied.',
'French work is placed broadly in the 1880s because institutional summaries use differing start dates. Thousands died is deliberately approximate across construction history, without treating incomplete hospital records as an exact total.',
'Locks are explained through the elevated lake route, not a supposed large sea-level difference between oceans. Disease was reduced rather than declared eliminated; no current clinical guidance.',
'Worker contributions and discrimination prevent a single-leader engineering triumph narrative. No unsolicited contemporary politics or unverified corruption-free claim.',
'Compared with all 001–066 and the other candidates. Panama construction and opening are distinct from the Suez blockage of 2021. Identity and aliases are registered in content/topics.json.'
])

draft(68, 'radioactivity-discovery-1896-1903', 'The Discovery of Radioactivity: Evidence and New Elements', 'Science and Discovery',
      'Unexpected marks on photographic plates led to careful measurements, new chemical elements and a changing understanding of the atom.',
'''In the late 19th century, scientists were investigating invisible rays and the structure of matter. The discovery of X-rays encouraged new experiments. One investigation in Paris would reveal that some materials released **radiation** without needing sunlight or an electrical machine.

In 1896, Henri Becquerel studied uranium salts using **photographic** plates protected from ordinary light. He initially thought sunlight might be necessary for the effect. However, plates stored in darkness also became strongly marked. Further experiments showed that uranium could **emit** radiation spontaneously.

Marie Curie chose these uranium rays as a subject for research. Instead of relying only on photographs, she used electrical instruments to compare different samples. Her **measurements** linked the activity to uranium itself, rather than to a particular chemical arrangement. She introduced the term radioactivity for this behavior.

Some **minerals** produced stronger activity than their uranium content could explain. Marie and Pierre Curie investigated together, separating materials and testing the different portions. The results suggested that the minerals contained unknown radioactive **elements**.

In July 1898, they announced polonium, named after Marie's homeland, Poland. In December, they announced evidence for radium with chemist Gustave Bémont. Another scientist, Eugène Demarçay, found an unfamiliar line in the material's light spectrum, adding independent support for the new element.

The announcements did not mean large quantities of pure material were immediately available. Years of processing mineral **residues** followed. In 1902, Marie prepared a tiny quantity of **purified** radium chloride and measured radium's atomic weight. The product was a chemical compound, rather than pure radium metal.

In 1903, Becquerel and the Curies received the Nobel Prize in Physics in **recognition** of their work. Their discoveries opened a growing field involving many researchers.

Later studies of radioactive changes challenged the idea that atoms were indivisible and unchanging. Radiation also damaged skin, revealing dangers that early researchers did not fully understand. The discovery combined an unexpected observation with repeated testing, chemical work and evidence gathered over years.''',
[
v('radiation', 'Energy that travels through space or material as waves or particles.', 'The instrument detected radiation from the sample.', 'Uncountable noun'),
v('photographic', 'Connected with photographs or the process of producing them.', 'The archive contains photographic records of the experiment.', 'Adjective'),
v('emit', 'To give off light, heat, gas, radiation or another form of energy or material.', 'Some materials emit radiation naturally.', 'Verb', verb=('emit','emitted','emitted',False)),
v('measurement', 'The act or result of determining an amount, size or physical property.', 'The team repeated the measurement to check the result.', 'Noun', form='measurements', plural='measurements'),
v('mineral', 'A naturally occurring solid substance with a particular chemical composition and structure.', 'The mineral contained a small amount of uranium.', 'Noun', form='minerals', plural='minerals'),
v('element', 'A chemical substance made of atoms that all have the same number of protons.', 'The researchers found evidence for a previously unknown element.', 'Noun', form='elements', plural='elements'),
v('residue', 'Material remaining after a process or after other material has been removed.', 'A small residue remained after the liquid had evaporated.', 'Noun', form='residues', plural='residues'),
v('purify', 'To remove unwanted substances from something.', 'The researchers needed to purify the sample before measuring it.', 'Verb', form='purified', verb=('purify','purified','purified',False)),
v('recognition', 'Public acknowledgment of someone’s work, achievement or importance.', 'The award brought recognition for years of research.', 'Uncountable noun')
],
[
m('Why did the result in darkness matter?', ['It proved that the plates had to receive direct sunlight.', 'It showed that uranium had stopped producing any effect.', 'It showed that sunlight was unnecessary for the radiation.'], 'C', 'However, plates stored in darkness also became strongly marked.', 'The unexpected result challenged Becquerel’s initial idea about sunlight.'),
m('Why did the Curies suspect unknown elements in some minerals?', ['The activity was stronger than the uranium content could explain.', 'Every tested mineral contained exactly the same substances.', 'The minerals produced no measurable activity.'], 'A', 'Some minerals produced stronger activity than their uranium content could explain.', 'The unexplained activity guided further separation and testing.'),
m('What had Marie prepared in 1902?', ['A large quantity of pure radium metal.', 'A tiny quantity of purified radium chloride.', 'A working X-ray machine invented by the Curies.'], 'B', "In 1902, Marie prepared a tiny quantity of purified radium chloride and measured radium's atomic weight.", 'The following sentence specifies that radium chloride is a compound, rather than radium metal.'),
g('Becquerel studied the unexpected photographic effect in ___.', '1896', 'In 1896, Henri Becquerel studied uranium salts using photographic plates protected from ordinary light.', '1896 marks Becquerel’s discovery, before the new-element announcements.'),
g('Polonium was named after Marie’s homeland, ___.', 'Poland', "In July 1898, they announced polonium, named after Marie's homeland, Poland.", 'The name referred to her country of origin.'),
g('The researchers received the Nobel Prize in Physics in ___.', '1903', 'In 1903, Becquerel and the Curies received the Nobel Prize in Physics in recognition of their work.', 'The prize recognized their work on radioactivity.')
],
[
'Curie Museum, The Curie Method, discovery of uranium rays — Includes Becquerel’s original 1896 account and the evidence in darkness: https://lamethodecurie.fr/en/article12.html',
'American Institute of Physics, Research Breakthroughs — Electrical measurements, uranium as an atomic property and the word radioactivity: https://history.aip.org/exhibits/curie/resbr1_text.htm',
'American Institute of Physics, discovery of polonium and radium — Unexpected mineral activity and collaborative chemical research: https://history.aip.org/exhibits/curie/resbr2.htm',
'Pierre Curie, Marie Curie and Gustave Bémont, December 26, 1898 paper, translated by Alfred Romer and hosted by AIP — Radium evidence and Demarçay’s spectrum: https://history.aip.org/exhibits/curie/discover.htm',
'Curie Museum, Radium’s atomic weight — 1902 purification of radium chloride and measurement, with original recollections: https://lamethodecurie.fr/en/article27.html',
'Nobel Prize, Physics 1903 award record — Becquerel and the Curies; indexed official text verified, direct retrieval blocked: https://www.nobelprize.org/prizes/physics/1903/summary/',
'American Institute of Physics, The Unstable Nucleus — Subsequent work by Rutherford, Soddy and others; its unnecessary claim about the longest-lived polonium isotope is not used: https://history.aip.org/exhibits/curie/unstable_text.htm',
'Curie Museum exhibit, The discovery of radioactivity, hosted by Google Arts and Culture — Early observed skin effects and hazards: https://artsandculture.google.com/story/9AUhgesyI5QKJw?hl=en'
],
[
'Whole-discovery overview covers the scientific setting, Becquerel’s observation and follow-up, Marie’s quantitative measurements, mineral puzzle, collaborative element announcements, years of confirmation, recognition, scientific changes and early hazards.',
'Becquerel discovered spontaneous radioactivity; the Curies investigated it and identified new elements. X-rays inspired the work but were not their discovery. An unexpected result is followed by investigation rather than being described as luck alone.',
'The 1898 announcements are distinct from purified radium chloride in 1902. No claim of pure radium metal in either year, no ore-processing quantities or hazardous practical recipe.',
'Bémont and Demarçay provide explicit acknowledgment of collaborators. Later understanding of changing atoms is not attributed entirely to the Curies, and there is no claim that they discovered the nucleus.',
'The skin-effects sentence is historical and nongraphic, not current medical guidance. No unsupported claim of safe exposure, and no isotope ranking or oversimplified magnetic-deflection account.',
'Compared with all 001–067 and the other candidates. Radioactivity discovery is distinct from earlier nuclear disasters, medical discoveries and DNA research. Identity and aliases are registered in content/topics.json.'
])

draft(69, 'great-train-robbery-britain-1963', 'Britain 1963: The Great Train Robbery and Its Aftermath', 'Crime and Investigation',
      'The theft of cash from an overnight postal train injured railway workers, triggered a major investigation and led to prison sentences and a long pursuit of fugitives.',
'''In 1963, Britain's railway network carried letters, parcels and valuable packages as well as passengers. On Travelling Post Office trains, employees sorted **mail** during the journey. Some packages contained large amounts of cash moving between banks.

Early on August 8, a **gang** stopped the Glasgow-to-London mail train in Buckinghamshire. The robbers, led by Bruce Reynolds, stole about £2.6 million near Bridego Bridge. It was an enormous loss at the time, and the attack quickly became known as the Great Train Robbery.

The theft involved serious violence. Driver Jack Mills was **assaulted** and suffered a head injury. His colleague David Whitby was also attacked. The injured Mills was forced to move the train. Both railway workers later struggled with the **trauma** of the experience.

The criminals took the money to a farmhouse before dispersing. A report from a local resident helped direct police toward the property. Investigators found abandoned postal material and other physical evidence connecting the building with the crime.

Local officers worked with London **detectives** and postal investigators in a large inquiry. **Fingerprints** found at the farmhouse helped identify **suspects**. Witness accounts, examination of objects and information from the public contributed to the search and the cases brought to court.

Trials led to long prison **sentences** for many involved. Some participants remained at large or escaped after being imprisoned, extending the investigation beyond the first arrests. Reynolds avoided capture for five years before police found him.

Ronnie Biggs became a particularly well-known **fugitive**. He escaped from prison in 1965 and spent decades abroad before returning to Britain in 2001. His story was one part of an aftermath involving many offenders, investigators and court proceedings.

Most of the stolen money was never recovered. Newspapers, books and films kept the case in public memory, while museum collections preserved evidence and records of the investigation. The robbery's history includes the loss of money, the lasting harm to ordinary workers and the effort required to bring those responsible to justice.''',
[
v('mail', 'Letters and packages sent or delivered through a postal system.', 'The staff sorted the mail before the train arrived.', 'Uncountable noun'),
v('gang', 'A group of people who associate together, especially to commit crimes.', 'Police investigated the activities of the gang.', 'Noun', plural='gangs'),
v('assault', 'To attack someone physically.', 'The witness reported that a worker had been assaulted.', 'Verb', form='assaulted', verb=('assault','assaulted','assaulted',False)),
v('trauma', 'Severe emotional shock or lasting distress after a frightening or harmful experience.', 'The survivors received support after the trauma.', 'Uncountable noun'),
v('detective', 'A police officer or investigator whose work is to investigate crimes.', 'The detective interviewed several witnesses.', 'Noun', form='detectives', plural='detectives'),
v('fingerprint', 'The distinctive pattern left by the ridges on a person’s fingertip.', 'The fingerprint was examined as part of the investigation.', 'Noun', form='Fingerprints', plural='fingerprints'),
v('suspect', 'A person believed to possibly be involved in a crime, whose involvement has not necessarily been proved.', 'The suspect was questioned and later released.', 'Noun', form='suspects', plural='suspects'),
v('sentence', 'A punishment formally imposed by a court on someone found guilty of a crime.', 'The court imposed a prison sentence.', 'Noun', form='sentences', plural='sentences'),
v('fugitive', 'A person who is escaping or hiding to avoid arrest or imprisonment.', 'The fugitive remained abroad for several years.', 'Noun', plural='fugitives')
],
[
m('What made the mail train valuable to the robbers?', ['It was carrying valuable paintings for a museum.', 'Some postal packages contained large amounts of cash.', 'Its passenger carriages were filled with gold bars.'], 'B', 'Some packages contained large amounts of cash moving between banks.', 'Cash was transported within the postal system as well as ordinary correspondence.'),
m('What helped connect suspects with the farmhouse?', ['A passenger list from a later train.', 'A film made years after the robbery.', 'Fingerprints found during the investigation.'], 'C', 'Fingerprints found at the farmhouse helped identify suspects.', 'Physical evidence was one part of the wider inquiry.'),
m('Why did the aftermath extend beyond the first arrests?', ['Some offenders remained at large or escaped from prison.', 'The courts waited until 2001 to hear every case.', 'Police recovered all the money immediately and ended the inquiry.'], 'A', 'Some participants remained at large or escaped after being imprisoned, extending the investigation beyond the first arrests.', 'Different offenders were pursued and dealt with at different times.'),
g('The robbery took place in August ___.', '1963', 'In 1963, Britain’s railway network carried letters, parcels and valuable packages as well as passengers.'.replace('’', "'"), 'The opening places the overnight train journey in 1963.'),
g('The driver’s surname was ___.', 'Mills', 'Driver Jack Mills was assaulted and suffered a head injury.', 'Mills and his colleague Whitby both suffered harm during the crime.'),
g('Biggs returned to Britain in ___.', '2001', 'He escaped from prison in 1965 and spent decades abroad before returning to Britain in 2001.', 'His return occurred decades after the original robbery.')
],
[
'The Postal Museum, archival exhibition hosted by Google Arts and Culture — Postal context, August 8, approximately £2.6 million, worker assaults, public tip, farmhouse evidence and unrecovered money: https://artsandculture.google.com/story/the-great-train-robbery-british-postal-museum/aAWRARcgrhkA8A?hl=en-GB',
'The Postal Museum, collection account — Production page returned a retrieval block; institutional indexed text corroborates date and approximate loss: https://www.postalmuseum.org/collections/great-train-robbery/',
'Thames Valley Police Museum, case history — Mills and Whitby, trauma, multi-agency investigation, fingerprints, court proceedings, Reynolds and Biggs: https://www.thamesvalley.police.uk/police-forces/thames-valley-police/areas/au/about-us/thames-valley-police-museum/the-great-train-robbery/',
'British Transport Police, crime history — Railway mail context, public information, fingerprints, later capture and Biggs’s 2001 return; its departure-date and loss-amount discrepancies are not repeated: https://www.btp.police.uk/police-forces/british-transport-police/areas/campaigns/our-history/crime-history/great-train-robbery/'
],
[
'Whole-event overview covers the railway postal system, attack and approximate loss, both workers, investigation and physical evidence, court outcomes, later fugitives, unrecovered money and public memory.',
'The raid occurred early on August 8, 1963. No claim that the train departed Glasgow late that same day. About £2.6 million follows Postal Museum records rather than the conflicting BTP figure; no unstable present-day currency equivalent.',
'No signal-tampering, communications interference, transport procedure, security vulnerability or escape instructions. Fingerprints and public information are described at a broad historical level.',
'The crime is not called nonviolent or celebrated as brilliant. Both Mills and Whitby are included. Their later deaths are omitted, avoiding an unsupported medical causal claim or invented identification of Mills’s attacker.',
'Many rather than all participants were imprisoned. Biggs is a brief part of the aftermath, not the central frame for the whole robbery. No claim the criminals kept or spent the entire amount successfully.',
'Compared with all 001–068 and the remaining candidate. This is a distinct British postal-train robbery, separate from the Fortaleza bank heist, Alcatraz escape and D. B. Cooper hijacking. Identity and aliases are registered in content/topics.json.'
])

draft(70, 'partition-british-india-1947', 'Partition 1947: Independence, Borders and Displacement', 'History and Society',
      'The end of British rule created India and Pakistan, while rushed borders, mass migration and communal violence transformed millions of lives.',
'''In August 1947, British rule in India ended and two independent countries emerged: India and Pakistan. **Independence** fulfilled a long struggle for self-government. It also came with **Partition**, the division of British India, and a major human crisis.

Decades of **colonial** rule and political campaigning shaped the transition. After World War II, Britain prepared to leave. Indian leaders disagreed about the future state, including how power would be shared and how religious **minorities** would be protected.

The Indian National Congress initially sought a united country. The Muslim League, led by Muhammad Ali Jinnah, demanded a separate Muslim homeland. **Negotiations** failed to produce an agreed political settlement. Growing communal violence and a rapid British withdrawal made the situation more dangerous.

In June 1947, a partition plan was announced. Pakistan would include two separated regions, one west of India and one to the east. The provinces of Punjab and Bengal were divided. Commissions chaired by British lawyer Cyril Radcliffe worked on the new **boundary** lines.

The final border decisions became public on August 17, after independence. Many people faced uncertainty over which country would contain their homes. Fear, attacks and changing borders helped drive a vast **migration**.

Millions of Muslims moved toward Pakistan, while millions of Hindus and Sikhs moved toward India. Many became **refugees**, leaving land, possessions and familiar communities behind. Hundreds of thousands were killed in communal violence, although no exact death toll is known.

People from different religious communities suffered and took part in attacks. Other people protected neighbors and helped families reach safety across religious lines. Experiences varied by region, and many people remained in their original homes.

The **displacement** continued to shape life after 1947. Families needed housing, work and education, and migration in Bengal continued for years. Disputes between India and Pakistan, especially over Kashmir, led to further conflict. East Pakistan later became Bangladesh.

Partition changed South Asia's political map and family histories across generations. Its consequences included the achievement of independence, enormous loss and the long task of rebuilding lives in new surroundings.''',
[
v('independence', 'The condition of a country governing itself without control by another country.', 'The country celebrated independence after a long political struggle.', 'Uncountable noun', form='Independence'),
v('partition', 'The division of a country or territory into separate parts.', 'The partition created new political borders.', 'Noun', form='Partition', plural='partitions'),
v('colonial', 'Connected with a country’s control over another territory and its people.', 'The archive contains documents from the colonial period.', 'Adjective'),
v('minority', 'A group within a society that is smaller in number than the main group, often with a different religion, language or background.', 'The constitution promised protection for every minority.', 'Noun', form='minorities', plural='minorities'),
v('negotiation', 'A discussion intended to reach an agreement between people or groups.', 'The negotiation continued after the first proposal was rejected.', 'Noun', form='Negotiations', plural='negotiations'),
v('boundary', 'A line marking the limit or division between areas.', 'The boundary separated two administrative districts.', 'Noun', plural='boundaries'),
v('migration', 'The movement of people from one place to another, especially to live there.', 'The migration changed the population of several cities.', 'Uncountable noun'),
v('refugee', 'A person forced to leave home to seek safety from war, persecution or violence.', 'The refugee family found temporary shelter.', 'Noun', form='refugees', plural='refugees'),
v('displacement', 'The forced movement of people from their homes or usual places of residence.', 'The displacement separated families from their land and livelihoods.', 'Uncountable noun')
],
[
m('What prevented an agreed political settlement before Partition?', ['All leaders had already agreed on one shared government.', 'The borders had been settled long before the talks began.', 'Leaders disagreed over the future state, power and protections for minorities.'], 'C', 'Indian leaders disagreed about the future state, including how power would be shared and how religious minorities would be protected.', 'These disagreements and failed negotiations formed part of a wider political and social crisis.'),
m('When did the final border decisions become public?', ['On August 17, after independence.', 'Several years before the independence campaign.', 'Only after East Pakistan became Bangladesh.'], 'A', 'The final border decisions became public on August 17, after independence.', 'Uncertainty about the final boundaries continued through the transfer of power.'),
m('Which statement describes the aftermath?', ['Every affected family completed its move in August 1947.', 'Displacement, rebuilding and regional migration continued beyond 1947.', 'Partition created three independent countries immediately.'], 'B', 'Families needed housing, work and education, and migration in Bengal continued for years.', 'The effects extended beyond the initial division; Bangladesh became independent later.'),
g('British rule ended and the two countries emerged in ___.', '1947', 'In August 1947, British rule in India ended and two independent countries emerged: India and Pakistan.', 'The opening establishes the year of independence and Partition.'),
g('Cyril ___ chaired the boundary commissions.', 'Radcliffe', 'Commissions chaired by British lawyer Cyril Radcliffe worked on the new boundary lines.', 'Radcliffe chaired the work concerning the new boundaries.'),
g('East Pakistan later became ___.', 'Bangladesh', 'East Pakistan later became Bangladesh.', 'Pakistan initially had eastern and western regions separated by India.')
],
[
'The National Archives, Partition of British India — Original documents and teaching context; official indexed text reviewed, direct page retrieval blocked: https://www.nationalarchives.gov.uk/education/teaching-resources/partition-of-british-india/',
'The National Archives, Indian independence part one — Wartime context, failed political plans and Muslims remaining in India: https://www.nationalarchives.gov.uk/education/teaching-resources/indian-independence-part-one/',
'National Army Museum, Independence and Partition, 1947 — Political disagreements, independence, two Pakistani regions, migration and Kashmir aftermath: https://www.nam.ac.uk/explore/independence-and-partition-1947',
'Partition Museum, historical and regional accounts — Punjab and Bengal boundaries, August 17 publication, uncertain totals, displacement and continuing migration: https://www.partitionmuseum.org/partition-of-india',
'Partition Museum, oral histories — Varied family experiences and assistance across religious lines: https://www.partitionmuseum.org/oral-history'
],
[
'Whole-event overview covers colonial and wartime setting, self-government and competing political plans, minorities and failed negotiations, rapid withdrawal, territorial division and boundary timing, migration and communal violence, varied responses and longer consequences.',
'No single-cause or single-community blame. Communal violence is situated within political conflict and colonial withdrawal, not described as timeless or inevitable. India is not called an exclusively Hindu state.',
'The June plan is not assigned a day because institutional summaries disagree. August 17 is the publication of final border awards, after independence. No claim that two wholly new republics had already been established in August 1947.',
'Millions displaced and hundreds of thousands killed are broad estimates, with uncertainty explicit; no false exact total or claim that every member of a religious group migrated. Violence remains nongraphic.',
'Two separated Pakistani regions existed in 1947; Bangladesh arose later. Regional differences and migration beyond 1947 are explicit. Kashmir is an aftermath reference, without claiming to settle current sovereignty or current diplomatic conditions.',
'Compared with all 001–069. This is the 1947 partition and independence transition in South Asia, distinct from the Berlin Wall and other previously covered political events. Identity and aliases are registered in content/topics.json.'
])
