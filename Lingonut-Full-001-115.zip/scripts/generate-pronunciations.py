"""Create reusable US-English MP3 pronunciations for vocabulary headwords."""
import argparse
import asyncio
import datetime
import hashlib
import html
import json
import os
from pathlib import Path
import re
import ssl
import subprocess
import tempfile
import unicodedata
import edge_tts

ROOT = Path(__file__).resolve().parent.parent
VOICE = 'en-US-AvaNeural'
AUDIO = ROOT / 'content/pronunciations'
INDEX = AUDIO / 'index.json'


def normalize(value):
    return re.sub(r'[^a-z0-9]', '', unicodedata.normalize('NFKD', html.unescape(value)).lower())


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--drafts', nargs='*', type=int, default=[])
    parser.add_argument('--concurrency', type=int, default=4, choices=range(1, 7))
    args = parser.parse_args()
    certificate = os.environ.get('SSL_CERT_FILE')
    if certificate and Path(certificate).is_file():
        import edge_tts.communicate as communicate
        communicate._SSL_CTX = ssl.create_default_context(cafile=certificate)
    AUDIO.mkdir(parents=True, exist_ok=True)
    index = json.loads(INDEX.read_text()) if INDEX.exists() else {'version': 1, 'voice': VOICE, 'entries': {}}
    lessons = [json.loads(p.read_text()) for p in (ROOT / 'content/lessons').glob('*.json')]
    lessons = [d for d in lessons if d.get('published', True)]
    for n in args.drafts:
        lessons.append(json.loads((ROOT / f'content/editorial-drafts/{n:03}.json').read_text())['lesson'])
    words = sorted(set(re.sub(r'\s+', ' ', p['phrase'].strip()).lower() for d in lessons for p in d['phrases']))
    todo = []
    for word in words:
        existing = index['entries'].get(word, {})
        if existing.get('voice') == VOICE and existing.get('textSha256') == hashlib.sha256(word.encode()).hexdigest() and (AUDIO / existing.get('file', '')).is_file():
            continue
        todo.append(word)
    print(f'Pronunciations: {len(words)} unique headwords; {len(todo)} need recordings.', flush=True)
    semaphore = asyncio.Semaphore(args.concurrency)
    completed = 0

    async def generate(word):
        nonlocal completed
        async with semaphore:
            filename = hashlib.sha256((VOICE + '\n' + word).encode()).hexdigest()[:20] + '.mp3'
            for attempt in range(3):
                try:
                    with tempfile.TemporaryDirectory(prefix='unicorn-word-') as directory:
                        temporary = Path(directory) / filename
                        boundaries = []
                        with temporary.open('wb') as output:
                            async for chunk in edge_tts.Communicate(word, VOICE, boundary='WordBoundary').stream():
                                if chunk['type'] == 'audio':
                                    output.write(chunk['data'])
                                elif chunk['type'] == 'WordBoundary':
                                    boundaries.append(chunk['text'])
                        assert normalize(' '.join(boundaries)) == normalize(word), (word, boundaries)
                        probe = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration:stream=codec_name', '-of', 'json', str(temporary)]))
                        duration = float(probe['format']['duration'])
                        assert probe['streams'][0]['codec_name'] == 'mp3' and 0.05 < duration < 30
                        subprocess.run(['ffmpeg', '-v', 'error', '-i', str(temporary), '-f', 'null', '-'], check=True)
                        target = AUDIO / filename
                        target.write_bytes(temporary.read_bytes())
                        index['entries'][word] = {'text': word, 'file': filename, 'voice': VOICE,
                            'textSha256': hashlib.sha256(word.encode()).hexdigest(),
                            'audioSha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                            'durationSeconds': duration, 'completeWordBoundaryMatch': True,
                            'provider': 'Microsoft Edge Read Aloud via edge-tts',
                            'registeredAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}
                        temporary_index = INDEX.with_suffix('.tmp')
                        temporary_index.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
                        temporary_index.replace(INDEX)
                        completed += 1
                        if completed % 10 == 0 or completed == len(todo):
                            print(f'Pronunciations saved: {completed}/{len(todo)}', flush=True)
                    return
                except Exception:
                    if attempt == 2:
                        raise
                    await asyncio.sleep(attempt + 1)
    await asyncio.gather(*(generate(word) for word in todo))
    print(json.dumps({'status': 'complete', 'headwords': len(words), 'newRecordings': completed, 'voice': VOICE}), flush=True)


if __name__ == '__main__':
    asyncio.run(main())
