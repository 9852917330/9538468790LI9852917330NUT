"""Reviewed world events, scientific discovery and the struggle against slavery."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(96, 'iranian-revolution-1979', 'Iran 1979: Revolution and the Creation of an Islamic Republic', 'World Events and Political Change',
      'A broad movement overthrew Iran’s monarchy, but competing hopes for the future gave way to a republic dominated by religious leadership.',
'''Before 1979, Iran was a **monarchy** ruled by Shah Mohammad Reza Pahlavi. His power had grown after a 1953 coup, backed by the United States and Britain, removed Prime Minister Mohammad Mossadegh. Many Iranians associated the Shah with foreign interference.

Oil income financed rapid development, education and social change. However, **inequality**, rising prices and corruption created anger. Some religious leaders opposed changes they considered harmful to Islamic society. Others demanded political freedom. The Shah's secret police suppressed **dissent**, leaving few peaceful ways to challenge his rule.

During 1978, protests spread across Iran. Students, religious groups, merchants, workers and secular opponents formed a broad **coalition**, although they disagreed about the country's future. Ayatollah Ruhollah Khomeini, a religious leader living abroad, became its most influential voice. Messages from him circulated through speeches and recordings.

Security forces killed demonstrators, increasing public anger. Large marches and **strikes**, including stoppages in the oil industry, weakened the government. The Shah offered changes, but confidence in his leadership continued to fall.

On January 16, 1979, he left Iran for **exile**. Khomeini returned on February 1 to an enormous welcome. The remaining government collapsed on February 11 after armed clashes and the army's declaration of neutrality. The monarchy had fallen, but the struggle over the new state was beginning.

After a March **referendum**, an Islamic republic was proclaimed on April 1. A new **constitution**, approved later that year, combined elected institutions with powerful religious authorities and placed Khomeini at the top of the system.

The groups that had opposed the Shah did not share power equally. Khomeini's supporters increasingly defeated or excluded rivals. New restrictions and **repression** challenged hopes for political freedom, including those of many women and minority communities.

In November, revolutionary students seized the United States embassy in Tehran, beginning a prolonged hostage crisis. Relations with Washington deteriorated sharply.

The revolution transformed Iran's government, society and international position. It also showed how a united movement against a ruler could produce deep conflict over what should replace him.''',
[
v('monarchy', 'A system of government in which a king, queen or similar hereditary ruler is head of state.', 'The revolution brought the monarchy to an end.', 'Noun', plural='monarchies'),
v('inequality', 'An unfair difference in resources, opportunities or treatment between people or groups.', 'Growing inequality increased public frustration.', 'Noun', plural='inequalities'),
v('dissent', 'Public disagreement with an official opinion, policy or authority.', 'The law restricted peaceful dissent.', 'Uncountable noun'),
v('coalition', 'A group of people or organizations that work together for a shared purpose.', 'The coalition united groups with different political views.', 'Noun', plural='coalitions'),
v('strike', 'A period when workers stop working together to demand change or express opposition.', 'The strike interrupted production at the factory.', 'Noun', form='strikes', plural='strikes'),
v('exile', 'The state of living away from one’s country because returning is forbidden or unsafe.', 'The former ruler spent his final years in exile.', 'Uncountable noun'),
v('referendum', 'A public vote on a particular political question.', 'The referendum asked voters to approve a new political system.', 'Noun', plural='referendums'),
v('constitution', 'The basic laws and principles that define how a country is governed.', 'The constitution described the powers of the elected assembly.', 'Noun', plural='constitutions'),
v('repression', 'The use of force or strict controls to prevent political opposition or personal freedom.', 'Political repression forced many activists into hiding.', 'Uncountable noun')
],
[
m('What united the groups opposing the Shah?', ['Opposition to his rule, despite disagreements about the country’s future.', 'Agreement that the monarchy should continue with the same powers.', 'A shared plan to remove religious organizations from public life.'], 'A', 'Students, religious groups, merchants, workers and secular opponents formed a broad coalition, although they disagreed about the country\'s future.', 'Their common opposition did not mean that they wanted the same new government.'),
m('Which sequence matches the political transition in 1979?', ['The republic was proclaimed before the Shah left, and Khomeini returned afterward.', 'The Shah left, Khomeini returned, the remaining government collapsed, and a republic was proclaimed.', 'The new constitution was approved before protests spread across Iran.'], 'B', 'The remaining government collapsed on February 11 after armed clashes and the army\'s declaration of neutrality.', 'The surrounding paragraphs place the Shah’s departure in January, Khomeini’s return in February and the republic’s proclamation in April.'),
m('What does the story say about the new political system?', ['Every group in the revolutionary coalition received an equal share of power.', 'It replaced all elected institutions with a restored hereditary monarchy.', 'It combined elected institutions with powerful religious authorities and excluded many rivals.'], 'C', 'A new constitution, approved later that year, combined elected institutions with powerful religious authorities and placed Khomeini at the top of the system.', 'The next paragraph describes the unequal struggle for power and growing restrictions.'),
g('Stoppages in the ___ industry helped weaken the government.', 'oil', 'Large marches and strikes, including stoppages in the oil industry, weakened the government.', 'Industrial action affected an important source of national income.'),
g('An Islamic republic was proclaimed on ___ 1, 1979.', 'April', 'After a March referendum, an Islamic republic was proclaimed on April 1.', 'The referendum and the formal proclamation occurred at different points in the transition.'),
g('The embassy seized in November was in ___.', 'Tehran', 'In November, revolutionary students seized the United States embassy in Tehran, beginning a prolonged hostage crisis.', 'The hostage crisis was a later development in the revolution’s international aftermath.')
],
[
'Library of Congress Federal Research Division, Iran: A Country Study, fifth edition, 2008 — Historical setting and introduction: 1953 coup, modernisation, inflation, inequality, political controls, diverse opposition, 1978 escalation, revolutionary power struggle and new constitution. Accessible full OCR, rather than the blocked catalog landing page: https://tile.loc.gov/storage-services/master/frd/frdcstdy/ir/irancountrystudy00curt_0/irancountrystudy00curt_0_djvu.txt',
'US State Department, Foreign Relations of the United States, May 8, 1980 intelligence briefing — Contemporary assessment of the broad anti-Shah coalition and its subsequent disintegration; its partisan language is not repeated as neutral narration: https://history.state.gov/historicaldocuments/frus1977-80v11p1/d281',
'US National Archives, 444 Days: Selected Records Concerning the Iran Hostage Crisis 1979–1981 — January 16 departure, February 1 return, February 11 fall of monarchy, April 1 republic, November embassy seizure and December constitutional referendum: https://www.archives.gov/research/foreign-policy/iran-hostage-crisis'
],
[
'Full-event overview balances preconditions and the Shah’s development programme with repression and inequality, a diverse opposition movement, protests and industrial action, the January–February collapse, institutional transformation, contested freedom and international consequences.',
'The Shah ruled before 1953; the foreign-backed coup strengthened his position rather than first placing him on the throne. Foreign influence is one grievance, not a complete single-cause explanation.',
'The revolutionary coalition included secular and religious groups with different aims. Khomeini’s prominence does not imply that every participant wanted the eventual constitutional settlement.',
'January departure, February collapse, March referendum, April republic and later constitution are distinct developments. The Archives timeline compresses Khomeini’s authority on February 11; the lesson does not claim that his later constitutional office already existed that day.',
'New repression and restrictions are described without presenting the fall of the Shah as an immediate democratic settlement. The hostage crisis receives one short paragraph and does not displace the revolution as the central subject. Contemporary Iranian politics is outside this historical scope.',
'Compared with all 001–095, the four other batch subjects and the Lincoln reservation. This is Iran’s 1979 revolution, distinct from 075’s Russian revolutions, 086’s French Revolution and 092’s Soviet dissolution.'
])


draft(97, 'rana-plaza-building-collapse-2013', 'Rana Plaza 2013: A Building Collapse That Exposed the Cost of Clothing', 'Disasters and Global Responsibility',
      'Ignored warnings and unsafe working conditions led to a deadly collapse in Bangladesh, bringing worldwide pressure for safer factories and support for victims.',
'''Clothes sold around the world often pass through long chains of factories, suppliers and retailers. In Bangladesh, the clothing industry created millions of jobs, many for women. Yet low pay, weak safety controls and pressure to keep production moving left workers vulnerable.

Rana Plaza was an eight-storey commercial building in Savar, near Dhaka. It contained shops, a bank and several **garment** factories producing clothes for international markets.

On April 23, 2013, large **cracks** were discovered. Shops and the bank closed, but factory managers ordered workers to return the following day. Many feared losing their **wages** or jobs if they refused. Their concern about the danger did not give them enough power to avoid it.

On April 24, the building collapsed while thousands of people were inside. Concrete floors and machinery fell together, trapping workers under **rubble**. Local volunteers joined emergency teams, searching for people and carrying the injured to hospitals. Rescue efforts continued for days.

The disaster killed 1,134 people and injured around 2,500. Families lost relatives and sources of income. Many **survivors** faced permanent injuries, emotional trauma and difficulty returning to work.

The collapse exposed failures in construction, enforcement and workers' ability to refuse dangerous work. It also raised questions about the responsibility of international brands buying from factories far from their customers.

Public pressure helped bring new safety programmes. The 2013 Accord on Fire and Building Safety brought brands and trade unions into a legally **binding** agreement. It supported independent **inspections**, repairs and ways for workers to raise safety concerns. Government inspection capacity also expanded.

A separate arrangement coordinated **compensation** for injured workers and victims' families. These responses improved protection, but did not remove every problem involving pay, safety or workers' rights.

Rana Plaza made the human cost of cheap clothing visible worldwide. Lasting **accountability** required more than promises: safe buildings, effective enforcement and workers able to speak without fear.''',
[
v('garment', 'An item of clothing.', 'The factory produced each garment for an overseas retailer.', 'Noun', plural='garments', note='Often used before another noun, as in garment factory or garment worker.'),
v('crack', 'A narrow line where a hard surface has split or broken.', 'A large crack appeared in the wall.', 'Noun', form='cracks', plural='cracks'),
v('wage', 'Money paid regularly to a worker for their work.', 'The worker depended on her weekly wage.', 'Noun', form='wages', plural='wages', note='Often used in the plural, wages.'),
v('rubble', 'Broken pieces of stone, brick or concrete left after a building is damaged or destroyed.', 'Rescuers searched through the rubble.', 'Uncountable noun'),
v('survivor', 'A person who remains alive after a dangerous event or serious illness.', 'The survivor received medical care and help finding work.', 'Noun', form='survivors', plural='survivors'),
v('binding', 'Creating an obligation that must be obeyed, especially under the law.', 'The companies signed a binding agreement on safety.', 'Adjective'),
v('inspection', 'A careful official examination to check condition, quality or compliance with rules.', 'The inspection identified unsafe electrical wiring.', 'Noun', form='inspections', plural='inspections'),
v('compensation', 'Money provided to help make up for injury, loss or damage.', 'The fund provided compensation to injured workers.', 'Uncountable noun'),
v('accountability', 'The responsibility to explain actions and face consequences for failures.', 'The investigation demanded greater accountability from employers.', 'Uncountable noun')
],
[
m('Why did many workers return after cracks were found?', ['The building had passed a complete independent safety inspection overnight.', 'Managers ordered them back, and they feared losing wages or jobs.', 'The shops and bank had already reopened and guaranteed the factories were safe.'], 'B', 'Many feared losing their wages or jobs if they refused.', 'The preceding sentence describes managers’ orders; the story emphasizes pressure and limited worker power.'),
m('What broader problem did the collapse reveal?', ['An isolated natural disaster that could not be connected to workplace decisions.', 'A transport failure that prevented finished clothes reaching foreign shops.', 'Failures in construction, enforcement and the protection of workers in a global industry.'], 'C', 'The collapse exposed failures in construction, enforcement and workers\' ability to refuse dangerous work.', 'The following sentence connects factory conditions to the responsibilities of international buyers.'),
m('How did the main responses differ?', ['The Accord addressed factory safety; a separate arrangement coordinated victim compensation.', 'The Accord handled only compensation, while the separate arrangement rebuilt Rana Plaza.', 'Both programmes replaced every national labour law with voluntary brand promises.'], 'A', 'A separate arrangement coordinated compensation for injured workers and victims\' families.', 'The earlier paragraph describes the legally binding safety agreement and its inspection and repair work.'),
g('Rana Plaza stood in Savar, near ___.', 'Dhaka', 'Rana Plaza was an eight-storey commercial building in Savar, near Dhaka.', 'The location connects the disaster to Bangladesh’s clothing industry.'),
g('The collapse killed ___ people.', '1,134', 'The disaster killed 1,134 people and injured around 2,500.', 'The death toll is distinct from the larger number of injured people.'),
g('Local ___ joined emergency teams in the rescue.', 'volunteers', 'Local volunteers joined emergency teams, searching for people and carrying the injured to hospitals.', 'The rescue involved members of the public as well as emergency personnel.')
],
[
'International Labour Organization, Vision Zero Fund, A turning point for occupational safety and health in supply chains — April 24 collapse, eight-storey building, warning cracks and 1,134 deaths: https://vzf.ilo.org/Photo%20Exhibition/a-turning-point-for-occupational-safety-and-health-in-supply-chains/',
'Clean Clothes Campaign, Rana Plaza — Direct campaign account of April 23 warning cracks, bank and shop closures, management pressure, injuries, global buyers, May 2013 Accord and separate compensation arrangement; advocacy judgments are not treated as court findings: https://cleanclothes.org/campaigns/past/rana-plaza',
'International Labour Organization, Rana Plaza Compensation Scheme, 2015 — Direct documentation of the compensation process, 1,134 deaths, survivors and rehabilitation: https://www.ilo.org/media/439026/download',
'International Labour Organization, International Labour Review, Anne Trebilcock, 2020 — Evacuation warning, management pressure and global supply-chain responses. Its older casualty count is not preferred over the ILO compensation report: https://www.ilo.org/media/390336/download',
'International Labour Organization, The Rana Plaza disaster ten years on: What has changed?, April 2023 — Industry context, inspection and repair programmes, compensation, stronger regulatory capacity and continuing labour-rights shortcomings. Historical assessment, not a claim about the exact present-day position: https://webapps.ilo.org/infostories/en-GB/Stories/Country-Focus/rana-plaza.html'
],
[
'Overview covers industry and employment context, the building and warning signs, pressure on workers, collapse and rescue, deaths and long-term harm, structural and labour failures, international purchasing relationships, safety reforms and distinct compensation arrangements.',
'Rana Plaza was a commercial building containing several factories, not a single-brand factory or a factory fire. The event is structural failure with ignored warnings. The original engineering inquiry was not retrieved, so precise claims about added floors, concrete quality or generators are not made.',
'The ILO compensation scheme’s toll of 1,134 deaths and the approximate figure of 2,500 injuries are used; historical sources vary, so the injury count is explicitly approximate. Not every person killed is described as a factory worker; rescue participants were also among the victims. Injured survivors are not assumed to have all recovered.',
'Workers returned under pressure, not because the story assumes they freely accepted the risk. Construction and enforcement failures are distinguished from the wider economic pressures and global responsibility debate.',
'The binding safety Accord and Rana Plaza compensation arrangement are separate responses. Improvements documented by ILO are balanced with continuing problems rather than implying that every factory became safe or every rights violation ended.',
'Compared with all 001–096, other batch subjects and the Lincoln reservation. This is the 2013 Savar building collapse, distinct from 032’s Bhopal gas release, 024’s crowd crush and the maritime or aviation disasters already covered.'
])


draft(98, 'rontgen-x-rays-discovery-1895', 'The Discovery of X-Rays: Seeing Inside the Human Body', 'Discoveries That Changed the World',
      'An unexpected laboratory observation led to a new way of examining hidden structures, transforming medicine while revealing the need for radiation protection.',
'''Before X-rays, doctors often struggled to locate a broken bone or a bullet inside the body without surgery. In 1895, a laboratory discovery opened a very different possibility: producing images of structures hidden beneath the skin.

Wilhelm Conrad Röntgen was a German **physicist** working at the University of Würzburg. On November 8, he was experimenting with electrical discharges in glass tubes containing very little gas. A covering blocked ordinary light from the tube, yet a nearby screen produced an unexpected **glow**.

Röntgen investigated carefully. Something **invisible** was travelling from the tube and affecting the screen. He called the unfamiliar radiation X-rays, using X to represent the unknown. Further experiments showed that the rays could **penetrate** materials that stopped ordinary light.

Different materials did not **absorb** the rays equally. Soft **tissue** allowed more through than bone, while metal also blocked them strongly. These differences created contrasting shadows on photographic plates. A famous early image showed the bones of his wife Anna Bertha's hand and her wedding ring.

Röntgen submitted his first report in December 1895. News spread internationally in January 1896, attracting scientists, doctors and an excited public. Other researchers repeated experiments and began improving the equipment.

Doctors quickly explored medical applications. An image could reveal a **fracture** or help locate a foreign object without first opening the body. These possibilities changed how injuries were examined and how treatment could be planned. In 1901, Röntgen received the first Nobel Prize in Physics for the discovery.

Early enthusiasm, however, ran ahead of understanding the dangers. Long or repeated **exposure** injured some patients and people working with the equipment. Knowledge of radiation risks developed gradually, encouraging protective methods and more careful control of its use.

The discovery extended beyond medicine into scientific research and industrial inspection. It did not make every disease visible or replace clinical judgement. Instead, it gave **diagnosis** a powerful new source of evidence and began a continuing effort to obtain useful images while limiting harm.''',
[
v('physicist', 'A scientist who studies matter, energy, forces and how the physical world behaves.', 'The physicist tested how the material responded to radiation.', 'Noun', plural='physicists'),
v('glow', 'A steady light, often weaker than a flame or a bright lamp.', 'A faint glow appeared on the screen.', 'Noun', plural='glows'),
v('invisible', 'Impossible to see with the eyes.', 'The instrument detected an invisible form of radiation.', 'Adjective'),
v('penetrate', 'To pass into or through something.', 'The rays could penetrate several layers of material.', 'Verb', verb=('penetrate','penetrated','penetrated',False)),
v('absorb', 'To take in a substance, energy or radiation rather than let it pass through.', 'Different materials absorb different amounts of radiation.', 'Verb', verb=('absorb','absorbed','absorbed',False)),
v('tissue', 'Material made of cells that forms part of a living body.', 'The image showed differences between bone and soft tissue.', 'Noun', plural='tissues', note='Often uncountable when referring to bodily material in general.'),
v('fracture', 'A break or crack in a bone or another hard material.', 'The image revealed a small fracture in the wrist.', 'Noun', plural='fractures'),
v('exposure', 'The state of being subjected to something that may affect or harm a person.', 'Researchers gradually recognized the dangers of excessive exposure.', 'Noun', plural='exposures'),
v('diagnosis', 'The identification of an illness or injury by examining signs and evidence.', 'The new image helped the doctor reach a diagnosis.', 'Noun', plural='diagnoses')
],
[
m('What made Röntgen’s initial observation surprising?', ['The screen remained completely dark even when exposed to ordinary light.', 'The glass tube produced only the visible light he had expected.', 'A nearby screen glowed although the covering blocked ordinary light from the tube.'], 'C', 'A covering blocked ordinary light from the tube, yet a nearby screen produced an unexpected glow.', 'The unexpected effect led him to investigate radiation that was different from ordinary visible light.'),
m('How did X-rays make hidden structures appear in an image?', ['Different materials absorbed different amounts, producing contrasting shadows.', 'Every material transmitted the same amount, producing a uniform picture.', 'Photographic plates converted bones into a source of visible light.'], 'A', 'Different materials did not absorb the rays equally.', 'The following sentences explain the different effects of soft tissue, bone and metal.'),
m('Which description best explains the discovery’s impact?', ['It immediately replaced surgery and made all diseases visible without risk.', 'It supplied powerful new evidence for medicine, while experience revealed risks requiring protection.', 'Its use stayed inside physics laboratories because doctors could not apply it to injuries.'], 'B', 'Knowledge of radiation risks developed gradually, encouraging protective methods and more careful control of its use.', 'The story balances medical benefits with injuries among early users and limits on what an image can show.'),
g('Röntgen worked at the University of ___.', 'Würzburg', 'Wilhelm Conrad Röntgen was a German physicist working at the University of Würzburg.', 'The discovery took place during his research in Germany.'),
g('The famous hand image showed bones and a wedding ___.', 'ring', 'A famous early image showed the bones of his wife Anna Bertha\'s hand and her wedding ring.', 'Metal and bone produced strong contrast in the early image.'),
g('Röntgen received the first Nobel Prize in Physics in ___.', '1901', 'In 1901, Röntgen received the first Nobel Prize in Physics for the discovery.', 'The award followed the original discovery by several years.')
],
[
'University of Würzburg Archives, Wilhelm Conrad Röntgen — Research setting, November 8 discovery, December first report and first physics Nobel: https://www.uni-wuerzburg.de/uniarchiv/persoenlichkeiten/bedeutende-gelehrte/wilhelm-conrad-roentgen/',
'Science Museum Group, photograph of the radiograph of Anna Bertha Röntgen’s hand — Hand, bones, ring and December 22 image date; the lesson does not confuse this later image with the November 8 discovery: https://collection.sciencemuseumgroup.org.uk/objects/co134691',
'University of Sydney Chau Chak Wing Museum, X-ray vision — Experiment and unexpected fluorescence, the name, international attention, medical applications and gradual recognition of radiation injuries: https://www.sydney.edu.au/museum/news/2022/07/28/x-ray-vision.html',
'LMU Munich, When the invisible was made visible, interview with historian Kärin Nickelsen — Different penetration and absorption, medical significance and limits of reconstructing the laboratory anecdote: https://www.lmu.de/en/newsroom/news-overview/news/when-the-invisible-was-made-visible-29928f4f.html',
'National Museum of Health and Medicine, Discovery of the X-ray — Contemporary Röntgen interview, varied absorption, early medical and military uses and later apparatus; its erroneous November 8 date for the wife’s hand image is not adopted: https://medicalmuseum.health.mil/index.cfm/visit/exhibits/virtual/xraydiscovery/index',
'Nobel Foundation, Physics 1901 official summary — Award independently corroborated by university sources; official indexed metadata accessible, direct full-page opening returned 403: https://www.nobelprize.org/prizes/physics/1901/summary/'
],
[
'Overview covers the earlier medical problem, research setting, unexpected observation, investigation and unknown name, differential absorption and imaging, publication and rapid adoption, Nobel recognition, injuries and protective practice, and wider scientific significance.',
'The November 8 discovery is distinct from the famous December hand image and December first report. The story avoids an unsupported first-ever-image claim, invented dialogue and a quotation attributed to Röntgen’s wife.',
'The glow account is presented without a detailed invented reconstruction. Surviving institutional accounts note that the private research notes were destroyed; precise minute-by-minute actions are not claimed.',
'Bone and metal absorb more than soft tissue; the lesson does not claim that no X-rays ever pass through bone. The high-level explanation is not a clinical or experimental procedure.',
'Medical adoption required many researchers and improvements. The discovery did not make every illness visible, remove the need for surgery or arrive with complete knowledge of radiation hazards.',
'Compared with all 001–097, other batch subjects and the Lincoln reservation. X-ray discovery is distinct from 068’s discovery of radioactivity: this episode concerns Röntgen’s electrically powered tube and imaging, not Becquerel and the Curies’ radioactive materials.'
])


draft(99, 'prague-spring-invasion-czechoslovakia-1968', 'The Prague Spring: Reform, Invasion and Repression', 'World Events and Political Change',
      'An attempt to make communist rule more open in Czechoslovakia met Soviet-led invasion, civilian resistance and a long reversal of reform.',
'''In 1968, Czechoslovakia was a communist country in Central Europe, home to Czechs and Slovaks. Its Communist Party had held power since 1948, and the country belonged to the Soviet-led Warsaw Pact military alliance. Strict political control and **censorship** limited public debate.

Economic **stagnation** and dissatisfaction with the leadership encouraged demands for change. Alexander Dubček became Communist Party leader in January 1968. He and other reformers wanted a more open form of socialism, often described as socialism with a human face.

During the Prague Spring, censorship weakened and then ended. Newspapers and public meetings discussed problems that had previously been difficult to challenge. An April programme proposed economic **reforms**, stronger legal protections and greater freedom of speech, association and travel. Citizens pressed for changes of their own, sometimes beyond the leadership's intentions.

Dubček still supported socialism and membership of the Warsaw Pact. His programme was not an immediate plan to replace communist rule with a Western political system. Nevertheless, Soviet leaders feared that **liberalization** would weaken their control and inspire similar movements elsewhere.

Negotiations and pressure failed to resolve the conflict. During the night of August 20–21, Soviet-led Warsaw Pact forces **invaded** Czechoslovakia. Troops and tanks seized important sites, while leading politicians, including Dubček, were **detained** and taken to Moscow.

The Czechoslovak army was ordered not to fight. Civilians nevertheless organized **resistance** through demonstrations, arguments with soldiers, broadcasts and changes to road signs. People were killed and injured, and many others later left the country. Western governments condemned the invasion but did not intervene militarily.

The **occupation** did not remove Dubček immediately. He remained party leader until April 1969, when Gustáv Husák replaced him. A period officially called normalization reversed the opening. Censorship returned, and political **purges** removed reform supporters from jobs and institutions.

The Prague Spring exposed the limits Moscow placed on independence within its alliance. Its suppression restored control, but damaged the Soviet Union's reputation and deepened disagreements within the international communist movement. Hopes for a more open society survived despite the defeat.''',
[
v('censorship', 'Official control that limits what people may publish, say or see.', 'The removal of censorship allowed wider public debate.', 'Uncountable noun'),
v('stagnation', 'A period of little or no growth, improvement or development.', 'Economic stagnation increased pressure for change.', 'Uncountable noun'),
v('reform', 'A change intended to improve a system or institution.', 'The reform gave managers greater responsibility.', 'Noun', form='reforms', plural='reforms'),
v('liberalization', 'The process of reducing restrictions and allowing greater freedom.', 'Political liberalization created space for public criticism.', 'Uncountable noun'),
v('invade', 'To enter another country or territory with armed forces in order to attack or control it.', 'The government feared that neighbouring forces might invade.', 'Verb', form='invaded', verb=('invade','invaded','invaded',False)),
v('detain', 'To keep someone in custody and prevent them from leaving.', 'The authorities decided to detain the opposition leader.', 'Verb', form='detained', verb=('detain','detained','detained',False)),
v('resistance', 'Action taken to oppose an authority, occupation or unwanted change.', 'The broadcasts became a form of peaceful resistance.', 'Uncountable noun'),
v('occupation', 'Control of a place by a foreign army.', 'The occupation restricted the country’s political choices.', 'Noun', plural='occupations'),
v('purge', 'An organized removal of people considered politically disloyal from a party, institution or public life.', 'The purge forced many teachers to leave their jobs.', 'Noun', form='purges', plural='purges')
],
[
m('What did Dubček’s programme seek to do?', ['Create a more open form of socialism while retaining Warsaw Pact membership.', 'Restore the monarchy and immediately join a Western military alliance.', 'Preserve existing censorship while ending all economic reforms.'], 'A', 'Dubček still supported socialism and membership of the Warsaw Pact.', 'The earlier paragraphs describe greater freedoms and economic reforms within a socialist framework.'),
m('Why did Soviet leaders oppose the opening?', ['They wanted Czechoslovakia to abandon socialism faster than Dubček intended.', 'They feared losing control and seeing similar movements spread elsewhere.', 'They believed the reforms would strengthen censorship throughout the alliance.'], 'B', 'Nevertheless, Soviet leaders feared that liberalization would weaken their control and inspire similar movements elsewhere.', 'The conflict concerned the political consequences of reform as well as Czechoslovakia’s place in the Soviet bloc.'),
m('What happened after the invasion?', ['Dubček was replaced that night, and civilian resistance ended before morning.', 'Western armies entered, ending the occupation and protecting the reforms.', 'Resistance continued, but later leadership changes restored censorship and removed reform supporters.'], 'C', 'Censorship returned, and political purges removed reform supporters from jobs and institutions.', 'The story distinguishes the August invasion from Dubček’s replacement in April 1969 and the later reversal of reform.'),
g('Czechoslovakia belonged to the ___ Pact.', 'Warsaw', 'Its Communist Party had held power since 1948, and the country belonged to the Soviet-led Warsaw Pact military alliance.', 'The alliance forms part of the political background to the invasion.'),
g('Soviet-led forces invaded during the night of ___ 20–21.', 'August', 'During the night of August 20–21, Soviet-led Warsaw Pact forces invaded Czechoslovakia.', 'The invasion followed months of reform, pressure and negotiation in 1968.'),
g('Detained leaders were taken to ___.', 'Moscow', 'Troops and tanks seized important sites, while leading politicians, including Dubček, were detained and taken to Moscow.', 'The military operation also involved detaining the reform leadership.')
],
[
'US State Department Office of the Historian, Soviet Invasion of Czechoslovakia, 1968 — Economic background, leadership change, April programme, Soviet concerns, Western non-intervention and April 1969 replacement. Retired historical series; compressed East German participation is not adopted: https://history.state.gov/milestones/1961-1968/soviet-invasion-czechoslavkia',
'Czech Institute for the Study of Totalitarian Regimes, August 1968 chronology — Night of August 20–21, army orders, detention and civilian responses: https://www.ustrcr.cz/uvod/rok-1968-na-webu-ustr/srpen-1968/srpen-1968-chronologie/',
'Government of the Czech Republic, 21st August 1968: Black Day of Czechoslovak History — Reform context, civilian protest, repression and consequences; an implausible troop figure in this summary is deliberately not used: https://vlada.gov.cz/en/media-centrum/aktualne/21st-august--1968-black-day-of-czechoslovak-history-61056/',
'European Network Remembrance and Solidarity, The Prague Spring — January leadership change, April programme, continued socialism and Warsaw Pact commitment: https://enrs.eu/article/the-prague-spring',
'German Federal Archives, 21 August 1968: invasion or no invasion? — East German preparations versus combat divisions remaining outside Czechoslovakia; no unqualified five-army participation claim: https://www.bundesarchiv.de/themen-entdecken/online-entdecken/geschichtsgalerien/21-august-1968-einmarsch-kein-einmarsch/'
],
[
'Balanced overview covers Czechoslovak and Soviet-bloc context, economic and political pressures, reform aims and public participation, Soviet fears, invasion, civilian resistance and Western non-intervention, the delayed leadership change, normalization and wider consequences.',
'Dubček was a Slovak Communist Party leader, not an elected president. The country is Czechoslovakia, including Czechs and Slovaks, rather than the present-day Czech Republic.',
'Proposals for greater freedoms are distinguished from reforms already implemented. The programme sought a more open socialism and continued alliance membership, not an immediate transition to a Western system.',
'The invasion occurred overnight on August 20–21. Soviet-led Warsaw Pact forces avoids overstating East German combat participation: the Bundesarchiv distinguishes preparation and support from the two intended divisions entering the country.',
'The army was ordered not to fight, but civilian resistance continued. No disputed precise troop or casualty total is used. Dubček’s April 1969 removal is not collapsed into the August invasion.',
'Normalization is identified as an official label for reversal and repression, not endorsed as a neutral description of political improvement. The focus remains 1968–1969 rather than retelling the 1989 changes.',
'Compared with all 001–098 and the Lincoln reservation. The Prague Spring and invasion are distinct from 004’s Berlin Wall, 059’s airlift and 092’s dissolution of the Soviet Union.'
])


draft(100, 'lincoln-emancipation-proclamation-1863', 'The Emancipation Proclamation: A Turning Point in the Fight Against Slavery', 'Freedom and Historical Turning Points',
      'Lincoln’s wartime declaration changed the purpose and course of the American Civil War, while freedom depended on military action and the wider struggle against slavery.',
'''The American Civil War began in 1861 after Southern states **seceded** from the United States and formed the Confederacy. **Slavery** lay at the heart of the conflict. The Confederate states sought to protect it, while President Abraham Lincoln's government initially fought primarily to preserve the Union.

Enslaved people did not wait for a presidential decision. Many escaped towards Union forces, seeking freedom and weakening the Confederacy's labour system. Black activists and other **abolitionists** demanded stronger action. Their efforts helped make emancipation an urgent national question.

On September 22, 1862, after the Battle of Antietam, Lincoln issued a preliminary **proclamation**. It warned that people enslaved in areas still in **rebellion** on January 1 would be declared free. When the rebellion continued, he issued the final Emancipation Proclamation on January 1, 1863.

Lincoln used his wartime authority as commander in chief. The declaration applied to specified states and parts of states rebelling against the United States. It **exempted** the loyal border states where slavery remained legal, as well as certain Confederate areas already under Union control.

Its reach was therefore limited. It did not immediately free every enslaved person or abolish slavery nationwide. Union military power was needed to **enforce** the declaration, and advancing armies brought freedom within reach of more people. Enslaved people continued taking risks to secure their own liberty.

The proclamation also authorized Black men to **enlist** in the Union's armed forces. By the war's end, almost 200,000 Black soldiers and sailors had served. Their participation strengthened the Union and made formerly enslaved people active contributors to emancipation.

The war now joined the preservation of the country to an explicit commitment to freedom. The proclamation gave the Union cause greater moral force, but a lasting nationwide legal change required more than a wartime order.

Congress passed the Thirteenth **Amendment** in January 1865. Ratified in December, it abolished slavery throughout the country, with an exception for punishment following criminal conviction. Emancipation was a decisive change, while struggles against discrimination and for equal rights continued.''',
[
v('secede', 'To formally leave a country or political union and claim independence.', 'The region voted to secede from the federation.', 'Verb', form='seceded', verb=('secede','seceded','seceded',False)),
v('slavery', 'A system in which people are treated as property and forced to work without freedom.', 'The movement demanded an end to slavery.', 'Uncountable noun', form='Slavery'),
v('abolitionist', 'A person who works to end a practice or institution, especially slavery.', 'The abolitionist campaigned for freedom and equal rights.', 'Noun', form='abolitionists', plural='abolitionists'),
v('proclamation', 'An official public announcement, especially one made by a government or ruler.', 'The proclamation announced a major change in government policy.', 'Noun', plural='proclamations'),
v('rebellion', 'Organized resistance or armed action against an established government.', 'The rebellion challenged the authority of the central government.', 'Noun', plural='rebellions'),
v('exempt', 'To officially free someone or something from a rule or requirement.', 'The law would exempt certain areas from the restriction.', 'Verb', form='exempted', verb=('exempt','exempted','exempted',False)),
v('enforce', 'To make sure a law, rule or order is obeyed.', 'The authorities needed resources to enforce the new law.', 'Verb', verb=('enforce','enforced','enforced',False)),
v('enlist', 'To join the armed forces.', 'He decided to enlist in the army.', 'Verb', verb=('enlist','enlisted','enlisted',False)),
v('amendment', 'An official change or addition to a law, constitution or formal document.', 'The amendment changed the constitution.', 'Noun', form='Amendment', plural='amendments')
],
[
m('How does the story describe the movement towards emancipation?', ['Enslaved people waited without taking action until Lincoln issued the final order.', 'Escapes, activism and wartime decisions combined to make emancipation a national priority.', 'Lincoln’s government made immediate nationwide abolition its sole war aim from the start.'], 'B', 'Their efforts helped make emancipation an urgent national question.', 'The preceding sentences describe the actions of enslaved people, Black activists and other abolitionists alongside Lincoln’s decisions.'),
m('What was the scope of the final proclamation?', ['It abolished slavery in every state immediately, including all loyal border states.', 'It granted equal voting rights nationwide without requiring military enforcement.', 'It declared freedom in specified rebellious areas, with exceptions and practical dependence on Union power.'], 'C', 'The declaration applied to specified states and parts of states rebelling against the United States.', 'The next paragraphs explain the geographic exceptions and the role of military enforcement.'),
m('Why was the Thirteenth Amendment an important further step?', ['It established a nationwide constitutional abolition beyond the proclamation’s limited wartime scope.', 'It permanently protected slavery in the loyal states excluded from the wartime order.', 'It granted formerly enslaved people equal voting rights as its main legal change.'], 'A', 'Ratified in December, it abolished slavery throughout the country, with an exception for punishment following criminal conviction.', 'The amendment was a lasting constitutional change; the final sentence distinguishes abolition from full equality.'),
g('Lincoln issued the preliminary proclamation in September ___.', '1862', 'On September 22, 1862, after the Battle of Antietam, Lincoln issued a preliminary proclamation.', 'The preliminary warning preceded the January 1863 final declaration.'),
g('Congress passed the Thirteenth Amendment in January ___.', '1865', 'Congress passed the Thirteenth Amendment in January 1865.', 'Congressional passage came before ratification in December of the same year.'),
g('The proclamation authorized Black men to ___ in the Union’s armed forces.', 'enlist', 'The proclamation also authorized Black men to enlist in the Union\'s armed forces.', 'Black military service was one important consequence of the declaration.')
],
[
'US National Archives, Emancipation Proclamation (1863), original document and contextual introduction — September 22 preliminary terms, January 1 final declaration, war power, geographic limits, military enforcement, Black agency and almost 200,000 Black soldiers and sailors: https://www.archives.gov/milestone-documents/emancipation-proclamation',
'US National Park Service, Slavery as a Cause of the Civil War — Secession, slavery and the Confederacy, including contemporary evidence: https://www.nps.gov/liho/learn/historyculture/slavery-cause-civil-war.htm',
'US National Park Service, Emancipation and the Quest for Freedom, Allen C. Guelzo — Antislavery activism, constitutional constraints and changing Union policy: https://www.nps.gov/articles/emancipation-and-the-quest-for-freedom.htm',
'US National Park Service, The Emancipation Proclamation — Antietam and September announcement; its older claim that the proclamation did not immediately free a single person is not adopted: https://www.nps.gov/articles/the-emancipation-proclamation.htm',
'US National Archives, Thirteenth Amendment (1865), original text and contextual introduction — Congressional passage January 31, ratification December 6 and the punishment exception: https://www.archives.gov/milestone-documents/13th-amendment'
],
[
'Event-centred overview includes slavery and secession, the initial Union aim, enslaved people’s agency and abolitionist pressure, preliminary and final declarations, wartime authority and exceptions, enforcement, Black military service, the changed Union cause and later constitutional abolition.',
'The proclamation did not free every enslaved person immediately, abolish slavery nationwide or grant equal citizenship. Its declaration concerned specified rebellious areas, excluding loyal border slave states and some already-controlled Confederate areas.',
'Practical freedom depended on Union power and individual action. The inaccurate older shorthand that no person was immediately freed is avoided; neither a paper-only claim nor instant universal freedom is asserted.',
'Almost 200,000 refers to Black soldiers and sailors by the war’s end, not only soldiers, only newly freed people or enlistments on January 1 itself.',
'Antietam preceded the preliminary proclamation; it did not cause Lincoln to invent emancipation policy overnight. The Thirteenth Amendment’s congressional passage and ratification are distinct, and its criminal-punishment exception is retained in simple language.',
'The main Library of Congress emancipation essay was inaccessible during research; accessible National Archives primary text and institutional histories supply the evidence instead. No claim to have read the blocked essay is made.',
'Compared with all 001–099 and the previously reserved Lincoln candidate. This fulfills that reservation as an event lesson, distinct from 018’s Montgomery boycott and 065’s New Zealand suffrage campaign. Lincoln’s whole life and assassination do not displace the proclamation.'
])

