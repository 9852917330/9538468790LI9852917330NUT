"""Source-reviewed global events, financial accountability and scientific breakthroughs."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(91, 'first-world-war-1914-1918', 'The First World War: How a European Crisis Became a Global Conflict', 'Wars and Historical Turning Points',
      'Competition, political decisions and a regional crisis expanded into a global war that devastated societies, broke empires and reshaped international borders.',
'''Before 1914, European powers competed for colonies, military strength and influence. **Nationalism** sharpened rival claims to territory, especially in the Balkans. Arms races, mistrust and **alliances** made a regional crisis harder to contain, although war was not inevitable.

On June 28, a Bosnian Serb nationalist killed Archduke Franz Ferdinand, heir to Austria-Hungary's throne, in Sarajevo. This **assassination** triggered a diplomatic crisis. Austria-Hungary, backed by Germany, declared war on Serbia on July 28. Russia supported Serbia, and governments **mobilized** their armies. German declarations of war and its invasion of Belgium helped draw France and Britain into a wider conflict.

Germany and Austria-Hungary were later joined by the Ottoman Empire and Bulgaria. Their opponents included France, Russia and the British Empire, with Italy joining in 1915. Imperial connections carried the war far beyond Europe. Soldiers and workers from India, Africa and other regions supported armies and supply systems.

On the Western Front, armies fought from **trenches** across France and Belgium. Machine guns, artillery and defensive positions produced terrible losses and long periods of **stalemate**. Elsewhere, fighting spread across Eastern Europe, the Balkans, the Middle East and Africa. War at sea threatened shipping and supplies.

Governments redirected factories and labour towards the fighting. Civilians faced hunger, restrictions and loss. The Allied **blockade** put pressure on Germany, while German submarines attacked shipping. The conflict demanded resources from entire societies.

The United States entered the war in 1917. Russia's revolutions brought political upheaval, followed by a peace agreement with Germany in March 1918. Germany then launched major western offensives, but failed to achieve victory. Allied advances later in 1918 pushed its forces back as Germany's partners also faced defeat.

An **armistice** with Germany took effect on November 11, 1918. Peace treaties followed, including Versailles in 1919. Millions of soldiers and civilians had died, and survivors faced injury, grief and displacement.

The war and its **aftermath** ended the German, Austro-Hungarian, Russian and Ottoman empires. New states and borders emerged, but the settlements left serious tensions unresolved.''',
[
v('nationalism', 'Strong identification with a nation and support for its interests or political independence.', 'Nationalism increased demands for control over the region.', 'Uncountable noun'),
v('alliance', 'An agreement between countries or groups to support one another.', 'The alliance shaped the government’s response to the crisis.', 'Noun', form='alliances', plural='alliances'),
v('assassination', 'The deliberate killing of an important person, often for political reasons.', 'The assassination led to an international crisis.', 'Noun', plural='assassinations'),
v('mobilize', 'To prepare and organize people or resources for action, especially war.', 'The government began to mobilize its armed forces.', 'Verb', form='mobilized', verb=('mobilize','mobilized','mobilized',False)),
v('trench', 'A long, narrow ditch used by soldiers for shelter and defence.', 'The soldiers remained in the trench during the attack.', 'Noun', form='trenches', plural='trenches'),
v('stalemate', 'A situation in which neither side can make decisive progress.', 'The fighting continued without breaking the stalemate.', 'Noun', plural='stalemates'),
v('blockade', 'An action that prevents people or supplies from entering or leaving an area.', 'The naval blockade reduced incoming supplies.', 'Noun', plural='blockades'),
v('armistice', 'An agreement between opposing sides to stop fighting.', 'The armistice came before the final peace treaty.', 'Noun', plural='armistices'),
v('aftermath', 'The period and consequences that follow a damaging or important event.', 'Families rebuilt their lives in the aftermath of the war.', 'Noun', note='Usually used with the, often in the phrase in the aftermath of.')
],
[
m('How does the story explain the outbreak of war?', ['A regional crisis escalated through political decisions amid rivalry, mistrust and alliances.', 'The assassination settled earlier disputes but created a new colonial conflict.', 'Identical alliance obligations forced every European country to enter at once.'], 'A', 'Arms races, mistrust and alliances made a regional crisis harder to contain, although war was not inevitable.', 'The following paragraph shows how governments’ decisions widened the crisis after Sarajevo.'),
m('What made the conflict global?', ['Its battles took place mainly in France while overseas countries supplied money alone.', 'Fighting and imperial connections involved several continents, soldiers and workers.', 'Every state joined the opposing alliances before the fighting began in 1914.'], 'B', 'Imperial connections carried the war far beyond Europe.', 'The narrative includes colonial service, fighting outside Europe and warfare at sea.'),
m('What is the distinction between the 1918 armistice and the later treaties?', ['The armistice immediately settled every border and political dispute.', 'The Versailles treaty was signed before the armistice stopped the fighting.', 'The armistice stopped fighting with Germany; later treaties set peace terms.'], 'C', 'Peace treaties followed, including Versailles in 1919.', 'The preceding sentence dates the armistice with Germany to November 11, 1918.'),
g('Franz Ferdinand was assassinated in ___.', 'Sarajevo', 'On June 28, a Bosnian Serb nationalist killed Archduke Franz Ferdinand, heir to Austria-Hungary\'s throne, in Sarajevo.', 'Sarajevo was the location of the attack that triggered the diplomatic crisis.'),
g('The United States entered the war in ___.', '1917', 'The United States entered the war in 1917.', 'The war had already been underway for several years.'),
g('The Treaty of Versailles followed in ___.', '1919', 'Peace treaties followed, including Versailles in 1919.', 'The peace settlement came after the November 1918 armistice.')
],
[
'New Zealand Ministry for Culture and Heritage, NZ History, Origins of the war — Nationalism, imperial competition, arms races, alliances, Sarajevo and escalation: https://nzhistory.govt.nz/war/first-world-war-overview/origins',
'National Army Museum, First World War — Opposing powers, Western and other fronts, mobilized societies and imperial consequences; its first truly global conflict superlative is not used: https://www.nam.ac.uk/explore/first-world-war',
'National Army Museum, The Commonwealth and the First World War — Indian, African, Caribbean and dominion soldiers and labourers: https://www.nam.ac.uk/explore/commonwealth-and-first-world-war',
'National WWI Museum and Memorial, Key Dates — Selected verified US entry, March 1918 Russian peace, armistice and later treaty dates; compressed peripheral timeline entries are not adopted: https://www.theworldwar.org/learn/about-wwi/key-dates',
'National Army Museum, 1918: Year of victory — Failed German spring offensives and later Allied advances: https://www.nam.ac.uk/explore/1918-victory',
'US Holocaust Memorial Museum, Treaty of Versailles — Human losses, displacement and the later peace settlement: https://encyclopedia.ushmm.org/content/en/article/treaty-of-versailles'
],
[
'Whole-war overview includes prewar rivalry, immediate trigger, escalation choices, opposing powers joining at different times, global and colonial participation, multiple fronts, civilians, 1917–1918 changes, military defeat, armistice and postwar consequences.',
'Sarajevo is a trigger, not the sole cause. Alliances did not remove political choice or give Britain, France and Russia identical obligations. Italy joins in 1915 rather than being assigned automatically to its prewar allies.',
'Western trench stalemate is distinguished from other fronts and 1918 movement. The story does not call this the first global war in all history or describe every campaign as trench warfare.',
'Russia’s 1917 upheavals and March 1918 peace are distinct. November 11 stopped fighting with Germany; it did not itself sign Versailles or settle every conflict.',
'Millions died is deliberately approximate. Four imperial endings belong to the war and aftermath, not a claim that every empire legally ended on November 11, 1918; the Ottoman sultanate ended in 1922.',
'Compared with all 001–090, batch subjects and the Lincoln reservation. This is the First World War, distinct from 075’s Russian Revolutions, 071’s Napoleonic life and the Second World War events already covered. Necessary contextual references do not retell those lessons.'
])

draft(92, 'soviet-union-dissolution-1991', 'The Soviet Union’s Collapse: Reform, Crisis and Independence', 'World Events and Political Change',
      'Economic strain, political reforms, national movements and a failed coup weakened central power until the Soviet Union’s republics became independent states.',
'''By 1991, the Soviet Union was a powerful state made up of 15 republics, including Russia, Ukraine and Lithuania. Russia was the largest, but the union contained many peoples, languages and national histories. Moscow's central government and the Communist Party controlled much of political and economic life.

Economic **stagnation**, inefficient management and everyday **shortages** had damaged confidence in the system. Many communities also resented central control and restrictions on national identity. These pressures interacted rather than providing one simple explanation for the collapse.

Mikhail Gorbachev became Soviet leader in 1985. His **reforms** sought to strengthen the system through economic restructuring and greater openness. Reduced **censorship** allowed people to discuss failures and past abuses more openly. Political competition expanded, but the economic crisis continued and criticism increasingly escaped the leadership's control.

Republican leaders demanded greater **sovereignty**. In the Baltic republics, movements sought to restore independence lost under Soviet rule; Lithuania declared independence in March 1990. Gorbachev tried to negotiate a looser union, while disagreements grew over who should control power and resources.

In August 1991, Communist **hardliners** attempted a **coup** to stop these changes. Gorbachev was detained, and troops appeared in Moscow. Public resistance, opposition led by Russian leader Boris Yeltsin and failures among the plotters helped defeat the attempt. Gorbachev returned with much less authority, while republican leaders gained influence.

Ukraine declared independence in August. On December 1, a large majority of participating voters confirmed it in a **referendum**. On December 8, the leaders of Russia, Ukraine and Belarus declared that the Soviet Union had ended and established the Commonwealth of Independent States.

Gorbachev resigned as Soviet president on December 25. The next day, a Soviet parliamentary declaration formally acknowledged the union's end. Fifteen independent states emerged from the former Soviet republics, with new questions about citizenship, borders, economies and security.

The **successor** states followed different paths. Independence brought hopes of freedom alongside hardship and, in some places, violence and conflict. The collapse transformed global power, but its meaning for ordinary people depended greatly on where they lived.''',
[
v('stagnation', 'A period of little or no growth, improvement or development.', 'Years of economic stagnation weakened confidence.', 'Uncountable noun'),
v('shortage', 'A situation in which there is not enough of something that is needed.', 'A food shortage affected many households.', 'Noun', form='shortages', plural='shortages'),
v('reform', 'A change intended to improve a system or institution.', 'The reform altered how public officials were chosen.', 'Noun', form='reforms', plural='reforms'),
v('censorship', 'Official control that limits what people may publish, say or see.', 'Reduced censorship allowed wider public debate.', 'Uncountable noun'),
v('sovereignty', 'The authority of a state or people to govern themselves and make their own decisions.', 'The dispute concerned national sovereignty.', 'Uncountable noun'),
v('hardliner', 'A person who strongly supports strict policies and opposes compromise or major change.', 'The hardliner opposed the proposed agreement.', 'Noun', form='hardliners', plural='hardliners'),
v('coup', 'A sudden attempt to seize control of a government, usually by a small group.', 'The coup failed after widespread resistance.', 'Noun', plural='coups'),
v('referendum', 'A public vote on a particular political question.', 'The referendum asked voters whether they supported independence.', 'Noun', plural='referendums'),
v('successor', 'A person or thing that follows and takes the place of another.', 'The successor state established new institutions.', 'Noun', plural='successors', note='Successor state describes a state that follows the end or division of an earlier state.')
],
[
m('What was Gorbachev originally trying to achieve through reform?', ['To dissolve the union immediately into separate national states.', 'To strengthen the system through restructuring and greater openness.', 'To end public discussion and restore stricter censorship.'], 'B', 'His reforms sought to strengthen the system through economic restructuring and greater openness.', 'The eventual collapse differed from his original intention to improve the existing system.'),
m('What was the effect of the failed August coup?', ['It restored Gorbachev’s control over the republican governments.', 'It stopped the independence process and preserved central power.', 'It weakened Gorbachev’s authority and strengthened republican leaders.'], 'C', 'Gorbachev returned with much less authority, while republican leaders gained influence.', 'The attempt failed, but its political consequences accelerated the loss of central control.'),
m('Which description best captures the breakup?', ['Different republics pursued independence through a process culminating in December 1991.', 'Russia and the Soviet Union were the same country under different names.', 'Every republic first declared independence on the day Gorbachev resigned.'], 'A', 'In the Baltic republics, movements sought to restore independence lost under Soviet rule; Lithuania declared independence in March 1990.', 'The narrative then describes later Ukrainian decisions, December agreements and the formal ending.'),
g('The Soviet Union contained ___ republics by 1991.', '15', 'By 1991, the Soviet Union was a powerful state made up of 15 republics, including Russia, Ukraine and Lithuania.', 'Russia was the largest republic, not the whole union.'),
g('Ukraine confirmed independence in a referendum on December ___.', '1', 'On December 1, a large majority of participating voters confirmed it in a referendum.', 'The vote followed Ukraine’s August independence declaration.'),
g('Gorbachev resigned as Soviet president on December ___.', '25', 'Gorbachev resigned as Soviet president on December 25.', 'The parliamentary declaration acknowledging the union’s end followed on December 26.')
],
[
'US Department of State Office of the Historian, The Collapse of the Soviet Union — Political pressures, coup, republics and December events: https://history.state.gov/milestones/1989-1992/collapse-soviet-union',
'George Washington University National Security Archive, The End of the Soviet Union 1991 — Declassified documents, attempts to preserve a reformed union and December 8 agreement: https://nsarchive.gwu.edu/briefing-book/russia-programs/2021-12-21/end-soviet-union-1991',
'Ohio State University Origins, David Hoffmann, The Soviet Collapse — Economic stagnation, reforms and the fifteen republics; compressed suggestion that all independence declarations followed the coup is not used: https://origins.osu.edu/article/soviet-collapse-yeltsin-putin-gorbachev-russia',
'Verkhovna Rada of Ukraine, December 1 referendum anniversary — Official confirmation of independence by 90.32 percent of participating voters; narrative uses a large majority: https://www.rada.gov.ua/en/news/News/top_news/216912.html',
'Harvard Davis Center, The Collapse of the USSR transcript — Eyewitness experiences and December 25/26 distinction; its erroneous over 92 percent Ukrainian figure is rejected: https://daviscenter.fas.harvard.edu/transcript-collapse-ussr',
'Harvard Ukrainian Research Institute, Serhii Plokhy, The Return of History — Baltic restoration claims and different experiences across successor states; historical discussion rather than present-day assertions: https://www.huri.harvard.edu/news/return-history-post-soviet-space-thirty-years-after-fall-ussr'
],
[
'Overview identifies the multinational union, underlying economic and political pressures, Gorbachev’s intended reforms, expanding criticism, republican movements, failed coup, changing authority, Ukrainian vote, December agreements, formal end and varied consequences.',
'The USSR is not equated with Russia. Yeltsin led the Russian republic; Gorbachev led the union. The narrative does not date the USSR’s founding to the 1917 revolutions.',
'Independence and restoration processes began at different times. Lithuania’s March 1990 declaration prevents a false impression that every independence movement or declaration began after August 1991.',
'The coup failed rather than establishing a replacement Soviet government. Gorbachev sought to preserve a reformed union. Public resistance and failures among the plotters are acknowledged alongside Yeltsin’s role.',
'The Ukrainian referendum majority concerns participating voters, not every citizen. Gorbachev’s December 25 resignation and the December 26 parliamentary declaration remain distinct.',
'No universal peaceful-transition or automatic-democracy claim is made. Economic hardship and regional violence are recognized without importing later current-affairs claims into a historical overview.',
'Compared with all 001–091, other new subjects and the Lincoln reservation. This is the 1991 dissolution, distinct from 075’s 1917 revolutions, 004’s Berlin Wall and 074’s North Korea history.'
])

draft(93, 'first-human-to-human-heart-transplant-1967', 'The First Human-to-Human Heart Transplant: A Surgical Turning Point', 'Science and Medical Breakthroughs',
      'A team in Cape Town showed that a donated human heart could work in another person, while the first recipient’s short survival exposed the challenges still ahead.',
'''On December 3, 1967, a team at Groote Schuur Hospital in Cape Town, South Africa, completed the first human-to-human heart **transplant**. Led by surgeon Christiaan Barnard, they replaced a severely damaged heart with one from another person. The operation brought worldwide attention and hope for patients with advanced heart disease.

This achievement followed decades of international research. Laboratory work, improved surgical methods and machines that supported circulation had made the attempt possible. Researchers including Richard Lower and Norman Shumway helped develop important techniques. In Cape Town, nurses, technicians, doctors and other hospital specialists all contributed to the operation and care afterwards.

The **donor**, Denise Darvall, had suffered fatal injuries in a road accident. Her father, Edward, gave **consent** for donation. The **recipient**, Louis Washkansky, had severe heart disease and was near death. He accepted an **experimental** treatment whose risks and long-term results remained uncertain.

The donated heart began to function. However, keeping an organ working inside another person involved more than surgery. A patient's **immune system** could attack the donated tissue, causing **rejection**. Medicines could reduce this response, but they also weakened protection against **infection**. Doctors faced a difficult balance between these dangers.

Washkansky lived for 18 days after the operation and died from pneumonia. His death revealed how much remained to be solved, even though the new heart had worked. Later recipients sometimes lived much longer, while many early transplant attempts elsewhere ended in serious complications or death.

The operation also added urgency to ethical questions about donor consent, determining death and access to treatment. South Africa's racially unequal apartheid system affected opportunities and recognition within medicine. The public story of one famous surgeon could obscure the wider research and teamwork behind the achievement.

Further progress came through better monitoring, patient care and medicines that controlled rejection, including major advances in the 1980s. Improved **survival** depended on this continuing work. The 1967 operation marked a turning point whose lasting value required research, skilled teams and the willingness of families to donate.''',
[
v('transplant', 'An operation that moves an organ or tissue into another body or another part of the body.', 'The patient needed a heart transplant.', 'Noun', plural='transplants'),
v('donor', 'A person who gives an organ, tissue, blood or something else for another person’s use.', 'The organ came from a deceased donor.', 'Noun', plural='donors'),
v('consent', 'Permission given freely after understanding what is proposed.', 'The team requested consent before the procedure.', 'Uncountable noun'),
v('recipient', 'A person who receives something.', 'The recipient remained in hospital after the operation.', 'Noun', plural='recipients'),
v('experimental', 'Used to test a new idea or method whose results are not yet fully established.', 'The experimental treatment required careful monitoring.', 'Adjective'),
v('immune system', 'The body’s network of cells and processes that protects it against infection and other threats.', 'The medicine changed how the immune system responded.', 'Noun phrase', plural='immune systems'),
v('rejection', 'An immune response in which the body attacks transplanted tissue or an organ.', 'Doctors monitored the patient for signs of rejection.', 'Uncountable noun', note='Medical meaning in this lesson.'),
v('infection', 'A condition caused when harmful microorganisms enter and multiply in the body.', 'The patient developed a serious infection.', 'Noun', plural='infections'),
v('survival', 'The state of remaining alive after danger or serious illness.', 'Better care improved survival after the operation.', 'Uncountable noun')
],
[
m('What made the Cape Town operation possible?', ['A new medicine had already solved rejection and infection before the operation.', 'Earlier research had shown that surgery alone was enough for long-term survival.', 'International research and the combined work of many hospital specialists.'], 'C', 'This achievement followed decades of international research.', 'The following sentences describe earlier techniques and the many people involved in surgery and care.'),
m('Why did medicines create a difficult balance?', ['They could reduce rejection while weakening protection against infection.', 'They protected against infection but guaranteed rejection of the new heart.', 'They made monitoring unnecessary once the heart had begun to function.'], 'A', 'Medicines could reduce this response, but they also weakened protection against infection.', 'The response refers to the immune system attacking donated tissue.'),
m('Which assessment best matches the operation’s significance?', ['It immediately established heart transplantation as a reliable long-term cure.', 'It demonstrated a possibility, while safer long-term treatment required continuing progress.', 'It showed that better donor selection could remove the need for medicines.'], 'B', 'Improved survival depended on this continuing work.', 'The story balances the working donated heart with the first recipient’s short survival and later advances.'),
g('The operation took place in December ___.', '1967', 'On December 3, 1967, a team at Groote Schuur Hospital in Cape Town, South Africa, completed the first human-to-human heart transplant.', 'The date identifies this particular human-to-human heart transplant breakthrough.'),
g('Washkansky survived for ___ days after the operation.', '18', 'Washkansky lived for 18 days after the operation and died from pneumonia.', 'The functioning donated heart did not guarantee long-term survival.'),
g('Denise Darvall’s father gave ___ for donation.', 'consent', 'Her father, Edward, gave consent for donation.', 'The donor’s family had an important role in the decision.')
],
[
'University of Cape Town Division of Cardiothoracic Surgery, World’s First Human Heart Transplant — Date, donor, father’s permission, recipient, experimental decision and multidisciplinary hospital work: https://health.uct.ac.za/cardiothoracic-surgery/historical/first-human-heart-transplant',
'University of Cape Town News, 50th anniversary of the first human heart transplant — Eighteen-day survival, pneumonia and later recipients living longer: https://www.news.uct.ac.za/article/-2017-11-29-50th-anniversary-of-the-first-human-heart-transplant',
'Stanford Medicine, Norman Shumway, Heart Transplantation Pioneer — Lower/Shumway laboratory research, Barnard’s use of developed techniques, early difficulties and later monitoring and cyclosporine: https://med.stanford.edu/news/all-news/2006/02/norman-shumway-heart-transplantation-pioneer-dies-at-83.html',
'Brink and Hassoulas, UCT research account, The first human heart transplant and further advances in cardiac transplantation, 2009 — Rejection, immunosuppression and infection; indexed full text reviewed during research, direct opening intermittently blocked by CAPTCHA: https://pmc.ncbi.nlm.nih.gov/articles/PMC4200566/',
'University of Cape Town CARE, 2017 institutional account of recognition and Hamilton Naki — Racial barriers to recognition in research and medical education; not evidence that Naki performed the first human operation: https://health.uct.ac.za/caresa/articles/2017-03-01-students-protest-art-fhs-canteen-wall-now-permanent-thought-provoking-mural',
'University of Cape Town Libraries, contemporary heart transplant team-list archive — The multidisciplinary team and December 3, 1967 date: https://atom.lib.uct.ac.za/index.php/za-uct-bc1163-h-h2b'
],
[
'Full-event overview includes the medical problem and international preparation, multidisciplinary work, donor and recipient decisions, functioning graft, immune rejection/infection balance, short first survival, later outcomes, ethical and social context and continuing development.',
'First human-to-human heart transplant is deliberately qualified. This was not the first organ transplant or the first animal-to-human heart attempt. The title does not promise an immediate reliable long-term cure.',
'Washkansky survived 18 days and died from pneumonia, not stated graft rejection. General immune suppression/infection trade-offs are historical explanatory context, not treatment recommendations.',
'Barnard is credited as team leader, not sole inventor. Lower and Shumway and the wider hospital team are included. The story avoids disputed recipient age and does not repeat the incorrect claim that Hamilton Naki participated in the first human surgical team.',
'Donor consent and determining death are recognized as ethical questions without pretending that all standards were settled in 1967. Apartheid context concerns barriers and recognition, not a second national-history overview.',
'Later clinical advances are historically bounded. No current survival rate, patient eligibility rule or claim of guaranteed safety is provided. The intermittently blocked research full-text route is distinguished from fully accessible institutional accounts.',
'Compared with all 001–092, other batch subjects and the Lincoln reservation. This transplant milestone differs from 031’s vaccination, 013’s penicillin, 034’s genome project and 090’s South African democratic transition.'
])

draft(94, 'enron-scandal-bankruptcy-2001', 'Enron: The Collapse Behind the Profits', 'Business Scandals and Accountability',
      'Misleading accounts and failed oversight hid the weakness of a celebrated energy company, until disclosures destroyed confidence and brought bankruptcy, losses and legal reform.',
'''In the 1990s, Enron was celebrated as an innovative American energy company. Based in Houston, it expanded from gas pipelines into trading gas, electricity and other contracts. Its reported growth attracted investors and helped make its shares valuable. Behind that reputation, however, its financial position was much weaker than it appeared.

Executives used complicated **partnerships** and accounting arrangements to **conceal** debt and losses or create misleading **profits**. Some reported **assets** were overvalued. Managers involved in partnerships also faced **conflicts of interest**, because their personal financial interests could differ from the company's interests.

Directors, **auditors**, banks, analysts and regulators did not provide effective checks. The problem extended beyond one false statement or one executive. Investors depended on reports and professional judgments that failed to reveal the full risks.

During 2001, questions about Enron's accounts grew. October disclosures revealed serious financial problems. In November, the company announced corrections to earlier accounts, showing that previously reported earnings could not be relied upon. Its share price fell, and confidence among investors, lenders and trading partners weakened.

A planned rescue merger with rival energy company Dynegy offered temporary hope. On November 28, Enron's debt ratings fell below investment grade and Dynegy ended the deal. With trust and financial support disappearing, Enron filed for **bankruptcy** protection on December 2, 2001. Its collapse left **creditors** seeking repayment from a business whose apparent strength had vanished.

Thousands of employees lost jobs. Many also lost retirement savings invested in Enron shares, while shareholders suffered enormous losses. Investigations uncovered fraud and led to guilty pleas and convictions.

Arthur Andersen, Enron's auditor, was convicted in a document-destruction case in 2002. The Supreme Court overturned that conviction in 2005 because the jury instructions were flawed. This did not establish that Enron's accounts had been accurate.

Enron, WorldCom and other scandals helped drive the Sarbanes–Oxley Act of 2002. It strengthened reporting responsibilities, auditor independence and public audit **oversight**. Enron's collapse exposed how misleading numbers and failed safeguards could turn a respected company into a disaster for people who had trusted it.''',
[
v('partnership', 'An arrangement in which people or organizations work together or share a business.', 'The companies formed a partnership to develop the project.', 'Noun', form='partnerships', plural='partnerships'),
v('conceal', 'To hide something or prevent it from being known.', 'The report was used to conceal the scale of the losses.', 'Verb', verb=('conceal','concealed','concealed',False)),
v('profit', 'Money remaining after the costs of a business activity have been paid.', 'The business reported a profit despite falling sales.', 'Noun', form='profits', plural='profits'),
v('asset', 'Something valuable that a person or organization owns or controls.', 'The building was the company’s most valuable asset.', 'Noun', form='assets', plural='assets'),
v('conflict of interest', 'A situation in which a person’s private interests may interfere with their responsibilities to others.', 'The manager disclosed a conflict of interest before the decision.', 'Noun phrase', form='conflicts of interest', plural='conflicts of interest'),
v('auditor', 'A person or organization that formally examines financial records.', 'The auditor questioned the company’s accounts.', 'Noun', form='auditors', plural='auditors'),
v('bankruptcy', 'A legal process for dealing with a person or organization unable to pay debts.', 'The company sought bankruptcy protection after losing financial support.', 'Noun', plural='bankruptcies'),
v('creditor', 'A person or organization to whom money is owed.', 'The creditor asked how much of the loan would be repaid.', 'Noun', form='creditors', plural='creditors'),
v('oversight', 'The work of supervising an activity and checking that it is done properly.', 'Independent oversight was intended to improve financial reporting.', 'Uncountable noun', note='Used here for supervision, not the separate meaning of an accidental omission.')
],
[
m('What was a central problem behind Enron’s reported success?', ['Its profits were accurately reported, but energy demand collapsed unexpectedly.', 'It disclosed its full debt, but lenders refused to support new pipelines.', 'Accounting arrangements hid weaknesses and made the company look stronger than it was.'], 'C', 'Executives used complicated partnerships and accounting arrangements to conceal debt and losses or create misleading profits.', 'Overvalued assets and conflicts of interest added to the misleading picture.'),
m('What happened as confidence collapsed in late 2001?', ['Debt ratings fell, the Dynegy rescue ended and Enron sought bankruptcy protection.', 'The Dynegy merger was completed before the accounts were corrected.', 'Higher debt ratings restored lending and prevented the bankruptcy filing.'], 'A', 'On November 28, Enron\'s debt ratings fell below investment grade and Dynegy ended the deal.', 'The following sentence dates the bankruptcy filing to December 2.'),
m('How does the story connect Enron to the 2002 reform law?', ['Enron’s bankruptcy was reversed when the law took effect.', 'Enron and other scandals contributed to stronger reporting and audit safeguards.', 'The law removed the need for independent auditors to examine company reports.'], 'B', 'Enron, WorldCom and other scandals helped drive the Sarbanes–Oxley Act of 2002.', 'The next sentence describes greater reporting responsibility, auditor independence and oversight.'),
g('Enron was based in the American city of ___.', 'Houston', 'Based in Houston, it expanded from gas pipelines into trading gas, electricity and other contracts.', 'The city is part of the company’s background.'),
g('The proposed rescue merger involved rival company ___.', 'Dynegy', 'A planned rescue merger with rival energy company Dynegy offered temporary hope.', 'The deal ended as Enron’s financial position and debt ratings deteriorated.'),
g('Enron filed for bankruptcy protection on December 2, ___.', '2001', 'With trust and financial support disappearing, Enron filed for bankruptcy protection on December 2, 2001.', 'The filing followed the failed rescue merger.')
],
[
'US Securities and Exchange Commission, December 12, 2001 testimony, Recent Events Relating to Enron — Contemporary account of business, partnerships and conflicts, October/November disclosures, restatement, downgrade, failed merger and bankruptcy chronology: https://www.sec.gov/newsroom/speeches-statements/121201tsrkh-testimony-recent-events-relating-enron-corporation',
'Federal Bureau of Investigation, Enron case history — False profits, concealed debt, overvalued assets, losses and criminal investigation: https://www.fbi.gov/history/cases-and-criminals/enron',
'US Senate Governmental Affairs Committee staff, Financial Oversight of Enron, October 7, 2002 — Directors, auditor, financial institutions and other gatekeepers, jobs and retirement/shareholder losses: https://www.govinfo.gov/content/pkg/CPRT-107SPRT82147/html/CPRT-107SPRT82147.htm',
'US Supreme Court, Arthur Andersen LLP v United States, May 31, 2005 — Reversal of the document-destruction conviction because instructions failed to convey required legal elements: https://tile.loc.gov/storage-services/service/ll/usrep/usrep544/usrep544696/usrep544696.pdf',
'US Securities and Exchange Commission, September 9, 2003 testimony, Implementation of the Sarbanes–Oxley Act — Enron alongside WorldCom and other scandals, auditor independence, reporting and oversight: https://www.sec.gov/newsroom/speeches-statements/090903tswhd-testimony-implementation-sarbanes-oxley-act-2002',
'US Government Publishing Office, Sarbanes–Oxley Act, Public Law 107–204, July 30, 2002 — Primary legislation on reporting, independence and public audit oversight: https://www.govinfo.gov/content/pkg/PLAW-107publ204/pdf/PLAW-107publ204.pdf'
],
[
'Whole-company overview covers growth and reputation, misleading financial position and conflicts, broad failures of oversight, disclosures and loss of confidence, failed rescue, bankruptcy, employee/investor harm, legal accountability and reform.',
'The story describes misleading uses of partnerships and accounting, not a claim that every partnership, off-balance-sheet structure or accounting method is inherently unlawful. It gives no fraud instructions.',
'November 2001 corrections are distinguished from earlier reported earnings; no ambiguous restatement total is given. Debt downgrade and Dynegy termination precede the December 2 bankruptcy filing.',
'Retirement losses concern savings invested in Enron shares. No assertion that every pension or every employee’s entire savings vanished.',
'Arthur Andersen’s 2002 conviction and 2005 Supreme Court reversal are explicitly distinguished. The reversal involved flawed jury instructions and is not represented as validation of Enron’s accounts. No unsupported claim about Andersen’s later survival or individual executives’ changing sentences is made.',
'Sarbanes–Oxley followed several scandals including WorldCom, not Enron alone. Legal consequences are described historically rather than as current legal advice.',
'Compared with all 001–093, remaining batch subjects and the Lincoln reservation. Enron’s energy-company accounting collapse is distinct from 053’s Theranos, 028’s financial crisis, 088’s Depression and 085’s oil embargo.'
])

draft(95, 'dolly-sheep-adult-cell-cloning-1996-1997', 'Dolly the Sheep: The Clone That Changed Biology', 'Science and Discoveries',
      'A lamb born from the nucleus of an adult body cell changed ideas about development and raised lasting questions about cloning, animal welfare and the limits of genetic similarity.',
'''On July 5, 1996, a lamb named Dolly was born at the Roslin Institute in Scotland. She was the first mammal **cloned** from an adult body cell. Earlier mammals had been cloned using embryo cells, but Dolly showed that an adult cell could also provide the starting point for a new animal.

The research involved Roslin and PPL Therapeutics, with a team including Ian Wilmut and Keith Campbell. Scientists wanted to understand cell development and improve methods for producing farm animals with useful traits. A central question was whether a **specialized** adult cell could support the development of an entire body.

An adult sheep's mammary cell supplied the **nucleus**, which contained most of its DNA. Another sheep supplied an egg whose own nucleus had been removed. An **embryo** developed and was carried by a **surrogate** mother. Dolly's birth showed that the adult cell's activity could be **reprogrammed** for development.

Most of Dolly's **genetic** information came from the adult-cell donor, but a small amount came from the egg. She was a new animal, whose development also depended on pregnancy and environment. Copying nuclear DNA did not mean copying every feature or experience of the original sheep.

The technique was **inefficient**, with many failed attempts before one lamb was born. Dolly was publicly announced on February 22, 1997, shortly before the research paper appeared. News spread worldwide, raising hopes for biology and medicine alongside concerns about animal **welfare** and possible human cloning.

Dolly lived with other sheep and produced six lambs. She later developed arthritis and a virus-related lung disease. She was euthanized on February 14, 2003, after developing lung tumours. Her illness and death did not establish that cloning caused premature ageing.

The experiment changed ideas about how cells develop and encouraged research into cell reprogramming. It also exposed the practical and ethical difficulties of producing cloned animals. Dolly was not the first cloned animal, a gene-edited sheep or evidence of successful human cloning. Her importance came from showing what an adult cell could make possible.''',
[
v('clone', 'To produce an organism with essentially the same nuclear genetic information as another.', 'The researchers tried to clone an animal from a body cell.', 'Verb', form='cloned', verb=('clone','cloned','cloned',False)),
v('specialized', 'Adapted or developed for a particular task or function.', 'A specialized cell performs a particular role in the body.', 'Adjective'),
v('nucleus', 'The part of a cell that contains most of its genetic information.', 'Most of the cell’s DNA is stored in its nucleus.', 'Noun', plural='nuclei'),
v('embryo', 'An organism at an early stage of development.', 'The embryo continued developing during pregnancy.', 'Noun', plural='embryos'),
v('surrogate', 'A female who carries a pregnancy on behalf of another individual.', 'The surrogate gave birth to the lamb.', 'Noun', plural='surrogates', note='Surrogate mother in the script describes the sheep that carried the developing embryo.'),
v('reprogram', 'To change the instructions or patterns that control how something works.', 'The experiment showed that scientists could reprogram aspects of a cell’s activity.', 'Verb', form='reprogrammed', verb=('reprogram','reprogrammed','reprogrammed',False), note='Cellular reprogramming changes how a cell uses genetic information; it is not necessarily editing the DNA sequence.'),
v('genetic', 'Related to genes and inherited biological information.', 'Genetic information influences many characteristics of an animal.', 'Adjective'),
v('inefficient', 'Using too much time, effort or resources for the results achieved.', 'The inefficient process required many attempts.', 'Adjective'),
v('welfare', 'The health, comfort and well-being of people or animals.', 'The study raised questions about animal welfare.', 'Uncountable noun')
],
[
m('What made Dolly scientifically distinctive?', ['She was the first animal ever produced without ordinary mating.', 'She was the first cloned mammal whose DNA had been deliberately edited.', 'She showed that an adult body cell could support the creation of a new mammal.'], 'C', 'Earlier mammals had been cloned using embryo cells, but Dolly showed that an adult cell could also provide the starting point for a new animal.', 'The important distinction concerns the adult source cell, not the first existence of any clone.'),
m('What does the story say about Dolly’s similarity to the donor?', ['Most genetic information came from the donor, but other DNA and development also mattered.', 'All her DNA came from the surrogate, while the donor determined her experiences.', 'Sharing nuclear DNA meant she necessarily repeated the donor’s life and characteristics.'], 'A', 'Most of Dolly\'s genetic information came from the adult-cell donor, but a small amount came from the egg.', 'The following sentences also explain the influence of pregnancy and environment.'),
m('Why did Dolly’s birth raise practical and ethical questions?', ['The experiment had removed pregnancy losses and settled the safety of cloning.', 'The method had low efficiency and raised concerns about animal welfare and possible human use.', 'The announcement confirmed that human cloning had already succeeded.'], 'B', 'News spread worldwide, raising hopes for biology and medicine alongside concerns about animal welfare and possible human cloning.', 'The preceding sentences describe many failed attempts and an inefficient method.'),
g('Dolly was born at the Roslin Institute in ___.', 'Scotland', 'On July 5, 1996, a lamb named Dolly was born at the Roslin Institute in Scotland.', 'The institute was the setting for this breakthrough.'),
g('Although born in 1996, Dolly was publicly announced in ___.', '1997', 'Dolly was publicly announced on February 22, 1997, shortly before the research paper appeared.', 'Birth, public announcement and journal publication occurred on different dates.'),
g('Dolly produced ___ lambs during her life.', 'six', 'Dolly lived with other sheep and produced six lambs.', 'Her offspring were part of her life after the original cloning experiment.')
],
[
'University of Edinburgh Roslin Institute, The Life of Dolly — Research setting and team, adult mammary cell, July 5 1996 birth, February 22 1997 announcement, six lambs, illness and February 14 2003 death: https://vet.ed.ac.uk/roslin/about/history/dolly/facts/life-of-dolly',
'University of Edinburgh Roslin Institute, Cloning FAQs — Adult nuclear transfer, egg DNA caveat, environment, inefficiency, welfare, uncertain ageing interpretation and cloning versus genetic modification: https://vet.ed.ac.uk/roslin/about/history/dolly/facts/cloning',
'University of Edinburgh Our History, Cloning of Dolly the Sheep 1996 — Wilmut/Campbell, earlier work, reprogramming and one live lamb after many attempts; its wording conflating public announcement and February 27 publication is not adopted: https://ourhistory.is.ed.ac.uk/index.php?title=Cloning_of_Dolly_the_Sheep,_1996',
'Wilmut et al., Nature 385, 810–813, February 27 1997, Viable offspring derived from fetal and adult mammalian cells — Original paper identity and publication date checked against institutional accounts and indexed metadata; direct full-text opening blocked by publisher authentication redirect: https://www.nature.com/articles/385810a0'
],
[
'Overview covers research motivation and team, adult-cell breakthrough, three biological roles, nuclear and egg genetic contributions, environment, low efficiency, announcement and response, Dolly’s later life, health uncertainty and scientific/ethical legacy.',
'Dolly was the first mammal cloned from an adult cell, not the first cloned animal or first cloned mammal. The source cell was an adult mammary cell, not an embryo cell.',
'Nucleus donor, egg donor and gestational surrogate play different roles. Most DNA is nuclear, but the egg contributes mitochondrial DNA. The narrative therefore avoids an absolutely identical copy claim and recognizes developmental/environmental influences.',
'Birth was July 5, 1996; Roslin dates public announcement to February 22, 1997; Nature publication was February 27. The Edinburgh history page compresses these last two events, so the direct Roslin date is preferred.',
'Many failed attempts is used instead of equating 277 reconstructed eggs or attempts with 277 surrogate pregnancies. High-level mechanism is explanatory, not an experimental protocol.',
'Lung tumours led to euthanasia in February 2003. Arthritis and death do not establish premature ageing caused by cloning. No general claim that every clone is healthy or that cloning carries no welfare risks is made.',
'Cloning, gene editing and human reproductive cloning are distinguished. Scientific significance concerns adult-cell reprogramming; no proven human cloning or immediate medical cure is claimed. Direct full-text access limits for the original paper are recorded rather than implied away.',
'Compared with all 001–094 and the Lincoln reservation. This animal-cloning event is distinct from 060’s DNA structure, 034’s genome project and 093’s human heart transplant.'
])
