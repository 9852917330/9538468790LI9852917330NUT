"""Source-reviewed historical events and turning points, lessons 086–090."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(86, 'french-revolution-1789-1799', 'The French Revolution: Rights, Violence and a New Political Order', 'Revolutions and Historical Turning Points',
      'Financial crisis and demands for rights overturned France’s old order, leading through constitutional reform, a republic, war and political violence to the coup of 1799.',
'''In 1789, France faced a financial and political crisis. Expensive wars had increased government **debt**, while poor harvests drove up bread prices. The clergy and nobility enjoyed special **privileges**, and many people resented unequal taxes and limited political influence. Enlightenment ideas encouraged challenges to traditional authority.

King Louis XVI called the Estates-General, an assembly of France's three social orders, to discuss the crisis. **Representatives** of the Third Estate, which included everyone outside the clergy and nobility, formed a National Assembly. They promised to give France a **constitution**.

On July 14, crowds stormed the Bastille prison in Paris. In the countryside, peasants attacked signs of their landlords' power. In August, the Assembly began dismantling old privileges and adopted the Declaration of the Rights of Man and of the Citizen. It proclaimed liberty and equality before the law. A march led by women later helped force the royal family from Versailles to Paris.

A constitution in 1791 limited the **monarchy**, but trust in the king had suffered after his failed attempt to escape. War with European powers and fears of betrayal deepened political divisions. The monarchy fell in 1792, and France became a **republic**. Louis XVI was executed in January 1793.

During the Terror of 1793–1794, revolutionary authorities arrested large numbers of **suspects** and ordered thousands of **executions**. Foreign war, civil war, food shortages and struggles for power intensified the crisis. Violence and severe repression extended beyond Paris.

Robespierre, a leading revolutionary politician, was overthrown in July 1794. The Directory government followed in 1795, but remained unstable and increasingly dependent on the army. In November 1799, Napoleon Bonaparte and his allies seized power in a coup, conventionally marking the Revolution's end.

The Revolution's **legacy** included weakened inherited privilege and powerful ideas about citizenship and rights. Yet its promises remained incomplete: women gained some civil rights but could not vote. The decade combined major reforms with war, exclusion and political violence, leaving questions about how freedom could be protected.''',
[
v('debt', 'Money that a person, organization or government owes.', 'The government struggled to repay its debt.', 'Noun', plural='debts'),
v('privilege', 'A special right or advantage available only to a particular person or group.', 'The reform ended a privilege enjoyed by wealthy landowners.', 'Noun', form='privileges', plural='privileges'),
v('representative', 'A person chosen to speak or act for a group of people.', 'Each district elected a representative to the assembly.', 'Noun', form='Representatives', plural='representatives'),
v('constitution', 'The basic rules that define a government’s powers and people’s rights.', 'The constitution placed limits on the government.', 'Noun', plural='constitutions'),
v('monarchy', 'A system of government with a king or queen as head of state.', 'The constitution changed the powers of the monarchy.', 'Noun', plural='monarchies'),
v('republic', 'A state whose head is not a hereditary monarch and whose power is held by the people or their representatives.', 'The country became a republic after the monarchy ended.', 'Noun', plural='republics'),
v('suspect', 'A person thought possibly to have committed an offence or done something wrong.', 'The suspect was questioned before any charge was brought.', 'Noun', form='suspects', plural='suspects'),
v('execution', 'The killing of a person as an official punishment.', 'The court ordered an execution after the trial.', 'Noun', form='executions', plural='executions'),
v('legacy', 'A lasting result or influence of past events or actions.', 'The reform left a complex political legacy.', 'Noun', plural='legacies')
],
[
m('Which combination helped produce the crisis of 1789?', ['War debts, costly bread, unequal privileges and demands for political influence.', 'A successful harvest, lower taxes and a dispute over the new republic.', 'The Directory’s financial policies and opposition to Napoleon’s government.'], 'A', 'Expensive wars had increased government debt, while poor harvests drove up bread prices.', 'The next sentences add unequal taxes, privileges, limited influence and new political ideas.'),
m('How did France’s political system change before the king’s execution?', ['The republic was established in 1789 and restored the monarchy in 1791.', 'A constitutional monarchy was followed by the fall of the monarchy and a republic.', 'The Estates-General replaced the monarchy with the Directory in 1791.'], 'B', 'The monarchy fell in 1792, and France became a republic.', 'The preceding paragraph describes the 1791 constitution that had first limited royal power.'),
m('Which assessment best matches the Revolution’s outcomes?', ['It gave equal voting rights to all adults immediately after the Declaration.', 'Its political effects ended when Robespierre lost power in 1794.', 'It advanced rights and weakened privilege, while exclusion and violence continued.'], 'C', 'Yet its promises remained incomplete: women gained some civil rights but could not vote.', 'The final paragraph balances lasting reforms with their limits and the decade’s violence.'),
g('The Paris prison stormed on July 14 was the ___.', 'Bastille', 'On July 14, crowds stormed the Bastille prison in Paris.', 'The attack was one development in a much wider revolution.'),
g('Louis XVI was executed in January ___.', '1793', 'Louis XVI was executed in January 1793.', 'His execution followed the monarchy’s fall in 1792.'),
g('Napoleon and his allies seized power in a ___ in November 1799.', 'coup', 'In November 1799, Napoleon Bonaparte and his allies seized power in a coup, conventionally marking the Revolution\'s end.', 'This seizure of power ended the Directory government.')
],
[
'Château de Versailles, Versailles at the heart of the French Revolution — Estates-General, National Assembly, August reforms and October march; its July 15 running-text typo is rejected in favour of the July 14 caption and corroborating chronology: https://en.chateauversailles.fr/discover/history/key-dates/versailles-heart-french-revolution',
'George Mason University / CUNY, Liberty, Equality, Fraternity, Social Causes of the Revolution — Social orders, inequality, bread prices and rural action: https://revolution.chnm.org/exhibits/show/liberty--equality--fraternity/social-causes-of-revolution',
'George Mason University / CUNY, Monarchy Falls — War debts, failed royal flight, constitutional monarchy, republic and execution: https://revolution.chnm.org/exhibits/show/liberty--equality--fraternity/monarchy-falls',
'George Mason University / CUNY, War, Terror, and Resistance — Civil and foreign war, Terror, Directory and coup; use November 1799 rather than an inconsistent December reference: https://www.revolution.chnm.org/exhibits/show/liberty--equality--fraternity/war-terror-and-resistance',
'George Mason University / CUNY, The Enlightenment and Human Rights — Rights declaration, incomplete equality, women’s civil rights and exclusion from voting: https://revolution.chnm.org/exhibits/show/liberty--equality--fraternity/enlightenment-and-human-rights'
],
[
'Overview follows the whole revolutionary decade: social and fiscal pressures, representative challenge, urban and rural action, rights reforms, constitutional monarchy, republic, wars and Terror, unstable Directory and the 1799 coup.',
'Bastille date is July 14. August reforms began dismantling feudal privilege; obligations did not all disappear immediately. The monarchy was not abolished in 1789.',
'The Terror is one phase, not a synonym for the entire Revolution. No single leader or Paris episode dominates; civil war and repression outside Paris are acknowledged without graphic detail or an incompatible aggregate death toll.',
'Women’s civil gains are distinguished from voting rights. The story does not claim universal equality, immediate democracy or a peaceful completion.',
'Compared with all 001–085, other batch subjects and future candidates. This is a revolutionary-decade overview, distinct from 071’s Napoleon life/Waterloo/exile and 075’s Russian Revolutions. Napoleon appears only at the endpoint, without repeating his biography.'
])

draft(87, 'lisbon-earthquake-tsunami-fires-1755', 'Lisbon 1755: An Earthquake, a Tsunami and a City Rebuilt', 'Disasters and Recovery',
      'A powerful offshore earthquake, destructive waves and lasting fires devastated Portugal’s capital and reshaped ideas about rebuilding cities and studying natural disasters.',
'''In 1755, Lisbon was Portugal's capital and a major centre of overseas trade. Its waterfront held warehouses, public buildings and the royal palace. On the morning of November 1, All Saints' Day, many people were attending church when a powerful **offshore** earthquake struck.

Violent shaking damaged buildings and brought walls and roofs down. Streets filled with **debris**, while frightened survivors searched for open ground. Some moved towards the waterfront beside the River Tagus, where another danger was approaching.

Movement beneath the Atlantic had generated a **tsunami**. Within roughly an hour, waves travelled into the river and **engulfed** parts of the waterfront. More than one wave arrived. Other Portuguese coastal communities and places in Spain and Morocco also suffered damage, and the waves travelled across the Atlantic.

Fires broke out in Lisbon and continued for days. They destroyed many buildings that had survived the shaking. Homes, churches, businesses and valuable collections were lost. Together, the earthquake, tsunami and fires **devastated** the city. Tens of thousands died across the affected region, although the exact total remains uncertain.

Survivors needed food, clean water and **shelter**. The government organized relief and **reconstruction** under the minister Sebastião José de Carvalho e Melo, later known as the Marquis of Pombal. Rebuilding was a major public effort that transformed the centre of the capital.

Planners replaced much of the old street pattern with regular blocks, wider roads and public squares. New buildings included wooden frames intended to make them more **resistant** to earthquakes. Firewalls and improved drainage also formed part of the design. These changes aimed to reduce future risks as well as restore daily life and trade.

Officials conducted a **survey**, collecting reports about the shaking, damage and unusual movements of the sea. Such accounts became valuable evidence for later researchers. Across Europe, writers and philosophers debated what the disaster meant for religion, nature and human responsibility.

The exact earthquake source and magnitude remain matters of reconstruction and research. Lisbon's destruction nevertheless showed how several hazards could combine, while its recovery influenced earthquake study and the planning of safer cities.''',
[
v('offshore', 'Located or happening in the sea away from the coast.', 'An offshore earthquake was felt in several coastal towns.', 'Adjective'),
v('debris', 'Broken pieces left after something has been damaged or destroyed.', 'Workers cleared debris from the road.', 'Uncountable noun'),
v('tsunami', 'A series of sea waves caused by a major disturbance such as an underwater earthquake.', 'The tsunami damaged several coastal communities.', 'Noun', plural='tsunamis'),
v('engulf', 'To flow over, surround or completely cover something.', 'Floodwater began to engulf the low-lying streets.', 'Verb', form='engulfed', verb=('engulf','engulfed','engulfed',False)),
v('devastate', 'To cause very great damage or destruction to a place or community.', 'The storm could devastate the coastal region.', 'Verb', form='devastated', verb=('devastate','devastated','devastated',False)),
v('shelter', 'Protection from weather or danger, or a place that provides it.', 'Displaced families urgently needed shelter.', 'Uncountable noun', note='Used uncountably here for basic protection or accommodation.'),
v('reconstruction', 'The work of rebuilding something after it has been damaged or destroyed.', 'Reconstruction of the city took many years.', 'Uncountable noun'),
v('resistant', 'Able to withstand or be less affected by something harmful.', 'The new materials were more resistant to heat.', 'Adjective', note='Often followed by to.'),
v('survey', 'An organized collection of information about a subject or area.', 'The survey recorded damage in several districts.', 'Noun', plural='surveys')
],
[
m('Why did moving to the waterfront fail to protect some survivors?', ['Fires had already destroyed every open area beside the river.', 'Tsunami waves entered the Tagus and flooded parts of the waterfront.', 'The earthquake occurred only after people reached the riverbank.'], 'B', 'Within roughly an hour, waves travelled into the river and engulfed parts of the waterfront.', 'The waterfront offered open space after the shaking but exposed people to another hazard.'),
m('Which description best explains the destruction?', ['Tsunami waves caused most inland damage, while shaking and fire affected only the port.', 'The shaking destroyed the city, while later fires caused little additional loss.', 'Shaking, tsunami waves and fires contributed in different ways.'], 'C', 'Together, the earthquake, tsunami and fires devastated the city.', 'The narrative explains how the three hazards combined and affected different places.'),
m('How did the rebuilding plan address future dangers?', ['It used wider streets, wooden structural frames, firewalls and improved drainage.', 'It restored the original narrow street pattern and avoided changes to buildings.', 'It concentrated on replacing the palace before collecting reports or planning streets.'], 'A', 'New buildings included wooden frames intended to make them more resistant to earthquakes.', 'The surrounding sentences describe wider roads, regular blocks, firewalls and drainage.'),
g('Lisbon was the capital of ___.', 'Portugal', 'In 1755, Lisbon was Portugal\'s capital and a major centre of overseas trade.', 'The opening sentence establishes the national and economic setting.'),
g('The disaster began on November 1, ___.', '1755', 'In 1755, Lisbon was Portugal\'s capital and a major centre of overseas trade.', 'The following sentence gives November 1 as the date of the earthquake.'),
g('Officials collected reports about damage and movements of the ___.', 'sea', 'Officials conducted a survey, collecting reports about the shaking, damage and unusual movements of the sea.', 'These reports became evidence for later research.')
],
[
'NOAA Pacific Tsunami Warning Center, Tsunami Historical Series: Lisbon 1755 — All Saints’ Day, Tagus sequence, multiple waves and wider Atlantic impact; historical animation is a model: https://sos.noaa.gov/catalog/datasets/tsunami-historical-series-lisbon-1755/',
'Santos et al., University of Lisbon, 2019 primary research, The historical reconstruction of the 1755 earthquake and tsunami in downtown Lisbon — Fire destruction, uneven impact and approximately 60-minute modelled tsunami arrival: https://researchportal.ulisboa.pt/en/publications/the-historical-reconstruction-of-the-1755-earthquake-and-tsunami--2/',
'Permanent Delegation of Portugal to UNESCO, Pombaline Lisbon Tentative List submission — Relief, reconstruction, planning, wooden frames, firewalls, drainage and intellectual responses: https://whc.unesco.org/en/tentativelists/6226/',
'US Geological Survey, Bosnic et al. 2021 primary research, Onshore flow characteristics of the 1755 CE Lisbon tsunami — Unresolved earthquake epicentre and source scenarios: https://www.usgs.gov/publications/onshore-flow-characteristics-1755-ce-lisbon-tsunami-linking-forward-and-inverse',
'European Geosciences Union, Lisbon at the dawn of modern geosciences — Lasting fires, official questionnaire and philosophical responses: https://blogs.egu.eu/divisions/ts/2018/11/03/lisbon-at-the-down-of-modern-geosciences/'
],
[
'Balanced event overview covers pre-disaster port setting, earthquake damage, multiple tsunami waves, lasting fires, regional reach, human needs, government response, reconstruction, evidence collection and intellectual consequences.',
'No instrumentally measured magnitude, settled source fault, universal wave height or exact death count is asserted. Tens of thousands refers to the affected region, not a sum of incompatible city-only estimates.',
'Arrival is roughly within an hour, accommodating reconstructed timing. No giant wave is claimed to cover all Lisbon. Later fires caused major additional damage, including buildings that survived the shaking.',
'The minister received the Marquis of Pombal title later. Rebuilding involved planners, engineers and public organization rather than one person’s action. Wooden frames were intended to improve resistance, not guarantee earthquake-proof buildings.',
'The UNESCO page is Portugal’s Tentative List submission, not evidence of World Heritage inscription. Questionnaire collection contributed to earthquake research; the story avoids a single-event invention claim.',
'Compared with all 001–086, other new subjects and reserved candidates. Lisbon 1755 is a separate event from London’s 1666 fire, Vesuvius, Tambora, Krakatoa and the 2004 and 2011 tsunamis.'
])

draft(88, 'wall-street-crash-great-depression-1929-1930s', 'The Great Depression: From Market Crash to Global Crisis', 'World Events and the Economy',
      'The 1929 stock market collapse became a symbol of a much deeper crisis as banking failures, falling spending and international weaknesses devastated jobs and livelihoods.',
'''During the 1920s, rising American stock prices encouraged **speculation**. Some investors borrowed money to buy **shares**, hoping that prices would keep climbing. The economy also had weaknesses, including struggling farms and uneven prosperity. Growth began to slow before the famous crash.

In October 1929, panic selling hit Wall Street in New York. Prices plunged on several days, including October 29, known as Black Tuesday. The crash destroyed wealth and confidence. Families reduced purchases, and businesses cut production and jobs.

The crash alone did not cause the whole Great Depression. The American downturn had begun in August 1929. From 1930, repeated **bank runs** and failures made conditions much worse. Frightened customers rushed to withdraw money, while banks reduced lending or closed. People and businesses lost access to savings and credit.

As spending and the money supply fell, **deflation** increased the burden of **debt**. Falling prices reduced incomes, but amounts owed did not fall with them. This made repayment harder and encouraged further cuts in spending. The Federal Reserve failed to provide enough support to stop the banking collapse.

The crisis spread through international finance and trade. European countries already faced financial weaknesses. The gold standard, which tied currencies to gold, limited government responses, while poor cooperation deepened the worldwide slump.

By 1933, **unemployment** affected about 25 percent of American workers. Families lost homes and farms, and many searched elsewhere for work. Drought and dust storms brought additional suffering to farming communities in the Great Plains.

President Franklin Roosevelt began the New Deal in 1933. Its programs provided **relief**, public jobs and financial reforms. Federal **deposit** insurance started in 1934 to protect covered bank savings and help restore trust. New measures changed expectations about government responsibility during economic emergencies.

The **recovery** remained uneven. Another recession struck in 1937, and full American employment and production returned during the Second World War. The Depression transformed economic policy and damaged trust in existing political systems. Its scale reflected connected financial, social and international failures, rather than a single bad day on the stock market.''',
[
v('speculation', 'Buying or selling something in the hope of profiting from changes in its price, often with substantial risk.', 'Speculation pushed prices beyond what many buyers expected.', 'Uncountable noun'),
v('share', 'One of the units into which ownership of a company is divided.', 'She owned a share in the company.', 'Noun', form='shares', plural='shares'),
v('bank run', 'A situation in which many customers try to withdraw their bank money at the same time because they fear the bank may fail.', 'A bank run quickly reduced the money available for withdrawals.', 'Noun phrase', form='bank runs', plural='bank runs'),
v('deflation', 'A general fall in prices across an economy.', 'Deflation increased the difficulty of repaying fixed debts.', 'Uncountable noun'),
v('debt', 'Money that a person, organization or government owes.', 'Lower income made the debt harder to repay.', 'Noun', plural='debts'),
v('unemployment', 'The situation in which people who want work cannot find jobs.', 'Factory closures caused unemployment to rise.', 'Uncountable noun'),
v('relief', 'Practical or financial help for people in serious difficulty.', 'The program provided relief for families without income.', 'Uncountable noun'),
v('deposit', 'Money placed in a bank account.', 'The insurance protected an eligible bank deposit.', 'Noun', plural='deposits', note='Used before insurance in the script to describe protection for bank deposits.'),
v('recovery', 'The process of returning towards a better or more normal condition after a period of difficulty.', 'Economic recovery took longer than many people expected.', 'Noun', plural='recoveries')
],
[
m('Why does the story distinguish the crash from the Great Depression?', ['The crash affected stock prices but left spending and employment unchanged.', 'The downturn began with Black Tuesday and remained mainly a stock-market problem.', 'The downturn had already begun, and later banking and policy failures deepened it.'], 'C', 'The crash alone did not cause the whole Great Depression.', 'The following sentences distinguish the August downturn from repeated banking crises after 1930.'),
m('How did falling prices make debt harder to repay?', ['Incomes fell while the amounts people owed did not fall with them.', 'Banks automatically increased every loan’s original amount as prices fell.', 'Deflation raised wages faster than the value of outstanding debts.'], 'A', 'Falling prices reduced incomes, but amounts owed did not fall with them.', 'A fixed debt became a heavier burden when borrowers received less income.'),
m('Which description best matches the New Deal and the recovery?', ['The New Deal restored full employment before deposit insurance began.', 'Relief and reforms helped, but recovery remained uneven and full employment came during the war.', 'Financial reforms were postponed until the 1937 recession had ended.'], 'B', 'Another recession struck in 1937, and full American employment and production returned during the Second World War.', 'The earlier paragraph describes relief and reforms beginning in 1933 without claiming immediate complete recovery.'),
g('The American downturn began in ___ 1929, before the October crash.', 'August', 'The American downturn had begun in August 1929.', 'The economic contraction preceded the best-known market collapse.'),
g('By 1933, about ___ percent of American workers were unemployed.', '25', 'By 1933, unemployment affected about 25 percent of American workers.', 'This is an approximate historical unemployment estimate, not a share of the entire population.'),
g('Federal deposit insurance started in ___.', '1934', 'Federal deposit insurance started in 1934 to protect covered bank savings and help restore trust.', 'The law creating the system was passed in 1933, but protection began the next year.')
],
[
'Federal Reserve History, Stock Market Crash of 1929 — Borrowing, speculation, October sell-offs, contraction before the crash and damage to confidence: https://www.federalreservehistory.org/essays/stock-market-crash-of-1929',
'Federal Reserve History, The Great Depression — August 1929 start, later banking panics, money contraction, deflation, policy failures, 1937 recession and wartime full recovery: https://www.federalreservehistory.org/essays/great-depression',
'US Department of State Office of the Historian, The Great Depression and US Foreign Policy — International weaknesses, gold-standard constraints, lack of cooperation and political consequences: https://history.state.gov/milestones/1921-1936/great-depression',
'FDR Presidential Library and Museum, Great Depression Facts — Approximately 25 percent unemployment, losses, migration, Dust Bowl, New Deal jobs and relief, incomplete 1930s recovery; inaccurate crash-volume and broad production figures are not used: https://www.fdrlibrary.org/great-depression-facts',
'Federal Reserve History, Banking Act of 1933 — Creation of the FDIC in 1933 and start of deposit insurance in January 1934: https://www.federalreservehistory.org/essays/glass-steagall-act'
],
[
'Whole-event overview includes speculative boom and underlying weaknesses, crash, later banking crises and policy mistakes, deflation and debt, international spread, ordinary lives, relief/reform and uneven recovery.',
'The October crash is neither the start of every economic problem nor the sole cause of the Depression. August 1929 contraction and later 1930–1933 banking failures are distinguished. No one-day 89 percent market decline is claimed.',
'Unemployment is an approximate share of American workers, not all Americans or a uniform world figure. Dust Bowl drought compounded the Depression rather than explaining the entire global collapse.',
'The 1933 insurance legislation and January 1934 start of coverage are different events. Covered savings are not all wealth or investments. Relief and reforms did not instantly restore full employment.',
'The gold standard and weak cooperation are contributing mechanisms, not a complete monocausal account. Political damage is acknowledged without claiming the Depression alone caused the Second World War.',
'Compared with all 001–087 and reserved candidates. The 1929–1930s Depression is distinct from 028’s 2008 Global Financial Crisis and 085’s 1973 oil shock; titles and aliases preserve that distinction.'
])

draft(89, 'black-death-pandemic-1347-1351', 'The Black Death: A Pandemic That Transformed Medieval Life', 'Disease and Historical Turning Points',
      'Medieval trade routes carried plague across regions, causing immense and uneven loss, persecution and lasting changes in work and community life.',
'''In the middle of the fourteenth century, a devastating **pandemic** spread across parts of Asia, Europe and North Africa. Later called the Black Death, it struck societies connected by busy trade routes. **Merchants**, sailors and travellers linked distant communities, helping disease move between them.

The illness was plague, caused by the bacterium Yersinia pestis. Modern analysis of ancient DNA has identified related plague in people buried in present-day Kyrgyzstan in 1338–1339. This evidence connects the pandemic's roots with Central Asia, although it does not reveal every journey the disease took.

In 1347, ships brought plague from the Black Sea into Mediterranean **ports**. It spread through towns and countryside during the following years. Fleas could **transmit** the bacteria from infected animals to people, and some forms could also spread through respiratory droplets. The importance of different routes during the medieval outbreak is still debated.

Many victims developed fever and painful **swellings**. People did not understand the bacterial cause, and the care available could do little to stop the catastrophe. Families lost relatives, businesses lost workers and communities struggled to arrange **burials**. Millions died, but the exact number is uncertain, and losses varied greatly between regions.

Fear also produced further harm. Some people falsely blamed Jewish communities for the disease. Many Jews suffered violent attacks and **persecution**, even though they were not responsible for the outbreak. Religious explanations and mistaken beliefs existed alongside efforts to care for the sick and protect communities.

The loss of workers disrupted farming, workshops and trade. Labour **shortages** gave some survivors greater **bargaining power** to demand higher wages or better conditions. Authorities and landowners sometimes tried to restrict wages and movement. The consequences developed differently across places; the plague did not simply make every survivor richer or immediately end the medieval social order.

The first great wave subsided in many European regions around 1351, but outbreaks continued elsewhere and returned repeatedly for centuries. The Black Death left deep losses and changed relations between workers, employers and authorities. Its history shows both the reach of connected societies and the danger of turning fear into blame.''',
[
v('pandemic', 'An outbreak of disease that spreads across many countries or a large part of the world.', 'The pandemic disrupted communities across several regions.', 'Noun', plural='pandemics'),
v('merchant', 'A person whose business is buying and selling goods.', 'The merchant carried cloth between trading towns.', 'Noun', form='Merchants', plural='merchants'),
v('port', 'A place on a coast or river where ships load and unload people or goods.', 'The ship entered the busy port.', 'Noun', form='ports', plural='ports'),
v('transmit', 'To pass something, such as a disease or signal, from one person or place to another.', 'Certain insects can transmit disease between animals and people.', 'Verb', verb=('transmit','transmitted','transmitted',False)),
v('swelling', 'An area of the body that has become larger, often because of illness or injury.', 'The doctor examined the painful swelling.', 'Noun', form='swellings', plural='swellings'),
v('burial', 'The act or ceremony of placing a dead person’s body in the ground.', 'The community arranged a burial for its neighbour.', 'Noun', form='burials', plural='burials'),
v('persecution', 'Cruel or unfair treatment of people because of their beliefs, identity or membership of a group.', 'Many families fled religious persecution.', 'Uncountable noun'),
v('shortage', 'A situation in which there is not enough of something that is needed.', 'A labour shortage delayed the harvest.', 'Noun', form='shortages', plural='shortages'),
v('bargaining power', 'The ability to influence the terms of an agreement or negotiation.', 'Workers gained bargaining power when employers struggled to find staff.', 'Uncountable noun phrase')
],
[
m('How did trade connections influence the outbreak?', ['Travel and shipping helped carry disease between distant communities.', 'Merchants prevented the disease from spreading beyond Mediterranean ports.', 'The disease moved through inland farming areas before trade routes existed.'], 'A', 'Merchants, sailors and travellers linked distant communities, helping disease move between them.', 'The later account of ships arriving from the Black Sea gives a specific example.'),
m('What does the story say about the number of deaths?', ['The same share of people died in every affected region.', 'Millions died, but the total is uncertain and regional losses differed greatly.', 'Ancient DNA has provided a complete count of all medieval victims.'], 'B', 'Millions died, but the exact number is uncertain, and losses varied greatly between regions.', 'Evidence supports a major catastrophe without establishing one exact, uniform death toll.'),
m('What was one consequence of the loss of workers?', ['Every surviving worker immediately became wealthy.', 'Authorities stopped trying to control wages or movement.', 'Some survivors gained more power to seek better pay and conditions.'], 'C', 'Labour shortages gave some survivors greater bargaining power to demand higher wages or better conditions.', 'The following sentences explain restrictions and regional differences rather than an automatic improvement for everyone.'),
g('The bacterium that caused plague was Yersinia ___.', 'pestis', 'The illness was plague, caused by the bacterium Yersinia pestis.', 'Plague was a bacterial disease, not a virus.'),
g('Ships carried plague from the Black Sea into Mediterranean ports in ___.', '1347', 'In 1347, ships brought plague from the Black Sea into Mediterranean ports.', 'This date describes Mediterranean entry within a broader pandemic.'),
g('Some people falsely blamed ___ communities for the disease.', 'Jewish', 'Some people falsely blamed Jewish communities for the disease.', 'The accusations were false and led to attacks on people who were not responsible.')
],
[
'Max Planck Society, Origins of the Black Death identified, 2022 — Researchers’ own ancient-DNA findings, Kyrgyzstan 1338–1339, Yersinia pestis, Mediterranean entry in 1347 and wider pandemic chronology: https://www.mpg.de/18778852/0607-evan-origins-of-the-black-death-identified-150495x',
'London Museum, The Great Pestilence in London — Pathogen, transmission routes, symptoms, community losses, labour and wages, and later recurrent plague: https://www.londonmuseum.org.uk/collections/london-stories/great-pestilence-london/',
'Izdebski et al., Nature Ecology & Evolution, 2022 primary regional pollen study — Evidence of strong regional variation and limits of uniform European mortality estimates: https://www.nature.com/articles/s41559-021-01652-4',
'US Holocaust Memorial Museum, Antisemitism in History: From the Early Church to 1400 — False blame, scapegoating and persecution during the Black Death: https://encyclopedia.ushmm.org/content/en/article/antisemitism-in-history-from-the-early-church-to-1400',
'Fordham History Sourcebooks, The Black Death and the Jews 1348–1349 — Translated contemporary documents concerning false accusations, coercion and attacks; chroniclers’ figures are not used as exact totals: https://sourcebooks.web.fordham.edu/jewish/1348-jewsblackdeath.asp'
],
[
'Overview includes connected trade routes and Central Asian genetic evidence, geographic spread, bacterial cause and uncertain medieval pathways, community losses, false blame and persecution, labour consequences and recurrent outbreaks.',
'1347–1351 identifies the central European wave, not the exact boundaries of every region’s experience. Wider accounts use 1346–1353, and the narrative explicitly allows later regional outbreaks and centuries of recurrence.',
'Yersinia pestis is a bacterium. Ancient DNA is evidence linking ancestry and place, not identification of an individual patient zero or every step of transmission. Modern routes do not settle their relative importance in medieval spread.',
'No exact world death total or uniform fraction of Europe is asserted. Regional pollen research documents highly unequal impact. Symptoms remain brief and nongraphic.',
'Antisemitic allegations are explicitly false; Jewish people were not responsible for the disease. Persecution is not presented as a medical explanation.',
'Labour losses improved some survivors’ bargaining position but brought controls and varied consequences. The story does not claim an immediate end of feudalism, universal prosperity or a single-cause Renaissance.',
'Compared with all 001–088 and reserved candidates. The medieval Black Death is distinct from 012’s cholera investigation, 022’s COVID-19 pandemic and 031’s smallpox vaccination and eradication.'
])

draft(90, 'mandela-south-africa-democratic-transition-1990-1994', 'South Africa 1994: The End of Apartheid and a Democratic Beginning', 'Rights and Historical Turning Points',
      'Decades of resistance and difficult negotiations brought South Africa from white minority rule to elections open to all races, while deep inequalities remained to be addressed.',
'''For decades, South Africa's government enforced **apartheid**, a system of racial separation and unequal rights. It controlled where people could live, work and study. White **minority** rule excluded the Black majority from national political power. Racial discrimination had older roots, but apartheid became government policy after 1948.

Opposition involved many people and organizations. The African National Congress, or ANC, campaigned against the system alongside workers, students and community groups. Protests faced arrests, bans and violent **repression**. Resistance also included armed struggle. Nelson Mandela, an ANC leader, was arrested in 1962 and received a life sentence in 1964.

Mandela spent about 27 years imprisoned. Meanwhile, domestic resistance, economic difficulties and international pressure, including **sanctions**, increased the cost of maintaining apartheid. The possibility of a negotiated settlement gradually became more important to both government and opposition leaders.

In February 1990, President F. W. de Klerk lifted bans on the ANC and other organizations. Mandela was released on February 11. These changes opened a new phase, but did not immediately create democracy.

The following years brought difficult **negotiations**. The ANC, the National Party government, Inkatha and other political groups disagreed about power and the future state. Talks broke down at times, while killings and political violence threatened the process. Eventually, negotiators agreed on an **interim** constitution and democratic elections.

In April 1994, South Africa held its first democratic national election open to all races. Long queues reflected the importance of a vote many people had previously been denied. The ANC won a majority. Mandela became the country's first Black president and was inaugurated on May 10.

A **coalition** government of national unity included the ANC, the National Party and the Inkatha Freedom Party. Work on a final constitution continued, and Mandela signed it in 1996. The new order established equal **citizenship** and protections for fundamental rights.

Political change did not instantly remove poverty or **inequality** in land, housing, education and services. The transition's achievement came from a broad struggle and a fragile negotiated settlement. Its next challenge was to turn formal rights into better daily lives.''',
[
v('apartheid', 'The former South African system of legally enforced racial separation and unequal rights.', 'The movement demanded an end to apartheid.', 'Uncountable noun'),
v('minority', 'A group that makes up less than half of a population.', 'A small minority controlled most political decisions.', 'Noun', plural='minorities', note='Used before rule in the script to describe government controlled by a minority.'),
v('repression', 'The use of force or restrictions by authorities to control opposition.', 'Repression made public protest dangerous.', 'Uncountable noun'),
v('sanction', 'An official restriction or penalty used to put pressure on a country, organization or person.', 'The government faced a trade sanction.', 'Noun', form='sanctions', plural='sanctions', note='Often plural when describing a set of economic restrictions.'),
v('negotiation', 'A discussion intended to reach an agreement.', 'The negotiation addressed how power would be shared.', 'Noun', form='negotiations', plural='negotiations'),
v('interim', 'Temporary and intended to be used until a final arrangement is ready.', 'An interim agreement allowed the work to begin.', 'Adjective'),
v('coalition', 'A group of parties or organizations that agree to work together, especially in government.', 'The parties formed a coalition after the election.', 'Noun', plural='coalitions'),
v('citizenship', 'The status and rights of being a member of a country.', 'The new law promised equal citizenship.', 'Uncountable noun'),
v('inequality', 'An unfair or unequal difference in rights, resources or opportunities between people.', 'The reforms aimed to reduce inequality in education.', 'Noun', plural='inequalities')
],
[
m('Why did a negotiated settlement become more important?', ['The 1990 reforms had already provided equal access to land and housing.', 'Resistance, economic difficulties and international pressure increased the cost of apartheid.', 'The ANC had won a national election before Mandela’s release.'], 'B', 'Meanwhile, domestic resistance, economic difficulties and international pressure, including sanctions, increased the cost of maintaining apartheid.', 'The change developed through several pressures, not one leader’s decision alone.'),
m('Which description best matches the years between 1990 and 1994?', ['Mandela’s release was immediately followed by his inauguration.', 'Talks involved only Mandela and de Klerk and proceeded without interruption.', 'Many political groups negotiated amid disagreements and continuing violence.'], 'C', 'Talks broke down at times, while killings and political violence threatened the process.', 'The preceding sentences identify several participants and disagreements over the future state.'),
m('What did the 1994 election achieve, according to the story?', ['It established a democratic national mandate while major social inequalities remained.', 'It completed the final constitution before Mandela became president.', 'It removed the need for a government involving more than one party.'], 'A', 'In April 1994, South Africa held its first democratic national election open to all races.', 'Later paragraphs distinguish democratic rights from the remaining social and economic damage.'),
g('Mandela was released on February 11, ___.', '1990', 'In February 1990, President F. W. de Klerk lifted bans on the ANC and other organizations.', 'The following sentence gives February 11 as Mandela’s release date in the same month and year.'),
g('The ___ won a majority in the April 1994 election.', 'ANC', 'The ANC won a majority.', 'The African National Congress then participated in a government of national unity.'),
g('Mandela signed the final constitution in ___.', '1996', 'Work on a final constitution continued, and Mandela signed it in 1996.', 'The final constitution followed the election held under an interim constitution.')
],
[
'South African Government, History — Apartheid and resistance, domestic and international pressure, April 1994 election under an interim constitution and national unity government; erroneous Youth League date not used: https://www.gov.za/about-sa/history',
'Nelson Mandela Foundation, Biography of Nelson Mandela — ANC leadership and armed struggle, 1962 arrest, 1964 life sentence, imprisonment in several places, February 11 1990 release and May 10 1994 inauguration: https://www.nelsonmandela.org/biography',
'Truth and Reconciliation Commission excerpts in the Nelson Mandela Foundation’s O’Malley Archives, Period following Mandela’s Release — Multiparty talks, breakdowns and escalating violence during 1990–1994; broad findings used rather than questionable fine chronology: https://omalley.nelsonmandela.org/index.php/site/q/03lv02167/04lv02264/05lv02335/06lv02336/07lv02340.htm',
'Constitutional Court of South Africa, Constitutional democracy 1994 onwards — Election, inauguration, Constitutional Assembly, final text and December 1996 signature: https://www.concourt.org.za/index.php/42-the-history-of-the-constitution/constitutional-democracy-1994-onwards',
'South African Government, Twenty Year Review 1994–2014, section What democratic South Africa inherited in 1994 — Historical inequalities in land, income, education, housing and services; not used as current conditions: https://www.gov.za/sites/default/files/gcis_document/201409/20yearreview.pdf'
],
[
'The subject is South Africa’s 1990–1994 democratic transition, not a full Mandela biography. Background establishes apartheid and a broad resistance movement; the narrative covers pressures, opening, violent and difficult multiparty talks, interim rules, election, unity government, constitutional follow-through and inherited inequalities.',
'Apartheid became National Party policy in 1948 but racial discrimination existed earlier. Black South Africans’ exclusion from national political power is distinguished from the rights of the ruling white minority.',
'Mandela’s imprisonment, release and inauguration are separate: about 27 years in several places, February 1990 release, April 1994 election and May 10 inauguration. The text does not put every prison year on Robben Island or call the whole resistance nonviolent.',
'No claim that the transition was wholly peaceful, inevitable or the achievement of Mandela alone. Several political groups participated and violence threatened the process.',
'The 1994 election used an interim constitution; the final constitution was signed in 1996. First democratic national election open to all races does not mean South Africa had never held an election.',
'Inherited inequalities are historically bounded to the transition and its tasks, not unsupported assertions about present-day government or conditions.',
'Compared with all 001–089 and the reserved candidates. This fulfills mandela-south-africa-democratic-transition-1990-1994 and remains distinct from 018’s Montgomery boycott, 070’s partition, 081’s Salt March and 082’s Rwanda genocide. Lincoln’s emancipation candidate remains reserved.'
])
