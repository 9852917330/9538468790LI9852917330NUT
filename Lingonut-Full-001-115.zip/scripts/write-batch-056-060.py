"""Source-reviewed, distinct-topic overviews for English Unicorn 056–060."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(56, 'hindenburg-airship-disaster-1937', 'Hindenburg 1937: An Airship Disaster and the End of an Era', 'Disasters and Safety',
      'A fire destroyed a German passenger airship during landing, causing deaths, investigations and a lasting loss of confidence in a form of international travel.',
'''During the 1930s, large passenger **airships** offered a way to cross the Atlantic in comfort. The German Hindenburg entered service in 1936. Its metal **framework** held gas cells filled with hydrogen, which was lighter than air. Engines moved it forward while the gas provided **lift**.

This design carried a serious risk. Hydrogen was **flammable**, so safe operation depended on keeping it away from sources of ignition. The giant aircraft combined impressive engineering and comfortable passenger spaces with a danger that could become catastrophic.

On May 3, 1937, Hindenburg left Frankfurt for Lakehurst, New Jersey. Headwinds slowed the crossing, and unsettled weather complicated the arrival. On May 6, it approached the naval air station with 97 people aboard, including passengers and crew.

As the airship prepared to land and lowered its **mooring** lines, fire appeared near the rear. Flames spread rapidly through the structure. Within seconds, the burning airship fell toward the ground, leaving people aboard and the ground team little time to react.

Some passengers and crew escaped as the structure descended. Ground workers and rescuers helped survivors away from the wreck. In total, 35 people aboard died, along with one worker on the ground. The other 62 people aboard survived, although many suffered injuries.

American and German investigators examined witness accounts, wreckage and possible causes. Both investigations considered leaking hydrogen mixed with air and electrical **ignition**. However, the exact cause of the first spark was not conclusively established. Later theories continued to be **debated**.

Photographs, newsreels and an eyewitness radio recording made the disaster internationally famous. Reporter Herbert Morrison recorded events at the scene; parts of his account were first **broadcast** the following day. These records made the speed and human cost of the fire visible far beyond Lakehurst.

The disaster severely damaged public **confidence** in passenger airships and helped end their commercial era. Smaller airships continued in other roles. Hindenburg's history became a lasting example of how technical risk, public trust and vivid reporting can shape the future of a technology.''',
[
v('airship', 'A powered aircraft supported in the air by a large container of gas lighter than air.', 'The airship crossed the coast at a low speed.', 'Noun', form='airships', plural='airships'),
v('framework', 'A supporting structure that holds the parts of something together.', 'The damaged framework could no longer support the roof.', 'Noun', plural='frameworks'),
v('lift', 'The upward force that supports an aircraft in the air.', 'The gas provided enough lift to support the airship.', 'Uncountable noun'),
v('flammable', 'Able to catch fire and burn easily.', 'Flammable materials must be kept away from ignition sources.', 'Adjective'),
v('mooring', 'The process of securing a ship or airship to a fixed place.', 'Strong winds complicated the mooring operation.', 'Uncountable noun'),
v('ignition', 'The process of starting a fire or causing something to burn.', 'Investigators examined several possible sources of ignition.', 'Uncountable noun'),
v('debate', 'To discuss or examine a question on which people disagree.', 'Researchers continue to debate the cause of the accident.', 'Verb', form='debated', verb=('debate','debated','debated',False)),
v('broadcast', 'To transmit a programme or information by radio, television or another electronic medium.', 'The station will broadcast the interview tomorrow.', 'Verb', verb=('broadcast','broadcast','broadcast',True)),
v('confidence', 'Trust or belief that someone or something is reliable or capable.', 'The investigation helped restore public confidence in the service.', 'Uncountable noun')
],
[
m('Why did hydrogen create a serious operating risk?', ['It could burn if it met a source of ignition.', 'It prevented the engines from moving the airship.', 'It made every Atlantic crossing impossible.'], 'A', 'Hydrogen was flammable, so safe operation depended on keeping it away from sources of ignition.', 'The lifting gas could burn, making control of ignition sources important.'),
m('What did investigators establish about the first spark?', ['They proved that sabotage was the only possible explanation.', 'Its exact cause was not conclusively established.', 'They found that no fire had occurred.'], 'B', 'However, the exact cause of the first spark was not conclusively established.', 'The account distinguishes likely involvement of hydrogen and electricity from certainty about the initiating event.'),
m('What was a wider consequence of the disaster?', ['All forms of air travel stopped permanently.', 'Passenger airships immediately became more popular.', 'Public confidence in passenger airships was severely damaged.'], 'C', 'The disaster severely damaged public confidence in passenger airships and helped end their commercial era.', 'The consequences extended beyond the destroyed aircraft to the future of passenger airship travel.'),
g('Hindenburg began service in ___.', '1936', 'The German Hindenburg entered service in 1936.', 'The disaster occurred the following year, rather than on its first flight.'),
g('There were ___ people aboard during the disaster.', '97', 'On May 6, it approached the naval air station with 97 people aboard, including passengers and crew.', '97 includes both passengers and crew.'),
g('The recorded radio report was first broadcast the following ___.', 'day', 'Reporter Herbert Morrison recorded events at the scene; parts of his account were first broadcast the following day.', 'The recording was not a live broadcast from the landing field.')
],
[
'National Archives, original eyewitness recording exhibit — May 6 landing, 97 aboard, 35 onboard deaths plus one ground worker, 62 survivors and next-day broadcast: https://www.archives.gov/exhibits/eyewitness/html.php?section=5',
'Civil Aeronautics Authority, 1938 compilation of American and German inquiries — Voyage, structure, hydrogen, fire sequence and uncertainty about electrical ignition, especially PDF pages 22–23: https://rosap.ntl.bts.gov/view/dot/81236/dot_81236_DS1.pdf',
'National Air and Space Museum, May 6, 2022 — Passenger-airship context, engineering and aftermath; primary museum article indexed, full retrieval blocked: https://airandspace.si.edu/stories/editorial/aftermath-hindenburg',
'U.S. Census Bureau historical account — Passenger service and disaster context: https://www.census.gov/about/history/stories/monthly/2022/may-2024.html'
],
[
'Whole-event overview covers passenger-airship context and mechanism, journey, landing fire, escape and casualties, investigation, reporting and commercial legacy.',
'35 deaths aboard plus one ground worker equals 36 overall; 62 of the 97 aboard survived. No claim that everyone aboard died, that this was a maiden flight or that it was the deadliest airship accident.',
'Hydrogen involvement and electrical-ignition hypotheses are distinguished from a conclusively known first spark. Sabotage, lightning and skin-coating theories are not presented as proven.',
'The eyewitness report was recorded and first aired the next day. No dramatic quotation or graphic account is reproduced.',
'Compared with all 001–055 and the remaining candidates; this 1937 airship event is distinct from earlier aircraft disasters. Identity and aliases registered in content/topics.json.'
])

draft(57, 'deepwater-horizon-oil-spill-2010', 'Deepwater Horizon: Explosion, Oil Spill and Recovery', 'Environment and Accountability',
      'A drilling accident killed workers and released oil into the sea, leading to a major response, damage to coastal life and years of investigation and restoration.',
'''On April 20, 2010, the Deepwater Horizon drilling **rig** was working at the Macondo well off Louisiana in the Gulf of Mexico. Transocean owned the rig, while BP directed the well project. Crews were preparing to secure the well temporarily after drilling.

Several layers of protection failed. A cement **barrier** did not stop oil and gas entering the well, and pressure-test results were misinterpreted. Gas rose to the rig and ignited. Explosions and fire killed 11 workers, while others escaped or were rescued.

An emergency device on the seabed, the blowout preventer, failed to **seal** the well. The rig sank on April 22, but the disaster continued below the surface. Oil escaped from the damaged well into the surrounding sea for weeks.

Engineers attempted several ways to control the **leak**, while responders worked across a huge area. Ships collected oil, floating barriers protected parts of the shore, and controlled burning removed some oil at the surface. Chemical **dispersants** broke oil into smaller droplets, with their use also requiring scientific assessment.

The spill harmed wildlife and **habitats**, including coastal wetlands and areas beneath the surface. Fishing restrictions and polluted beaches affected **livelihoods**. Families and businesses connected with fishing and tourism faced disruption even when they were far from the original drilling site.

On July 15, a new cap stopped the oil release after 87 days. This was an important breakthrough, but permanent closure required further work. On September 19, officials confirmed that the well had been permanently sealed with cement.

Investigations identified technical failures alongside weaknesses in management, risk assessment and safety culture. The disaster led to legal settlements, funding for environmental **restoration** and changes to drilling rules and **oversight**. Its causes could not be explained simply by one broken piece of equipment.

Stopping the flow did not repair all the damage. Scientists assessed injuries to natural resources, while long recovery projects addressed affected ecosystems and communities. Deepwater Horizon showed how failures at an industrial site could connect worker safety, marine life and the economic security of an entire coastal region.''',
[
v('rig', 'A large structure with equipment used for drilling into the ground or seabed.', 'The drilling rig operated far from the coast.', 'Noun', plural='rigs'),
v('barrier', 'Something intended to prevent movement, danger or an unwanted event.', 'The safety barrier was designed to prevent a release.', 'Noun', plural='barriers'),
v('seal', 'To close something tightly so that gas or liquid cannot pass through.', 'Engineers worked to seal the damaged well.', 'Verb', verb=('seal','sealed','sealed',False)),
v('leak', 'The unintended escape of liquid or gas through a hole or opening.', 'The crew reported a leak in the pipe.', 'Noun', plural='leaks'),
v('dispersant', 'A chemical used to break a substance such as oil into smaller droplets.', 'Responders assessed the effects of the dispersant.', 'Noun', form='dispersants', plural='dispersants'),
v('habitat', 'The natural environment in which a plant or animal lives.', 'The wetland is an important habitat for birds.', 'Noun', form='habitats', plural='habitats'),
v('livelihood', 'The means by which a person earns the money needed to live.', 'Fishing provided a livelihood for many families.', 'Noun', form='livelihoods', plural='livelihoods'),
v('restoration', 'The process of repairing damage and helping something return to a healthier or earlier condition.', 'The project supported the restoration of coastal wetlands.', 'Uncountable noun'),
v('oversight', 'The supervision of an activity to check that it is managed properly.', 'The inquiry called for stronger safety oversight.', 'Uncountable noun')
],
[
m('Why did the disaster continue after the rig sank?', ['The oil had already been permanently sealed underground.', 'The well continued releasing oil beneath the sea.', 'All the pollution came from beaches rather than the well.'], 'B', 'Oil escaped from the damaged well into the surrounding sea for weeks.', 'The loss of the rig did not close the source of the oil release.'),
m('How did the spill affect coastal communities?', ['It disrupted fishing, tourism and related livelihoods.', 'Its effects were limited to the original rig workers.', 'Fishing restrictions immediately increased every business’s income.'], 'A', 'Fishing restrictions and polluted beaches affected livelihoods.', 'The following sentence connects disruption with fishing and tourism businesses.'),
m('What did investigations reveal?', ['Only the weather contributed to the disaster.', 'The presence of an emergency device guaranteed a safe outcome.', 'Technical failures were connected with wider management and safety weaknesses.'], 'C', 'Investigations identified technical failures alongside weaknesses in management, risk assessment and safety culture.', 'The account treats the disaster as a chain of failures rather than one isolated defect.'),
g('The explosions and fire killed ___ workers.', '11', 'Explosions and fire killed 11 workers, while others escaped or were rescued.', 'The human losses preceded the long environmental response.'),
g('The new cap stopped the oil release on July ___.', '15', 'On July 15, a new cap stopped the oil release after 87 days.', 'July 15 marks stopping the release, rather than permanent sealing.'),
g('Permanent sealing was confirmed on September ___.', '19', 'On September 19, officials confirmed that the well had been permanently sealed with cement.', 'Permanent sealing followed the July capping operation.')
],
[
'NOAA original response timeline — April 20 explosion, April 22 sinking, response methods, July 15 capping and September 19 sealing: https://response.restoration.noaa.gov/timelines/deepwater-horizon-oil-spill',
'DOI/USCG, September 2011 investigation, Volume II — Ownership, project oversight, cement failure, pressure tests and sequence: https://www.bsee.gov/sites/bsee.gov/files/2024-12/DWH%20DOI%20Vol%20II%20Final.pdf',
'U.S. Chemical Safety Board, June 2014 investigation findings — Emergency device failed to seal; shear ram likely activated but could not seal buckled pipe: https://www.csb.gov/csb-board-approves-final-report-finding-deepwater-horizon-blowout-preventer-failed-due-to-unrecognized-pipe-buckling-phenomenon-during-emergency-well-control-efforts-on-april-20-2010-leading-to-environmental-disaster-in-gulf-of-mexico/',
'NOAA damage assessment — Wildlife and habitat injuries: https://darrp.noaa.gov/node/212',
'NOAA coastal education — Fishing, recreation, tourism and community effects: https://oceanservice.noaa.gov/education/tutorial-coastal/oil-spills/os05.html',
'BSEE historical safety reforms — Management and regulatory changes following the disaster: https://www.bsee.gov/sites/bsee.gov/files/5-yr-dwh-fact-sheet.pdf',
'Department of the Interior, April 4, 2016 — Settlement and natural-resource restoration funding: https://www.doi.gov/restoration/historic-nrdar-settlement-reached-deepwater-horizon-spill'
],
[
'Overview includes purpose and setting, failure chain, worker deaths, continued release, response, ecological and livelihood damage, capping, permanent closure, investigations and recovery.',
'Explosion on April 20 and sinking on April 22 are separate; July 15 stopped the release, whereas September 19 confirmed permanent sealing. No disputed discharge-volume estimate.',
'Failed to seal avoids the inaccurate simplification that the blowout preventer never activated. No operating instructions or unsupported single-cause explanation.',
'Response methods are described historically, without claiming dispersants removed all harm or were harmless. Reforms are described as historical changes rather than a claim about current rules.',
'Compared with all 001–056 and the other candidates; distinct from Bhopal, Chernobyl and other industrial accidents. Identity and aliases registered in content/topics.json.'
])

draft(58, 'db-cooper-hijacking-1971', 'D. B. Cooper: A Hijacking and an Unsolved Disappearance', 'Mysteries and Evidence',
      'An airline hijacker received ransom money and disappeared after leaving the aircraft, beginning a long investigation that never established his identity or fate.',
'''On November 24, 1971, a man using the **alias** Dan Cooper bought a ticket for Northwest Orient Flight 305. It was a short journey from Portland, Oregon, to Seattle, Washington. A mistake in press reporting later made him widely known as D. B. Cooper.

During the flight, he told a flight attendant that he had a bomb. The threat turned an ordinary passenger journey into a **hijacking**. He demanded 200,000 dollars and parachutes, while the crew communicated with people on the ground and worked to keep those aboard safe.

After the aircraft landed in Seattle, the money and parachutes were delivered. Cooper released the 36 passengers but kept several crew members aboard. The plane took off again. During this second flight, he jumped from the aircraft with a **parachute** and the **ransom** money.

The crew later landed safely, but Cooper disappeared. Investigators could establish that the crime had happened without knowing whether he survived the jump. Searches and later claims produced possible explanations, but no confirmed account of what happened to him afterward.

The FBI named its investigation NORJAK, short for Northwest Hijacking. Agents interviewed **witnesses**, examined objects left on the aircraft and followed **leads** across the country. A tie later provided a DNA sample. Many **suspects** were considered, yet none was established as the hijacker.

In 1980, a boy found damaged banknotes beside the Columbia River. Their **serial numbers** matched some of the ransom money, linking the discovery to the crime. The recovered 5,800 dollars became important physical evidence, but did not settle Cooper's identity or fate.

In July 2016, the FBI announced that it had redirected resources to other investigative priorities after decades of work. It preserved the evidence and said that specific new material connected with the parachutes or money could still be reported.

The case became famous because a documented crime ended with unanswered questions. Its **uncertainty** encouraged stories and speculation. The difference between a plausible theory and a supported conclusion remained central to understanding the disappearance.''',
[
v('alias', 'A name used by a person instead of their real name.', 'The suspect booked the room under an alias.', 'Noun', plural='aliases'),
v('hijacking', 'The unlawful seizure and control of a vehicle, especially an aircraft.', 'The crew reported the hijacking to authorities.', 'Noun', plural='hijackings'),
v('parachute', 'A device that opens into a large canopy to slow a fall through the air.', 'The rescue team checked each parachute before training.', 'Noun', plural='parachutes'),
v('ransom', 'Money demanded in exchange for releasing a captive or ending a threat.', 'The authorities recorded the ransom demand.', 'Noun', plural='ransoms'),
v('witness', 'A person who sees an event and can describe what happened.', 'The witness gave a statement to investigators.', 'Noun', form='witnesses', plural='witnesses'),
v('lead', 'A piece of information that may help an investigation move forward.', 'The new lead gave investigators another person to interview.', 'Noun', form='leads', plural='leads'),
v('suspect', 'A person believed possibly to have committed a crime.', 'Investigators compared the suspect’s account with the evidence.', 'Noun', form='suspects', plural='suspects'),
v('serial number', 'A number used to identify a particular item among others of the same kind.', 'The serial number identified the recovered banknote.', 'Noun phrase', form='serial numbers', plural='serial numbers'),
v('uncertainty', 'A lack of definite knowledge about something.', 'Uncertainty remained about the aircraft’s final position.', 'Uncountable noun')
],
[
m('What happened after Cooper received the money in Seattle?', ['The passengers remained aboard throughout every later flight.', 'He released the passengers but kept several crew members aboard.', 'He immediately surrendered to investigators.'], 'B', 'Cooper released the 36 passengers but kept several crew members aboard.', 'The account distinguishes the released passengers from the crew who continued on the second flight.'),
m('What did the banknotes found in 1980 establish?', ['They identified the hijacker beyond doubt.', 'They proved that he was still alive in 1980.', 'Their serial numbers connected them with the ransom money.'], 'C', 'Their serial numbers matched some of the ransom money, linking the discovery to the crime.', 'The money was genuine evidence of the crime, but it did not settle identity or survival.'),
m('What did the FBI’s 2016 announcement mean?', ['Resources moved to other priorities, while evidence was preserved and certain new material could still be reported.', 'The hijacker had been conclusively identified.', 'Every possible future discovery had been declared irrelevant.'], 'A', 'It preserved the evidence and said that specific new material connected with the parachutes or money could still be reported.', 'Reassigning investigative resources did not resolve the mystery or rule out all future physical evidence.'),
g('Flight 305 travelled from Portland to ___.', 'Seattle', 'It was a short journey from Portland, Oregon, to Seattle, Washington.', 'Seattle was the original destination.'),
g('Cooper released ___ passengers in Seattle.', '36', 'Cooper released the 36 passengers but kept several crew members aboard.', 'The crew remained after the passengers were released.'),
g('The banknotes were found in ___.', '1980', 'In 1980, a boy found damaged banknotes beside the Columbia River.', 'The discovery came years after the 1971 hijacking.')
],
[
'FBI current case history — 1971 route, threat, payment, passenger release, disappearance, investigation and uncertainty: https://www.fbi.gov/history/cases-and-criminals/db-cooper-hijacking',
'FBI original ticket artifact — Dan Cooper alias and Flight 305 ticket: https://www.fbi.gov/history/artifacts/d-b-cooper-plane-ticket',
'FBI, July 12, 2016 announcement — July 8 resource reassignment, preserved evidence and possible new physical evidence: https://www.fbi.gov/contact-us/field-offices/seattle/news/press-releases/update-on-investigation-of-1971-hijacking-by-d.b.-cooper',
'FBI, March 2009 archive account — Reporting error in the name, recovered money and evidence limits: https://archives.fbi.gov/archives/news/stories/2009/march/in-search-of-d.b.-cooper'
],
[
'Whole-event overview covers the original flight and alias, threat, passengers and crew, payment, disappearance, evidence and searches, recovered banknotes, 2016 resource decision and unresolved outcome.',
'The explosive device remains Cooper’s claim. No bomb construction, escape settings, aircraft procedures or tactical hijacking instructions.',
'No suspect is declared guilty, no survival or death theory is presented as fact, and a DNA sample is not confused with identification.',
'The FBI’s 2016 resource decision is dated and distinguished from solving the case or refusing all possible future evidence. Ransom evidence is not proof of survival.',
'Compared with all 001–057 and the remaining candidates; distinct from Alcatraz and MH370. Identity and aliases registered in content/topics.json.'
])

draft(59, 'berlin-blockade-airlift-1948-1949', 'The Berlin Airlift: Supplying a City Under Blockade', 'History and Cooperation',
      'When Soviet restrictions cut normal supply routes into western Berlin, a large air operation sustained the city and became a defining early Cold War crisis.',
'''After World War II, the United States, Britain, France and the Soviet Union occupied Germany. Berlin was also divided into four **sectors**, although the city lay deep inside the Soviet occupation zone. The Western Allies controlled its western areas and needed routes through surrounding territory to supply them.

Relations between the former allies deteriorated. They disagreed about Germany's political and economic future. Western plans to organize their zones more closely, together with changes to the **currency** in 1948, deepened the conflict.

On June 24, Soviet authorities imposed a **blockade** on the main road, railway and water routes into western Berlin. Normal deliveries of food, coal and other necessities were cut off. Around two million residents faced **shortages**, and the Western powers had to choose how to respond.

Agreed air **corridors** remained available. The United States began supply flights on June 26, and Britain joined shortly afterward. The American operation was called Vittles; the British operation became known as Plainfare. Their aircraft carried essential goods from western Germany into the city.

Supplying a large population by air required far more than individual flights. Crews followed coordinated schedules, unloaded **cargo** quickly and maintained aircraft for repeated journeys. More and larger planes increased capacity. German workers helped expand airport **infrastructure**, including the new airfield at Tegel in the French sector.

Coal was especially important for heating and electricity. Bad weather, winter conditions and heavy workloads made the operation difficult and dangerous. The growing airlift nevertheless demonstrated that the city could continue receiving supplies without an armed attempt to force open the land routes.

On May 12, 1949, the Soviet Union lifted the blockade. Land access reopened, but flights continued to build **reserves**. American supply flights lasted until September 30, months after the immediate crisis had ended.

The airlift delivered more than two million tons of supplies. It strengthened Western cooperation and became a symbol of **resolve** during the early Cold War. For Berliners, an international political confrontation had also become a daily effort to keep homes, hospitals and businesses functioning.''',
[
v('sector', 'A distinct part of an area, activity or organization.', 'Each occupying power controlled a sector of the city.', 'Noun', form='sectors', plural='sectors'),
v('currency', 'The money used in a particular country or economic area.', 'The authorities introduced a new currency.', 'Noun', plural='currencies'),
v('blockade', 'An action that prevents people or supplies from entering or leaving an area.', 'The blockade interrupted ordinary deliveries.', 'Noun', plural='blockades'),
v('shortage', 'A situation in which there is not enough of something that people need.', 'The city faced a serious shortage of fuel.', 'Noun', form='shortages', plural='shortages'),
v('corridor', 'An agreed or defined route through an area, including airspace.', 'The aircraft followed an approved air corridor.', 'Noun', form='corridors', plural='corridors'),
v('cargo', 'Goods carried by a ship, aircraft or other vehicle.', 'Workers unloaded the cargo before the next flight.', 'Noun', plural='cargoes'),
v('infrastructure', 'The basic facilities and systems needed for a place or activity to function.', 'The project improved the region’s transport infrastructure.', 'Uncountable noun'),
v('reserve', 'A supply kept for use when it is needed later.', 'The hospital kept a reserve of essential equipment.', 'Noun', form='reserves', plural='reserves'),
v('resolve', 'Strong determination to continue with a decision or purpose.', 'The community showed resolve during the crisis.', 'Uncountable noun')
],
[
m('Why was western Berlin vulnerable to restrictions on land access?', ['It lay on an island with no surrounding territory.', 'It had no connection with the Western Allies.', 'It was inside the Soviet occupation zone, while Western powers controlled its western sectors.'], 'C', 'Berlin was also divided into four sectors, although the city lay deep inside the Soviet occupation zone.', 'The city’s geography and occupation arrangements made access a central problem.'),
m('What made the airlift capable of supplying a large city?', ['Coordinated flights, rapid unloading, more aircraft and improved airport infrastructure.', 'A single flight that brought all supplies for the entire year.', 'The permanent closure of every airport.'], 'A', 'Crews followed coordinated schedules, unloaded cargo quickly and maintained aircraft for repeated journeys.', 'The following sentences add larger capacity and expanded airports to the coordinated operation.'),
m('Why did supply flights continue after the blockade ended?', ['The blockade had secretly remained unchanged forever.', 'The Allies wanted to build reserves after land access reopened.', 'All land routes had disappeared from the map.'], 'B', 'Land access reopened, but flights continued to build reserves.', 'Ending the immediate restrictions did not remove the reason to build a safety margin of supplies.'),
g('The United States began supply flights on June ___.', '26', 'The United States began supply flights on June 26, and Britain joined shortly afterward.', 'June 26 was the American operation’s starting date in 1948.'),
g('The blockade was lifted on May 12, ___.', '1949', 'On May 12, 1949, the Soviet Union lifted the blockade.', 'The blockade ended in May, before the later end of American supply flights.'),
g('___ was especially important for heating and electricity.', 'Coal', 'Coal was especially important for heating and electricity.', 'Fuel was a major part of the city’s supply needs.')
],
[
'U.S. State Department Office of the Historian — Occupation, location, political and currency conflict, June 24 blockade and June 26 American airlift: https://history.state.gov/milestones/1945-1952/berlin-airlift',
'U.S. Army, June 2023 engineering history — German workers and airport construction: https://www.army.mil/article/267744/engineering_the_worlds_most_famous_airlift_in_berlin_75_years_later',
'U.S. Air Force Historical Support Division — Supply operation, coordination, tonnage and American endpoint: https://www.afhistory.af.mil/FAQs/Fact-Sheets/Article/458961/1949-the-berlin-airlift/',
'Berlin Allied Museum — Occupation geography, currency context, supplies, Tegel, May 12 lifting and separate American/British endpoints: https://www.alliiertenmuseum.de/en/thema/the-berlin-airlift-1948-49/'
],
[
'Whole-event overview covers occupation geography, political and economic tensions, blockade and shortages, air access, logistics and German labor, winter difficulties, reopening, reserve-building and Cold War significance.',
'Manually compared with 004: the existing lesson concerns the 1961 border wall and 1989 opening. This lesson concerns the separate 1948–1949 blockade and supply operation; no retelling of the wall’s construction or fall.',
'May 12 lifting follows the established chronology and the State page introduction, rather than its inconsistent later May 11 line. June 26 is the American start; no claim that all Allied flights began that day.',
'September 30 is explicitly the American supply-flight endpoint. The Allied Museum separately dates the final RAF flight to October 6, so no claim that every Allied flight ended September 30.',
'Compared with all 001–058 and the DNA candidate. Identity and aliases registered in content/topics.json.'
])

draft(60, 'dna-double-helix-discovery-1953', 'The DNA Double Helix: Evidence, Discovery and Scientific Credit', 'Discoveries and Inventions',
      'Researchers combined chemical knowledge, X-ray evidence and model building to explain DNA’s structure, suggesting how genetic information could be copied.',
'''DNA is a **molecule** that carries **hereditary** information in living cells. Scientists knew it long before 1953, and earlier experiments linked it to the passing of biological characteristics between generations. However, its three-dimensional shape remained a major question.

At Cambridge University, James Watson and Francis Crick built models to investigate that question. Their work drew on other scientists' findings, including Erwin Chargaff's observation that DNA contained approximately equal amounts of A and T, and of C and G.

At King's College London, Rosalind Franklin and Raymond Gosling produced detailed X-ray **diffraction** patterns from DNA samples. Maurice Wilkins and colleagues also studied DNA using X-rays. These experiments provided important evidence about its shape and dimensions, including the image known as Photograph 51.

The resulting model resembled a twisted ladder. Two **strands** wound around each other, with sugar-phosphate **backbones** on the outside. Chemical bases formed pairs inside: A with T, and C with G. This **complementary** pairing connected chemistry with the information carried by DNA.

The structure also suggested a copying mechanism. If the strands separated, each could serve as a **template** for a new matching partner. More experiments were needed to test this proposed explanation of DNA **replication**, but the model opened a new way to investigate inheritance.

On April 25, 1953, Nature published three related papers. Watson and Crick described their model, while papers by Wilkins and colleagues and by Franklin and Gosling presented experimental findings.

The history also raised questions about permission and scientific **recognition**. Watson saw Photograph 51 without Franklin's knowledge, and some of her measurements were shared with the Cambridge researchers. Her experimental contribution was essential to the discovery, even though public accounts often centered on Watson and Crick.

Watson, Crick and Wilkins shared the 1962 Nobel Prize in Physiology or Medicine. Franklin had died in 1958. The discovery transformed biology by connecting molecular structure with the storage and copying of genetic information, while its history showed why evidence and fair credit both matter.''',
[
v('molecule', 'A group of atoms bonded together as a unit of a chemical substance.', 'The researchers studied the shape of the molecule.', 'Noun', plural='molecules'),
v('hereditary', 'Passed genetically from parents to their offspring.', 'Researchers investigated a hereditary condition in the family.', 'Adjective'),
v('diffraction', 'The spreading or bending of waves, which can produce patterns used to study the structure of materials.', 'The X-ray diffraction pattern gave clues about the sample’s structure.', 'Uncountable noun'),
v('strand', 'A single thin length of material, including one chain of a molecule such as DNA.', 'Each strand carried a sequence of chemical bases.', 'Noun', form='strands', plural='strands'),
v('backbone', 'A main supporting structure or chain.', 'The molecular backbone supported the attached chemical groups.', 'Noun', form='backbones', plural='backbones'),
v('complementary', 'Matching or working together because the parts have corresponding features.', 'The model showed how complementary bases could pair.', 'Adjective'),
v('template', 'A pattern or guide used to produce something else.', 'The existing strand acted as a template for a new one.', 'Noun', plural='templates'),
v('replication', 'The process of producing a copy, especially of genetic material.', 'The experiment tested how DNA replication takes place.', 'Uncountable noun'),
v('recognition', 'Acknowledgment of someone’s work, contribution or importance.', 'The research team received recognition for its discovery.', 'Uncountable noun')
],
[
m('What did the 1953 model explain?', ['The three-dimensional structure of a molecule that was already known.', 'The first discovery that any chemical substance could exist.', 'The complete sequence of every human genome.'], 'A', 'However, its three-dimensional shape remained a major question.', 'The account distinguishes discovering DNA’s structure from discovering DNA itself or later sequencing projects.'),
m('Why did complementary pairing matter?', ['It showed that DNA could not carry information.', 'It proved that earlier experiments were unnecessary.', 'It suggested how each strand could guide the formation of a matching new partner.'], 'C', 'If the strands separated, each could serve as a template for a new matching partner.', 'The structure suggested a copying mechanism that later experiments could test.'),
m('Which description best represents the discovery?', ['It resulted from one researcher working without any experimental evidence.', 'It combined model building, chemical findings and experimental work by several researchers.', 'Franklin and Gosling contributed no useful information.'], 'B', 'Their work drew on other scientists’ findings, including Erwin Chargaff’s observation that DNA contained approximately equal amounts of A and T, and of C and G.'.replace('’', "'"), 'The following paragraphs explain the experimental contributions of Franklin, Gosling, Wilkins and colleagues.'),
g('The three related Nature papers appeared in ___.', '1953', 'On April 25, 1953, Nature published three related papers.', '1953 marks publication of the structural model and related experimental findings.'),
g('Franklin and Gosling worked at King’s College ___.', 'London', "At King's College London, Rosalind Franklin and Raymond Gosling produced detailed X-ray diffraction patterns from DNA samples.", 'London identifies the institution’s location, distinct from the Cambridge model-building work.'),
g('Watson, Crick and Wilkins shared the Nobel Prize in ___.', '1962', 'Watson, Crick and Wilkins shared the 1962 Nobel Prize in Physiology or Medicine.', 'The Nobel award followed the 1953 papers; Franklin had died in 1958.')
],
[
'NHGRI 1953 timeline — Chargaff, chemical structure, model building, complementary bases, copying insight and Nobel recipients: https://www.genome.gov/25520255/online-education-kit-1953-dna-double-helix',
'NHGRI DNA fact sheet — Earlier identification of DNA, hereditary information, structure and copying: https://www.genome.gov/about-genomics/fact-sheets/Deoxyribonucleic-Acid-Fact-Sheet',
'King’s College London archive — Franklin, Gosling, Wilkins, Photograph 51 and three related Nature papers on April 25, 1953: https://www.kcl.ac.uk/discovering-the-structure-of-dna',
'U.S. National Library of Medicine, April 23, 2026 historical collection account — Models, experimental evidence, data sharing, credit and Franklin’s death: https://circulatingnow.nlm.nih.gov/2026/04/23/national-dna-day-reflecting-on-crick-and-watson/',
'Complete scans of the three original Nature papers, hosted by Memorial Sloan Kettering — Model and experimental publications: https://www.mskcc.org/teaser/1953-nature-papers-watson-crick-wilkins-franklin.pdf',
'Nobel Prize official 1962 award record — Watson, Crick and Wilkins; archive retrieval available through indexed official record: https://www.nobelprize.org/prizes/medicine/1962/summary/',
'King’s College London, October 9, 2026 archival research announcement — Franklin understood the significance of her helical evidence and deliberately improved an earlier image: https://www.kcl.ac.uk/news/rosalind-franklin-deliberately-created-photo-51-after-earlier-photograph-revealed-dnas-structure'
],
[
'Overview covers the existing molecule and heredity problem, model building and chemical findings, multiple experimental contributors, double-helix mechanism, copying insight, three publications, data-sharing issues, award and significance.',
'Manually compared with 034: this is the 1953 structural discovery and proposed copying mechanism, rather than the international 1990–2003 sequencing project. DNA itself was identified much earlier.',
'Photograph 51 and measurements are part of a broader evidence base, not a lone picture that solved everything. No claim Franklin failed to understand her evidence, received no acknowledgment in the original paper, or definitely would have won a Nobel Prize.',
'1962 Nobel recipients and Franklin’s 1958 death are stated without inventing an award counterfactual. Proposed copying is distinguished from later experimental confirmation.',
'Compared with all 001–059. Identity and aliases registered in content/topics.json.'
])
