"""Source-reviewed world events and discoveries for lessons 076–080."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(76, 'suez-crisis-1956', 'Suez 1956: Invasion, International Pressure and Withdrawal', 'World Events and Politics',
      'Egypt’s takeover of the Suez Canal Company led to a secret invasion plan, a war and international pressure that forced the attackers to withdraw.',
'''The Suez Canal in Egypt connects the Mediterranean Sea with the Red Sea. It provides a valuable shortcut for ships travelling between Europe and Asia. In 1956, control of this route became the center of an international crisis involving Egypt, Israel, Britain and France.

On July 26, Egyptian President Gamal Abdel Nasser **nationalized** the Suez Canal Company, which had British and French ownership. Western governments had recently withdrawn an offer to help finance Egypt's Aswan High Dam. Nasser intended to use canal **revenue** to support the project. For Egypt, taking control also asserted national **sovereignty** after decades of foreign influence.

Britain and France feared losing their position in the region. Israel regarded Egypt as a security threat amid border violence and restrictions on shipping. The three governments secretly agreed on a military plan against Egypt.

Israeli forces entered Egypt's Sinai Peninsula on October 29. Britain and France then issued an **ultimatum** demanding that the opposing armies pull back from the canal. Presenting themselves as outside powers protecting the waterway provided a **pretext** for intervention, although they had already coordinated with Israel.

British and French forces attacked from the air and landed troops. Egypt suffered military defeats, and fighting damaged communities around the canal. The **invasion** also disrupted the shipping route that the attackers claimed to protect.

International opposition changed the outcome. The United States opposed its allies' action and applied diplomatic and financial pressure. The Soviet Union also condemned the attack and issued threats. The United Nations called for a **ceasefire**, which Britain and France accepted on November 6.

British and French troops left in December. Israel completed its **withdrawal** by March 1957. A United Nations emergency force carried out **peacekeeping** duties. Egypt retained control of the canal, and Nasser remained in power.

The crisis weakened British and French influence and strengthened Nasser's standing in the Arab world. British Prime Minister Anthony Eden resigned in January 1957. Military advances had failed to secure the attackers' political aims, demonstrating how international pressure could limit the use of force.''',
[
v('nationalize', 'To transfer a privately owned business or industry into state ownership.', 'The government decided to nationalize the railway company.', 'Verb', form='nationalized', verb=('nationalize','nationalized','nationalized',False)),
v('revenue', 'Money received by a business, organization or government from its activities.', 'Canal fees provided revenue for the state.', 'Uncountable noun'),
v('sovereignty', 'The authority of a country to govern itself and control its own affairs.', 'The agreement recognized the country’s sovereignty.', 'Uncountable noun'),
v('ultimatum', 'A final demand that threatens serious consequences if it is not accepted.', 'The leaders rejected the ultimatum.', 'Noun', plural='ultimatums'),
v('pretext', 'A stated reason used to hide the real reason for an action.', 'The official used a safety inspection as a pretext to close the meeting.', 'Noun', plural='pretexts'),
v('invasion', 'The entry of armed forces into another territory to attack or take control.', 'The invasion caused widespread displacement.', 'Noun', plural='invasions'),
v('ceasefire', 'An agreement or order to stop fighting, often temporarily.', 'The two sides agreed to a ceasefire.', 'Noun', plural='ceasefires'),
v('withdrawal', 'The act of removing people, forces or support from a place or situation.', 'The withdrawal of troops took several weeks.', 'Noun', plural='withdrawals'),
v('peacekeeping', 'The work of helping maintain peace, especially through an international mission.', 'The international force carried out peacekeeping duties.', 'Uncountable noun')
],
[
m('Why did Nasser intend to use canal revenue?', ['To finance a new shipping route around Africa.', 'To support the Aswan High Dam project.', 'To pay for British and French control of Egypt.'], 'B', "Nasser intended to use canal revenue to support the project.", 'The previous sentence identifies the project as Egypt’s Aswan High Dam.'),
m('What explains Britain and France’s claim to be outside powers protecting the canal?', ['They had no previous contact with Israel.', 'They had been invited to take over Egypt’s government.', 'It was a pretext after they had secretly coordinated with Israel.'], 'C', 'Presenting themselves as outside powers protecting the waterway provided a pretext for intervention, although they had already coordinated with Israel.', 'Their public justification concealed their participation in the military plan.'),
m('Which description best matches the political outcome?', ['Egypt kept canal control despite military defeats, while British and French influence weakened.', 'Nasser lost power and the canal returned permanently to foreign ownership.', 'The attackers achieved every political aim without international opposition.'], 'A', "Egypt retained control of the canal, and Nasser remained in power.", 'The following paragraph describes weaker British and French influence and Nasser’s increased standing.'),
g('Nasser nationalized the canal company on July 26, ___.', '1956', 'In 1956, control of this route became the center of an international crisis involving Egypt, Israel, Britain and France.', 'The takeover and the invasion occurred during the same 1956 crisis.'),
g('The United States applied diplomatic and ___ pressure.', 'financial', "The United States opposed its allies' action and applied diplomatic and financial pressure.", 'American pressure contributed to the acceptance of a ceasefire.'),
g('Israel completed its withdrawal by ___ 1957.', 'March', 'Israel completed its withdrawal by March 1957.', 'British and French troops had already left in December 1956.')
],
[
'US Department of State, Office of the Historian, The Suez Crisis, 1956 — Nationalization, secret plan, October 29 invasion, American pressure and November 6 ceasefire: https://history.state.gov/milestones/1953-1960/suez',
'National Army Museum, Suez Crisis — Canal revenue and dam context, fighting, civilian damage, financial pressure and consequences: https://www.nam.ac.uk/explore/suez-crisis',
'United Nations, UNEF I background — British/French withdrawal in December 1956, Israeli withdrawal by March 1957 and peacekeeping role: https://peacekeeping.un.org/sites/default/files/past/unef1backgr1.html'
],
[
'Balanced overview covers the canal’s commercial and colonial background, dam financing, nationalization, the three-country plan, fighting, civilian disruption, international pressure, withdrawal and political consequences.',
'Egypt’s military defeats do not imply Nasser’s political removal. Egypt retained canal control; Britain and France did not achieve their central political aims.',
'The 1956 crisis is distinct from lesson 019’s Ever Given blockage in 2021 and lesson 067’s construction of the Panama Canal. All 001–075 and four reserved candidates were compared before assigning 076.',
'No speculative single-cause explanation for Eden’s resignation, precise disputed casualty figure or operational military instructions.'
])

draft(77, 'great-fire-london-1666', 'London 1666: The Great Fire and the Rebuilding of a City', 'Disasters and Recovery',
      'A bakery fire spread through London’s crowded streets, destroyed homes and landmarks, displaced thousands and changed the rules for rebuilding.',
'''Early on September 2, 1666, a fire began in Thomas Farriner's bakery on Pudding Lane in London. Its exact starting cause remains uncertain. Within days, it had destroyed much of the old City of London, a commercial center beside the River Thames.

A dry summer had left buildings vulnerable. Many houses were wooden and stood close together along narrow streets. Warehouses held oil, rope and other **combustible** goods. Strong winds carried flames between buildings, turning a local fire into a spreading disaster.

There was no organized fire brigade. Residents used buckets, simple pumps and hooks to pull down buildings. Officials were slow to respond decisively. As the emergency grew, soldiers helped **demolish** buildings to create gaps that could slow the flames. Weaker winds also helped bring the fire under control by its fourth day.

Meanwhile, families rushed to save their **possessions**. Some escaped in boats on the Thames; others carried belongings into fields beyond the city walls. Crowded streets made movement difficult. The **displaced** population needed food and temporary shelter after losing homes and workplaces.

The fire destroyed around 13,200 houses, 87 churches and the old St Paul's Cathedral. Tens of thousands were left homeless. Only a few deaths were recorded, although the true total is uncertain. For survivors, the destruction of businesses and property brought hardship long after the flames had gone.

Rebuilding required clearing **rubble** and resolving property disputes. New **regulations** required greater use of brick and stone. Plans for a completely redesigned city proved difficult to put into practice. Most streets and property boundaries followed their earlier pattern, while some roads became wider.

The **architect** Christopher Wren designed the new St Paul's Cathedral, whose dome became a major landmark. Much of the damaged city was rebuilt on its old **foundations**, combining familiar streets with changed buildings.

The disaster revealed how crowded construction, weather and limited emergency organization could combine to overwhelm a city. Its **aftermath** changed building practices and left a lasting mark on London's appearance and memory.''',
[
v('combustible', 'Able to catch fire and burn.', 'The warehouse stored combustible materials.', 'Adjective'),
v('demolish', 'To deliberately pull down or destroy a building.', 'Workers had to demolish the unsafe structure.', 'Verb', verb=('demolish','demolished','demolished',False)),
v('possession', 'Something that a person owns.', 'She packed her most valuable possessions into a bag.', 'Noun', form='possessions', plural='possessions'),
v('displaced', 'Forced to leave the place where one normally lives.', 'Displaced families needed temporary shelter.', 'Adjective'),
v('rubble', 'Broken pieces of stone, brick and other material left after buildings are destroyed.', 'Workers cleared rubble from the road.', 'Uncountable noun'),
v('regulation', 'An official rule governing an activity or situation.', 'The new regulation set safety standards for buildings.', 'Noun', form='regulations', plural='regulations'),
v('architect', 'A person who designs buildings.', 'The architect prepared plans for the new library.', 'Noun', plural='architects'),
v('foundation', 'The supporting structure beneath a building.', 'Engineers checked the foundations before work began.', 'Noun', form='foundations', plural='foundations', note='Often plural when referring to the base of a building.'),
v('aftermath', 'The period and consequences following a serious or damaging event.', 'Many families needed support in the aftermath of the storm.', 'Noun', note='Commonly used in the phrase “in the aftermath of”.')
],
[
m('Which conditions helped the fire spread?', ['Wet weather, wide streets and isolated stone houses.', 'Strong winds blowing across an empty city.', 'Dry conditions, closely packed wooden buildings and combustible goods.'], 'C', 'Warehouses held oil, rope and other combustible goods. Strong winds carried flames between buildings, turning a local fire into a spreading disaster.', 'The preceding sentences also describe a dry summer and wooden houses close together.'),
m('What did soldiers do to help slow the fire?', ['They demolished buildings to create gaps.', 'They moved every building to the river.', 'They rebuilt St Paul’s Cathedral during the fire.'], 'A', 'As the emergency grew, soldiers helped demolish buildings to create gaps that could slow the flames.', 'Removing buildings interrupted the continuous route available to the flames.'),
m('How was most of the damaged city rebuilt?', ['It was abandoned permanently after the disaster.', 'It followed much of the old street pattern, with changes to buildings and some roads.', 'It adopted a completely new street plan with no old property boundaries.'], 'B', 'Most streets and property boundaries followed their earlier pattern, while some roads became wider.', 'Large redesign plans were difficult to implement, so much of the earlier layout remained.'),
g('The fire began in a ___ on Pudding Lane.', 'bakery', "Early on September 2, 1666, a fire began in Thomas Farriner's bakery on Pudding Lane in London.", 'The starting location is known even though the exact cause is uncertain.'),
g('Some residents escaped in boats on the River ___.', 'Thames', 'Some escaped in boats on the Thames; others carried belongings into fields beyond the city walls.', 'Other residents escaped on foot to open ground.'),
g('New regulations required greater use of brick and ___.', 'stone', 'New regulations required greater use of brick and stone.', 'Rebuilding rules favored materials less vulnerable to fire than timber.')
],
[
'London Museum, The Great Fire of London — Start, spread, responses, destruction, recorded deaths and rebuilding: https://www.londonmuseum.org.uk/collections/london-stories/great-fire-of-london/',
'London Museum, Three myths about the Great Fire of London — No thatched-roof or plague-ending explanation; brick existed before the fire: https://www.londonmuseum.org.uk/collections/london-stories/myths-great-fire-london/',
'London Fire Brigade Museum, The Great Fire of London — Firefighting, escape and control by September 5; thatch generalization is corrected using London Museum: https://www.london-fire.gov.uk/museum/london-fire-brigade-history-and-stories/fires-and-incidents-that-changed-history/the-great-fire-of-london/'
],
[
'Overview follows the fire’s origin, interacting causes, firefighting and escape, destruction and displacement, rebuilding constraints and lasting changes. No single diarist or family dominates.',
'Distinguish the historic City of London from all of metropolitan London. Start is September 2; control by the fourth day avoids a falsely exact extinction time for every remaining fire.',
'Death records are incomplete. No assertion that exactly six people died or that the fire ended the plague. Avoid the thatched-roof myth and the false claim that London first used brick only after 1666.',
'Building demolition is described at historical overview level, with no explosive details or instructions.',
'Compared with every 001–076 identity and all reserved candidates. This urban fire is distinct from other disaster and cholera lessons; identity and alternative names are registered.'
])

draft(78, 'indian-ocean-earthquake-tsunami-2004', 'The Indian Ocean Tsunami of 2004: Disaster Across an Ocean', 'Disasters and Recovery',
      'An earthquake near Sumatra generated waves that devastated communities across the Indian Ocean and led to a regional warning system.',
'''On December 26, 2004, a magnitude 9.1 earthquake struck beneath the Indian Ocean near northern Sumatra, Indonesia. A long **rupture** between moving sections of Earth's crust lifted part of the **seabed**. The sudden movement pushed the water above it, generating a tsunami that travelled across the ocean.

Near the earthquake, communities had little time before the waves arrived. Indonesia's Aceh province suffered the greatest losses. The tsunami also devastated parts of Sri Lanka, India and Thailand, and reached distant shores in East Africa. Its effects crossed national borders within hours.

The tsunami arrived as a series of powerful **surges**, rather than one ordinary breaking wave. Water swept through settlements, carrying **debris** and destroying homes, boats, roads and public buildings. Coastal geography affected how far the water travelled inland and how high it rose.

Around 230,000 people died or went missing. Large numbers lost relatives and homes, while fishing and tourism communities lost their **livelihoods**. The disaster affected local residents and international visitors, but its deepest and longest burdens fell on the surviving communities.

The Indian Ocean had no coordinated regional tsunami **warning system** at the time. Many people did not recognize the danger. Even in places far from the earthquake, the waves reached populations without an effective alert. Scientific detection alone was insufficient without communication and public understanding.

An enormous international **relief** effort followed. Local survivors, national authorities, aid organizations and foreign governments provided food, water, medical care and shelter. Recovery also required rebuilding **infrastructure**, restoring income and supporting people separated from their families. Replacing buildings could not quickly repair every loss.

Countries worked with UNESCO to establish the Indian Ocean Tsunami Warning and Mitigation System in 2005. It became fully operational in 2011, linking monitoring equipment, regional centers and national authorities. Education and practice exercises also became important parts of **preparedness**.

The catastrophe changed how countries understood their shared exposure to ocean hazards. Its lasting lesson concerned the whole chain of protection: observing danger, communicating it and helping coastal communities prepare before another disaster.''',
[
v('rupture', 'A break or tear in something that was previously connected.', 'The earthquake caused a long rupture in the ground.', 'Noun', plural='ruptures'),
v('seabed', 'The ground at the bottom of the sea.', 'Scientists mapped changes in the seabed.', 'Noun', plural='seabeds'),
v('surge', 'A sudden, powerful forward movement or increase.', 'A surge of water flooded the harbor.', 'Noun', form='surges', plural='surges'),
v('debris', 'Scattered broken pieces left after something has been damaged or destroyed.', 'Rescue teams cleared debris from the street.', 'Uncountable noun'),
v('livelihood', 'The means by which a person earns money or obtains what is needed to live.', 'Fishing provided a livelihood for many families.', 'Noun', form='livelihoods', plural='livelihoods'),
v('warning system', 'An organized set of equipment and procedures used to detect danger and alert people.', 'The warning system connected monitoring stations with local authorities.', 'Noun phrase', plural='warning systems'),
v('relief', 'Help provided to people suffering because of a disaster or emergency.', 'Relief workers delivered food and clean water.', 'Uncountable noun'),
v('infrastructure', 'The basic physical systems and facilities that a community needs to function.', 'The storm damaged transport infrastructure.', 'Uncountable noun'),
v('preparedness', 'The state of being ready to respond to a possible event or emergency.', 'Regular exercises improved community preparedness.', 'Uncountable noun')
],
[
m('How did the earthquake generate the tsunami?', ['It lifted part of the seabed and suddenly moved the water above it.', 'It created a storm that blew waves across the ocean.', 'It caused a volcanic eruption on every affected coast.'], 'A', 'The sudden movement pushed the water above it, generating a tsunami that travelled across the ocean.', 'The preceding sentence identifies the seabed movement caused by the earthquake.'),
m('Why were many distant communities also caught without an effective alert?', ['The tsunami affected only the earthquake’s immediate surroundings.', 'The Indian Ocean lacked a coordinated regional warning system.', 'Every national authority received an alert but refused all assistance.'], 'B', 'The Indian Ocean had no coordinated regional tsunami warning system at the time.', 'Distance from the earthquake did not ensure that a warning reached the population.'),
m('What did long-term recovery require besides replacing buildings?', ['Ending all coastal employment permanently.', 'Using monitoring equipment without any public communication.', 'Restoring livelihoods, public systems and support for affected families.'], 'C', 'Recovery also required rebuilding infrastructure, restoring income and supporting people separated from their families.', 'The recovery effort addressed the wider needs of surviving communities.'),
g('The earthquake struck near northern ___, Indonesia.', 'Sumatra', 'On December 26, 2004, a magnitude 9.1 earthquake struck beneath the Indian Ocean near northern Sumatra, Indonesia.', 'The tsunami began near Sumatra before spreading across the ocean.'),
g('The tsunami arrived as a ___ of powerful surges.', 'series', 'The tsunami arrived as a series of powerful surges, rather than one ordinary breaking wave.', 'The event involved repeated powerful movements of water.'),
g('The regional warning system became fully operational in ___.', '2011', 'It became fully operational in 2011, linking monitoring equipment, regional centers and national authorities.', 'The system had been established in 2005 before reaching full operation.')
],
[
'US Geological Survey EROS, 2004 Indian Ocean Tsunami — December 26, magnitude 9.1, Sumatra and seabed uplift: https://eros.usgs.gov/media-gallery/image-of-the-week/2004-indian-ocean-tsunami',
'NOAA, JetStream Max: 2004 Indian Ocean Tsunami — Basin-wide effects, mechanism, approximate dead-or-missing toll, impacts and communication gaps: https://www.noaa.gov/jetstream/2004tsu_max',
'UNESCO, Ten years after the 2004 tsunami — Regional system established 2005, fully operational 2011, monitoring, communication and public preparedness: https://www.unesco.org/en/articles/ten-years-after-2004-tsunami-indian-ocean-better-prepared-avert-disaster-1',
'UNHCR, December 29, 2004, response to Asian tsunami catastrophe — Contemporary relief supplies and shelter response: https://www.unhcr.org/us/news/stories/unhcr-steps-response-asian-tsunami-catastrophe'
],
[
'Full-event overview includes tectonic cause and water displacement, regional sequence, multiple waves, human and livelihood losses, the warning gap, relief and recovery, and the subsequent regional warning system.',
'The rounded toll is about 230,000 dead or missing, not an exact death count. Official summaries differ slightly in totals and country definitions; no falsely precise list or one universal wave height is used.',
'System establishment in 2005 is distinct from full operation in 2011. The story does not imply that detection guarantees successful community alerts or that technological improvements remove all risk.',
'Historical description, without a sensational individual tragedy or emergency response instructions.',
'Compared with every 001–077 topic and all reserved candidates. This earthquake-triggered basin-wide event is distinct from lesson 027’s Japan 2011 disaster and lesson 066’s volcanic Krakatoa event of 1883.'
])

draft(79, 'einstein-relativity-eclipse-test-1919', 'The 1919 Eclipse: Testing Einstein’s Theory of Gravity', 'Discoveries and Scientific Turning Points',
      'Astronomers photographed stars during a solar eclipse to test Einstein’s prediction that gravity bends light, producing evidence that changed physics and public attention.',
'''In 1915, Albert Einstein presented a new theory of gravity called general relativity. It described how matter **distorts** space and time. One consequence was that light passing near a massive object, such as the Sun, should follow a curved path.

This idea could be tested. Einstein **predicted** how much the Sun's gravity would bend light from distant stars. From Earth, those stars would appear slightly displaced from their usual positions. Normally, however, the Sun's brightness made nearby background stars impossible to photograph.

A total solar **eclipse** offered a brief opportunity. When the Moon covered the bright solar surface, astronomers could record the surrounding stars. British researchers organized **expeditions** to observe the eclipse of May 29, 1919, from two widely separated locations.

Frank Dyson coordinated the work from England. Arthur Eddington and Edwin Cottingham travelled to Príncipe, an island off West Africa. Charles Davidson and Andrew Crommelin observed from Sobral in Brazil. The experiment depended on several people, observing sites and sets of equipment.

The teams photographed the star field during the eclipse. They compared the stars' **apparent** positions with **reference** photographs taken when the Sun was elsewhere in the sky. A small difference could reveal how the light's path had changed near the Sun.

Conditions complicated the work. Clouds limited the usable photographs from Príncipe. At Sobral, one telescope produced **blurred** images. Researchers assessed which observations were reliable enough for comparison. The usable **measurements** supported the amount of bending predicted by Einstein.

The findings were announced in London on November 6, 1919, at a joint meeting of the Royal Society and the Royal Astronomical Society. Newspaper coverage soon made Einstein internationally famous. A difficult astronomical observation had brought an unfamiliar theory into public discussion.

The eclipse provided important evidence, while the theory remained open to further **scrutiny**. Later observations strengthened the evidence. The bending of light by gravity also became a tool for studying distant objects in space. The episode showed how a mathematical prediction could be tested through carefully planned observations.''',
[
v('distort', 'To change the shape or form of something from its usual state.', 'Heat can distort the shape of a metal part.', 'Verb', form='distorts', verb=('distort','distorted','distorted',False)),
v('predict', 'To state what is expected to happen, often using evidence or a theory.', 'The model can predict the planet’s position.', 'Verb', form='predicted', verb=('predict','predicted','predicted',False)),
v('eclipse', 'An event in which one object in space partly or completely blocks another from view or light.', 'The team photographed the stars during the solar eclipse.', 'Noun', plural='eclipses'),
v('expedition', 'An organized journey made for a particular purpose, such as exploration or research.', 'The expedition carried scientific instruments to the island.', 'Noun', form='expeditions', plural='expeditions'),
v('apparent', 'Seeming to be true or present as observed, although the underlying situation may differ.', 'The apparent position of the star changed as its light passed the Sun.', 'Adjective'),
v('reference', 'Something used as a standard or source for comparison.', 'The older photograph provided a reference for the new measurements.', 'Noun', plural='references', note='In “reference photograph”, the noun describes a photograph used for comparison.'),
v('blurred', 'Not clear or sharply defined.', 'The blurred image was difficult to measure.', 'Adjective'),
v('measurement', 'A value obtained by finding the size, amount or position of something.', 'The measurement showed a small change in position.', 'Noun', form='measurements', plural='measurements'),
v('scrutiny', 'Careful and detailed examination.', 'The findings received close scrutiny from other researchers.', 'Uncountable noun')
],
[
m('What prediction were the astronomers testing?', ['The Moon produces all of the Sun’s light.', 'Gravity near the Sun changes the path of starlight.', 'Stars physically move to new locations whenever an eclipse occurs.'], 'B', "Einstein predicted how much the Sun's gravity would bend light from distant stars.", 'The test concerned the bending of light, observed through a shift in apparent star positions.'),
m('How did the researchers look for the effect?', ['They compared the stars’ apparent positions in eclipse and reference photographs.', 'They watched the stars without recording their positions.', 'They measured only how long the Moon remained visible.'], 'A', "They compared the stars' apparent positions with reference photographs taken when the Sun was elsewhere in the sky.", 'Reference photographs provided a comparison for the small apparent shifts.'),
m('Which statement best describes the significance of the results?', ['The eclipse proved every part of relativity permanently and ended further tests.', 'The results were never announced outside the observing teams.', 'The results supported Einstein’s prediction, drew public attention and were followed by further testing.'], 'C', 'The eclipse provided important evidence, while the theory remained open to further scrutiny. Later observations strengthened the evidence.', 'The story also describes the announcement and newspaper coverage that made Einstein famous.'),
g('Einstein presented general relativity in ___.', '1915', 'In 1915, Albert Einstein presented a new theory of gravity called general relativity.', 'The eclipse test followed four years after the theory’s presentation.'),
g('Davidson and Crommelin observed from Sobral in ___.', 'Brazil', 'Charles Davidson and Andrew Crommelin observed from Sobral in Brazil.', 'The other observing team worked on Príncipe.'),
g('The results were announced in London on ___ 6, 1919.', 'November', 'The findings were announced in London on November 6, 1919, at a joint meeting of the Royal Society and the Royal Astronomical Society.', 'The public announcement followed the May observations and their analysis.')
],
[
'Royal Society, Observing general relativity — Archival account of theory, team roles, observation quality and the November 6 announcement: https://royalsociety.org/blog/2024/08/observing-relativity/',
'Royal Astronomical Society, World celebrates centenary of confirmation of relativity — May 29 eclipse, two observing sites, apparent displacement and public impact: https://ras.ac.uk/news-and-press/news/world-celebrates-centenary-confirmation-relativity',
'NASA, Hubble Gravitational Lenses — Curved spacetime, eclipse comparison, subsequent confirmations and gravitational lensing as an astronomical tool: https://science.nasa.gov/mission/hubble/science/science-behind-the-discoveries/hubble-gravitational-lenses/'
],
[
'Event-focused scientific turning point, fulfilling the reserved Einstein candidate through a prediction, measurement, analysis and public announcement rather than a full life story.',
'The Sun bends the light; the Moon briefly blocks the bright solar surface to permit observations. The stars’ apparent positions change, not their physical positions because of the eclipse.',
'Dyson coordinated from England; Eddington and Cottingham went to Príncipe, Davidson and Crommelin to Sobral. Credit is not confined to one astronomer. Einstein did not join either observing team.',
'Use the Royal Society’s documented November 6 meeting date, not a conflicting November 8 date in an ESA summary. May 29 is the observation date.',
'Clouds and blurred images constrained the data. The results supported the prediction; one observation did not prove every aspect of the theory forever. No unsupported fraud accusation or claim that all images were equally useful.',
'Compared with 001–078 and all reserved candidates. This owns the existing reserved eventKey einstein-relativity-eclipse-test-1919, which must move to completed after its individual publication. It is distinct from radioactivity, the DNA structure and other scientific topics.'
])

draft(80, 'antarctic-ozone-hole-discovery-and-montreal-protocol', 'The Ozone Hole: Discovery and a Global Response', 'Discoveries and the Environment',
      'Measurements over Antarctica revealed severe ozone loss, leading to stronger scientific investigation and an international agreement to phase out damaging chemicals.',
'''In May 1985, British Antarctic Survey scientists Joe Farman, Brian Gardiner and Jonathan Shanklin reported an alarming change above Antarctica. Measurements showed that the amount of ozone overhead fell sharply during the southern spring. Their findings revealed a major threat to the atmosphere's protective ozone layer.

High above Earth's surface, ozone absorbs much of the Sun's harmful **ultraviolet** radiation. Loss of this protection increases risks to human health and ecosystems. The expression “ozone hole” described severe **thinning** of the layer over Antarctica, rather than a completely empty opening.

The discovery built on earlier research. In 1974, Mario Molina and Sherwood Rowland had warned that chemicals called chlorofluorocarbons, or CFCs, could damage ozone. These chemicals had been widely used as **refrigerants** and in aerosol sprays. Their stability allowed them to survive long enough to reach the upper atmosphere.

There, strong sunlight breaks CFCs apart, releasing **chlorine**. Through repeated chemical reactions, chlorine can destroy many ozone molecules. Over Antarctica, extremely cold winter conditions create clouds high in the atmosphere that help prepare chlorine for rapid reactions. Returning spring sunlight drives the **seasonal** ozone loss.

The findings made the danger visible and urgent. Governments faced a problem that no country could solve alone: chemicals released in one region could eventually affect the shared atmosphere. Scientific investigation and diplomatic negotiations developed together.

In 1987, countries adopted the Montreal Protocol. The **treaty** entered into force in 1989 and established controls on ozone-depleting substances. Later changes strengthened the requirements and expanded the chemicals covered. The gradual **phaseout** required industries to change products and equipment, while international assistance helped countries make the transition.

Progress depended on **compliance** and continued research. Long-lived chemicals remained in the atmosphere after production declined, so recovery could not happen immediately. Ozone levels also varied with atmospheric conditions from year to year.

By 2026, scientific assessments reported a long-term recovery trend, with full recovery still expected to take decades. Continued **monitoring** remained essential. The ozone story showed how sustained measurements, public concern and international cooperation could turn evidence of global environmental damage into collective action.''',
[
v('ultraviolet', 'Describing radiation with wavelengths shorter than visible violet light.', 'Ultraviolet radiation can damage living tissue.', 'Adjective'),
v('thinning', 'A reduction in the thickness, density or amount of something.', 'Scientists measured the thinning of the protective layer.', 'Uncountable noun'),
v('refrigerant', 'A substance used in equipment that cools air or keeps things cold.', 'The cooling system used a different refrigerant.', 'Noun', form='refrigerants', plural='refrigerants'),
v('chlorine', 'A chemical element that can take part in reactions which destroy ozone in the upper atmosphere.', 'Chlorine compounds contributed to ozone loss.', 'Uncountable noun'),
v('seasonal', 'Happening or changing at a particular time of year.', 'The researchers recorded a seasonal change in the measurements.', 'Adjective'),
v('treaty', 'A formal agreement between countries.', 'Several countries signed the environmental treaty.', 'Noun', plural='treaties'),
v('phaseout', 'The gradual ending of the production or use of something.', 'The phaseout gave companies time to replace the old equipment.', 'Noun', plural='phaseouts'),
v('compliance', 'The act of following a law, rule or agreement.', 'Regular reports helped assess compliance with the treaty.', 'Uncountable noun'),
v('monitoring', 'The activity of observing and checking something over time.', 'Continued monitoring revealed a long-term trend.', 'Uncountable noun')
],
[
m('What did the Antarctic measurements reported in 1985 reveal?', ['Ozone had disappeared permanently from the entire atmosphere.', 'The Sun had stopped producing ultraviolet radiation.', 'Ozone overhead was falling sharply during the southern spring.'], 'C', 'Measurements showed that the amount of ozone overhead fell sharply during the southern spring.', 'The “hole” referred to severe seasonal thinning over Antarctica.'),
m('How did CFCs contribute to ozone loss?', ['Sunlight broke them apart in the upper atmosphere, releasing chlorine that destroyed ozone.', 'They immediately removed all oxygen from the air near factories.', 'They stopped sunlight from reaching Antarctica in summer.'], 'A', 'There, strong sunlight breaks CFCs apart, releasing chlorine. Through repeated chemical reactions, chlorine can destroy many ozone molecules.', 'The chemicals could survive long enough to reach the upper atmosphere before breaking apart.'),
m('Why did ozone recovery take time after controls were introduced?', ['The treaty required every country to increase CFC production.', 'Long-lived chemicals remained in the atmosphere, and recovery required continued action.', 'Monitoring ended as soon as the treaty was adopted.'], 'B', 'Long-lived chemicals remained in the atmosphere after production declined, so recovery could not happen immediately.', 'The story describes continued compliance, research and monitoring during a gradual recovery.'),
g('The Montreal Protocol was adopted in ___.', '1987', 'In 1987, countries adopted the Montreal Protocol.', 'The agreement entered into force two years later, in 1989.'),
g('The ozone layer absorbs much of the Sun’s harmful ___ radiation.', 'ultraviolet', "High above Earth's surface, ozone absorbs much of the Sun's harmful ultraviolet radiation.", 'Ozone loss weakens this protection for people and ecosystems.'),
g('Later changes to the treaty ___ its requirements.', 'strengthened', 'Later changes strengthened the requirements and expanded the chemicals covered.', 'The original agreement was followed by stronger and wider controls.')
],
[
'British Antarctic Survey, The Ozone Layer — Shared discovery, longstanding Antarctic observations and seasonal cloud chemistry: https://legacy.bas.ac.uk/bas_research/science_briefings/ozone_layer.php',
'British Antarctic Survey, The ozone hole discovery — Farman, Gardiner and Shanklin’s 1985 findings and significance: https://www.bas.ac.uk/about/history/ozone-hole-discovery/',
'NASA, World of Change: Antarctic Ozone Hole — CFC chemistry and the meaning of severe thinning; its outdated recovery projection is not used: https://science.nasa.gov/earth/earth-observatory/world-of-change/ozone-hole/',
'UNEP Ozone Secretariat, The Montreal Protocol — Adopted 1987, in force 1989, progressive controls and subsequent amendments: https://ozone.unep.org/treaties/montreal-protocol',
'World Meteorological Organization, September 16, 2026, ozone recovery successes and challenges — Current long-term recovery and remaining decades: https://wmo.int/media/news/wmo-bulletin-shows-successes-and-challenges-ozone-layer-recovery',
'Nobel Foundation, Mario J. Molina facts — Molina and Rowland’s 1974 CFC–ozone research: https://www.nobelprize.org/prizes/chemistry/1995/molina/facts/'
],
[
'Balanced discovery-to-response overview includes ozone’s protective role, shared discovery and earlier theory, CFC transport and chlorine chemistry, seasonal Antarctic conditions, treaty and later controls, industrial transition and incomplete recovery.',
'The ozone hole is severe thinning, not a literal empty opening. Winter cold prepares chemical conditions; returning southern spring sunlight drives rapid ozone destruction.',
'Credit includes Farman, Gardiner and Shanklin for the 1985 report and Molina and Rowland for the earlier 1974 warning. No individual alone discovered every element of the problem.',
'Montreal was adopted in 1987 and entered into force in 1989. It was strengthened over time, rather than imposing an immediate universal end to every chemical.',
'Current recovery statement checked against WMO’s September 16, 2026 update. Do not reuse the outdated Antarctic recovery-by-2040 sentence on NASA’s World of Change page; no specific recovery year is promised.',
'Ozone depletion is not presented as the cause of global surface warming. The related but distinct climate problem and Kigali amendment are outside this short event’s scope.',
'Compared with all 001–079 and the remaining reserved candidates. This discovery and international response is a distinct environmental event, not a second radioactivity or oil-spill lesson.'
])
