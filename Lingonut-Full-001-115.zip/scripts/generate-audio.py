"""Generate and validate matching Brian/Ava recordings for published lessons."""

import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path
import re
import ssl
import subprocess
import sys
import tempfile

import edge_tts

ROOT = Path(__file__).resolve().parent.parent


def use_environment_certificates():
    certificate_file = os.environ.get("SSL_CERT_FILE")
    if certificate_file and Path(certificate_file).is_file():
        # Respect an explicitly configured trust store, keeping TLS verification on.
        import edge_tts.communicate as communicate
        communicate._SSL_CTX = ssl.create_default_context(cafile=certificate_file)


async def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("lessons", nargs="*", type=int)
    parser.add_argument("--concurrency", type=int, default=3, choices=range(1, 7))
    args = parser.parse_args()
    use_environment_certificates()
    semaphore = asyncio.Semaphore(args.concurrency)
    selected = set(args.lessons)
    files = sorted((ROOT / "content/lessons").glob("*.json"))
    lessons = [json.loads(p.read_text()) for p in files]
    lessons = [item for item in lessons if item.get("published", True) and (not selected or item["order"] in selected)]
    missing = selected.difference(item["order"] for item in lessons)
    if missing:
        raise ValueError(f"No published lesson for: {sorted(missing)}")

    async def generate(lesson):
        async with semaphore:
            stem = f"{lesson['order']:03}"
            voice = "en-US-BrianNeural" if lesson["order"] % 2 else "en-US-AvaNeural"
            text = lesson["script"].replace("**", "").strip()
            script_hash = hashlib.sha256(text.encode()).hexdigest()
            existing_audio = ROOT / "content/audio" / f"{stem}.mp3"
            existing_meta = ROOT / "content/audio" / f"{stem}.meta.json"
            if existing_audio.is_file() and existing_meta.is_file():
                metadata = json.loads(existing_meta.read_text())
                if metadata.get("scriptSha256") == script_hash and metadata.get("voice") == voice and metadata.get("completeSubtitleMatch"):
                    print(f"{stem}: matching recording already exists", flush=True)
                    return
            print(f"{stem}: generating {voice}", flush=True)
            with tempfile.TemporaryDirectory(prefix=f"unicorn-{stem}-") as directory:
                audio = Path(directory) / f"{stem}.mp3"
                vtt = Path(directory) / f"{stem}.vtt"
                subtitles = edge_tts.SubMaker()
                stream = edge_tts.Communicate(text, voice, boundary="WordBoundary")
                with audio.open("wb") as output:
                    async for item in stream.stream():
                        if item["type"] == "audio":
                            output.write(item["data"])
                        elif item["type"] == "WordBoundary":
                            subtitles.feed(item)
                srt = subtitles.get_srt()
                webvtt = re.sub(r"(\d{2}:\d{2}:\d{2}),(\d{3})", r"\1.\2", srt)
                vtt.write_text("WEBVTT\n\n" + webvtt, encoding="utf-8")
                subprocess.run([sys.executable, str(ROOT / "scripts/register-recording.py"), stem, str(audio), str(vtt), voice], check=True)

    await asyncio.gather(*(generate(lesson) for lesson in lessons))


if __name__ == "__main__":
    asyncio.run(main())
