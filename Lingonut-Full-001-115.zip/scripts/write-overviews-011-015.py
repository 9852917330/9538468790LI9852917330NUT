import runpy
from pathlib import Path
globals().update(runpy.run_path('/workspace/sites/english-unicorn-listening/scripts/overview-revision.py'))

draft(11,'Titanic: From Maiden Voyage to Maritime Disaster','The voyage, collision, flooding, evacuation, rescue and safety reforms behind the Titanic disaster.',
'''On April 10, 1912, Titanic began its **maiden voyage** from Southampton to New York. The large passenger liner carried about 2,200 people, including wealthy travelers, emigrants seeking new lives and the crew who kept the ship operating. Its size and modern equipment attracted worldwide attention.

The route crossed the North Atlantic, where ice presented a known danger. Titanic received ice warnings during the journey. At about 11:40 p.m. on April 14, it struck an iceberg.

Water entered several forward **compartments**. Internal barriers were intended to limit flooding, but the damage exceeded what the ship could survive. As the bow sank lower, water spread beyond the barriers into more areas. Titanic could no longer **stay afloat**.

Evacuation became **a race against time**. The ship carried 20 lifeboats with a total **capacity** of about 1,178 people, far fewer than the number aboard. Although Titanic met the British lifeboat rules then in force, those rules were inadequate for its needs.

Some boats also left **far from full**. The evacuation was uneven, and access to safety differed among people on board. In the darkness, some passengers hesitated to leave a large ship for a small lifeboat, while others could not reach a place in time.

Radio operators sent **distress calls**. Carpathia changed course to help, but it was too far away to arrive before Titanic sank at about 2:20 a.m. on April 15. Around 1,500 people died. Carpathia later rescued roughly 700 **survivors** from the boats.

**In the aftermath**, investigations examined navigation, lifeboats, crew preparation and radio communication. The first international Safety of Life at Sea convention was adopted in 1914, making the disaster a major influence on maritime safety reform.

Titanic's loss was not explained by an iceberg alone. Damage, limited lifesaving equipment, uneven preparation and the distance of help combined to turn a collision into a catastrophe.''',[
mcq('Why did flooding continue beyond the damaged forward areas?',['All internal barriers were open to passengers.','The lowering bow allowed water to spread beyond the barriers.','The lifeboats pumped water back into the ship.'],'B','As the bow sank lower, water spread beyond the barriers into more areas.','The flooding exceeded the protection offered by the compartment design.'),
mcq('What made evacuation especially difficult?',['Too few lifeboat places and boats that sometimes left underfilled.','Enough places for everyone but no passengers needing rescue.','Carpathia ordered every lifeboat to remain on Titanic.'],'A','The ship carried 20 lifeboats with a total capacity of about 1,178 people, far fewer than the number aboard.','Insufficient total capacity was made worse by uneven use of available places.'),
mcq('What did the aftermath include?',['An agreement that modern ships needed no safety rules.','A ban on all Atlantic travel.','Investigations and international maritime safety reforms.'],'C','The first international Safety of Life at Sea convention was adopted in 1914, making the disaster a major influence on maritime safety reform.','The response addressed equipment, preparation and communication.'),
gap('Titanic was traveling from Southampton to New ___.','York','On April 10, 1912, Titanic began its maiden voyage from Southampton to New York.','New York was its planned destination.'),
gap('The ship struck an ___ in the North Atlantic.','iceberg','At about 11:40 p.m. on April 14, it struck an iceberg.','The collision began the flooding.'),
gap('The ship that rescued the survivors was ___.','Carpathia','Carpathia later rescued roughly 700 survivors from the boats.','Carpathia arrived after Titanic had sunk.')
],['https://www.rmg.co.uk/stories/maritime-history/rms-titanic-facts','https://www.senate.gov/about/powers-procedures/investigations/titanic.htm','https://www.titanicinquiry.org/USInq/USReport/AmInqRep05.php','https://www.imo.org/en/about/conventions/pages/international-convention-for-the-safety-of-life-at-sea-(solas),-1974.aspx'],['Voyage and people, ice warnings, collision, flooding, evacuation, rescue and reforms. Use rounded people counts. No speed-record myth or single-person blame.'])

draft(12,'John Snow and the London Cholera Outbreak','London’s sanitation crisis, competing explanations, several lines of evidence and the growth of disease investigation.',
'''In 1854, London was a crowded city with serious sanitation problems. Human waste could contaminate water used for drinking. Cholera repeatedly struck its neighborhoods, causing severe diarrhea and a rapid loss of body fluids. Many people died before effective help was available.

Many doctors **blamed** dirty, bad-smelling air. John Snow **suspected** that drinking water carried the disease. During an **outbreak** in Soho that August, he examined death **records**, visited households and compared the water people drank.

Many victims had used the public pump on Broad Street. A map showed deaths clustered nearby, but Snow did not rely on location alone. Interviews revealed drinking habits and helped him **look for patterns** that a map could miss. Some people living farther away had also drunk water from that pump.

Snow gathered **evidence** beyond Soho too. Elsewhere in London, homes received water from different companies. One company obtained cleaner water farther upstream; another drew from a more polluted source. The companies served overlapping areas, making comparisons possible between households in similar surroundings. Death rates were much higher among customers receiving the more polluted water.

On September 7, Snow presented his Broad Street findings to local officials. The pump handle was **removed** the following day, restricting access to the suspected source. However, the outbreak was already **in decline**. Snow recognized that fewer cases afterwards could not prove that removing the handle alone had ended it.

His conclusions challenged an established explanation of disease, and acceptance took time. Later scientific understanding confirmed the importance of contaminated water in spreading cholera. Safe water and sanitation became central to prevention.

Snow's work helped **lay the groundwork for** modern epidemiology. Its importance went beyond one pump: records, interviews, maps and comparisons of different water supplies had been combined to investigate a public health problem.''',[
mcq('Why did Snow investigate drinking habits as well as addresses?',['Distance alone did not show which water people had consumed.','Every household used the pump nearest its door.','A map could identify the bacteria directly.'],'A','Interviews revealed drinking habits and helped him look for patterns that a map could miss.','Exposure depended on the water people actually drank.'),
mcq('What did the comparison of water companies add?',['It showed that every part of London had identical death rates.','It connected higher death rates with a more polluted supply.','It proved that the pump handle was the only possible explanation.'],'B','Death rates were much higher among customers receiving the more polluted water.','The comparison supplied evidence beyond the famous Soho pump.'),
mcq('What limit did Snow recognize about the pump’s closure?',['The handle had never been removed.','No one had been ill before the closure.','The outbreak was already declining, so closure alone could not explain its end.'],'C','Snow recognized that fewer cases afterwards could not prove that removing the handle alone had ended it.','He distinguished an action taken to reduce risk from proof of its exact effect.'),
gap('Snow examined death ___ during his investigation.','records','During an outbreak in Soho that August, he examined death records, visited households and compared the water people drank.','He used recorded deaths alongside interviews and water-use information.'),
gap('He also compared customers of different water ___.','companies','Elsewhere in London, homes received water from different companies.','The suppliers provided water from sources of different quality.'),
gap('Officials removed the pump ___ on September 8.','handle','The pump handle was removed the following day, restricting access to the suspected source.','The action followed Snow’s September 7 presentation.')
],['https://www.cdc.gov/mmwr/preview/mmwrhtml/mm5334a1.htm','https://epi-snow.ph.ucla.edu/Stream2_BSPoutbreak_a.html','https://epi-snow.ph.ucla.edu/Stream3_GrandExperiment_a.html','https://www.who.int/news-room/fact-sheets/detail/cholera'],['Background sanitation and disease, competing hypotheses, pump study plus water-company comparison, intervention, limits and legacy. Do not claim the handle instantly ended the outbreak or that Snow identified the bacterium.'])

draft(13,'Penicillin: From Discovery to Medicine','How a laboratory observation became a practical antibiotic through testing, industrial cooperation and wider use.',
'''Before effective antibiotics, an ordinary wound or bacterial infection could become life-threatening. Doctors could clean injuries and provide care, but often had no reliable medicine to stop the bacteria responsible. Penicillin would help transform that situation, though its development took far more than one discovery.

In 1928, Alexander Fleming noticed something unusual in a laboratory dish at St. Mary's Hospital in London. **Mold** had entered a culture of **bacteria**, and bacterial growth was absent around it. He investigated the substance responsible, named it penicillin and published his findings in 1929.

The observation did not immediately produce a medicine. Penicillin was difficult to extract, **purify** and keep **stable**. Hospitals needed a dependable drug in useful quantities, not just a small amount of active material in a laboratory.

At Oxford, Howard Florey, Ernst Chain, Norman Heatley and colleagues developed methods to prepare and test it. Experiments in 1940 showed protection against bacterial **infection** in mice. Treatment of patients in 1941 showed promise, but penicillin was **in short supply** and there was not always enough to complete treatment.

British and American researchers then worked with industrial teams to **scale up production**. Better growing conditions, more productive mold strains and large tanks with controlled air and nutrients increased the supply. By 1944, penicillin was helping treat wounded Allied soldiers.

After the war, access expanded for civilian patients. Infections that had once been extremely dangerous became much more treatable. Penicillin acted against certain bacteria, however; it was not a cure for every illness, and it did not treat viral infections.

Fleming, Florey and Chain shared the Nobel Prize in 1945. Their recognition marked an achievement involving many other scientists, technicians, factory workers and clinicians. Penicillin's history was a **collective achievement**: observation opened the possibility, experiments established its value, and reliable production brought the medicine to people who needed it.''',[
mcq('Why was Fleming’s observation not enough to supply hospitals?',['Hospitals had no patients with bacterial infections.','The drug still needed extraction, purification and dependable production.','The mold observation was made only after the war.'],'B','Penicillin was difficult to extract, purify and keep stable.','Turning an active substance into a usable medicine required further development.'),
mcq('What enabled wider use during the war?',['Scientific and industrial work greatly increased production.','Every hospital began collecting its own contaminated dishes.','Human testing was abandoned entirely.'],'A','Better growing conditions, more productive mold strains and large tanks with controlled air and nutrients increased the supply.','Production methods made useful quantities available.'),
mcq('Which description best fits penicillin’s development?',['A complete medicine produced immediately by one scientist.','A treatment that worked against every illness.','A shared process from observation through testing to production.'],'C',"Penicillin's history was a collective achievement: observation opened the possibility, experiments established its value, and reliable production brought the medicine to people who needed it.",'Many different kinds of work were needed to develop and distribute the drug.'),
gap('Fleming made his initial observation in ___.','London',"In 1928, Alexander Fleming noticed something unusual in a laboratory dish at St. Mary's Hospital in London.",'The observation took place at St Mary’s Hospital.'),
gap('Experiments in 1940 tested protection against infection in ___.','mice','Experiments in 1940 showed protection against bacterial infection in mice.','The Oxford work included animal experiments before the patient treatments described.'),
gap('After the war, access expanded for ___ patients.','civilian','After the war, access expanded for civilian patients.','The benefits spread more widely beyond wartime military use.')
],['https://www.acs.org/education/whatischemistry/landmarks/flemingpenicillin.html','https://www.ars.usda.gov/news-events/news/research-news/2021/penicillium-strain-named-state-microbe-of-illinois/'],['Pre-antibiotic context, Fleming, development obstacles, Oxford tests, industrial scale, civilian impact and collaboration. No rose-thorn anecdote, sole-discoverer myth or universal cure claim.'])

draft(14,'Apollo 13: From Moon Mission to Rescue','The original mission, oxygen-tank accident, several survival challenges, safe return and investigation.',
'''Apollo 13 launched on April 11, 1970, carrying Jim Lovell, Jack Swigert and Fred Haise toward the Moon. It was intended to be the third human lunar landing. Instead, the journey became an emergency that tested the spacecraft, the crew and teams on Earth.

Two days after launch, an oxygen tank exploded in the service module. The damaged oxygen supply threatened more than breathing. Fuel cells used oxygen and hydrogen to produce electricity and water, so the accident endangered several essential systems at once. The crew had to **abandon** the landing.

Mission Control and the astronauts turned the lunar module, Aquarius, into a temporary **shelter**. Its independent oxygen and batteries provided a **lifeline**. Most systems in Odyssey, the command module, were switched off to **preserve** power for the final return through Earth's atmosphere.

Aquarius had been designed for 2 people on a short lunar visit. Now it had to support 3 during the journey home. Carbon dioxide **built up**, while water and electricity had to be used carefully. The cabin grew cold as equipment was shut down.

Ground teams solved problems with the supplies already aboard. One **workaround** adapted square carbon-dioxide filters to round connections using materials including cardboard and tape. It was one part of a wider effort to **conserve** resources and keep the crew alive.

Engine firings adjusted the route around the Moon and back toward Earth. Teams worked **around the clock** on navigation, power use and restarting Odyssey. Near home, the crew returned to the command module, whose heat shield was essential for re-entry.

On April 17, Odyssey **splashed down** safely in the Pacific Ocean. All 3 astronauts survived. Investigators later found that overheating during ground preparation had damaged electrical insulation inside the oxygen tank. NASA changed the oxygen system and strengthened engineering reviews.

Apollo 13 failed to land on the Moon, but its rescue demonstrated how preparation, adaptable equipment and coordinated work could prevent a serious accident from becoming a fatal one.''',[
mcq('Why did the oxygen accident threaten several systems?',['The Moon had no oxygen for the spacecraft to collect.','The crew had already used every battery aboard.','Oxygen was also needed to generate electricity and water.'],'C','Fuel cells used oxygen and hydrogen to produce electricity and water, so the accident endangered several essential systems at once.','The same supply supported several vital functions.'),
mcq('Why was Aquarius important to survival?',['It had independent supplies that could support the crew temporarily.','It was designed to land safely in the Pacific Ocean.','It could replace Odyssey’s heat shield.'],'A','Its independent oxygen and batteries provided a lifeline.','Aquarius kept the crew alive while Odyssey’s power was preserved for re-entry.'),
mcq('What did the investigation lead to?',['The abandonment of all engineering reviews.','Changes to the oxygen system and stronger reviews.','A conclusion that no equipment changes were needed.'],'B','NASA changed the oxygen system and strengthened engineering reviews.','The rescue was followed by work to prevent similar failures.'),
gap('The mission’s intended destination was the ___.','Moon','Apollo 13 launched on April 11, 1970, carrying Jim Lovell, Jack Swigert and Fred Haise toward the Moon.','Apollo 13 was a planned lunar landing mission.'),
gap('The lunar module used as a temporary shelter was named ___.','Aquarius','Mission Control and the astronauts turned the lunar module, Aquarius, into a temporary shelter.','The crew used Aquarius’s independent supplies.'),
gap('Odyssey was needed for re-entry because it had a heat ___.','shield','Near home, the crew returned to the command module, whose heat shield was essential for re-entry.','The command module protected the crew during the final atmospheric return.')
],['https://www.nasa.gov/missions/apollo/apollo-13-mission-details/','https://www.nasa.gov/history/50-years-ago-apollo-13-review-board-report/','https://www.nasa.gov/image-article/putting-square-peg-round-hole/'],['Full mission, accident, linked resource failures, shelter, conservation, navigation, return, investigation and redesign. Filter adapter is one brief example; it did not create oxygen. No immediate U-turn or lunar-module re-entry claim.'])

draft(15,'The Birth and Growth of the World Wide Web','The research problem, first tools, linked information, wider access and shared foundations behind the Web.',
'''In 1989, researchers at CERN, a physics laboratory near Geneva, faced a growing information problem. Scientists worked with different computers, organizations and documents. Knowledge could become difficult to find when projects changed or people left. Tim Berners-Lee proposed a way to connect that information.

The Internet already linked computers across the world. His proposal used it to connect documents through clickable **links**. People could follow related information across different machines without learning how each computer stored its files. This system became the World Wide Web.

By the end of 1990, Berners-Lee had built the first Web **browser** and **server** at CERN. The browser could display and edit pages; the server provided pages when requested. The first website explained the project itself. Common formats and communication rules allowed the parts to work together.

Other people helped **put the idea into practice**. Robert Cailliau worked on the proposal, and Nicola Pellow developed a simpler browser that could run on different computer systems. In 1991, the software reached people outside CERN, who began building their own tools and websites.

Wider access helped the project **gain momentum**. Graphical browsers, including Mosaic in 1993, made the Web easier to explore. Pictures and more convenient controls helped attract people beyond the research community.

On April 30, 1993, CERN placed the core Web software in the **public domain**, allowing others to use it without paying CERN licensing fees. This helped **lower the barrier to entry** for developers. It did not make every website free or remove ownership of its content.

Berners-Lee helped establish the World Wide Web Consortium in 1994 to develop shared **open standards**. Independent tools could then continue working together as the system expanded.

The Web grew into a worldwide means of publishing, learning, communication and business. Its success depended on a useful idea, an existing network, accessible tools and cooperation. No single website or company was the whole Web; its strength came from many people building on shared foundations.''',[
mcq('What problem inspired the original proposal?',['Researchers needed an easier way to connect and find scattered information.','CERN needed to invent the Internet from nothing.','Every scientist was already using the same documents and computer.'],'A','Scientists worked with different computers, organizations and documents.','The proposal addressed information shared across different systems.'),
mcq('How did the Web relate to the Internet?',['It replaced the Internet with a separate physical network.','It used the existing network to connect documents and pages.','It was simply another name for every Internet service.'],'B','His proposal used it to connect documents through clickable links.','The Web was built on the already existing Internet.'),
mcq('What helped the Web expand beyond CERN?',['A requirement that every developer pay CERN for each page.','A rule that only one company could build browsers.','Accessible software, easier browsers and shared standards.'],'C','Its success depended on a useful idea, an existing network, accessible tools and cooperation.','Technical access and shared foundations enabled many independent contributors.'),
gap('The first website explained the Web ___ itself.','project','The first website explained the project itself.','The initial site described what the new system was for.'),
gap('Mosaic was one of the graphical ___ that made the Web easier to explore.','browsers','Graphical browsers, including Mosaic in 1993, made the Web easier to explore.','Browsers is plural after one of the graphical browsers.'),
gap('The Web Consortium developed shared open ___.','standards','Berners-Lee helped establish the World Wide Web Consortium in 1994 to develop shared open standards.','Common standards supported independent tools working together.')
],['https://home.cern/science/computing/the-birth-of-the-web/short-history-web/','https://home.cern/science/computing/the-birth-of-the-web/where-web-was-born/','https://www.w3.org/People/Berners-Lee/1996/ppf.html'],['Research setting, proposal, mechanism, early tools, wider distribution, graphical browsers, software openness, standards and global uses. Web differs from Internet; Mosaic was not the first browser; software freedom does not make all site content free.'])
