"""Source-reviewed, distinct-topic overviews for English Unicorn 061–065."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(61, 'halifax-explosion-1917', 'Halifax 1917: Collision, Explosion and Recovery', 'Disasters and Recovery',
      'A collision in a busy wartime harbour started a fire and a devastating explosion, followed by urgent rescue, international assistance and years of rebuilding.',
'''During World War I, Halifax in Nova Scotia was a busy Canadian **harbor**. Ships gathered there to carry troops, food and military supplies across the Atlantic. This activity placed dangerous cargo close to docks, factories and crowded residential neighbourhoods.

On December 6, 1917, the French ship Mont-Blanc entered the harbour carrying **explosives**. The Norwegian ship Imo was travelling outward. The two vessels met in the narrow channel, where a **collision** started a fire aboard Mont-Blanc.

Its crew left the burning ship, fearing what would happen to the cargo. Mont-Blanc drifted toward the waterfront. People gathered to watch the fire, many unaware of the danger. At about 9:05 in the morning, the cargo **detonated**.

The **blast** destroyed buildings and threw **debris** across a wide area. Fires spread through damaged neighbourhoods, while a powerful harbour wave caused further destruction. Richmond in northern Halifax was devastated, and communities across the water in Dartmouth also suffered.

About 2,000 people died, and thousands were injured. Homes, schools, workplaces and medical facilities were damaged or destroyed. Families had lost relatives as well as the places and services they depended on. The emergency involved an entire urban community.

Residents, sailors, soldiers, firefighters and medical workers began rescue efforts. Hospitals treated large numbers of patients, while **relief** committees organized food, clothing and **shelter**. A snowstorm the following day made the work harder. Assistance arrived from elsewhere in Canada and from abroad.

Recovery continued long after the immediate rescue. Temporary housing helped people through the crisis, and major **reconstruction** projects followed. The Hydrostone neighbourhood used more fire-resistant building materials and a planned layout as part of efforts to create safer homes.

The disaster also encouraged improvements in medical treatment, support for people with serious eye injuries and public health. Halifax's experience showed how an accident involving commercial shipping could overwhelm a city, and how recovery depended on local action, outside help and sustained planning.''',
[
v('harbor', 'A sheltered area of water where ships can stay or load and unload goods.', 'The ships waited inside the harbor.', 'Noun', plural='harbors'),
v('explosive', 'A substance designed or able to release energy suddenly in an explosion.', 'Specialists examined the explosive found in the cargo.', 'Noun', form='explosives', plural='explosives'),
v('collision', 'An event in which two moving objects strike each other.', 'The collision damaged both vessels.', 'Noun', plural='collisions'),
v('detonate', 'To explode or cause an explosive substance to explode.', 'The inquiry examined why the cargo had detonated.', 'Verb', form='detonated', verb=('detonate','detonated','detonated',False)),
v('blast', 'A sudden, powerful movement of air or pressure caused by an explosion.', 'The blast damaged buildings near the port.', 'Noun', plural='blasts'),
v('debris', 'Broken pieces left after damage or destruction.', 'Rescuers searched the debris for survivors.', 'Uncountable noun'),
v('relief', 'Practical assistance given to people affected by a disaster or serious difficulty.', 'The relief effort provided food and medical supplies.', 'Uncountable noun'),
v('shelter', 'A place that provides protection from danger or bad weather.', 'Families found shelter in a temporary building.', 'Noun', plural='shelters'),
v('reconstruction', 'The process of rebuilding something after it has been damaged or destroyed.', 'Reconstruction continued for several years after the disaster.', 'Uncountable noun')
],
[
m('What connected the collision with the later explosion?', ['A fire began on a ship carrying explosives.', 'Both ships had already left the harbour safely.', 'The cargo had been unloaded far from the city.'], 'A', 'The two vessels met in the narrow channel, where a collision started a fire aboard Mont-Blanc.', 'Mont-Blanc’s explosive cargo made the resulting fire especially dangerous.'),
m('What complicated rescue work on the following day?', ['The disappearance of all outside assistance.', 'A snowstorm made the work harder.', 'The city had no injured people to treat.'], 'B', 'A snowstorm the following day made the work harder.', 'The response continued under difficult weather conditions.'),
m('Which description best represents the longer recovery?', ['It ended as soon as the first fire was extinguished.', 'Only the two ships required repairs.', 'It involved housing, safer rebuilding, medical treatment and public health.'], 'C', 'The disaster also encouraged improvements in medical treatment, support for people with serious eye injuries and public health.', 'The preceding paragraphs also describe temporary housing and safer reconstruction.'),
g('The disaster happened in December ___.', '1917', 'On December 6, 1917, the French ship Mont-Blanc entered the harbour carrying explosives.', '1917 places the disaster during World War I.'),
g('The Norwegian ship was called ___.', 'Imo', 'The Norwegian ship Imo was travelling outward.', 'Imo was the outward-bound vessel involved in the collision.'),
g('The Hydrostone project used more fire-resistant building ___.', 'materials', 'The Hydrostone neighbourhood used more fire-resistant building materials and a planned layout as part of efforts to create safer homes.', 'Safer materials formed part of the rebuilding approach.')
],
[
'Parks Canada, national historic event account — Wartime port, collision, fire, approximate deaths, rescue, medical changes and safer rebuilding: https://parks.canada.ca/culture/designation/evenement-event/halifax-explosion',
'Nova Scotia Museum, Explosion in the Narrows — Ship movements, affected communities and local response: https://museum.novascotia.ca/stories/explosion-narrows-1917-halifax-harbour-explosion',
'Nova Scotia Archives, A Vision of Regeneration — Relief organization, temporary shelter and Hydrostone reconstruction: https://archives.novascotia.ca/explosion/'
],
[
'Whole-event overview covers the wartime port and cargo, collision and fire, explosion mechanism, destruction and deaths, rescue and weather, outside aid, housing and medical legacy.',
'About 2,000 deaths is an approximate total including later deaths, not a claim that all victims died instantly. No exact disputed total or unsupported single-villain account.',
'Imo is described as outbound, avoiding older accounts that confuse future relief cargo with cargo already aboard. No unverified legal blame or specific new navigation-rule claim.',
'No graphic injuries, explosive formulations or technical instructions. Medical changes are historical outcomes, not current clinical advice.',
'Compared with all 001–060 and the other candidates; distinct from earlier maritime and industrial disasters. Identity and aliases registered in content/topics.json.'
])

draft(62, 'endurance-expedition-survival-1914-1916', 'Endurance: An Antarctic Expedition Becomes a Rescue', 'Exploration and Survival',
      'An attempt to cross Antarctica became a long struggle to survive moving sea ice, reach land and organize a rescue across the Southern Ocean.',
'''In 1914, Ernest Shackleton led an **expedition** intended to cross Antarctica. His ship Endurance would approach from the Weddell Sea, while a separate support party worked on the Ross Sea side. The planned crossing depended on reaching land with people, equipment and supplies.

In January 1915, Endurance became trapped in **pack ice** before reaching its destination. The ship moved with the ice instead of sailing freely. Months of pressure damaged its structure, and it was eventually **crushed**. The men abandoned the vessel in October; it sank in November.

The 28 members of the Endurance party now had to survive without their ship. They established camps on **drifting** ice and kept three **lifeboats**. Their original goal had changed completely: the priority was bringing everyone back alive.

When the ice broke up, they took to the boats. In April 1916, they reached Elephant Island. It offered solid ground but was **uninhabited** and far from normal shipping routes. Waiting there gave little reason to expect that a passing vessel would discover them.

Shackleton and five companions therefore sailed the small James Caird toward South Georgia to seek help. Frank Wild remained in charge of the men on Elephant Island. The boat journey required careful preparation, **navigation** and considerable **endurance** in dangerous ocean conditions.

After reaching South Georgia, Shackleton, Frank Worsley and Tom Crean crossed its mountainous interior to a whaling station. Help was finally available, but bringing it back to Elephant Island remained difficult. Ice prevented earlier rescue attempts from reaching the waiting party.

On August 30, 1916, the Chilean vessel Yelcho, commanded by Luis Pardo, rescued the 22 men on the island. All 28 members of the Endurance party survived. The separate Ross Sea support party suffered three deaths.

The Antarctic crossing had failed, but survival depended on **coordination** across changing camps, open boats, mountain travel and the final rescue ship. The outcome reflected camp leadership, navigation, practical skills and outside assistance, alongside Shackleton's decisions under pressure.''',
[
v('expedition', 'An organized journey made for exploration, research or another specific purpose.', 'The expedition carried scientific equipment and food supplies.', 'Noun', plural='expeditions'),
v('pack ice', 'Large areas of floating sea ice packed closely together.', 'The ship could not move through the pack ice.', 'Uncountable noun phrase'),
v('crush', 'To damage or destroy something by applying strong pressure.', 'The pressure threatened to crush the vessel.', 'Verb', form='crushed', verb=('crush','crushed','crushed',False)),
v('drift', 'To move slowly under the influence of wind or water rather than direct control.', 'The ice began to drift away from the shore.', 'Verb', form='drifting', verb=('drift','drifted','drifted',False)),
v('lifeboat', 'A small boat carried or used to help people escape danger at sea.', 'The crew lowered a lifeboat into the water.', 'Noun', form='lifeboats', plural='lifeboats'),
v('uninhabited', 'Having no permanent human residents.', 'The island was uninhabited and difficult to reach.', 'Adjective'),
v('navigation', 'The process of determining position and directing travel along a route.', 'Accurate navigation was essential during the voyage.', 'Uncountable noun'),
v('endurance', 'The ability to continue through physical difficulty, discomfort or stress.', 'The long journey tested the team’s endurance.', 'Uncountable noun'),
v('coordination', 'The organization of people or activities so that they work effectively together.', 'The rescue required coordination between several teams.', 'Uncountable noun')
],
[
m('How did the expedition’s main goal change after the loss of Endurance?', ['The group decided to complete the crossing without supplies.', 'Survival and bringing the party home became the priority.', 'The men immediately returned to their original port.'], 'B', 'Their original goal had changed completely: the priority was bringing everyone back alive.', 'Losing the ship transformed an exploration project into a survival and rescue effort.'),
m('Why did a small group leave Elephant Island?', ['It was already served by regular passenger ships.', 'Everyone else had already been rescued.', 'The island was remote, so the group went to South Georgia to seek help.'], 'C', 'Shackleton and five companions therefore sailed the small James Caird toward South Georgia to seek help.', 'The preceding paragraph explains the island’s isolation and the low chance of discovery.'),
m('What was the outcome for the Endurance party?', ['All 28 survived, although the separate Ross Sea party suffered deaths.', 'The planned Antarctic crossing was completed.', 'Only the six people in the James Caird survived.'], 'A', 'All 28 members of the Endurance party survived.', 'The following sentence distinguishes the separate support party, which suffered three deaths.'),
g('Endurance became trapped in ice in January ___.', '1915', 'In January 1915, Endurance became trapped in pack ice before reaching its destination.', 'The ship was lost later in the same year.'),
g('The men kept three ___ after abandoning the ship.', 'lifeboats', 'They established camps on drifting ice and kept three lifeboats.', 'The boats later provided a way to leave the breaking ice.'),
g('The final rescue vessel was called ___.', 'Yelcho', 'On August 30, 1916, the Chilean vessel Yelcho, commanded by Luis Pardo, rescued the 22 men on the island.', 'Yelcho completed the rescue from Elephant Island.')
],
[
'Royal Geographical Society expedition timeline — January entrapment, October abandonment, November sinking, island arrival and August 30 rescue: https://www.rgs.org/media/mh0lxvg2/ks2_shackleton_l4_shackleton-timeline-and-historical-overview-v2.pdf',
'New Zealand Ministry for Culture and Heritage, expedition parties — Original plan, Worsley, boat preparation, crossing and separate Ross Sea losses: https://nzhistory.govt.nz/media/interactive/shackleton-sea-parties',
'Royal Navy, January 15, 2025 commemoration — Luis Pardo, Yelcho and Chilean rescue: https://www.royalnavy.mod.uk/news/2025/january/15/20250115-chilean-officer-who-rescued-shackleton-crew-remembered',
'Antarctic Heritage Trust — Three-man South Georgia crossing and survival: https://nzaht.org/encourage/inspiring-explorers/crossing-south-georgia/',
'State Library New South Wales — Frank Wild’s camp leadership; original collection account indexed, direct retrieval blocked by bot wall: https://www.sl.nsw.gov.au/stories/shackleton-expedition'
],
[
'Overview covers the original purpose, ice entrapment and ship loss, camp survival, boat journey and island isolation, seeking help, crossing South Georgia, Chilean rescue and shared contribution.',
'October abandonment and November sinking are distinct. The exact January day is omitted because institutional summaries differ. No claim the Antarctic crossing succeeded.',
'All 28 survivors refers to the Endurance party, not the entire Imperial Trans-Antarctic Expedition: the separate Ross Sea party had three deaths, stated explicitly.',
'Credits include Wild, Worsley, Crean and Pardo, alongside the camp and boat teams; survival is not attributed solely to one leader. No practical hazardous survival instructions.',
'Compared with all 001–061 and the remaining candidates; distinct from other rescue events. Identity and aliases registered in content/topics.json.'
])

draft(63, 'watergate-scandal-1972-1974', 'Watergate: A Break-In, a Cover-Up and a President’s Resignation', 'Politics and Accountability',
      'A break-in at a political party’s offices led investigators toward a cover-up, a struggle over presidential recordings and Richard Nixon’s departure from office.',
'''In 1972, Richard Nixon was seeking another term as president of the United States. On June 17, police arrested five men inside the Democratic National Committee's offices at the Watergate complex in Washington. The **burglary** involved an attempt to gather information about political opponents using **surveillance** equipment.

Investigators found connections to Nixon's **reelection** campaign. The White House denied involvement, and Nixon won the November election decisively. However, the arrests had begun an investigation that would extend far beyond the original break-in.

FBI agents, prosecutors, courts, journalists and Congress pursued different parts of the case. Washington Post reporters Bob Woodward and Carl Bernstein investigated campaign links. Attention increasingly turned to a **cover-up**, including efforts to prevent investigators from learning the full story.

Senate hearings began in May 1973 and reached a large television audience. Witness **testimony** raised questions about conduct inside the White House. In July, an official revealed that Nixon had a system for recording presidential conversations. The tapes could provide evidence beyond conflicting personal accounts.

Investigators issued **subpoenas** seeking recordings, but Nixon resisted demands to surrender them. The dispute tested the limits of presidential confidentiality. On July 24, 1974, the Supreme Court required the production of tapes for a criminal trial.

Later that month, the House Judiciary Committee approved three articles of **impeachment**. A recording released in August showed Nixon's involvement in **obstruction** of the investigation. His political support collapsed as the evidence became harder to dispute.

Nixon announced his **resignation** on August 8. It took effect on August 9, 1974, when Vice President Gerald Ford became president. Nixon left office before the full House voted on impeachment. Ford later pardoned him.

Watergate damaged public trust and brought criminal convictions for officials and others involved. Congress strengthened campaign-finance law and created the Federal Election Commission. The scandal became a major example of how reporting, witnesses, courts and legislative investigation could expose abuse of presidential power, while showing the damage caused by attempts to conceal wrongdoing.''',
[
v('burglary', 'The crime of entering a building unlawfully to steal something or commit another crime.', 'The burglary led to a wider investigation.', 'Noun', plural='burglaries'),
v('surveillance', 'Close observation of people or places to gather information.', 'The inquiry examined the use of surveillance equipment.', 'Uncountable noun'),
v('reelection', 'The process or result of being elected again to the same office.', 'The president was seeking reelection.', 'Uncountable noun'),
v('cover-up', 'An attempt to hide wrongdoing or prevent the truth from becoming known.', 'The investigation uncovered evidence of a cover-up.', 'Noun', plural='cover-ups'),
v('testimony', 'A formal account or statement given by a witness.', 'The committee compared the testimony with written records.', 'Uncountable noun'),
v('subpoena', 'A formal legal order requiring a person to appear or provide evidence.', 'The court issued a subpoena for the documents.', 'Noun', form='subpoenas', plural='subpoenas'),
v('impeachment', 'A legislative process of bringing formal charges against a public official, which can lead to a separate decision on removal.', 'The committee considered articles of impeachment.', 'Noun', plural='impeachments'),
v('obstruction', 'An act of preventing or interfering with a process, especially an investigation or the administration of justice.', 'The evidence raised questions about obstruction of the inquiry.', 'Uncountable noun'),
v('resignation', 'The act of formally leaving a job or position.', 'The minister announced her resignation.', 'Noun', plural='resignations')
],
[
m('Why did the recordings become important?', ['They replaced every other part of the investigation without examination.', 'They proved that the original arrests never happened.', 'They could provide evidence beyond conflicting personal accounts.'], 'C', 'The tapes could provide evidence beyond conflicting personal accounts.', 'The recordings offered a way to examine conversations rather than relying only on what witnesses remembered or claimed.'),
m('What did the Supreme Court require in July 1974?', ['The production of tapes for a criminal trial.', 'The publication of every recording ever made in the White House.', 'The immediate appointment of a new president without a resignation.'], 'A', 'On July 24, 1974, the Supreme Court required the production of tapes for a criminal trial.', 'The ruling concerned evidence needed in criminal proceedings.'),
m('Which sequence correctly describes Nixon’s departure?', ['The full House removed him before any committee considered charges.', 'He resigned before the full House voted, and Ford became president.', 'He remained president until the next scheduled election.'], 'B', 'Nixon left office before the full House voted on impeachment.', 'The account distinguishes committee action from a full House vote and Nixon’s resignation.'),
g('The Watergate arrests took place in June ___.', '1972', "In 1972, Richard Nixon was seeking another term as president of the United States. On June 17, police arrested five men inside the Democratic National Committee's offices at the Watergate complex in Washington.", '1972 was the year of the arrests and Nixon’s reelection campaign.'),
g('Nixon’s resignation took effect on August ___.', '9', 'It took effect on August 9, 1974, when Vice President Gerald Ford became president.', 'August 8 was the announcement; August 9 was the effective date.'),
g('The new president was Gerald ___.', 'Ford', 'It took effect on August 9, 1974, when Vice President Gerald Ford became president.', 'Ford succeeded Nixon after the resignation.')
],
[
'U.S. Senate official investigation history — Arrests, campaign links, denial, reporters, hearings, witnesses and recording system: https://www.senate.gov/about/powers-procedures/investigations/watergate.htm',
'National Archives chronology — Subpoenas, July 24 ruling, July committee articles, August 9 resignation and later pardon: https://www.archives.gov/education/lessons/watergate-constitution/chronology.html',
'FBI official case history — Burglary and surveillance, campaign connections and investigation: https://www.fbi.gov/history/cases-and-criminals/watergate',
'Library of Congress impeachment guide — Committee votes on July 27, 29 and 30, August evidence release and distinction from full House impeachment: https://guides.loc.gov/federal-impeachment/richard-nixon',
'Nixon Presidential Library — August 8 announcement, August 9 departure, succession and pardon: https://www.nixonlibrary.gov/president-nixon',
'National Archives original resignation letter — Formal departure: https://www.archives.gov/files/historical-docs/doc-content/images/nixon-resignation-letter.pdf',
'Federal Election Commission institutional history — Campaign-finance changes and creation of the commission: https://www.fec.gov/about/mission-and-history/'
],
[
'Overview covers political context and original crime, campaign connections, multiple investigators, cover-up, public hearings, recordings and court dispute, committee action, resignation, succession and institutional legacy.',
'No claim Nixon personally ordered the original burglary. His role in obstruction is distinguished from the initial crime.',
'The Supreme Court required tapes for criminal proceedings, not publication of every White House recording. July committee action precedes the August release of the decisive recording.',
'Nixon resigned before the full House voted; committee articles are not treated as completed House impeachment or removal. August 8 announcement and August 9 effective date are distinct.',
'Compared with all 001–062 and the remaining candidates; distinct from the JFK assassination and earlier fraud cases. Identity and aliases registered in content/topics.json.'
])

draft(64, 'otzi-iceman-discovery-1991', 'Ötzi the Iceman: Discovery, Evidence and Preservation', 'Discoveries and Archaeology',
      'A body found in Alpine ice proved to be a naturally preserved Copper Age man, opening a rare record of ancient clothing, tools, health and a violent death.',
'''On September 19, 1991, German hikers Erika and Helmut Simon noticed a body partly exposed in Alpine ice. They were near the **border** between Austria and Italy. At first, people thought they had found a modern climber who had died in a mountain accident.

Recovery teams removed the body, and it was taken to Innsbruck in Austria. When an archaeologist examined it, the importance of the discovery became clear. This was an ancient **mummy**, naturally **preserved** rather than prepared for burial through a deliberate human process.

Scientific dating placed the man's life about 5,300 years ago, around 3300 BCE, during the Copper Age. His modern nickname, Ötzi, came from the Ötztal Alps. A later survey confirmed that the discovery site was just inside Italy.

Cold mountain conditions and ice had preserved much of his body, clothing and equipment. Together, they provided an unusual picture of everyday skills. Unlike a collection of isolated objects, the find connected a person with the things he wore and carried.

His clothing used animal hides and other natural materials. His footwear included dry grass for **insulation**. A **copper** axe and stone tools showed different materials being used together. These **artifacts** helped researchers investigate craftsmanship, available resources and adaptation to the mountain environment.

In 1998, the body became part of the South Tyrol Museum of Archaeology in Bolzano, Italy. A specially controlled cold chamber supported its **conservation**, while research continued on the body and associated objects.

Medical imaging added another part of the story. In 2001, an X-ray revealed a stone **arrowhead** in his left shoulder. Scientists found evidence that he had been shot with an arrow. This changed the interpretation of his death, but did not identify an attacker or establish a motive.

Ötzi became a rare connection between an individual life and a distant period of human history. The discovery showed how clothing, tools, scientific tests and careful preservation could support **reconstructions** of the past, while leaving some questions unanswered.''',
[
v('border', 'The boundary between two countries or other defined areas.', 'The village lies close to the border.', 'Noun', plural='borders'),
v('mummy', 'A dead body that has been preserved naturally or by deliberate treatment.', 'The researchers examined the mummy without removing it from the chamber.', 'Noun', plural='mummies'),
v('preserve', 'To protect something from damage, decay or loss.', 'Cold conditions helped preserve the ancient material.', 'Verb', form='preserved', verb=('preserve','preserved','preserved',False)),
v('insulation', 'Material or protection that slows the transfer of heat, sound or electricity.', 'The dry grass provided insulation against the cold.', 'Uncountable noun'),
v('copper', 'A reddish-brown metal used in tools, electrical wiring and other objects.', 'The ancient tool had a copper blade.', 'Uncountable noun'),
v('artifact', 'An object made or used by people that provides evidence about the past.', 'The artifact showed signs of careful repair.', 'Noun', form='artifacts', plural='artifacts'),
v('arrowhead', 'The pointed end of an arrow.', 'An X-ray revealed the arrowhead inside the shoulder.', 'Noun', plural='arrowheads'),
v('conservation', 'The protection and preservation of objects, buildings or natural environments.', 'The museum controlled humidity as part of its conservation work.', 'Uncountable noun'),
v('reconstruction', 'An account, model or representation of something in the past based on available evidence.', 'The reconstruction combined physical evidence with scientific analysis.', 'Noun', form='reconstructions', plural='reconstructions')
],
[
m('Why was the discovery different from the initial assumption?', ['The body belonged to an ancient man rather than a modern climber.', 'The hikers had found an empty modern coat.', 'The body was known from the beginning to be a named historical ruler.'], 'A', 'Scientific dating placed the man’s life about 5,300 years ago, around 3300 BCE, during the Copper Age.'.replace('’', "'"), 'The discovery was far older than the recent mountain accident initially imagined.'),
m('Why did the clothing and equipment matter?', ['They proved his attacker’s identity.', 'They showed that people in his time had no practical skills.', 'They connected an individual with ancient materials, skills and adaptation.'], 'C', 'These artifacts helped researchers investigate craftsmanship, available resources and adaptation to the mountain environment.', 'The associated objects provided evidence about ancient life as well as the body itself.'),
m('What did the arrowhead evidence establish?', ['It proved exactly why and by whom he was attacked.', 'It supported a shooting injury while leaving the attacker and motive unknown.', 'It showed that the body was modern.'], 'B', 'Scientists found evidence that he had been shot with an arrow.', 'The next sentence distinguishes the injury evidence from unanswered questions about an attacker and motive.'),
g('The hikers found the body in ___.', '1991', 'On September 19, 1991, German hikers Erika and Helmut Simon noticed a body partly exposed in Alpine ice.', '1991 was the modern discovery year, not the time when the man lived.'),
g('The discovery site was confirmed to be inside ___.', 'Italy', 'A later survey confirmed that the discovery site was just inside Italy.', 'The find was near the Austrian–Italian border.'),
g('His axe used the metal ___.', 'copper', 'A copper axe and stone tools showed different materials being used together.', 'Copper and stone tools were present in the same set of equipment.')
],
[
'South Tyrol Museum of Archaeology, discovery account — Hikers, September 19, recovery, examination and Italian border survey: https://www.iceman.it/en/oetzi/the-discovery',
'Museum Iceman overview — Copper Age identity, nickname and equipment: https://www.iceman.it/en/oetzi/the-iceman',
'Museum clothing account — Hides, footwear and grass insulation: https://www.iceman.it/en/oetzi/clothing',
'Museum equipment account — Copper axe and stone tools: https://www.iceman.it/en/oetzi/equipment',
'Museum body account and research milestones — Natural preservation, 2001 arrowhead, injury and controlled museum conservation: https://www.iceman.it/en/oetzi/the-body',
'Museum research milestones — Imaging and conservation chronology: https://www.iceman.it/en/the-research/milestones',
'Pilø and colleagues, online November 7, 2022, The Holocene 2023 — Reassessment of ice, repeated exposure and taphonomy: https://doi.org/10.1177/09596836221126133',
'Hajdas and Saracoğlu, Radiocarbon, February 19, 2026 — Radiocarbon reanalysis supporting approximate ancient dating rather than a single exact year: https://doi.org/10.1017/RDC.2026.10194'
],
[
'Overview covers discovery and initial misunderstanding, recovery and recognition, age and border location, preservation, clothing and equipment, later injury evidence, conservation and historical significance.',
'About 5,300 years ago and around 3300 BCE are approximate, consistent with current reanalysis. No false exact year, Ice Age or Neanderthal identity.',
'Cold conditions and ice is deliberately broad: no claim of uninterrupted 5,300-year burial beneath a moving glacier. The older museum preservation reconstruction is not repeated as settled science.',
'Arrowhead evidence is distinguished from an identified attacker, motive or documented pursuit. No graphic injury details, invented profession, hairstyle reconstruction or genetic identity story.',
'Compared with all 001–063 and the suffrage candidate; distinct from Tutankhamun and the Rosetta Stone. Identity and aliases registered in content/topics.json.'
])

draft(65, 'new-zealand-womens-suffrage-1893', 'New Zealand 1893: The Campaign for Women’s Votes', 'Rights and Social Change',
      'Years of campaigning and petitions helped secure women’s parliamentary voting rights, while the separate struggle to enter Parliament continued.',
'''Before 1893, women in New Zealand could not vote in national parliamentary elections. Supporters of women's **suffrage** challenged the belief that political decisions should be made only by men. Laws affected women's homes, work and opportunities, yet they lacked a vote in choosing national lawmakers.

Kate Sheppard became a leading organizer among many **campaigners**. The Women's Christian Temperance Union played an important role. Its support connected equal political rights with **temperance**, including efforts to reduce harm associated with alcohol. Other organizations and sympathetic politicians also joined the movement.

Campaigners held meetings, gave speeches and circulated **petitions**. In 1891, 1892 and 1893, they gathered growing numbers of **signatures** from around the country. These documents turned support in many communities into a visible demand that Parliament could examine.

The campaign faced strong **opposition**. Some people defended traditional gender roles, while liquor interests feared that women would support restrictions on alcohol. Earlier attempts to change the law had failed, so large petitions alone did not guarantee success.

In September 1893, the proposed **legislation** finally passed Parliament. On September 19, Governor Lord Glasgow signed the Electoral Act. New Zealand became the first self-governing country to give women the right to vote in national parliamentary elections.

The new rights covered **eligible** British subjects aged 21 or older, including Māori women. Other voting requirements still applied. Women voted in the general electorates on November 28. Elections in the Māori electorates followed on December 20.

Voting rights were an important change, but eligibility to become a member of Parliament was a separate matter. Women gained the right to stand for Parliament in 1919. Elizabeth McCombs became the country's first woman member of Parliament in 1933.

The 1893 victory expanded political **representation** and became an influential example of organized reform. Its history brought together local meetings, national networks, public arguments and parliamentary decisions. It also showed that winning one political right could leave further barriers to equal participation.''',
[
v('suffrage', 'The right to vote in political elections.', 'The campaign called for equal suffrage.', 'Uncountable noun'),
v('campaigner', 'A person who works in an organized way to bring about a political or social change.', 'The campaigner spoke at a public meeting.', 'Noun', form='campaigners', plural='campaigners'),
v('temperance', 'The practice or promotion of limiting or avoiding alcoholic drinks.', 'The temperance movement supported restrictions on alcohol.', 'Uncountable noun'),
v('petition', 'A formal written request supported by the signatures of people who want a change.', 'The petition asked Parliament to change the law.', 'Noun', form='petitions', plural='petitions'),
v('signature', 'A person’s name written to identify them or show agreement with a document.', 'Each signature represented support for the request.', 'Noun', form='signatures', plural='signatures'),
v('opposition', 'Disagreement with or resistance to a proposal, action or group.', 'The proposal faced opposition from several politicians.', 'Uncountable noun'),
v('legislation', 'A law or set of laws made by a legislative body.', 'Parliament considered legislation on voting rights.', 'Uncountable noun'),
v('eligible', 'Meeting the conditions required to do or receive something.', 'Residents checked whether they were eligible to vote.', 'Adjective'),
v('representation', 'The inclusion or expression of people’s interests through someone who acts or speaks for them.', 'Voting gave more citizens a role in political representation.', 'Uncountable noun')
],
[
m('How did petitions help the campaign?', ['They automatically changed the law without any vote in Parliament.', 'They turned support from communities into a visible demand for change.', 'They were used only after women had already entered Parliament.'], 'B', 'These documents turned support in many communities into a visible demand that Parliament could examine.', 'Petitions connected local participation with the national legislative process.'),
m('What did the 1893 Electoral Act achieve?', ['It immediately made every woman a member of Parliament.', 'It ended all electoral requirements for every resident.', 'It established parliamentary voting rights for eligible women.'], 'C', 'The new rights covered eligible British subjects aged 21 or older, including Māori women.', 'The reform concerned voting eligibility under the electoral rules, rather than immediate office-holding or universal eligibility without conditions.'),
m('Why does the account distinguish voting from standing for Parliament?', ['Women could vote before they gained the separate right to become parliamentary candidates.', 'Women had always been eligible for every parliamentary position.', 'The 1893 voting reform had no political consequences.'], 'A', 'Women gained the right to stand for Parliament in 1919.', 'The vote was secured in 1893; eligibility to become a candidate came later.'),
g('Campaigners circulated ___ to show support for change.', 'petitions', 'Campaigners held meetings, gave speeches and circulated petitions.', 'Petitions provided a way to collect and present support.'),
g('The new rights covered eligible British subjects aged ___ or older.', '21', 'The new rights covered eligible British subjects aged 21 or older, including Māori women.', '21 was the age threshold described in the 1893 eligibility rule.'),
g('Women gained the right to stand for Parliament in ___.', '1919', 'Women gained the right to stand for Parliament in 1919.', 'The later candidate-eligibility reform was separate from the 1893 vote.')
],
[
'New Zealand Ministry for Culture and Heritage, suffrage introduction — September 19 law and precise first-self-governing-country achievement: https://nzhistory.govt.nz/politics/womens-suffrage',
'NZHistory brief history — Equal-rights and temperance context, campaign methods, opposition, earlier failures and eligible British subjects aged 21 or older: https://nzhistory.govt.nz/politics/womens-suffrage/brief-history',
'Archives New Zealand, original petition account — National networks, petition sheets, signatures and parliamentary presentation: https://www.archives.govt.nz/discover-our-stories/womens-suffrage-petition',
'Te Ara, Voting rights — Movement, temperance and electoral context: https://teara.govt.nz/en/voting-rights/page-4',
'Original Electoral Act 1893 — Assent date, qualifications and separate exclusion from parliamentary membership: https://www.legislation.govt.nz/act/public/1893/18/en/latest/',
'NZHistory Māori electorate account — November 28 general polling and December 20 Māori polling, with some Māori women also eligible in general electorates: https://nzhistory.govt.nz/page/women-vote-maori-seats-first-time',
'New Zealand Parliament, centenary of candidate eligibility — 1919 reform and Elizabeth McCombs in 1933: https://www3.parliament.nz/en/get-involved/features/100-years-since-women-gained-the-right-to-stand-for-parliament/'
],
[
'Whole-event overview covers exclusion, arguments and movement, Sheppard and wider organizations, temperance, petitions and signatures, opposition and legislative struggle, law, eligibility and first polling, later candidate rights and significance.',
'First self-governing country with women’s national parliamentary voting is used instead of first women anywhere to vote. Eligible British subjects aged 21 or older and other electoral conditions are acknowledged.',
'General and Māori electorate polling dates are distinct. No claim that every Māori woman first voted only in December; the distinction concerns electorates.',
'Signature counts are omitted to avoid confusing all 1893 petitions with the surviving main roll. The right to vote in 1893 is distinct from candidacy in 1919 and the first woman MP in 1933.',
'Compared with all 001–064; distinct from the Montgomery boycott and other rights movements. Identity and aliases registered in content/topics.json.'
])
