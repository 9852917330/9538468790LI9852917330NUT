import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { parseTranslation, plainScript, scriptParagraphs, translationCodes } from "../lib/translation.ts";
import { parseTitleTranslations } from "../lib/title-translation.ts";
import { readdir } from "node:fs/promises";

const lesson = JSON.parse(await readFile(new URL("../content/lessons/001.json", import.meta.url), "utf8"));
const expected = {
  lessonId: lesson.id, sourceTitle: lesson.title,
  sourceScriptSha256: createHash("sha256").update(plainScript(lesson.script)).digest("hex"),
  paragraphCount: scriptParagraphs(lesson.script).length,
};
const bundles = await Promise.all(translationCodes.map(async language => JSON.parse(await readFile(new URL(`../content/translations/001/${language}.json`, import.meta.url), "utf8"))));

test("all eight demo translations match the current source and paragraph boundaries", () => {
  assert.equal(bundles.length, 8);
  assert.equal(expected.paragraphCount, 7);
  for (const bundle of bundles) assert.equal(parseTranslation(bundle, { ...expected, language: bundle.language }).paragraphs.length, 7);
});
test("editing either the source script or title blocks stale translations", () => {
  const bundle = bundles[0];
  assert.throws(() => parseTranslation(bundle, { ...expected, language: bundle.language, sourceScriptSha256: "0".repeat(64) }), /older English source/);
  assert.throws(() => parseTranslation(bundle, { ...expected, language: bundle.language, sourceTitle: "Updated title" }), /older English source/);
});
test("missing, empty or merged paragraphs are rejected", () => {
  const bundle = bundles[0];
  const context = { ...expected, language: bundle.language };
  assert.throws(() => parseTranslation({ ...bundle, paragraphs: bundle.paragraphs.slice(1) }, context), /align/);
  assert.throws(() => parseTranslation({ ...bundle, paragraphs: [" ", ...bundle.paragraphs.slice(1)] }, context));
  assert.throws(() => parseTranslation({ ...bundle, paragraphs: ["First\nSecond", ...bundle.paragraphs.slice(1)] }, context));
});
test("a response for another lesson or language cannot be displayed as the selection", () => {
  const bundle = bundles[0];
  assert.throws(() => parseTranslation(bundle, { ...expected, language: bundle.language, lessonId: "02" }), /different lesson or language/);
  assert.throws(() => parseTranslation(bundle, { ...expected, language: "vi" }), /different lesson or language/);
});

const titleLessons = await Promise.all((await readdir(new URL("../content/lessons/", import.meta.url))).filter(name => name.endsWith(".json")).map(async name => JSON.parse(await readFile(new URL(`../content/lessons/${name}`, import.meta.url), "utf8"))));
const titleBundles = await Promise.all(translationCodes.map(async language => JSON.parse(await readFile(new URL(`../content/title-translations/${language}.json`, import.meta.url), "utf8"))));
test("every title language covers the whole catalog and matches its existing lesson 001 translation", () => {
  for (const bundle of titleBundles) {
    const parsed = parseTitleTranslations(bundle, bundle.language, titleLessons);
    assert.equal(parsed.titles.length, titleLessons.length);
    assert.equal(parsed.titles.find(item => item.lessonId === lesson.id).title, bundles.find(item => item.language === bundle.language).title);
  }
});
test("decomposed accents and Hangul normalize for display without changing source identity", () => {
  for (const bundle of bundles) {
    const parsed = parseTranslation({ ...bundle, title: bundle.title.normalize("NFD"), paragraphs: bundle.paragraphs.map(text => text.normalize("NFD")) }, { ...expected, language: bundle.language });
    assert.equal(parsed.title, bundle.title.normalize("NFC"));
    assert.deepEqual(parsed.paragraphs, bundle.paragraphs.map(text => text.normalize("NFC")));
    assert.equal(parsed.sourceScriptSha256, expected.sourceScriptSha256);
    assert.equal(parsed.sourceTitle, expected.sourceTitle);
  }
  for (const bundle of titleBundles) {
    const parsed = parseTitleTranslations({ ...bundle, titles: bundle.titles.map(item => ({ ...item, title: item.title.normalize("NFD") })) }, bundle.language, titleLessons);
    assert.deepEqual(parsed.titles.map(item => item.title), bundle.titles.map(item => item.title.normalize("NFC")));
  }
});
test("stale or wrong-language title responses are rejected", () => {
  const bundle = titleBundles[0];
  assert.throws(() => parseTitleTranslations(bundle, "vi", titleLessons), /different language/);
  assert.throws(() => parseTitleTranslations(bundle, bundle.language, titleLessons.map(item => item.id === lesson.id ? { ...item, title: "Changed English title" } : item)), /matching current English title/);
});
test("duplicate IDs and partial title catalogs are rejected rather than mixed with another language", () => {
  const bundle = titleBundles[0];
  assert.throws(() => parseTitleTranslations({ ...bundle, titles: bundle.titles.slice(1) }, bundle.language, titleLessons), /every published/);
  assert.throws(() => parseTitleTranslations({ ...bundle, titles: [bundle.titles[0], ...bundle.titles.slice(0, -1)] }, bundle.language, titleLessons), /Duplicate/);
});

for (const stem of ["002", "003", "004", "005"]) {
  const source = JSON.parse(await readFile(new URL(`../content/lessons/${stem}.json`, import.meta.url), "utf8"));
  const folder = new URL(`../content/translations/${stem}/`, import.meta.url);
  const filenames = (await readdir(folder)).sort();
  const translated = await Promise.all(translationCodes.map(async language => JSON.parse(await readFile(new URL(`${language}.json`, folder), "utf8"))));
  test(`lesson ${stem} has eight complete, current translations aligned with its home titles`, () => {
    assert.deepEqual(filenames, translationCodes.map(language => `${language}.json`).sort());
    const context = { lessonId: source.id, sourceTitle: source.title, sourceScriptSha256: createHash("sha256").update(plainScript(source.script)).digest("hex"), paragraphCount: scriptParagraphs(source.script).length };
    for (const bundle of translated) {
      const parsed = parseTranslation(bundle, { ...context, language: bundle.language });
      const catalogTitle = titleBundles.find(item => item.language === bundle.language).titles.find(item => item.lessonId === source.id).title;
      assert.equal(parsed.title, catalogTitle.normalize("NFC"));
      assert.equal(parsed.paragraphs.length, context.paragraphCount);
      assert.ok(parsed.paragraphs.every((paragraph, index) => paragraph !== plainScript(scriptParagraphs(source.script)[index])));
      assert.ok(parsed.paragraphs.every(paragraph => !paragraph.includes("**") && !paragraph.includes("\ufffd")));
    }
  });
}
