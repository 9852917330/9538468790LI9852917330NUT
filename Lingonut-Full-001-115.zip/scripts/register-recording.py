from pathlib import Path
import datetime,hashlib,html,json,re,shutil,subprocess,sys,unicodedata

root=Path(__file__).resolve().parent.parent
stem,mp3_arg,vtt_arg,voice=sys.argv[1:]
assert re.fullmatch(r'\d{3,4}',stem)
lesson=json.loads((root/'content/lessons'/f'{stem}.json').read_text())
script=lesson['script'].replace('**','').strip()
vtt=Path(vtt_arg).read_text()
chunks=re.split(r'\n\s*\n',vtt.strip())[1:]
spoken=' '.join(' '.join(chunk.splitlines()[2:]) for chunk in chunks)
def norm(value):
    value=unicodedata.normalize('NFKD',html.unescape(value)).lower()
    return re.sub(r'[^a-z0-9]','',value)
if norm(script)!=norm(spoken):raise ValueError(f'{stem}: TTS subtitles do not match the complete script.')
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration:stream=codec_name','-of','json',mp3_arg]))
duration=float(probe['format']['duration'])
assert duration>60 and probe['streams'][0]['codec_name']=='mp3'
subprocess.run(['ffmpeg','-v','error','-i',mp3_arg,'-f','null','-'],check=True)
audio=root/'content/audio';subtitles=root/'content/subtitles';subtitles.mkdir(exist_ok=True)
shutil.copyfile(mp3_arg,audio/f'{stem}.mp3');shutil.copyfile(vtt_arg,subtitles/f'{stem}.vtt')
meta={'provider':'Microsoft Edge Read Aloud via edge-tts','voice':voice,'scriptSha256':hashlib.sha256(script.encode()).hexdigest(),'registeredAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'durationSeconds':duration,'completeSubtitleMatch':True}
(audio/f'{stem}.meta.json').write_text(json.dumps(meta,indent=2)+'\n')
published=sorted((json.loads(p.read_text()) for p in (root/'content/lessons').glob('*.json')),key=lambda item:item['order'])
text_ready=[f"{item['order']:03}" for item in published if item.get('published',True)]
ready=[number for number in text_ready if (audio/f'{number}.mp3').is_file()]
production_path=root/'content/production.json'
progress=json.loads(production_path.read_text()) if production_path.exists() else {}
progress.update({'textReady':text_ready,'audioReady':ready,'pendingAudio':[number for number in text_ready if number not in ready],'audioCheck':'Complete TTS subtitle match and successful MP3 decoding; pronunciation not independently reviewed.'})
production_path.write_text(json.dumps(progress,indent=2)+'\n')
progress_path=root/'PROGRESS.md'
notes=progress_path.read_text() if progress_path.exists() else '# Lingonut\n'
for label,numbers in [('Audio ready',ready),('Audio pending',progress['pendingAudio'])]:
    line=label+': '+', '.join(numbers)
    notes=re.sub(r'^'+label+r':.*$',lambda match:line,notes,flags=re.MULTILINE) if re.search(r'^'+label+r':',notes,re.MULTILINE) else notes.rstrip()+'\n\n'+line+'\n'
notes=notes.rstrip()+f'\n\nRecording registered ({datetime.date.today().isoformat()}): lesson {stem}, {voice}, complete subtitle match and successful MP3 decoding.\n'
progress_path.write_text(notes)
print(json.dumps({'lesson':stem,'voice':voice,'durationSeconds':duration,'completeSubtitleMatch':True,'audioSaved':len(ready)}))
