"""Reviewed new English overviews for Lingonut's English-first collection."""
from importlib.machinery import SourceFileLoader
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent.parent
h=SourceFileLoader('lesson_batch',str(Path(__file__).with_name('lesson-batch.py'))).load_module()
h.DATE='2026-11-22'
v,m,g,draft=h.vocab,h.mcq,h.gap,h.write_draft

identities=[
 (111,'meiji-restoration-japan-1868','The Meiji Restoration: Building a New Japanese State',['Meiji Restoration 1868','Japan Meiji Restoration']),
 (112,'cosmic-microwave-background-discovery-1965','The Cosmic Microwave Background: Finding a Trace of the Early Universe',['Discovery of cosmic microwave background','Penzias Wilson background radiation 1965']),
 (113,'haitian-revolution-independence-1791-1804','The Haitian Revolution: Slavery, Independence and the Cost of Freedom',['Haitian Revolution','Haitian independence 1804','Saint-Domingue revolution 1791']),
 (114,'san-francisco-earthquake-fire-1906','San Francisco 1906: Earthquake, Fire and Recovery',['San Francisco earthquake and fire 1906','1906 San Francisco earthquake']),
 (115,'transatlantic-telegraph-cables-1858-1866','Transatlantic Telegraph Cables: From Early Failure to Lasting Connection',['First transatlantic telegraph cable','Atlantic telegraph cables 1858 1866'])
]
path=ROOT/'content/topics.json';ledger=json.loads(path.read_text())
for n,key,label,aliases in identities:
 row={'order':n,'eventKey':key,'label':label,'aliases':aliases,'reviewedAgainstThrough':n-1,'reviewedOn':h.DATE}
 prior=next((x for x in ledger['topics'] if x['order']==n),None)
 if prior is None:ledger['topics'].append(row)
 else:assert prior==row
path.write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')

draft(111,'meiji-restoration-japan-1868',identities[0][2],'World Events and Political Change',
      'Foreign pressure and domestic conflict ended the Tokugawa order, while new leaders centralised government and transformed Japan over decades of reform and resistance.',
'''In the mid-nineteenth century, Japan's Tokugawa **shogun** exercised military and political power, while the emperor remained an important source of legitimacy. Regional lords governed their own territories. This order faced growing internal tensions and pressure from abroad.

Commodore Matthew Perry's arrival with American warships in 1853, and the **treaties** that followed, intensified debate over foreign relations. Critics questioned whether the shogunate could protect Japan. Powerful opponents sought a new political arrangement centred on the emperor.

The last Tokugawa shogun returned political authority in 1867. In 1868, new leaders declared imperial rule **restored**. The young Emperor Meiji became the centre of the new order, although influential politicians and former regional leaders shaped its policies.

The change was not simply peaceful. The Boshin War, fought from 1868 to 1869, brought victory to the new government's forces over supporters of the old order. Establishing authority required military success as well as political agreements.

In 1871, the government abolished the old **domains** and replaced them with prefectures under central administration. This reduced hereditary lords' power and helped **centralise** government and finance.

**Conscription** created a national army. Samurai **privileges** were removed over the following years, while education, industry and transport expanded. These changes brought opportunities, but also new demands through taxation and military service.

Resistance continued. The government defeated the Satsuma Rebellion in 1877. Meanwhile, campaigners in the Freedom and People's Rights Movement demanded a national assembly and greater political participation.

A **constitution** was issued in 1889, and the Imperial Diet opened in 1890. Voting remained limited and imperial authority remained strong. Japan's growing strength also supported later imperial expansion. The restoration transformed the state through conflict and reform; it did not create an equal, fully democratic society in a single moment.''',
[
v('shogun','A hereditary military ruler of Japan during certain periods of its history.','The shogun exercised political power in the emperor’s name.','Noun',plural='shoguns'),
v('treaty','A formal agreement between states.','The treaty opened new ports to foreign trade.','Noun',form='treaties',plural='treaties'),
v('restore','To bring back a previous condition, position or arrangement.','The leaders promised to restore imperial authority.','Verb',form='restored',verb=('restore','restored','restored',False)),
v('domain','A territory controlled by a particular ruler or authority.','The lord governed a large domain.','Noun',form='domains',plural='domains'),
v('centralise','To bring power or administration under one central authority.','The reforms aimed to centralise government finance.','Verb',verb=('centralise','centralised','centralised',False)),
v('conscription','The compulsory recruitment of people into military service.','Conscription supplied soldiers for the national army.','Uncountable noun',form='Conscription'),
v('privilege','A special right or advantage available to a particular person or group.','The reform removed a hereditary privilege.','Noun',form='privileges',plural='privileges'),
v('constitution','The basic laws and principles that define a state’s government.','The constitution established a national legislature.','Noun',plural='constitutions')
],
[
m('What helped bring about the change in government?',['Foreign pressure combined with domestic tensions and opposition to the shogunate.','The emperor abolished regional government before foreign ships reached Japan.','The shogun introduced universal voting to end criticism of foreign treaties.'],'A','This order faced growing internal tensions and pressure from abroad.','The following paragraphs connect foreign relations, political opposition and the restoration.'),
m('Why was abolishing the old domains important?',['It returned national taxation to independent regional lords.','It moved power and administration towards the central government.','It ended all political resistance without further military action.'],'B','This reduced hereditary lords\' power and helped centralise government and finance.','The replacement of domains by prefectures was part of state-building.'),
m('How does the passage describe the later constitutional system?',['It allowed every adult to vote as soon as imperial rule was declared.','It immediately removed the emperor from political life.','It introduced national institutions while retaining limited voting and strong imperial authority.'],'C','Voting remained limited and imperial authority remained strong.','The passage distinguishes constitutional change from immediate and complete democracy.'),
g('New leaders declared imperial rule restored in ___.','1868','In 1868, new leaders declared imperial rule restored.','The formal return of authority in 1867 was followed by a new declaration and conflict.'),
g('The old domains were abolished in ___.','1871','In 1871, the government abolished the old domains and replaced them with prefectures under central administration.','Prefectures replaced the earlier territorial system.'),
g('Compulsory military recruitment is called ___.','conscription','Conscription created a national army.','This reform supplied personnel for the new national military.')
],
[
'National Diet Library, Modern Japan in Archives, Initial Steps toward a Constitutional State — Perry, political arguments, 1867 return, 1868 state formation and rights movements: https://www.ndl.go.jp/modern/e/cha1/index.html',
'National Diet Library, Evolution of the Meiji State — 1889 constitution, 1890 Diet and government-party conflict: https://www.ndl.go.jp/modern/e/cha2/index.html',
'National Diet Library, Constitution of the Empire of Japan — Primary constitutional text and imperial authority: https://www.ndl.go.jp/constitution/e/etc/c02.html',
'Japan International Cooperation Agency, Japan 150 years after the Meiji Restoration — Domain abolition, conscription, education and timeline of state development: https://www.jica.go.jp/english/about/president/archives_kitaoka/speech/181019_01.html'
],
[
'Compared against all 110 completed events, aliases, reserved candidates and the other four new topics. This restoration and state-building event is distinct from earlier Japanese disasters and wartime events.',
'The 1867 return of authority, 1868 restoration and Boshin War through 1869 are distinct stages. The young emperor is not treated as a solitary designer of every reform.',
'Centralisation, the loss of samurai privileges, military service and political resistance accompany economic and educational change. Opening is not described as the first foreign contact in all Japanese history.',
'The 1889 constitution and 1890 Diet did not mean universal suffrage. Later imperial expansion is acknowledged without presenting conquest as moral greatness.'
])

draft(112,'cosmic-microwave-background-discovery-1965',identities[1][2],'Science and Major Discoveries',
      'Persistent microwave noise, careful instrument checks and cosmological theory came together to identify radiation left from an early stage of the universe.',
'''In 1964, Arno Penzias and Robert Wilson were studying microwave signals at Bell Laboratories in New Jersey. Their large horn-shaped **antenna** detected an unexpected background signal. At first, it looked like a problem with the equipment or its surroundings.

They searched for **interference**, checked the receiver and **calibrated** their instruments. They even removed debris left by birds inside the antenna. The excess signal remained after these practical explanations had been investigated.

The noise was **persistent** and appeared across the sky. Nearby, Robert Dicke's team at Princeton University was preparing to search for radiation from the early universe. Earlier researchers, including Ralph Alpher and Robert Herman, had already predicted such a background.

In a hot early universe, matter and **radiation** interacted closely. After the universe cooled enough for neutral atoms to form, light could travel freely. As space **expanded**, its wavelengths stretched. This ancient radiation is now detected mainly as microwaves.

Contact between the Bell Labs and Princeton groups connected the unexplained measurements with this interpretation. In 1965, two accompanying papers appeared: one reported the observations, while the other explained their cosmological significance.

The discovery strongly supported models of a hot early universe and challenged the competing steady-state picture. It was not a photograph of the initial instant, nor an answer to every question about cosmic origins. Observations and theoretical interpretation had different, complementary roles.

Penzias and Wilson received a share of the 1978 Nobel Prize in Physics for their discovery. Later satellite missions measured the background's **spectrum** and tiny differences across the sky much more precisely, allowing further tests of cosmological models.

The cosmic microwave background became a major source of **evidence** about the universe's history. Its discovery combined an unexpected observation with patient checking and ideas developed by several researchers. A signal first treated as unwanted noise became a way to investigate the distant past.''',
[
v('antenna','A device for receiving or transmitting electromagnetic signals.','The antenna detected a faint signal from the sky.','Noun',plural='antennas'),
v('interference','An unwanted disturbance that affects a signal or measurement.','The team checked whether local interference explained the noise.','Uncountable noun'),
v('calibrate','To check and adjust an instrument against a known standard.','The researchers needed to calibrate the receiver carefully.','Verb',form='calibrated',verb=('calibrate','calibrated','calibrated',False)),
v('persistent','Continuing to exist or occur despite efforts to stop or explain it.','A persistent signal remained after the equipment was cleaned.','Adjective'),
v('radiation','Energy transmitted through space or matter as waves or particles.','The instrument measured microwave radiation.','Uncountable noun'),
v('expand','To become larger or increase in extent.','As space continues to expand, light travelling through it is stretched.','Verb',form='expanded',verb=('expand','expanded','expanded',False)),
v('spectrum','The distribution of radiation over different wavelengths or frequencies.','The measured spectrum closely matched the theoretical prediction.','Noun',plural='spectra'),
v('evidence','Information or observations that help establish whether an explanation is supported.','The measurements provided evidence for a hot early universe.','Uncountable noun')
],
[
m('Why did Penzias and Wilson check and clean their equipment?',['They were preparing an optical photograph of the initial instant of the universe.','They wanted to test practical explanations for an unexpected signal.','They already knew that every source of microwave noise was cosmological.'],'B','At first, it looked like a problem with the equipment or its surroundings.','Their investigation tested interference and instrument problems before the cosmological interpretation.'),
m('Why is the ancient radiation detected mainly as microwaves today?',['The antenna converted light from nearby birds into a cosmic signal.','The universe has remained at exactly the same size since the radiation was released.','The expansion of space stretched its wavelengths.'],'C','As space expanded, its wavelengths stretched.','The preceding sentences place the radiation in the cooling early universe.'),
m('What did contact with the Princeton group contribute?',['It connected the measured signal with a theoretical explanation of its cosmic origin.','It replaced observations with a claim that no measurement was necessary.','It showed that the signal disappeared when the antenna was cleaned.'],'A','Contact between the Bell Labs and Princeton groups connected the unexplained measurements with this interpretation.','The two papers had complementary observational and theoretical roles.'),
g('The two accompanying discovery papers appeared in ___.','1965','In 1965, two accompanying papers appeared: one reported the observations, while the other explained their cosmological significance.','The measurements began before the papers were published.'),
g('Robert Dicke’s team worked at ___ University.','Princeton','Nearby, Robert Dicke\'s team at Princeton University was preparing to search for radiation from the early universe.','The Princeton group supplied the relevant theoretical interpretation.'),
g('Penzias and Wilson received their Nobel recognition in ___.','1978','Penzias and Wilson received a share of the 1978 Nobel Prize in Physics for their discovery.','The Nobel award came after the discovery papers.')
],
[
'NASA, WMAP Overview — Early background radiation and later all-sky measurements: https://science.nasa.gov/mission/wmap/wmap-overview/',
'Arno Penzias, Nobel Lecture, 1978 — Primary account of Bell Labs measurements, instrument checks and contact with theoretical cosmology: https://www.nobelprize.org/uploads/2018/06/penzias-lecture.pdf',
'NASA Goddard, Cosmic Times, Murmur of a Bang — 1965 discovery narrative and the complementary papers; historical classroom reconstruction is not used for modern cosmic-age or temperature claims: https://imagine.gsfc.nasa.gov/educators/programs/cosmictimes/online_edition/1965/murmur.html',
'ESA, Planck and the cosmic microwave background — Neutral atoms, freely travelling early light, expansion and modern observations: https://www.esa.int/articles/about-us/directorates/science/planck/planck-and-the-cosmic-microwave-background',
'Nobel Committee, Scientific Background on the Nobel Prize in Physics 2019 — Dicke, Peebles, Roll and Wilkinson, the 1965 papers and cosmological interpretation; indexed text consulted when PDF fetch returned 403: https://www.nobelprize.org/uploads/2019/10/advanced-physicsprize2019.pdf'
],
[
'Checked against the full 110-topic ledger and the four other new subjects. Background-radiation detection is distinct from Sputnik, the 1919 eclipse and particle-physics discoveries.',
'1964 measurements and 1965 publication are distinguished. Theoretical predictions preceded detection; Princeton and earlier researchers are acknowledged rather than assigning all theory to the two observers.',
'The background is radiation from an early transparent stage, not a direct image of the initial instant. Expansion stretches wavelengths. No claim is made that discovery settled every cosmological question.',
'The 1978 Nobel award is described as a share, avoiding omission of the separate half awarded to Pyotr Kapitsa. Historical NASA classroom text is not treated as a source of present-day numerical parameters.'
])

draft(113,'haitian-revolution-independence-1791-1804',identities[2][2],'Wars and Historical Turning Points',
      'An uprising against plantation slavery developed through shifting alliances and war into an independent state, followed by violence, foreign pressure and a heavy financial burden.',
'''Before independence, Haiti was the French colony of Saint-Domingue. Sugar and coffee **plantations** produced wealth through the labour of **enslaved** Africans. Racial inequality, brutal working conditions and struggles among different free groups shaped colonial society.

The French Revolution opened arguments about rights and authority. In 1791, a major uprising began among enslaved people in the colony's north. The struggle developed into a complex war involving local factions, France, Spain and Britain.

French commissioners proclaimed **emancipation** in the colony in 1793. In 1794, France's revolutionary government abolished slavery across its colonies. These decisions changed alliances, but did not immediately end fighting or resolve who would control the territory.

Toussaint Louverture, a formerly enslaved leader, became a dominant figure. He built considerable **autonomy** while maintaining formal ties to France. Freedom from slavery and political separation from France were related questions, but not identical goals at every stage.

In 1802, Napoleon sent forces to restore French control. Louverture was captured and **deported** to France, where he died in 1803. Renewed resistance under Jean-Jacques Dessalines and other leaders defeated French forces, which also suffered heavily from disease.

On January 1, 1804, Dessalines and other commanders declared Haiti independent. The new state emerged from a successful revolt against slavery and asserted Black **sovereignty** in a world where powerful states still defended slaveholding and colonial rule.

Victory did not end violence. In 1804, Dessalines ordered the **massacre** of many remaining white French inhabitants. War had devastated communities and farms, and building the new state brought further political conflict.

In 1825, France demanded a large **indemnity** in exchange for recognition, backed by military pressure. Payments and related loans burdened later generations. The revolution destroyed slavery and colonial rule, but defending freedom and independence continued to require struggles against foreign pressure and internal division.''',
[
v('plantation','A large agricultural estate producing crops, especially in a colonial setting.','The plantation produced sugar for overseas markets.','Noun',form='plantations',plural='plantations'),
v('enslave','To force a person into slavery and treat them as property.','Colonial traders helped enslave people for forced labour.','Verb',form='enslaved',verb=('enslave','enslaved','enslaved',False)),
v('emancipation','The act or process of freeing people from slavery or other legal restrictions.','The declaration promised emancipation from slavery.','Uncountable noun'),
v('autonomy','The ability of a territory or group to govern its own affairs.','The territory gained greater autonomy while retaining formal ties to the empire.','Uncountable noun'),
v('deport','To force a person to leave a country or territory.','The authorities decided to deport the captured leader.','Verb',form='deported',verb=('deport','deported','deported',False)),
v('sovereignty','A state’s authority to govern itself independently.','The new government demanded recognition of its sovereignty.','Uncountable noun'),
v('massacre','The deliberate killing of many people, especially those unable to defend themselves.','The massacre left lasting trauma among survivors.','Noun',plural='massacres'),
v('indemnity','A payment demanded or agreed as compensation for a loss or damage.','The indemnity imposed a heavy burden on the country.','Noun',plural='indemnities')
],
[
m('How does the passage describe the revolution’s development?',['A brief disagreement between two French officials ended slavery without war.','All groups pursued complete separation from France from the beginning.','An uprising developed into a wider conflict with shifting alliances and changing goals.'],'C','The struggle developed into a complex war involving local factions, France, Spain and Britain.','Later paragraphs distinguish emancipation, autonomy and independence.'),
m('Which distinction is important in understanding Louverture’s position?',['Freedom from slavery did not always mean immediate political separation from France.','Autonomy meant accepting the permanent restoration of plantation slavery.','France had already recognised Haitian independence before Louverture became a leader.'],'A','Freedom from slavery and political separation from France were related questions, but not identical goals at every stage.','His autonomy coexisted with formal ties to France.'),
m('Why does the story continue beyond the independence declaration?',['The declaration immediately ended every form of violence and foreign pressure.','The new state faced internal violence and later a financially damaging demand for recognition.','The 1825 indemnity was the event that first abolished slavery in the colony.'],'B','Payments and related loans burdened later generations.','The final paragraphs describe both post-independence violence and the later French demand.'),
g('The major uprising began in ___.','1791','In 1791, a major uprising began among enslaved people in the colony\'s north.','The revolt grew into a longer revolutionary struggle.'),
g('Haiti declared independence on January 1, ___.','1804','On January 1, 1804, Dessalines and other commanders declared Haiti independent.','The declaration followed the defeat of French forces.'),
g('France demanded an indemnity in ___.','1825','In 1825, France demanded a large indemnity in exchange for recognition, backed by military pressure.','The demand came years after Haiti had declared independence.')
],
[
'US Department of State, Office of the Historian, The United States and the Haitian Revolution — Plantation economy, racial divisions, multi-sided war, Louverture, post-independence killings and recognition: https://history.state.gov/milestones/1784-1800/haitian-rev',
'Bibliothèque nationale de France, Jean-Jacques Dessalines and the Independence of Haiti — Emancipation, changing alliances, war, declaration and 1804 violence, with digitised primary documents: https://heritage.bnf.fr/france-ameriques/en/jean-jacques-dessalines-and-independence-haiti',
'Bibliothèque nationale de France, Haiti’s independence debt — The 1825 recognition demand, compensation to former colonists and the debt structure: https://heritage.bnf.fr/france-ameriques/en/haitis-independence-debt-slave-unit-account-1794-1922',
'United Nations in the Caribbean, How Haiti paid for its freedom twice over — Military pressure in 1825 and long-term financial burden: https://caribbean.un.org/en/293392-how-haiti-paid-its-freedom-%E2%80%93-twice-over'
],
[
'Compared against all 110 previous events and the other new subjects. This antislavery and independence revolution is distinct from the French Revolution and the US Emancipation Proclamation.',
'The central actors include enslaved people, with different free groups and foreign powers also present. No claim is made that everyone sought independence from the outset or that emancipation immediately ended war.',
'Louverture’s death in France in 1803 is distinguished from Dessalines and the January 1804 declaration. Disease accompanied military resistance; it is not treated as the sole cause of French defeat.',
'The 1804 killings are acknowledged without graphic description or an unsupported exact total. French recognition in 1825 is not confused with the earlier creation of an independent state. No modern currency conversion is asserted.'
])

draft(114,'san-francisco-earthquake-fire-1906',identities[3][2],'Disasters and Human Responses',
      'A major fault rupture damaged northern California, while broken utilities and spreading fires turned the earthquake into a prolonged urban disaster and a turning point in earthquake science.',
'''On April 18, 1906, a powerful earthquake struck northern California. Movement along the San Andreas **fault** shook San Francisco and surrounding communities. Buildings collapsed, chimneys fell and residents rushed into the streets as the city began a major emergency.

The damage extended beyond the first broken buildings. Falling **debris** blocked routes, while broken gas pipes helped start fires. Water mains also failed, reducing the supply available to firefighters just as flames were spreading.

The fires developed into a vast **conflagration** that burned for about three days. They destroyed much of central San Francisco and caused more destruction than the initial shaking alone. The earthquake and fire formed a connected disaster rather than two unrelated events.

Firefighters, soldiers and volunteers tried to contain the flames. Troops **demolished** buildings to make firebreaks. These actions were dangerous, and some attempts were unsuccessful; the extent to which dynamiting helped or worsened damage remains debated.

Residents **evacuated** threatened districts and carried what possessions they could. Many found **shelter** in parks, tents and military areas such as the Presidio. Food, drinking water and medical supplies became urgent needs. Aid arrived from elsewhere, but hardship continued after the fires ended.

Later research estimated more than 3,000 deaths and about 225,000 people left homeless. Early official counts understated the loss. These figures describe the combined catastrophe, including deaths caused directly or indirectly by its effects.

Investigators also mapped the fault and measured how the ground had moved. Their evidence helped Henry Fielding Reid develop the theory of elastic **rebound**: rocks accumulate strain and release stored energy when a fault suddenly slips. This advanced understanding rather than providing exact predictions of the next earthquake.

Rebuilding changed the city, while better construction, water systems and emergency planning remained important. The disaster showed that urban **resilience** depends on interconnected systems. Its consequences continued long after the ground stopped shaking.''',
[
v('fault','A fracture or zone of fractures in the Earth’s crust where blocks of rock can move relative to each other.','The earthquake occurred along a major fault.','Noun',plural='faults'),
v('debris','Scattered pieces left after something is broken or destroyed.','Debris blocked the road after the buildings collapsed.','Uncountable noun'),
v('conflagration','A large and destructive fire.','The conflagration spread through several city districts.','Noun',plural='conflagrations'),
v('demolish','To deliberately destroy or pull down a building or structure.','The team had to demolish the unsafe building.','Verb',form='demolished',verb=('demolish','demolished','demolished',False)),
v('evacuate','To leave, or move people away from, a place because of danger.','Residents were told to evacuate the threatened neighbourhood.','Verb',form='evacuated',verb=('evacuate','evacuated','evacuated',False)),
v('shelter','Protection or a place providing protection from danger or the weather.','Families found shelter in temporary camps.','Uncountable noun'),
v('rebound','A return or springing back towards a previous position or condition.','Elastic rebound helps explain the release of stored strain during an earthquake.','Noun',plural='rebounds',note='Elastic rebound is the geological expression used in the story.'),
v('resilience','The ability to withstand difficulties and recover after disruption.','Reliable water supplies can improve a city’s resilience.','Uncountable noun')
],
[
m('Why did damaged water mains make the emergency worse?',['They increased the earthquake’s magnitude along the entire fault.','They reduced firefighting capacity while fires were spreading.','They prevented the later movement of any aid into California.'],'B','Water mains also failed, reducing the supply available to firefighters just as flames were spreading.','The story connects utility failures with the growth of the fires.'),
m('What do the death estimates in the passage refer to?',['Only people struck by falling chimneys in the first seconds.','Every resident who left California during rebuilding.','The combined catastrophe and its direct or indirect effects.'],'C','These figures describe the combined catastrophe, including deaths caused directly or indirectly by its effects.','The passage distinguishes later research from incomplete early official counts.'),
m('What was a major scientific result of the investigations?',['Evidence helped explain how stored strain is released when a fault slips.','Researchers learned the exact date of the next major earthquake.','Scientists showed that fires cause movement along the San Andreas fault.'],'A','Their evidence helped Henry Fielding Reid develop the theory of elastic rebound: rocks accumulate strain and release stored energy when a fault suddenly slips.','The theory improved understanding of earthquake mechanics without supplying precise predictions.'),
g('The earthquake occurred in April ___.','1906','On April 18, 1906, a powerful earthquake struck northern California.','The opening sentence gives the date and region.'),
g('The earthquake involved the San ___ fault.','Andreas','Movement along the San Andreas fault shook San Francisco and surrounding communities.','The fault extends beyond the city itself.'),
g('One military area used for shelter was the ___.','Presidio','Many found shelter in parks, tents and military areas such as the Presidio.','The passage describes temporary refuge for displaced residents.')
],
[
'US Geological Survey, Casualties and damage after the 1906 Earthquake — Later death estimates, about 225,000 homeless, and the greater destruction caused by the fire: https://earthquake.usgs.gov/earthquakes/events/1906calif/18april/casualties.php',
'US National Park Service, 1906 Earthquake: Fire Fighting — Broken gas and water mains, firebreaks, military demolitions, three-day fires and debate over their effects: https://www.nps.gov/prsf/learn/historyculture/1906-earthquake-fire-fighting.htm',
'US National Archives, San Francisco Earthquake, 1906 — Refuge, supplies, congressional aid and prolonged hardship: https://www.archives.gov/legislative/features/sf',
'US Geological Survey, Reid’s Elastic Rebound Theory — Ground displacement evidence and earthquake mechanics: https://earthquake.usgs.gov/earthquakes/events/1906calif/18april/reid.php'
],
[
'Reviewed against the complete ledger. This 1906 northern California earthquake and fire is distinct from the Japanese earthquake and tsunami, Lisbon, and the Indian Ocean tsunami.',
'Shaking and fires are connected through damaged buildings and utility networks. Effects beyond San Francisco are acknowledged; no tsunami is invented as the main urban cause.',
'More than 3,000 is a later estimate for direct and indirect deaths, not a precise first-day official count. About 225,000 homeless follows USGS; uncertainty is retained.',
'Dynamiting is neither celebrated as uniformly successful nor asserted to have caused every fire. Scientific understanding and exact event prediction are kept distinct.'
])

draft(115,'transatlantic-telegraph-cables-1858-1866',identities[4][2],'Technology and Global Connections',
      'Repeated failures, improved cable design and large-scale marine engineering established a lasting electrical connection across the Atlantic and transformed long-distance communication.',
'''By the mid-nineteenth century, telegraphs could **transmit** coded messages rapidly over land. Communication across the Atlantic still depended on ships carrying letters. Engineers and investors wanted an electrical link between Europe and North America.

Businessman Cyrus Field helped organise funding and international cooperation. The proposed cable needed a copper **conductor**, strong **insulation** and protection against damage. Manufacturing, testing and laying thousands of kilometres of cable required factories, crews and specialised equipment.

An expedition failed in 1857 when the cable broke. In 1858, ships finally completed a connection between Ireland and Newfoundland. Queen Victoria and President James Buchanan exchanged messages in August, and celebrations greeted the achievement. Each weak **signal** was slow and difficult to read.

The connection failed within weeks. Weak insulation and other **faults** undermined the system; high voltages damaged it further. A successful public demonstration had not yet produced a lasting service. The failure made technical investigation essential.

Engineers improved cable construction, tests and receiving instruments. William Thomson, later Lord Kelvin, helped develop sensitive methods for reading weak signals. Commercial backers also had to rebuild confidence and obtain new investment.

In 1865, the huge steamship Great Eastern carried a new cable across the ocean. It had space for the complete load, but the cable broke during laying and could not be recovered that year. The project faced another expensive setback.

In July 1866, Great Eastern successfully laid a new connection. Teams then **retrieved** and completed the broken 1865 cable, providing a second working line. A more **reliable** transatlantic service had emerged from repeated attempts, not from the first celebration alone.

News, finance and diplomacy could now cross the ocean far faster. Messages remained costly, and control of the **network** carried commercial and political power. The achievement depended on sustained cooperation among investors, scientists, factory workers, sailors and repair teams. Long-distance communication had changed because practical reliability finally matched the original ambition.''',
[
v('transmit','To send a signal, message or information from one place to another.','The cable could transmit coded messages across the ocean.','Verb',verb=('transmit','transmitted','transmitted',False)),
v('conductor','A material or object through which an electrical current can flow.','Copper served as the cable’s conductor.','Noun',plural='conductors'),
v('insulation','Material or protection that limits the flow of electricity, heat or sound.','Damaged insulation allowed the electrical signal to leak.','Uncountable noun'),
v('signal','A transmitted electrical or electromagnetic change that carries information.','The receiver detected a weak signal.','Noun',plural='signals'),
v('fault','A defect or problem that prevents something from working correctly.','Tests revealed a fault in the cable.','Noun',form='faults',plural='faults',note='Here fault means a technical defect, rather than a geological fracture.'),
v('retrieve','To find and bring something back.','The crew tried to retrieve the broken cable.','Verb',form='retrieved',verb=('retrieve','retrieved','retrieved',False)),
v('reliable','Able to be trusted to work consistently or correctly.','The improved cable provided a more reliable connection.','Adjective'),
v('network','A connected system of routes, equipment or people.','The telegraph network linked distant centres of trade.','Noun',plural='networks')
],
[
m('What does the 1858 connection show about technological success?',['A first working demonstration can still fall short of a durable service.','Any cable that carries one message is certain to work for decades.','The Atlantic connection had already become reliable before the first expedition.'],'A','A successful public demonstration had not yet produced a lasting service.','The passage distinguishes celebration from the need for reliable operation.'),
m('Why was Great Eastern useful for cable laying?',['It eliminated the need to manufacture and test a new cable.','It could carry the entire cable load in one ship.','It sent messages without any electrical conductor.'],'B','It had space for the complete load, but the cable broke during laying and could not be recovered that year.','Its carrying capacity helped, although the 1865 attempt still failed.'),
m('How does the passage explain the eventual achievement?',['One investor succeeded without scientific advice, factory labour or ship crews.','The first cable worked permanently once higher voltages were applied.','Repeated attempts combined investment, improved engineering and many forms of labour.'],'C','The achievement depended on sustained cooperation among investors, scientists, factory workers, sailors and repair teams.','The narrative includes both technical improvements and sustained cooperation.'),
g('The first completed connection in this story was made in ___.','1858','In 1858, ships finally completed a connection between Ireland and Newfoundland.','The early link was followed by failure within weeks.'),
g('The large cable-laying steamship was Great ___.','Eastern','In 1865, the huge steamship Great Eastern carried a new cable across the ocean.','The same vessel succeeded the following year.'),
g('A successful new connection was laid in July ___.','1866','In July 1866, Great Eastern successfully laid a new connection.','Teams then recovered and completed the previous year’s cable.')
],
[
'Institution of Engineering and Technology Archives, The first transatlantic telegraph cable 1858 — Original collection context, first expeditions, celebrations, weak signals, insulation and high-voltage damage: https://www.theiet.org/membership/library-and-archives/the-iet-archives/archives-highlights/the-first-transatlantic-telegraph-cable-1858',
'Institution of Engineering and Technology Archives, The Transatlantic Telegraph Cables 1865–1866 — Testing, Thomson, Great Eastern, 1865 failure and 1866 recovery: https://www.theiet.org/membership/library-and-archives/the-iet-archives/archives-highlights/the-transatlantic-telegraph-cables-1865-1866',
'Royal Museums Greenwich, The steamship Great Eastern laying the first successful Atlantic cable — Collection object and 1865/1866 expeditions: https://www.rmg.co.uk/collections/objects/rmgc-object-14853',
'Royal Museums Greenwich, Henry Clifford archive — Cable machinery, engineering labour and successive expeditions: https://www.rmg.co.uk/collections/archive/rmgc-object-463591'
],
[
'Compared with all 110 completed events and the other four new topics. Cable construction is distinct from lesson 108’s solar storm, where telegraphs are an affected technology rather than the main event.',
'1857 failure, the briefly working 1858 cable, the 1865 lost cable and the lasting 1866 service are distinguished. The first completed cable is not incorrectly dated to 1866.',
'The 1858 ships are not confused with Great Eastern. Faulty insulation, long-cable signal behaviour and excessive voltage are not reduced to one heroic inventor or one simple technical mistake.',
'The link joined Ireland and Newfoundland, not an uninterrupted cable directly between London and New York. Affordability, commercial control and the work of crews and factories remain visible alongside faster communication.'
])
