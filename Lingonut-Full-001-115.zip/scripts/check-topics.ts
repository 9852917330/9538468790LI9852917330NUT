import { readdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

export type TopicEntry = { order: number; eventKey: string; label: string; aliases: string[]; reviewedAgainstThrough: number; reviewedOn: string };
export type TopicRegistry = { version: number; targetLessons: number; policy: string; topics: TopicEntry[] };
type Story = { order: number; title: string; slug: string; script: string };
const root = fileURLToPath(new URL("../", import.meta.url));
export const normalizeTopic = (value: string) => value.normalize("NFKD").replace(/\p{M}/gu, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();

function shingles(text: string) {
  const words = normalizeTopic(text).split(/\s+/);
  const result = new Set<string>();
  for (let i = 0; i + 5 <= words.length; i++) result.add(words.slice(i, i + 5).join(" "));
  return result;
}

export function validateTopics(stories: Story[], registry: TopicRegistry) {
  if (registry.version !== 1 || registry.targetLessons !== 1000 || !Array.isArray(registry.topics)) throw new Error("Invalid topic registry.");
  const entries = new Map<number, TopicEntry>();
  const eventKeys = new Map<string, number>();
  const aliases = new Map<string, number>();
  for (const topic of registry.topics) {
    if (!Number.isInteger(topic.order) || topic.order < 1 || topic.order > registry.targetLessons || entries.has(topic.order)) throw new Error(`Invalid or repeated topic number: ${topic.order}`);
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(topic.eventKey) || !topic.label?.trim() || !Array.isArray(topic.aliases) || !topic.aliases.length) throw new Error(`Incomplete topic identity: ${topic.order}`);
    if (!Number.isInteger(topic.reviewedAgainstThrough) || topic.reviewedAgainstThrough < topic.order - 1 || !/^\d{4}-\d{2}-\d{2}$/.test(topic.reviewedOn)) throw new Error(`Topic ${topic.order} needs a recorded comparison against every earlier topic.`);
    const key = normalizeTopic(topic.eventKey);
    if (eventKeys.has(key)) throw new Error(`Repeated event key: ${topic.eventKey} (${eventKeys.get(key)} and ${topic.order}). Revise the existing lesson instead of adding the event again.`);
    eventKeys.set(key, topic.order);
    for (const value of [topic.eventKey, topic.label, ...topic.aliases]) {
      const alias = normalizeTopic(value);
      if (!alias) throw new Error(`Empty topic alias: ${topic.order}`);
      const owner = aliases.get(alias);
      if (owner !== undefined && owner !== topic.order) throw new Error(`Repeated topic alias: ${value} (${owner} and ${topic.order}).`);
      aliases.set(alias, topic.order);
    }
    entries.set(topic.order, topic);
  }
  const titles = new Map<string, number>(), slugs = new Map<string, number>(), scripts = new Map<string, number>();
  const selected = new Set<number>();
  const fingerprints: { order: number; grams: Set<string> }[] = [];
  for (const story of stories) {
    if (selected.has(story.order)) throw new Error(`Repeated selected lesson: ${story.order}`);
    selected.add(story.order);
    if (!entries.has(story.order)) throw new Error(`Lesson ${story.order} has no reviewed event in content/topics.json.`);
    for (const [name, value, seen] of [["title", story.title, titles], ["slug", story.slug, slugs], ["script", story.script, scripts]] as const) {
      const normalized = normalizeTopic(value);
      if (!normalized) throw new Error(`Lesson ${story.order} has an empty ${name}.`);
      if (seen.has(normalized)) throw new Error(`Repeated ${name}: lessons ${seen.get(normalized)} and ${story.order}.`);
      seen.set(normalized, story.order);
    }
    const identity = ` ${normalizeTopic(story.title + " " + story.slug)} `;
    for (const [alias, owner] of aliases) {
      if (owner !== story.order && alias.length >= 5 && identity.includes(` ${alias} `)) throw new Error(`Lesson ${story.order} names the event already reserved for lesson ${owner}: ${alias}.`);
    }
    const grams = shingles(story.script);
    for (const prior of fingerprints) {
      const smaller = grams.size < prior.grams.size ? grams : prior.grams;
      const larger = smaller === grams ? prior.grams : grams;
      if (smaller.size < 40) continue;
      let shared = 0;
      for (const gram of smaller) if (larger.has(gram)) shared++;
      if (shared / smaller.size >= 0.5) throw new Error(`Near-duplicate scripts: lessons ${prior.order} and ${story.order} share ${Math.round(shared / smaller.size * 100)}% of the smaller script's five-word passages. Review before recording or publishing.`);
    }
    fingerprints.push({ order: story.order, grams });
  }
  return { status: "passed", checkedLessons: stories.length, distinctEvents: stories.length, registeredTopics: entries.size,
    reviewedThrough: Math.max(0, ...stories.map(s => s.order)), exactDuplicates: 0, nearDuplicatePairs: 0,
    method: "Reviewed event keys and aliases; normalized titles, slugs and scripts; five-word passage overlap at 50% of the smaller script. Semantic event identity requires editorial review of the topic ledger." };
}

export async function checkTopicFiles(draftNumbers: number[] = [], writeReport = false) {
  const registry: TopicRegistry = JSON.parse(await readFile(path.join(root, "content/topics.json"), "utf8"));
  const stories: Story[] = [];
  for (const file of (await readdir(path.join(root, "content/lessons"))).filter(n => n.endsWith(".json"))) {
    const lesson = JSON.parse(await readFile(path.join(root, "content/lessons", file), "utf8"));
    if (lesson.published !== false) stories.push(lesson);
  }
  for (const n of draftNumbers) {
    if (stories.some(s => s.order === n)) continue;
    const draft = JSON.parse(await readFile(path.join(root, "content/editorial-drafts", `${String(n).padStart(3, "0")}.json`), "utf8"));
    stories.push(draft.lesson);
  }
  stories.sort((a, b) => a.order - b.order);
  const result = { checkedAt: new Date().toISOString(), ...validateTopics(stories, registry) };
  if (writeReport) await writeFile(path.join(root, "content/topic-verification.json"), JSON.stringify(result, null, 2) + "\n");
  return result;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const invalid = args.find(a => !["--drafts", "--write-report"].includes(a) && !/^\d+$/.test(a));
  if (invalid) throw new Error(`Unknown topic-check argument: ${invalid}`);
  checkTopicFiles(args.filter(a => /^\d+$/.test(a)).map(Number), args.includes("--write-report"))
    .then(result => console.log(JSON.stringify(result)))
    .catch(error => { console.error(error.message); process.exitCode = 1; });
}
