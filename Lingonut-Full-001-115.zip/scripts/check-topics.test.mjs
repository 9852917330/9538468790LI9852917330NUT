import test from "node:test";
import assert from "node:assert/strict";
import { validateTopics } from "./check-topics.ts";

const registry = topics => ({ version: 1, targetLessons: 1000, policy: "One event per lesson", topics: topics.map((t, i) => ({ order: i + 1, reviewedAgainstThrough: i, reviewedOn: "2026-10-21", ...t })) });
const first = { order: 1, title: "Chile: A Mine Rescue", slug: "chile-rescue", script: "Miners waited underground while teams prepared a safe passage." };
const second = { order: 2, title: "Thailand: A Cave Rescue", slug: "thailand-rescue", script: "Divers moved through flooded tunnels to reach a football team." };
const topics = [{ eventKey: "chile-2010", label: "Chile Mine Rescue", aliases: ["San Jose 2010"] }, { eventKey: "thailand-2018", label: "Thailand Cave Rescue", aliases: ["Tham Luang 2018"] }];

test("related rescue themes remain distinct events", () => {
  assert.equal(validateTopics([first, second], registry(topics)).distinctEvents, 2);
});
test("a renamed lesson cannot reuse an event key", () => {
  assert.throws(() => validateTopics([first, second], registry([topics[0], { ...topics[1], eventKey: topics[0].eventKey }])), /Repeated event key/);
});
test("aliases remain unique after accents, case and punctuation are normalized", () => {
  assert.throws(() => validateTopics([first, second], registry([topics[0], { ...topics[1], aliases: ["SAN-JOSÉ 2010"] }])), /Repeated topic alias/);
});
test("a fresh key cannot hide a known event name in the new title", () => {
  assert.throws(() => validateTopics([first, { ...second, title: "San José 2010: Another Perspective" }], registry(topics)), /already reserved/);
});
test("copied narrative is blocked even with a changed title and opening", () => {
  const passage = "The miners waited in a shelter below the desert. Their families gathered above ground as engineers examined several possible routes. Supplies were limited and the trapped group shared food carefully. The rescue teams drilled through difficult rock and kept working despite repeated setbacks. After contact was established, narrow holes carried supplies and messages between the surface and the underground refuge. Doctors planned support while other specialists prepared a passage large enough for a person. The eventual rescue depended on careful planning and cooperation between many different teams.";
  assert.throws(() => validateTopics([{ ...first, script: passage }, { ...second, script: "This is presented as a new story. " + passage }], registry(topics)), /Near-duplicate scripts/);
});
test("unregistered stories and unchecked topic comparisons are blocked", () => {
  assert.throws(() => validateTopics([first, second], registry([topics[0]])), /no reviewed event/);
  assert.throws(() => validateTopics([first, second], registry([topics[0], { ...topics[1], reviewedAgainstThrough: 0 }])), /recorded comparison/);
});
