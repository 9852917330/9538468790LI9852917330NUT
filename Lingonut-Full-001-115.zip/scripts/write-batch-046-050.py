"""Source-reviewed, distinct-event overviews for English Unicorn 046–050."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(46, 'thich-quang-duc-buddhist-crisis-1963', 'Thích Quảng Đức and the 1963 Buddhist Crisis', 'World Events',
      'A Buddhist monk’s death during a protest drew worldwide attention to religious repression and a deepening political crisis in South Vietnam.',
'''In 1963, South Vietnam was fighting communist forces with American support. President Ngô Đình Diệm led its government. He was Catholic, while Buddhism had a large following. Buddhist leaders complained of religious **discrimination**, restrictions on their activities and official favoritism toward Catholics.

The crisis intensified in Huế in May. Authorities enforced restrictions on religious flags during celebrations of the Buddha's birthday. On May 8, several people were killed when government forces dispersed a gathering. The deaths brought long-standing **grievances** into the streets.

Buddhist leaders demanded equal religious treatment, freedom to worship, an end to arrests and intimidation, and **compensation** for victims' families. Demonstrations spread, while talks with officials failed to restore trust. Religious demands had become a major political challenge.

On June 11, the Buddhist **monk** Thích Quảng Đức died by **self-immolation** during a public protest in Saigon. His death was intended to draw attention to the movement's demands. Malcolm Browne of the Associated Press photographed the event, and the image appeared around the world.

The photograph brought the crisis into international view. It intensified questions about the government that the United States was supporting. American officials pressed Diệm to reach an agreement with Buddhist leaders and make meaningful changes.

On June 16, a joint agreement promised measures addressing Buddhist demands. However, promised **concessions** did not end the conflict. Tensions continued through the summer, and government forces **raided** Buddhist pagodas in August. Arrests and repression further damaged confidence in the government.

South Vietnamese military officers began planning a **coup** amid growing political and military tensions. They overthrew Diệm on November 1, and he was killed the following day. The Buddhist crisis formed an important part of the wider breakdown of his rule.

Thích Quảng Đức's death became a lasting image of that crisis. Its historical significance lay within a larger struggle over religious freedom, state violence and political **legitimacy**, during a war in which domestic events also shaped international decisions.''',
[
v('discrimination', 'Unfair treatment of a person or group because of identity, beliefs or another characteristic.', 'The campaign called for an end to religious discrimination.', 'Uncountable noun'),
v('grievance', 'A complaint about treatment believed to be unfair.', 'Community leaders presented their grievance to the authorities.', 'Noun', form='grievances', plural='grievances'),
v('compensation', 'Money or other support given to make up for harm or loss.', 'The families asked for compensation after the disaster.', 'Uncountable noun'),
v('monk', 'A member of a religious community who follows a particular way of life.', 'The monk lived at a nearby monastery.', 'Noun', plural='monks'),
v('self-immolation', 'The act of causing one’s own death by burning, sometimes during a political protest.', 'The historian discussed the political context of the self-immolation.', 'Noun'),
v('concession', 'A change or agreement made in response to a demand or disagreement.', 'The negotiators offered a concession to help resolve the dispute.', 'Noun', form='concessions', plural='concessions'),
v('raid', 'To enter a place suddenly using force, often to arrest people or take control.', 'Security forces were ordered to raid the building.', 'Verb', form='raided', verb=('raid','raided','raided',False)),
v('coup', 'A sudden seizure of government power, usually by a small group using force.', 'The coup removed the country’s president.', 'Noun', plural='coups'),
v('legitimacy', 'The quality of being accepted as having a rightful basis or authority.', 'The disputed election damaged the government’s legitimacy.', 'Uncountable noun')
],
[
m('What were the Buddhist protests demanding?', ['A complete end to every form of religious worship.', 'Equal religious treatment and action over repression and deaths.', 'The closure of all Buddhist pagodas.'], 'B', "Buddhist leaders demanded equal religious treatment, freedom to worship, an end to arrests and intimidation, and compensation for victims' families.", 'The demands concerned religious equality, freedom, protection and accountability.'),
m('How did the photograph affect the crisis?', ['It drew worldwide attention and increased scrutiny of Diệm’s government.', 'It immediately ended all political conflict.', 'It prevented any news about the protests from leaving Vietnam.'], 'A', 'The photograph brought the crisis into international view.', 'The image helped turn an existing domestic crisis into an international issue.'),
m('What happened after the June agreement?', ['All arrests and repression ended permanently.', 'The government ceased to exist that same day.', 'Tensions continued, followed by pagoda raids and a later coup.'], 'C', 'Tensions continued through the summer, and government forces raided Buddhist pagodas in August.', 'The agreement did not resolve the crisis, which remained part of the wider collapse of the government.'),
g('Thích Quảng Đức died during a protest in ___ 1963.', 'June', 'On June 11, the Buddhist monk Thích Quảng Đức died by self-immolation during a public protest in Saigon.', 'June identifies the month of the protest.'),
g('The joint agreement was issued on June ___.', '16', 'On June 16, a joint agreement promised measures addressing Buddhist demands.', 'June 16 was the date of the joint agreement.'),
g('The officers overthrew Diệm on ___ 1.', 'November', 'They overthrew Diệm on November 1, and he was killed the following day.', 'The coup occurred in November 1963.')
],
[
'U.S. Office of the Historian, FRUS document 112 — Huế incident, religious flags and differing casualty reports: https://history.state.gov/historicaldocuments/frus1961-63v03/d112',
'Buddhist manifesto of May 10, 1963, reproduced in FRUS document 118 — Five demands and grievances: https://history.state.gov/historicaldocuments/frus1961-63v03/d118',
'U.S. embassy report and editorial notes, FRUS document 163 — June 11 event and Browne’s Associated Press photograph: https://history.state.gov/historicaldocuments/frus1961-63v03/d163',
'FRUS document 178 — June 16 agreement and its terms: https://history.state.gov/historicaldocuments/frus1961-63v03/d178',
'John F. Kennedy Presidential Library — U.S. response, August raids, political crisis and November coup: https://www.jfklibrary.org/learn/about-jfk/jfk-in-history/vietnam-diem-the-buddhist-crisis'
],
[
'Whole-event overview places the monk’s death within religious grievances, the Huế deaths, organized demands, international reporting, attempted settlement, repression and the wider political breakdown.',
'No operational self-harm details, graphic description, admiration for suffering or suggestion that the act is a model to imitate. Historical purpose is stated neutrally.',
'Several people avoids inconsistent contemporary and later Huế casualty totals. The crisis is a contributing part of the coup context, not a claim that one death or photograph alone overthrew Diệm.',
'Compared against all 001–045 and the four other candidates. The 1963 Buddhist crisis is distinct from the 1968 Mỹ Lai massacre and the JFK assassination; identity registered in content/topics.json.'
])

draft(47, 'miriam-rodriguez-mexico-justice', 'Miriam Rodríguez: A Mother’s Search for Justice in Mexico', 'Justice and Human Rights',
      'After finding her murdered daughter, a Mexican mother helped investigators and other searching families, then faced threats and was killed herself.',
'''Miriam Rodríguez lived in San Fernando, in the Mexican state of Tamaulipas. Criminal groups operated in the region, and families searching for missing relatives faced serious danger. Her daughter Karen was **abducted** and killed, turning a family tragedy into a search for truth and justice.

Rodríguez began investigating the disappearance herself. She followed information about Karen's whereabouts and eventually located her daughter's **remains** in an unmarked grave. Finding them answered the question of where Karen was, while leaving the family with grief and the demand that those responsible face justice.

She gave authorities information that helped them pursue the people involved. Her work contributed to arrests, according to human rights organizations. The investigation depended on gathering information and pressing officials to act, in a setting where fear and **intimidation** could silence families and **witnesses**.

Her efforts also extended beyond Karen's case. She helped establish and coordinated a **collective** of relatives of disappeared people in San Fernando. Members shared knowledge, supported searches and accompanied other families seeking answers. Personal loss had become organized work defending other people's rights.

That work exposed her to further danger. She sought **protection** from the authorities, especially as concerns grew about accused kidnappers escaping custody. Requests for help did not result in effective safety. On May 10, 2017, gunmen killed her at her home. It was Mother's Day in Mexico.

The killing prompted condemnation from the United Nations and the Inter-American Commission on Human Rights. They called for a proper investigation and protection for relatives, search groups and other **human rights defenders**. The case highlighted how seeking justice could expose families to **retaliation**.

In 2018, Mexico's National Human Rights Commission found failures by Tamaulipas authorities to provide adequate, effective protection. Its recommendation addressed official responsibilities surrounding the danger she faced.

Rodríguez's story became part of a wider struggle against disappearance and **impunity**. It joined a mother's search, collective action and the need for institutions that investigate crimes while protecting those who report them.''',
[
v('abduct', 'To take someone away illegally using force or threats.', 'The police investigated an attempt to abduct the witness.', 'Verb', form='abducted', verb=('abduct','abducted','abducted',False)),
v('remains', 'The body or parts of the body of a person who has died.', 'Specialists worked to identify the human remains.', 'Plural noun', note='Used in the plural in this meaning.'),
v('intimidation', 'The use of threats or fear to control someone’s actions.', 'Witness intimidation made the investigation more difficult.', 'Uncountable noun'),
v('witness', 'A person who has seen an event or has information relevant to it.', 'The witness gave an account to investigators.', 'Noun', form='witnesses', plural='witnesses'),
v('collective', 'A group of people who work together toward a shared purpose.', 'The collective helped families organize searches.', 'Noun', plural='collectives'),
v('protection', 'Actions or measures that keep someone or something safe from harm.', 'The threatened journalist requested protection.', 'Uncountable noun'),
v('human rights defender', 'A person who works to protect and promote people’s basic rights.', 'The human rights defender supported families seeking justice.', 'Noun phrase', form='human rights defenders', plural='human rights defenders'),
v('retaliation', 'An action intended to harm someone in response to something they have done.', 'The witness feared retaliation after reporting the crime.', 'Uncountable noun'),
v('impunity', 'Freedom from punishment or consequences for wrongdoing.', 'The organization campaigned against impunity for violent crimes.', 'Uncountable noun')
],
[
m('How did Rodríguez’s search contribute to the investigation?', ['She replaced every police officer in the state.', 'She provided information that helped authorities pursue those involved.', 'She kept all information away from investigators.'], 'B', 'She gave authorities information that helped them pursue the people involved.', 'Her information supported the official investigation; the account does not claim she personally arrested or killed suspects.'),
m('How did her work extend beyond her daughter’s case?', ['She stopped all contact with other searching families.', 'She worked only on unrelated commercial disputes.', 'She helped coordinate a collective supporting relatives and searches.'], 'C', 'She helped establish and coordinated a collective of relatives of disappeared people in San Fernando.', 'Her personal search developed into collective work with other affected families.'),
m('What did the 2018 human rights finding concern?', ['Failures by authorities to provide adequate and effective protection.', 'A finding that searching families needed no protection.', 'Proof that every disappearance case in Mexico had been solved.'], 'A', "In 2018, Mexico's National Human Rights Commission found failures by Tamaulipas authorities to provide adequate, effective protection.", 'The recommendation addressed official failures surrounding the danger to Rodríguez.'),
g('Rodríguez lived in the state of ___.', 'Tamaulipas', 'Miriam Rodríguez lived in San Fernando, in the Mexican state of Tamaulipas.', 'Tamaulipas identifies the Mexican state where she lived and worked.'),
g('She was killed on May 10, ___.', '2017', 'On May 10, 2017, gunmen killed her at her home.', '2017 was the year of her killing.'),
g('Her daughter’s remains were found in an unmarked ___.', 'grave', "She followed information about Karen's whereabouts and eventually located her daughter's remains in an unmarked grave.", 'The discovery established where Karen’s remains were.')
],
[
'United Nations experts, May 19, 2017, published by UN Human Rights Mexico — Daughter’s death, investigation, threats, protection requests, killing and impunity: https://hchr.org.mx/comunicados/mexico-expertos-de-la-onu-condenan-asesinato-de-una-defensora-de-ddhh-y-piden-medidas-efectivas-para-combatir-la-impunidad/',
'Inter-American Commission on Human Rights, May 24, 2017 — Remains, assistance to authorities, collective work and protection concerns: https://www.oas.org/en/iachr/media_center/preleases/2017/067.asp',
'Mexico National Human Rights Commission, Recommendation 50/2018 — Failure to provide adequate and effective protection, especially paragraphs 74–76 and 145–146: https://www.cndh.org.mx/sites/default/files/doc/Recomendaciones/2018/Rec_2018_050.pdf',
'UN Human Rights Mexico, May 11, 2017 — Contemporary official condemnation and search work: https://hchr.org.mx/wp/wp-content/themes/hchr/images/Comunicados/2017/20170511_ComPrensa_SraRodr%C3%ADguez_TAMPS.pdf',
'Mexico City Human Rights Commission, May 12, 2017 — Defender role and demands for investigation: https://cdhcm.org.mx/2017/05/la-cdhdf-condena-el-asesinato-de-la-defensora-de-derechos-humanos-miriam-rodriguez-e-insta-a-las-autoridades-a-investigar-los-hechos/'
],
[
'Identified as Miriam Elizabeth Rodríguez Martínez, mother of Karen Alejandra Salinas Rodríguez. Overview covers loss, search, evidence, collective work, threats, killing and institutional responsibility.',
'Karen’s disappearance year is omitted: UN sources and the Mexico City commission say 2014, while the IACHR says 2012 and discovery two years later. No false precision or invented resolution of that conflict.',
'No exact arrest count, claim of personal arrests or revenge killings, invented confrontations, or unsupported identification of every perpetrator. Arrest contribution is attributed to human rights organizations.',
'CNDH recommendation uses redacted identifiers; its facts, timing and protection failures correspond to the publicly documented case. No claim that Miriam’s own murder case has reached a particular present-day outcome.',
'Compared manually with all 001–046 and the remaining candidates. Distinct event identity and aliases registered in content/topics.json.'
])

draft(48, 'ted-bundy-serial-murders', 'Ted Bundy: Serial Murders and the Search for Justice', 'Crime and Investigations',
      'A series of murders across several American states led to a long investigation, repeated escapes from custody, further killings and criminal trials.',
'''During the 1970s, women and girls disappeared or were attacked in several American states. Some cases were eventually linked to Ted Bundy. Families searched for missing relatives, while surviving victims gave accounts that helped investigators understand a wider **pattern** of violence.

The cases crossed state boundaries, including Washington, Utah, Colorado and Florida. Police initially handled separate local investigations. Connecting the **disappearances** required agencies to compare information from different places, examine possible links and distinguish useful evidence from unreliable reports.

Bundy was arrested in Utah in August 1975. The following year, he was **convicted** of kidnapping a young woman who had escaped from him. Her survival and identification helped bring the case to court. He also faced a murder charge in Colorado.

While facing that charge, Bundy escaped from **custody** twice in 1977. He was caught after the first escape, but the second led to a national search. The FBI circulated identification material and helped compare **fingerprints**, while local officers pursued possible sightings.

He reached Florida and committed more crimes in early 1978. Margaret Bowman and Lisa Levy, students at Florida State University, were killed at their sorority house. Other women survived attacks. Twelve-year-old Kimberly Leach was also killed in Florida. Police arrested Bundy in Pensacola on February 15.

A Florida jury found him guilty of the two students' murders in 1979. A separate trial in 1980 found him guilty of kidnapping and murdering Leach. **Witnesses**, physical evidence and arguments over its reliability formed part of the court proceedings. He received death sentences.

After years of **appeals**, Florida executed Bundy on January 24, 1989. Before his death, he made **confessions** to 30 killings. The full number of victims remains unknown, and that figure represents what he admitted rather than a separately proven total.

The investigation required **coordination** among local police, federal agents and surviving witnesses. Its history includes repeated failures to keep a dangerous suspect in custody, determined efforts to connect crimes and lasting loss for the victims' families.''',
[
v('pattern', 'A repeated form or connection that can be recognized across events.', 'Investigators looked for a pattern across the separate reports.', 'Noun', plural='patterns'),
v('disappearance', 'An event in which a person or thing goes missing.', 'The family reported the disappearance to police.', 'Noun', form='disappearances', plural='disappearances'),
v('convict', 'To officially find someone guilty of a crime in court.', 'The jury needed sufficient evidence to convict the defendant.', 'Verb', form='convicted', verb=('convict','convicted','convicted',False)),
v('custody', 'The state of being held under official control, especially by police or prison authorities.', 'The suspect remained in custody before the hearing.', 'Uncountable noun'),
v('fingerprint', 'A mark or pattern from a fingertip that can help identify a person.', 'The laboratory compared the fingerprint with official records.', 'Noun', form='fingerprints', plural='fingerprints'),
v('witness', 'A person who saw an event or gives relevant evidence in court.', 'The witness described what she had seen.', 'Noun', form='Witnesses', plural='witnesses'),
v('appeal', 'A request for a higher court to review a legal decision.', 'The lawyer filed an appeal against the sentence.', 'Noun', form='appeals', plural='appeals'),
v('confession', 'A statement admitting responsibility for a crime or wrongdoing.', 'Investigators checked the confession against other evidence.', 'Noun', form='confessions', plural='confessions'),
v('coordination', 'The organization of different people or activities so they work together effectively.', 'The operation required coordination between several police departments.', 'Uncountable noun')
],
[
m('Why did the investigation require cooperation across states?', ['Possible linked crimes had occurred in different places.', 'All the crimes were investigated by one small local office.', 'No witness or physical evidence was available anywhere.'], 'A', 'Connecting the disappearances required agencies to compare information from different places, examine possible links and distinguish useful evidence from unreliable reports.', 'Investigators needed to connect separate cases across state boundaries.'),
m('What happened after the second escape in 1977?', ['Bundy immediately completed his sentence in Utah.', 'A national search followed, and he committed further crimes in Florida.', 'All criminal proceedings were cancelled.'], 'B', 'He was caught after the first escape, but the second led to a national search.', 'The account then describes the further attacks in Florida before his arrest.'),
m('How should the figure of 30 killings be understood?', ['It proves the exact final number of victims.', 'It counts only the two Florida university victims.', 'It is the number of killings he confessed to; the full total remains unknown.'], 'C', 'Before his death, he made confessions to 30 killings.', 'The next sentence distinguishes his admissions from a separately established total.'),
g('Bundy was first arrested in Utah in August ___.', '1975', 'Bundy was arrested in Utah in August 1975.', '1975 marks the arrest described in the lesson.'),
g('Police arrested him in ___ in February 1978.', 'Pensacola', 'Police arrested Bundy in Pensacola on February 15.', 'Pensacola was the city of the Florida arrest.'),
g('Florida executed him on January 24, ___.', '1989', 'After years of appeals, Florida executed Bundy on January 24, 1989.', '1989 was the year of the execution.')
],
[
'FBI retrospective, 2013 — Interstate investigation, Utah arrest and conviction, 1977 escapes, identification and fingerprint work, Pensacola arrest: https://www.fbi.gov/news/stories/serial-killers-part-3-ted-bundys-campaign-of-terror1',
'Florida Supreme Court, Bundy v. State, 455 So.2d 330 — University victims, trial evidence and convictions: https://library.law.fsu.edu/Digital-Collections/flsupct/dockets/57772/op-57772.pdf',
'Florida Supreme Court, Bundy v. State, 471 So.2d 9 — Leach case, arrest, evidence and legal findings: https://library.law.fsu.edu/Digital-Collections/flsupct/dockets/59128/op-59128.pdf',
'Federal appellate opinion — 1979 jury verdict and proceedings: https://law.justia.com/cases/federal/appellate-courts/F2/808/1410/173788/',
'ABC News original timeline — 1980 verdict, confessions and January 24, 1989 execution: https://abcnews.com/US/timeline-ted-bundys-brutal-crimes/story?id=61077236'
],
[
'Overview covers victims and geography, linked investigations, first conviction, custody failures, further crimes, Florida trials, appeals, confessions and wider investigative lessons.',
'30 is explicitly a confession figure, not an exact proven death toll. No invented first murder or unsupported total.',
'FBI retrospective contains some date and sequencing errors; the lesson avoids its incorrect precise date for the university attack, New Year’s Eve escape wording and apparent Colorado-return error.',
'No graphic violence, operational abduction or escape methods, offender glamour or claim that bite-mark evidence has established scientific reliability. Named victims support the wider account.',
'Compared with all 001–047 and the other candidates. The Bundy series is distinct from the Alcatraz escape and other criminal cases in the collection; identity registered in content/topics.json.'
])

draft(49, 'josef-fritzl-amstetten-case', 'The Fritzl Case: Captivity, Discovery and Justice', 'Justice and Human Rights',
      'A hospital emergency exposed decades of imprisonment and abuse in an Austrian home, leading to prosecution and protection for the surviving family.',
'''In 1984, Josef Fritzl imprisoned his daughter Elisabeth in a hidden part of the family home in Amstetten, Austria. She was 18 years old. Her **captivity** lasted almost 24 years, while people outside the home were told that she had left.

During those years, Fritzl repeatedly subjected her to sexual **abuse**. She gave birth to seven children, and he was their father. Six survived. Three children lived with their mother in captivity. The other three grew up upstairs with Fritzl and his wife. He told others that Elisabeth had left them behind.

The separation gave the children very different lives. Those below were denied ordinary freedom and contact with the outside world. One infant died after Fritzl failed to seek medical help. The crimes remained **concealed** within a household whose public story hid prolonged violence and control.

The case came to light in April 2008 when one of the children became seriously ill and was taken to hospital. Doctors needed information about her medical history and tried to contact her mother. Their concerns brought police into the case.

When Elisabeth could speak safely to investigators, she described what had happened. Fritzl was arrested, and DNA tests confirmed that he was the father of the six surviving children. The discovery began both a criminal investigation and care for a family emerging from years of **trauma**.

His trial took place in St Pölten in March 2009. Recorded testimony from Elisabeth and expert evidence helped establish the crimes. He eventually pleaded guilty to all charges. The jury convicted him of murder through **neglect** of the infant, rape, incest, enslavement and other offences.

On March 19, he received life **imprisonment**, with detention in a secure institution providing **psychiatric** treatment. The sentence followed a finding of criminal responsibility.

The survivors received medical and psychological support, while their **privacy** was protected. The case prompted debate about hidden abuse and **safeguarding**. Austrian lawmakers also referred to it in discussions of criminal records and penalties for unlawful confinement.''',
[
v('captivity', 'The state of being kept somewhere and prevented from leaving freely.', 'The hostages spent months in captivity.', 'Uncountable noun'),
v('abuse', 'Harmful, cruel or violent treatment of another person.', 'The inquiry examined reports of abuse in the institution.', 'Uncountable noun'),
v('conceal', 'To keep something hidden or prevent it from becoming known.', 'The false account was used to conceal the crime.', 'Verb', form='concealed', verb=('conceal','concealed','concealed',False)),
v('trauma', 'Deep physical or psychological harm caused by a distressing experience.', 'The survivors received support after the trauma.', 'Noun', plural='traumas'),
v('neglect', 'Failure to provide the care or attention that someone needs.', 'The investigation examined whether neglect had contributed to the death.', 'Uncountable noun'),
v('imprisonment', 'The state or punishment of being kept in prison.', 'The offence could result in a long term of imprisonment.', 'Uncountable noun'),
v('psychiatric', 'Related to the medical assessment and treatment of mental illness.', 'The institution provided psychiatric treatment.', 'Adjective'),
v('privacy', 'Freedom from unwanted access to personal information or private life.', 'Reporters were asked to respect the family’s privacy.', 'Uncountable noun'),
v('safeguarding', 'Actions and systems intended to protect people, especially those at risk, from harm or abuse.', 'The review called for stronger safeguarding procedures.', 'Uncountable noun')
],
[
m('What helped expose the crimes in 2008?', ['A hospital emergency led doctors to seek information and involve police.', 'The entire family had already publicly described the captivity in 1984.', 'No medical staff or investigators were involved.'], 'A', 'The case came to light in April 2008 when one of the children became seriously ill and was taken to hospital.', 'Doctors’ questions about the patient and her mother helped bring the hidden situation to light.'),
m('What did the DNA tests establish?', ['That Elisabeth had never been held captive.', 'That every child had grown up outside the household.', 'That Fritzl was the father of the six surviving children.'], 'C', 'Fritzl was arrested, and DNA tests confirmed that he was the father of the six surviving children.', 'The tests provided evidence about the children’s parentage.'),
m('What was the legal outcome in March 2009?', ['An acquittal based on a finding that no crimes occurred.', 'Life imprisonment, with secure detention providing psychiatric treatment.', 'A decision to stop the case before any verdict.'], 'B', 'On March 19, he received life imprisonment, with detention in a secure institution providing psychiatric treatment.', 'The treatment setting accompanied a criminal conviction and life sentence.'),
g('Elisabeth’s captivity began in ___.', '1984', 'In 1984, Josef Fritzl imprisoned his daughter Elisabeth in a hidden part of the family home in Amstetten, Austria.', '1984 was the year the imprisonment began.'),
g('She was ___ years old when she was imprisoned.', '18', 'She was 18 years old.', '18 was her age at the start of the captivity.'),
g('The case came to light in ___ 2008.', 'April', 'The case came to light in April 2008 when one of the children became seriously ill and was taken to hospital.', 'April identifies the month of the discovery.')
],
[
'Reuters, Sylvia Westall, March 19, 2009, contemporary court report — Guilty pleas, crimes, verdict, infant death, sentence and family circumstances; reproduction: https://mg.co.za/news/south-africa/2009-03-19-fritzl-gets-life-in-psychiatric-ward-for-incest-murder/',
'ABC Australia/AFP, March 20, 2009 — Hospital discovery, DNA, family facts and sentence: https://www.abc.net.au/news/2009-03-20/fritzl-sentenced-to-life-in-mental-institution/1625018',
'ORF, original reporting with investigators and prosecutor — Hospital questions, investigation, trial and criminal responsibility: https://noe.orf.at/magazin/stories/3179833/',
'Austrian Parliament, Justice Committee report, pages 32–33 — Explicit reference to the case in criminal-record and unlawful-confinement proposals: https://www.parlament.gv.at/dokument/XXIV/I/106/fname_151801.pdf'
],
[
'Overview covers the beginning and duration of captivity, family circumstances, concealment, medical discovery, investigation, evidence, trial, sentence and survivor support.',
'Seven births, six surviving children and one infant death are distinguished. No implication that all six grew up below ground or that the grandmother knowingly participated in the crimes.',
'Infant murder finding was based on failure to seek medical care. Life imprisonment plus secure psychiatric detention is distinguished from an insanity acquittal. No present-day detention or release claim.',
'No original public 2009 judgment was located; contemporary Reuters/AFP court reporting and ORF interviews provide the event evidence, with a primary parliamentary source for legislative discussion.',
'Sexual abuse is described clinically without graphic details. No chamber layout, confinement techniques, later identities, current location or private details of survivors are disclosed.',
'Compared manually with all 001–048 and the Jonestown candidate. Distinct case identity and alternative names registered in content/topics.json.'
])

draft(50, 'jonestown-mass-deaths-1978', 'Jonestown 1978: Coercion, Violence and Mass Death', 'World Events',
      'A movement promising equality developed into a tightly controlled settlement, where an attack on visiting investigators was followed by mass deaths.',
'''Peoples Temple began in the United States in the 1950s under religious leader Jim Jones. Its **congregation** attracted people who supported **racial equality** and help for poor and older people. Many joined hoping to build a fairer community in a society marked by discrimination.

The movement later moved from Indiana to California. During the 1970s, it established Jonestown, a farming settlement in Guyana, South America. Jones and many followers moved there in 1977, describing it as a place where their shared ideals could become everyday life.

The settlement was geographically **isolated**, and Jones exercised increasing control over residents. Former members reported exhausting work, punishments, threats and restricted freedom. **Coercion** and fear made it difficult to challenge him. Relatives in the United States worried about people living there and sought help.

Congressman Leo Ryan travelled to Guyana to investigate reports of abuse. He reached Jonestown on November 17, 1978, with journalists and other members of his **delegation**. Some residents asked to leave with them, revealing a difference between the community's public image and experiences inside it.

On November 18, Temple gunmen attacked the departing group at the nearby Port Kaituma airstrip. The **ambush** killed five people: Ryan, three journalists and a Temple member who was leaving. Others were wounded, including Ryan's aide Jackie Speier.

That day, Jones directed the deaths of the Jonestown community. Most were poisoned. Some adults took their own lives, while others were forced or murdered. Children were victims. Survivor accounts describe pressure, armed control and efforts to prevent people from leaving during the killings.

In total, 909 people died at Jonestown. Five died at the airstrip and four at a Temple residence in Georgetown, bringing the total across Guyana to 918. Jones was among the dead.

Investigators interviewed **survivors** and worked on the **identification** of victims. Families faced devastating loss, while **remembrance** preserved the lives behind the numbers. The tragedy exposed how isolation, abusive authority and demands for obedience could turn a community's hopes into extreme violence.''',
[
v('congregation', 'A group of people who gather for religious worship.', 'The congregation organized support for local families.', 'Noun', plural='congregations'),
v('racial equality', 'Equal rights, treatment and opportunities regardless of race.', 'The campaign called for racial equality in public services.', 'Noun phrase'),
v('isolated', 'Separated from other people or places, with limited contact or access.', 'The isolated settlement was difficult to reach.', 'Adjective'),
v('coercion', 'The use of force, threats or pressure to make someone act against their will.', 'The investigation found evidence of coercion.', 'Uncountable noun'),
v('delegation', 'A group chosen to visit a place or represent others for a particular purpose.', 'The delegation met local residents during its visit.', 'Noun', plural='delegations'),
v('ambush', 'A sudden attack launched from a hidden or unexpected position.', 'Several people were injured in the ambush.', 'Noun', plural='ambushes'),
v('survivor', 'A person who remains alive after a dangerous or deadly event.', 'The survivor gave an account to investigators.', 'Noun', form='survivors', plural='survivors'),
v('identification', 'The process of establishing who a person is or what something is.', 'Specialists helped with the identification of the victims.', 'Uncountable noun'),
v('remembrance', 'The act of remembering and honoring people or past events.', 'The families gathered for a day of remembrance.', 'Uncountable noun')
],
[
m('Why had many people originally joined Peoples Temple?', ['They expected the group to oppose racial equality.', 'They hoped to support equality and build a fairer community.', 'They had all joined knowing that mass deaths were planned.'], 'B', 'Many joined hoping to build a fairer community in a society marked by discrimination.', 'The account distinguishes members’ original hopes from the abusive control that later developed.'),
m('Why did Leo Ryan visit Guyana?', ['To investigate reports of abuse and conditions affecting residents.', 'To establish the settlement in the 1950s.', 'To announce that no resident could leave.'], 'A', 'Congressman Leo Ryan travelled to Guyana to investigate reports of abuse.', 'Relatives’ concerns and reports of abuse prompted the visit.'),
m('Which description best reflects the deaths?', ['All 918 people died at the same spot inside Jonestown.', 'Every death was a freely chosen adult suicide.', 'Deaths occurred at three locations, and coercion and murder were part of the tragedy.'], 'C', 'Some adults took their own lives, while others were forced or murdered.', 'The account also distinguishes the settlement deaths from those at the airstrip and in Georgetown.'),
g('Jonestown was established in the South American country of ___.', 'Guyana', 'During the 1970s, it established Jonestown, a farming settlement in Guyana, South America.', 'Guyana was the country where the settlement was located.'),
g('The airstrip attack occurred on November ___, 1978.', '18', 'On November 18, Temple gunmen attacked the departing group at the nearby Port Kaituma airstrip.', 'November 18 was the date of the attack and mass deaths.'),
g('The total number of deaths across Guyana was ___.', '918', 'Five died at the airstrip and four at a Temple residence in Georgetown, bringing the total across Guyana to 918.', '918 includes deaths at the settlement, airstrip and Georgetown residence.')
],
[
'U.S. House of Representatives, 1979 congressional staff report, House Document 96-223, reproduced by SDSU — Origins, integration, California move, settlement and intimidation: https://jonestown.sdsu.edu/?page_id=13674',
'U.S. State Department, Dwyer eyewitness account, FRUS document 293 — November 17 arrival, interviews and departure attempts: https://history.state.gov/historicaldocuments/frus1977-80v23/d293',
'U.S. State Department, FRUS document 289, editorial footnote 4 — 909 settlement deaths and 918 total: https://history.state.gov/historicaldocuments/frus1977-80v23/d289',
'FBI interviews with survivors Odell Rhodes and Stanley Clayton, serial 2242, transcribed by SDSU — Coercion, guarded departures and differing adult responses: https://jonestown.sdsu.edu/?page_id=78593',
'FBI case history — Airstrip attack, murder investigation, survivor interviews and identification work: https://www.fbi.gov/history/cases-and-criminals/jonestown',
'U.S. National Archives, Jackie Speier eyewitness discussion — Delegation, airstrip violence, survivor experience and remembrance: https://www.archives.gov/news/articles/undaunted-jackie-speier-lecture'
],
[
'Overview covers the movement’s social appeal, relocation and isolation, coercive control, outside concerns, Ryan’s visit, the airstrip killings, mass deaths, investigation and memory.',
'909 at Jonestown is distinguished from the total 918 across three Guyanese locations. No exact child total or unsupported division between voluntary deaths and murders.',
'Some adult suicides, coercion and killings are distinguished; children are victims. Members are not portrayed as uniformly willing or responsible for their own deaths.',
'No poison names, quantities, preparation methods, graphic description, suicide instructions or celebratory treatment of Jones. Historical abuse is not generalized to all religious communities.',
'Compared manually with all 001–049, including the other new cases. Jonestown is distinct from earlier mass atrocities and disasters; identity and aliases registered in content/topics.json.'
])
