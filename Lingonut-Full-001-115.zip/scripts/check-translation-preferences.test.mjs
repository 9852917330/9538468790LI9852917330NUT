import test from "node:test";
import assert from "node:assert/strict";
import { defaultTranslationPreferences, parseTranslationPreferences, readTranslationPreferences, saveTranslationPreferences, translationPreferenceKey } from "../lib/translation-preferences.ts";

const storage = (entries = {}) => {
  const values = new Map(Object.entries(entries));
  return { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, value), values };
};
test("new visitors and inaccessible storage keep English readable", () => {
  assert.deepEqual(readTranslationPreferences(), defaultTranslationPreferences);
  assert.deepEqual(readTranslationPreferences({ getItem() { throw new Error("Blocked"); } }), defaultTranslationPreferences);
});
test("one persisted Thai selection and mode round-trip for every page", () => {
  const saved = storage();
  const value = { version: 1, language: "th", view: "whole" };
  saveTranslationPreferences(saved, value);
  assert.deepEqual(readTranslationPreferences(saved), value);
  assert.deepEqual([...saved.values.keys()], [translationPreferenceKey]);
});
test("the global record takes precedence over both previous independent controls", () => {
  const saved = storage({
    [translationPreferenceKey]: JSON.stringify({ version: 1, language: "de", view: "paragraphs" }),
    "english-unicorn-title-language": "vi", "english-unicorn-translation-language": "fr", "english-unicorn-translation-view": "whole",
  });
  assert.deepEqual(readTranslationPreferences(saved), { version: 1, language: "de", view: "paragraphs" });
});
test("migration prefers the old header language, including an explicit English Only", () => {
  assert.deepEqual(readTranslationPreferences(storage({ "english-unicorn-title-language": "en", "english-unicorn-translation-language": "vi", "english-unicorn-translation-view": "whole" })), { version: 1, language: "en", view: "whole" });
  assert.deepEqual(readTranslationPreferences(storage({ "english-unicorn-translation-language": "ja" })), { version: 1, language: "ja", view: "paragraphs" });
});
test("invalid preferences cannot introduce an unsupported language or reading mode", () => {
  assert.equal(parseTranslationPreferences({ version: 1, language: "xx", view: "whole" }), null);
  assert.equal(parseTranslationPreferences({ version: 1, language: "vi", view: "unknown" }), null);
  assert.equal(parseTranslationPreferences({ version: 2, language: "vi", view: "whole" }), null);
  assert.deepEqual(readTranslationPreferences(storage({ [translationPreferenceKey]: "broken JSON", "english-unicorn-title-language": "fr" })), { version: 1, language: "fr", view: "paragraphs" });
});
test("English Only stays global and storage failures do not break selection", () => {
  const saved = storage({ "english-unicorn-translation-language": "vi" });
  saveTranslationPreferences(saved, { version: 1, language: "en", view: "paragraphs" });
  assert.equal(readTranslationPreferences(saved).language, "en");
  assert.doesNotThrow(() => saveTranslationPreferences({ setItem() { throw new Error("Blocked"); } }, { version: 1, language: "th", view: "whole" }));
});
