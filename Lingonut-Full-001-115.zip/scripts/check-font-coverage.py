"""Audit imported font faces against all translations (requires fonttools + brotli)."""
from pathlib import Path
from functools import lru_cache
from fontTools.ttLib import TTFont
import json
import re
import sys
import unicodedata

ROOT = Path(__file__).resolve().parent.parent
LANGUAGES = {
    'fr': ('Nunito Variable', 'Français'),
    'de': ('Nunito Variable', 'Deutsch'),
    'es': ('Nunito Variable', 'Español'),
    'ja': ('Zen Maru Gothic', '日本語'),
    'ko': ('Nanum Gothic', '한국어'),
    'zh-Hans': ('Chiron GoRound TC Variable', '中文（简体）'),
    'vi': ('Nunito Variable', 'Tiếng Việt'),
    'th': ('Mitr', 'ไทย'),
}


def ranges(text):
    result = set()
    for entry in text.split(','):
        value = entry.strip().upper().removeprefix('U+')
        if '-' in value:
            first, last = value.split('-')
            result.update(range(int(first, 16), int(last, 16) + 1))
        else:
            result.add(int(value, 16))
    return result


@lru_cache
def imported_faces():
    families = {}
    imports = re.findall(r'import\s+["\'](@fontsource[^"\']+)["\']', (ROOT / 'src/fonts.ts').read_text())
    for specifier in imports:
        parts = specifier.split('/')
        package = ROOT / 'node_modules' / '/'.join(parts[:2])
        stylesheet = package / ('/'.join(parts[2:]) or 'index.css')
        for face in re.findall(r'@font-face\s*\{([^}]+)\}', stylesheet.read_text()):
            assert 'font-style: normal' in face
            family = re.search(r'font-family:\s*["\']([^"\']+)', face).group(1)
            source = re.search(r'url\(([^)]+)\)', face).group(1).strip('"\'')
            weights = [int(n) for n in re.search(r'font-weight:\s*([^;]+)', face).group(1).split()]
            low, high = min(weights), max(weights)
            unicode_range = re.search(r'unicode-range:\s*([^;]+)', face).group(1)
            file = stylesheet.parent / source
            with TTFont(file, lazy=True) as font:
                if low != high:
                    axis = next(axis for axis in font['fvar'].axes if axis.axisTag == 'wght')
                    assert axis.minValue <= low and axis.maxValue >= high
                else:
                    assert font['OS/2'].usWeightClass == low
                glyphs = set(font.getBestCmap()) & ranges(unicode_range)
            families.setdefault(family, []).append((low, high, glyphs, file))
    return families


@lru_cache
def coverage(family, weight):
    # Require shipped normal/bold faces rather than relying on synthetic bold.
    faces = imported_faces()[family]
    matching = [face for face in faces if face[0] <= weight <= face[1]]
    assert matching, (family, weight)
    return set().union(*(face[2] for face in matching))


report = {'status': 'passed', 'languages': {}, 'totalScriptJsonBytes': 0,
          'totalTitleJsonBytes': 0, 'fontFamilies': {}}
for language, (family, label) in LANGUAGES.items():
    title_file = ROOT / f'content/title-translations/{language}.json'
    title_bundle = json.loads(title_file.read_text())
    script_files = sorted((ROOT / 'content/translations').glob(f'*/{language}.json'))
    values = [label, *(item['title'] for item in title_bundle['titles'])]
    for file in script_files:
        bundle = json.loads(file.read_text())
        values.extend([bundle['title'], *bundle['paragraphs']])
    text = '\n'.join(values)
    # Display parsers normalize to NFC; decomposed inputs are tested in Node.
    characters = {ord(c) for c in unicodedata.normalize('NFC', text)
                  if not c.isspace() and unicodedata.category(c) not in ('Cc', 'Cf')}
    missing_by_weight = {}
    for weight in [400, 700]:
        available = coverage(family, weight) | coverage('Nunito Variable', weight)
        missing_by_weight[str(weight)] = sorted(characters - available)
    missing = sorted(set().union(*map(set, missing_by_weight.values())))
    if missing or '\ufffd' in text:
        report['status'] = 'failed'
    report['languages'][language] = {
        'family': family, 'titles': len(title_bundle['titles']),
        'scripts': len(script_files), 'uniqueCodepointsNfc': len(characters),
        'missing': [f'U+{code:04X} {chr(code)}' for code in missing],
        'missingCountByWeight': {weight: len(values) for weight, values in missing_by_weight.items()},
        'replacementCharacterFound': '\ufffd' in text,
    }
    report['totalTitleJsonBytes'] += title_file.stat().st_size
    report['totalScriptJsonBytes'] += sum(file.stat().st_size for file in script_files)
for family, faces in sorted(imported_faces().items()):
    files = {face[3] for face in faces}
    report['fontFamilies'][family] = {
        'faces': len(faces), 'woff2Bytes': sum(file.stat().st_size for file in files),
        'availableCodepoints': len(coverage(family, 400)), 'weightsChecked': [400, 700],
    }
output = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
if '--write-report' in sys.argv:
    (ROOT / 'FONT_COVERAGE_REPORT.json').write_text(output)
print(output, end='')
if report['status'] != 'passed':
    raise SystemExit(1)
