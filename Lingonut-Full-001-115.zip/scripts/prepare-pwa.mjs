import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../dist/',import.meta.url));
async function walk(dir){return (await Promise.all((await readdir(dir,{withFileTypes:true})).map(e=>e.isDirectory()?walk(path.join(dir,e.name)):path.join(dir,e.name)))).flat();}
// Multilingual font subsets are cached when requested, rather than downloading
// every language's fonts during installation.
const files=(await walk(root)).map(p=>path.relative(root,p).split(path.sep).join('/')).filter(p=>!p.startsWith('audio/')&&!p.startsWith('pronunciation/')&&!p.startsWith('data/lessons/')&&!p.startsWith('data/translations/')&&!p.startsWith('data/titles/')&&!/\.woff2?$/i.test(p)&&!['sw.js','_headers'].includes(p)).sort();
const hash=createHash('sha256');for(const f of files)hash.update(f).update(await readFile(path.join(root,f)));
const code=`const CACHE='lingonut-${hash.digest('hex').slice(0,16)}';
const BASE=self.registration.scope;
const SHELL=${JSON.stringify(files)}.map(p=>new URL(p,BASE).href);
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>(k.startsWith('lingonut-')||k.startsWith('koalango-')||k.startsWith('english-unicorn-'))&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
async function remember(request,response){if(response.ok){try{await(await caches.open(CACHE)).put(request,response.clone());}catch{}}return response;}
self.addEventListener('fetch',e=>{
 const r=e.request,u=new URL(r.url);
 if(r.method!=='GET'||!u.href.startsWith(BASE)||r.headers.has('range')||u.pathname.includes('/audio/'))return;
 const network=async()=>remember(r,await fetch(r));
 if(r.mode==='navigate'){
  const home=new URL(u.pathname.endsWith('/donate.html')?'donate.html':'index.html',BASE).href;
  e.respondWith(fetch(r).then(res=>remember(home,res)).catch(async()=>(await caches.match(home))||new Response('Open Lingonut while online first.',{status:503})));
 }else if(u.pathname.endsWith('/data/index.json')){
  e.respondWith(network().catch(async()=>(await caches.match(r))||new Response('{}',{status:503})));
 }else if(SHELL.includes(u.href)||r.destination==='font'||u.pathname.includes('/data/lessons/')||u.pathname.includes('/data/translations/')||u.pathname.includes('/data/titles/')){
  e.respondWith(caches.match(r).then(saved=>saved||network()));
 }
});`;
await writeFile(path.join(root,'sw.js'),code);
console.log(`PWA shell: ${files.length} assets; audio loads on demand.`);
