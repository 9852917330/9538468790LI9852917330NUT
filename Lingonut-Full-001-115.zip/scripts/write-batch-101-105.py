"""Reviewed military, political, scientific and environmental turning points."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(101, 'd-day-normandy-landings-1944', 'D-Day 1944: The Allied Landings in Normandy', 'Wars and Historical Turning Points',
      'A multinational air, sea and land operation established Allied footholds in occupied France, beginning a difficult campaign rather than ending the war in a single day.',
'''By 1944, Nazi Germany controlled much of Western Europe during the Second World War. The Soviet Union was fighting German forces in the east. Allied leaders wanted to establish a major front in northwestern France, putting Germany under greater pressure and advancing through occupied territory.

Planning required months of training and an enormous build-up of troops and equipment in Britain. Commanders had to **coordinate** armies, ships and aircraft from many countries. American, British and Canadian forces would lead the beach landings, with wider international support.

Normandy was chosen for the **amphibious** attack. **Deception** plans encouraged German commanders to expect the main invasion nearer Calais. Intelligence gathering and French resistance activity also supported the preparations.

Bad weather delayed the operation by a day. Allied commander Dwight Eisenhower then accepted a brief improvement in conditions, and the invasion began on June 6, 1944.

During the night, **paratroopers** and troops carried by gliders landed behind the coast. They sought to secure bridges and routes and disrupt German responses. After air attacks and naval gunfire, landing craft carried soldiers towards five beaches: Utah, Omaha, Gold, Juno and Sword.

The defenders had prepared **fortifications**, mines and obstacles. Conditions varied greatly. Some units advanced relatively quickly; others faced intense fire, confusion and heavy **casualties**. Omaha became especially costly, but it was only one part of the wider operation.

By the end of the day, more than 150,000 Allied troops had reached Normandy by sea and air. They held **footholds** on all five beaches, although many objectives remained unmet. More than 4,000 Allied troops had died, and thousands more were wounded or missing. German forces and French civilians also suffered losses.

Ships continued bringing **reinforcements** and supplies. Fighting through Normandy lasted for weeks, causing further military and civilian deaths and widespread destruction. Paris was liberated in August; the war in Europe ended in May 1945.

D-Day made a major contribution to the **liberation** of Western Europe. Its success depended on combined operations and sustained effort after the first landings, alongside the wider Allied struggle against Germany.''',
[
v('coordinate', 'To organize different people or activities so that they work effectively together.', 'The commanders needed to coordinate air and ground operations.', 'Verb', verb=('coordinate','coordinated','coordinated',False)),
v('amphibious', 'Involving military forces moving from the sea onto land.', 'The amphibious operation required ships and landing troops.', 'Adjective'),
v('deception', 'The deliberate creation of a false belief in order to mislead someone.', 'Deception concealed the location of the planned landing.', 'Noun', plural='deceptions'),
v('paratrooper', 'A soldier trained to enter an area by parachuting from an aircraft.', 'The paratrooper landed behind the defensive positions.', 'Noun', form='paratroopers', plural='paratroopers'),
v('fortification', 'A defensive structure built to protect a place against attack.', 'The fortification guarded the coastal road.', 'Noun', form='fortifications', plural='fortifications'),
v('casualty', 'A person killed, wounded or otherwise lost to a force during a conflict or disaster.', 'The battle caused a high number of casualties.', 'Noun', form='casualties', plural='casualties', note='Military casualty totals may include missing or captured people as well as those killed or wounded.'),
v('foothold', 'A secure position from which further progress can be made.', 'The troops established a foothold on the coast.', 'Noun', form='footholds', plural='footholds'),
v('reinforcement', 'Additional people or equipment sent to strengthen an existing force.', 'The reinforcement arrived before the next attack.', 'Noun', form='reinforcements', plural='reinforcements', note='Often plural when referring to additional troops and equipment.'),
v('liberation', 'The act of freeing people or a place from occupation or oppressive control.', 'The liberation allowed displaced families to return.', 'Uncountable noun')
],
[
m('What was the main strategic purpose of the landings?', ['To establish a major front in France and increase pressure on Germany.', 'To defend Britain by keeping the Allied armies on the British side of the Channel.', 'To make Calais the main landing area after the Normandy campaign was abandoned.'], 'A', 'Allied leaders wanted to establish a major front in northwestern France, putting Germany under greater pressure and advancing through occupied territory.', 'The opening paragraph places Normandy within a wider war fought on several fronts.'),
m('Which description best matches the operation?', ['An attack centred on beach landings, with airborne troops arriving only after the coast was secured.', 'A coordinated air, sea and land operation with different tasks and varied outcomes.', 'Five beach assaults following the same timetable and encountering similar resistance.'], 'B', 'During the night, paratroopers and troops carried by gliders landed behind the coast.', 'The next sentences describe beach landings, air and naval support, while later passages explain the varied fighting.'),
m('What did the Allies achieve by the end of D-Day?', ['They had completed the liberation of Paris and ended the war in Europe.', 'They had captured every planned inland objective, allowing the next stage to begin without delay.', 'They held positions on all five beaches, but a difficult campaign still lay ahead.'], 'C', 'They held footholds on all five beaches, although many objectives remained unmet.', 'The later paragraphs distinguish the first day from the Normandy campaign and the eventual end of the war.'),
g('The invasion began on June 6, ___.', '1944', 'Allied commander Dwight Eisenhower then accepted a brief improvement in conditions, and the invasion began on June 6, 1944.', 'The operation followed extensive preparations and a weather delay.'),
g('Deception plans encouraged German commanders to expect the main landing nearer ___.', 'Calais', 'Deception plans encouraged German commanders to expect the main invasion nearer Calais.', 'The false expectation helped conceal the intended landing area.'),
g('Paris was liberated in ___.', 'August', 'Paris was liberated in August; the war in Europe ended in May 1945.', 'The city’s liberation came after the initial June landings.')
],
[
'National Army Museum, D-Day — Strategic setting, preparations, deception, combined command, airborne operations, five beaches and varied fighting: https://www.nam.ac.uk/explore/d-day',
'UK National Archives, Operation Overlord and D-Day — Primary records and institutional explanation of beaches, airborne contribution, landing logistics and the continuing supply effort: https://www.nationalarchives.gov.uk/explore-the-collection/explore-by-time-period/second-world-war/operation-overlord-and-d-day/',
'Imperial War Museums, 10 Things You Need to Know About D-Day — Multinational operation, more than 150,000 troops, costly first-day footholds and wider campaign; official UK web-archive copy used when the live page returned 403: https://tnaqa.mirrorweb.com/ukgwa/20260803083203mp_/https:/www.iwm.org.uk/history/second-world-war/d-day/10-things-you-need-to-know-about-d-day',
'National Army Museum, Normandy Campaign — Continuing combat, civilian losses and destruction, August liberation of Paris and wider consequences: https://www.nam.ac.uk/explore/normandy-campaign',
'Portsmouth City Council, The D-Day Story, D-Day facts — First-day death and troop estimates cross-checked; the current headline death number and nationality subtotals differ, so only more than 4,000 Allied dead is used: https://theddaystory.com/discover/what-is-d-day/'
],
[
'Full-event overview includes the wider war, strategic purpose, international preparation, deception and resistance, weather, airborne and beach operations, varied fighting, incomplete objectives, human losses, supply and the later campaign.',
'The five beaches and airborne operations remain visible; Omaha is not allowed to dominate the story. Main beach forces were American, British and Canadian, with personnel and support from other countries.',
'The troop total includes both sea and airborne arrivals. Casualties are not equated with deaths. More than 4,000 Allied dead avoids inconsistent precise institutional totals, and losses among German forces and civilians are acknowledged.',
'D-Day is June 6, not the whole Normandy campaign. Operation Neptune is the assault phase within Overlord. The story does not imply that the Allies had never previously fought in continental Europe or that France, Paris or Europe was liberated in a single day.',
'Compared with every 001–100 topic, planning records and the other four batch subjects. Normandy is distinct from 007’s Pearl Harbor, 008’s Hiroshima, 023’s Holocaust and 052’s Hitler biography. No whole-Second-World-War lesson is duplicated.'
])

draft(102, 'chile-military-coup-1973', 'Chile 1973: A Coup and the Beginning of Military Rule', 'World Events and Political Change',
      'A violent overthrow ended Salvador Allende’s elected government and brought years of military dictatorship, repression and a difficult return to civilian rule.',
'''In 1970, Salvador Allende became Chile's elected president at the head of a left-wing coalition. He sought to build socialism through democratic institutions. His government expanded social programmes, redistributed land and **nationalized** major industries, including copper production.

Supporters hoped these changes would reduce inequality. Opponents feared growing state control and challenged the government's policies. Political **polarization** deepened as inflation, **shortages** and strikes disrupted everyday life. Conflict grew between the government, opposition parties, business groups and other institutions.

The Cold War also shaped events. The United States government opposed Allende and supported opposition activities through **covert** funding. Chile's crisis involved both domestic struggles and foreign pressure; it cannot be explained by one actor or cause alone.

On September 11, 1973, Chile's armed forces and national police carried out a **coup**. Naval forces took control in Valparaíso, while military units seized important sites elsewhere. In Santiago, troops surrounded the presidential palace, La Moneda. Aircraft attacked it, and the building burned.

Allende refused to resign. He died inside the palace; later official investigations concluded that he had killed himself. The elected government was overthrown, and a military **junta** took power. Army commander Augusto Pinochet increasingly became its dominant figure.

Congress was closed, political parties were banned or restricted, and censorship silenced opposition. Stadiums and other sites became centres of **detention**. The regime used imprisonment, **torture**, killings and forced disappearance against people it treated as enemies.

Across the years of military rule, more than 3,000 people were killed or disappeared, and tens of thousands were imprisoned for political reasons or tortured. Many Chileans went into exile. Economic policies also changed sharply under the dictatorship, transforming work and social services.

In a 1988 **referendum**, voters rejected extending Pinochet's presidency. Elections followed, and an elected civilian government took office in March 1990. The transition left difficult questions about military influence, victims' rights and accountability.

The coup became an international symbol of democracy's destruction during the Cold War. Its aftermath showed how a change of government by force could reshape a society for generations.''',
[
v('nationalize', 'To transfer a privately owned company or industry into state ownership.', 'The government proposed to nationalize the industry.', 'Verb', form='nationalized', verb=('nationalize','nationalized','nationalized',False)),
v('polarization', 'The division of people or opinions into sharply opposed groups.', 'Political polarization made agreement increasingly difficult.', 'Uncountable noun'),
v('shortage', 'A situation in which there is not enough of something that is needed.', 'The shortage forced families to wait for basic supplies.', 'Noun', form='shortages', plural='shortages'),
v('covert', 'Kept secret or not openly acknowledged.', 'The investigation revealed covert support for the group.', 'Adjective'),
v('coup', 'A sudden seizure of government power by a small group, often involving the military.', 'The coup brought the elected government to an end.', 'Noun', plural='coups'),
v('junta', 'A group of military leaders who govern a country after taking power.', 'The junta issued new restrictions on political activity.', 'Noun', plural='juntas'),
v('detention', 'The act or condition of being held in custody and prevented from leaving.', 'The family searched for information about his detention.', 'Uncountable noun'),
v('torture', 'The deliberate infliction of severe pain or suffering, often to punish, intimidate or obtain information.', 'Survivors gave evidence about torture in custody.', 'Uncountable noun'),
v('referendum', 'A public vote on a particular political question.', 'The referendum asked whether the president should remain in office.', 'Noun', plural='referendums')
],
[
m('How does the story explain the crisis before the coup?', ['Foreign pressure created the crisis while domestic support for Allende remained united.', 'Domestic political and economic struggles interacted with Cold War foreign pressure.', 'Inflation and shortages reduced political divisions by producing agreement over nationalization.'], 'B', 'Chile\'s crisis involved both domestic struggles and foreign pressure; it cannot be explained by one actor or cause alone.', 'The earlier paragraphs describe policy disputes, inflation, shortages and foreign opposition.'),
m('What followed the overthrow of Allende’s government?', ['A civilian caretaker government restored Congress and arranged an immediate election.', 'The junta restricted political parties but kept opposition supporters outside its detention system.', 'Military leaders took power, suppressed opposition and used systematic repression.'], 'C', 'Congress was closed, political parties were banned or restricted, and censorship silenced opposition.', 'The following sentences describe detention, torture, killings and disappearance under the regime.'),
m('What role did the 1988 referendum play?', ['Voters rejected extending Pinochet’s presidency, helping open the route to elections and civilian government.', 'It approved another presidential term for Pinochet before civilian elections could be held.', 'It replaced Pinochet with a civilian president on voting day, completing the transfer immediately.'], 'A', 'In a 1988 referendum, voters rejected extending Pinochet\'s presidency.', 'The following sentences describe later elections, the March 1990 transfer and unresolved issues.'),
g('Allende became president in ___.', '1970', 'In 1970, Salvador Allende became Chile\'s elected president at the head of a left-wing coalition.', 'His government preceded the September 1973 coup.'),
g('The presidential palace attacked during the coup was La ___.', 'Moneda', 'In Santiago, troops surrounded the presidential palace, La Moneda.', 'The palace became one of the main sites of the overthrow.'),
g('The elected civilian government took office in March ___.', '1990', 'Elections followed, and an elected civilian government took office in March 1990.', 'The transfer followed the 1988 vote and subsequent elections.')
],
[
'Chile National Archives, 11 de septiembre 1973: Golpe civil-militar — Naval uprising, junta composition, Allende’s refusal, palace attack, death and the beginning of repression: https://www.archivonacional.gob.cl/11-de-septiembre-1973-golpe-civil-militar',
'Chile National Library, Memoria Chilena, El gobierno de la Unidad Popular (1970–1973) — Programme, nationalization, conflict and collapse; inconsistent peripheral confirmation/inauguration date entries are not adopted: https://www.memoriachilena.gob.cl/602/w3-article-31433.html',
'Chile National Library, Memoria Chilena, Junta Militar de Gobierno — Military and police junta and removal of democratic institutions; the junta’s own justifications are not repeated as established fact: https://www.memoriachilena.gob.cl/602/w3-article-92407.html',
'US State Department Office of the Historian, Foreign Relations of the United States, Chile 1969–1973 — Declassified documentary context for US opposition and covert activity, distinguished from Chilean forces’ execution of the coup: https://history.state.gov/historicaldocuments/frus1969-76v21',
'Chile Congressional Library, Salvador Allende biography — Election, democratic socialist programme and suicide conclusion: https://www.bcn.cl/historiapolitica/resenas_biograficas/wiki/Salvador_Allende_Gossens',
'Chile Congressional Library, El Golpe de Estado y sus consecuencias para la memoria histórica — Junta, repressive institutional changes, economic policy and later civilian transition: https://www.bcn.cl/conmemoracion50-septiembre-1973/golpe_estado.html',
'US State Department, original covert-funding memorandum — Primary documentary evidence of opposition funding: https://history.state.gov/historicaldocuments/frus1969-76ve16/d145',
'Museo de la Memoria, truth-commission summaries — Distinct recognized categories of execution/disappearance and political imprisonment/torture over the dictatorship: https://comisiones.museodelamemoria.cl/category/sin-categoria/',
'Museo de la Memoria y los Derechos Humanos, September 11 chronology — Museum documentation of the overthrow and violent end of elected government: https://mmdh.cl/noticias/cultura/post-noticia-175'
],
[
'Overview covers the elected reform programme, political and economic divisions, domestic and foreign pressures, the nationwide military action and palace attack, junta and Pinochet, systematic repression and exile, and the later route to civilian government.',
'US covert opposition is documented without claiming that US troops conducted the coup or that a single foreign intervention fully explains the crisis. Economic problems and political disagreement do not justify the subsequent human-rights violations.',
'Allende’s death is described using official investigation conclusions, without method or graphic detail. The palace attack supports the whole event rather than becoming the entire story.',
'The junta included military branches and national police. Pinochet’s growing dominance is distinguished from a claim that the initial junta had only one member.',
'Death/disappearance and political imprisonment/torture are distinct categories covering the dictatorship, not casualties on September 11 alone. Approximate broad totals avoid conflating changing official recognition counts.',
'The 1988 vote, later elections and March 1990 civilian transfer are distinct. The transition did not immediately settle military influence or victims’ claims. Contemporary constitutional or legal developments are outside the historical scope.',
'Compared with all 001–101 topics and other batch subjects. This is Chile’s 1973 coup, distinct from 035’s 2010 mine rescue, 096’s Iranian revolution and 099’s Prague Spring.'
])

draft(103, 'higgs-boson-discovery-2012', 'The Higgs Boson: Finding a Missing Piece of Particle Physics', 'Discoveries That Changed the World',
      'Decades of theoretical work and international experiments led to a new particle, providing evidence for the Higgs field while leaving major questions open.',
'''For decades, physicists faced a difficult question about nature's tiny building blocks. Their theory, the Standard Model, successfully described **elementary** particles and their interactions. However, explaining how some particles have **mass** required an additional idea that could be tested.

In 1964, several teams proposed related solutions. Their work included contributions from Peter Higgs, François Englert and Robert Brout. The idea involved a **field** present throughout space. Elementary particles such as electrons acquire mass through interaction with this field. The theory also **predicted** a related particle, the Higgs boson, which scientists could search for.

The search required powerful machines and years of development. At CERN near Geneva, the Large Hadron Collider brought protons together at very high energies. Two separate experiments, ATLAS and CMS, used enormous instruments and international teams to examine the results.

When protons **collided**, new particles could briefly appear. Higgs bosons **decayed** almost immediately into other particles. The experiments' **detectors** measured these products, allowing researchers to reconstruct evidence of what had happened.

One unusual event would not be enough. Scientists looked for **statistical** patterns across large amounts of data and compared them with processes already understood. The two experiments independently found signals strong enough to meet the usual discovery standard.

On July 4, 2012, they announced a new particle consistent with the predicted Higgs boson. Further measurements were needed to establish its nature. By March 2013, additional results strongly indicated that it was a Higgs boson, while its detailed properties remained under study.

The 2013 Nobel Prize in Physics honoured Englert and Higgs for the theoretical mechanism. The experimental achievement depended on international **collaboration**, including scientists, engineers and technical staff.

The discovery supported a central part of the Standard Model, but it did not explain every source of mass. Most mass in protons and neutrons comes from energy inside them. Questions about gravity and dark matter also remained open.

Finding the Higgs boson showed how a proposal could become measurable evidence through decades of theory, engineering and careful checks.''',
[
v('elementary', 'Not known to be made of smaller parts, in the context of particles.', 'An electron is an elementary particle.', 'Adjective', note='In particle physics; in other contexts elementary can mean basic or introductory.'),
v('mass', 'A physical property that measures an object’s resistance to changes in its motion.', 'The experiment measured the particle’s mass.', 'Uncountable noun', note='Mass and weight are different: weight depends on gravity.'),
v('field', 'A physical quantity or influence present throughout a region of space.', 'The theory described a field extending throughout space.', 'Noun', plural='fields', note='Used here in the physics sense.'),
v('predict', 'To state what is expected to happen or be found, based on evidence or a theory.', 'The theory could predict a result before it was measured.', 'Verb', form='predicted', verb=('predict','predicted','predicted',False)),
v('collide', 'To crash into or strike something else.', 'The particles collide inside the machine.', 'Verb', form='collided', verb=('collide','collided','collided',False)),
v('decay', 'To change into other particles, in the context of particle physics.', 'The unstable particle can decay into lighter particles.', 'Verb', form='decayed', verb=('decay','decayed','decayed',False), note='A specialized physics use; it does not mean ordinary biological rotting here.'),
v('detector', 'An instrument that identifies or measures the presence of something.', 'The detector recorded the particles leaving the collision.', 'Noun', form='detectors', plural='detectors'),
v('statistical', 'Relating to the collection and analysis of numerical data.', 'The team used statistical analysis to test the signal.', 'Adjective'),
v('collaboration', 'People or groups working together to achieve a shared result.', 'The discovery depended on international collaboration.', 'Noun', plural='collaborations', note='Often uncountable when describing the activity of working together.')
],
[
m('What problem did the proposed Higgs field help address?', ['How protons and neutrons obtain most of their mass directly from the Higgs field.', 'How gravity fits into the Standard Model’s account of elementary particles.', 'How elementary particles such as electrons could have mass.'], 'C', 'Elementary particles such as electrons acquire mass through interaction with this field.', 'The opening paragraphs connect the mass problem to the theoretical proposal.'),
m('How did ATLAS and CMS obtain evidence for the new particle?', ['They studied decay products and statistical patterns across many collisions.', 'They stored long-lived Higgs bosons and examined them directly over several years.', 'They compared the largest single collision in each experiment and set other events aside.'], 'A', 'Scientists looked for statistical patterns across large amounts of data and compared them with processes already understood.', 'The preceding paragraph explains how detectors measured the particles produced by rapid decay.'),
m('What was the significance of the discovery?', ['It established that every kind of mass comes only from the Higgs field.', 'It supported part of the Standard Model while leaving important questions unresolved.', 'It explained gravity and dark matter through the new particle’s measured interactions.'], 'B', 'The discovery supported a central part of the Standard Model, but it did not explain every source of mass.', 'The final paragraphs distinguish the achievement from unresolved questions about mass, gravity and dark matter.'),
g('CERN is near ___.', 'Geneva', 'At CERN near Geneva, the Large Hadron Collider brought protons together at very high energies.', 'The location provides the setting for the two experiments.'),
g('The experiments announced the new particle on July 4, ___.', '2012', 'On July 4, 2012, they announced a new particle consistent with the predicted Higgs boson.', 'Later measurements strengthened the interpretation of the initial discovery.'),
g('The 2013 Nobel Prize honoured Englert and ___.', 'Higgs', 'The 2013 Nobel Prize in Physics honoured Englert and Higgs for the theoretical mechanism.', 'The award recognized theoretical work, while the story also credits the experimental teams.')
],
[
'CERN, What is the Higgs boson? — Theoretical mass problem, field and boson distinction: https://home.web.cern.ch/science/physics/higgs-boson/what/',
'ATLAS Collaboration, Higgs boson overview — Three 1964 theory teams, ATLAS/CMS experimental contributions and continued study: https://atlas.cern/Discover/Physics/Higgs',
'CERN, original July 4, 2012 announcement — Independent discovery-level signals, preliminary new-particle interpretation and the need for further measurements: https://home.cern/cern-experiments-observe-particle-consistent-with-long-sought-higgs-boson/',
'CMS Collaboration, Observation of a New Particle with a Mass of 125 GeV, original announcement — Collision and decay evidence, detector measurements and statistical analysis: https://cms.cern/index.php/physics/higgs-boson/observation-new-particle-mass-125-gev',
'CERN, original March 14, 2013 announcement — Additional data strongly indicating a Higgs boson, with its detailed nature still requiring study: https://home.cern/new-results-indicate-that-particle-discovered-at-cern-is-a-higgs-boson/',
'Royal Swedish Academy of Sciences, original 2013 Nobel announcement — Englert/Higgs award, theory and experimental credit; accessible primary Academy announcement used when NobelPrize.org returned 403: https://www.kva.se/en/news/nobelpriset-i-fysik-2013-2/',
'CERN, The other 99% — Most proton and neutron mass arises from strong-interaction energy rather than directly from quark Higgs masses: https://home.cern/other-99/',
'CERN, The Standard Model — Successes and limits, including gravity and dark matter: https://home.cern/science/physics/standard-model/'
],
[
'Overview explains the original mass question, several theory teams, field and predicted boson, machine and two experiments, rapid decay and reconstruction, statistical comparison, the 2012 announcement and 2013 clarification, shared credit and remaining limits.',
'The field and its particle are distinct. Elementary-particle mass is not confused with all mass in ordinary matter, and no friction or slowing-through-syrup analogy is used. The proton/neutron energy qualification is retained.',
'Researchers reconstructed evidence from decay products rather than photographing a persistent Higgs particle. Independent ATLAS/CMS signals and comparison with background processes are described without interpreting significance as the probability that an entire theory is true.',
'The initial 2012 wording consistent with Higgs and the stronger March 2013 interpretation are distinct. No claim of complete knowledge of the particle’s properties or solution of gravity/dark matter is made.',
'The Nobel recognized Englert and Higgs for theory, while Brout, other theory teams and the large experimental collaborations are acknowledged. Direct NobelPrize.org access was blocked, so the accessible Royal Swedish Academy primary announcement supplies the award evidence.',
'Compared with all 001–102 topics and the remaining batch subjects. The Higgs discovery is distinct from 079’s relativity eclipse, 068’s radioactivity and 098’s X-ray discovery.'
])

draft(104, 'great-smog-london-1952', 'London 1952: The Great Smog and the Fight for Cleaner Air', 'Disasters and Environmental Change',
      'Coal pollution and unusual weather trapped a deadly mixture over London, exposing a public-health danger and helping drive lasting changes in air-pollution policy.',
'''London was familiar with smoke and fog long before 1952. Coal heated homes and powered industry, leaving dirty air above a crowded city. In early December, bitter cold led households to burn more fuel, while factories and power stations continued releasing pollution.

On December 5, 1952, weather conditions turned this everyday problem into a disaster. Winds were light, and a layer of warmer air lay above colder air near the ground. This temperature **inversion** prevented polluted air from rising and mixing freely. Smoke from thousands of **chimneys** could not **disperse** normally.

Fog droplets mixed with particles and gases. Chemical changes made the mixture still more harmful, including the formation of acidic pollution. A thick yellow-brown **smog** covered London. The danger came from polluted air trapped by the weather, rather than ordinary fog alone.

As **visibility** fell to a few metres, people struggled to find familiar streets. Many buses stopped, cars were abandoned and travel became dangerous. The polluted air also entered buildings, so remaining indoors did not fully separate people from the event.

The mixture was **toxic**. Many Londoners developed severe breathing problems, especially people already living with **respiratory** illness. The visible smog cleared on December 9 as the weather changed, but its health effects continued.

Early estimates put the death toll at about 4,000. Later research **estimated** around 12,000 deaths above the expected level from December 1952 through February 1953. These figures describe different assessments and time periods, rather than an exact count of everyone who died during the five visible days.

The disaster increased pressure for government action. Investigations and debate helped lead to the Clean Air Act of 1956. Smoke-control areas, cleaner fuels and restrictions on **emissions** formed part of the response. Further legislation followed in 1968.

Change took time. Households and industries needed new equipment and different fuels, and serious smoky fogs did not vanish immediately. Gradually, changes in heating and regulation reduced the old coal-smoke problem.

The Great Smog showed that familiar urban pollution could become a mass public-health emergency when harmful emissions and weather conditions combined.''',
[
v('inversion', 'A reversal of the usual arrangement; here, warmer air lies above colder air near the ground.', 'The temperature inversion trapped pollution above the city.', 'Noun', plural='inversions', note='Temperature inversion is the weather expression used in the story.'),
v('chimney', 'A structure that carries smoke or gases out of a building.', 'Smoke rose from the factory chimney.', 'Noun', form='chimneys', plural='chimneys'),
v('disperse', 'To spread out over a wider area.', 'A stronger wind helped the smoke disperse.', 'Verb', verb=('disperse','dispersed','dispersed',False)),
v('smog', 'Polluted air containing smoke, gases or particles, sometimes mixed with fog.', 'Thick smog reduced visibility across the city.', 'Uncountable noun'),
v('visibility', 'The distance or degree to which things can be seen clearly.', 'Visibility fell sharply during the fog.', 'Uncountable noun'),
v('toxic', 'Poisonous or capable of causing serious harm to living things.', 'The factory released toxic gases.', 'Adjective'),
v('respiratory', 'Relating to breathing and the organs used for it.', 'The pollution worsened respiratory illness.', 'Adjective'),
v('estimate', 'To calculate an approximate amount or value using available information.', 'Researchers estimate the impact by comparing different records.', 'Verb', form='estimated', verb=('estimate','estimated','estimated',False)),
v('emission', 'A substance released into the air, or the act of releasing it.', 'The new rule limited smoke emissions.', 'Noun', form='emissions', plural='emissions')
],
[
m('Why did pollution become especially dangerous in December 1952?', ['Coal smoke and other pollution became trapped by light winds and a temperature inversion.', 'A temperature inversion carried most chimney smoke out of London while moisture remained below.', 'Coal use produced the disaster independently of winds and the arrangement of air layers.'], 'A', 'This temperature inversion prevented polluted air from rising and mixing freely.', 'The opening paragraphs connect increased coal use, existing emissions and the unusual weather.'),
m('Why does the story mention two different death estimates?', ['The smaller figure covers London, while the larger one covers the whole of Britain.', 'They come from different assessments and time windows, including later health effects.', 'The later study counted only deaths between December 5 and 9, correcting the earlier register.'], 'B', 'These figures describe different assessments and time periods, rather than an exact count of everyone who died during the five visible days.', 'The preceding sentences distinguish early estimates from later research covering December through February.'),
m('How did the policy response develop?', ['The visible smog cleared when a new law immediately stopped coal burning across London.', 'Reforms targeted road travel while coal heating and factory smoke stayed outside the response.', 'Laws, cleaner fuels and changes in equipment gradually reduced coal-smoke pollution.'], 'C', 'Gradually, changes in heating and regulation reduced the old coal-smoke problem.', 'The story separates the 1956 and 1968 legislation from the slower practical changes that followed.'),
g('The main visible episode began on December 5, ___.', '1952', 'On December 5, 1952, weather conditions turned this everyday problem into a disaster.', 'The weather and existing pollution combined to produce the main episode.'),
g('The visible smog cleared on December ___.', '9', 'The visible smog cleared on December 9 as the weather changed, but its health effects continued.', 'Clearing of the air did not mean that every health consequence had ended.'),
g('The first Clean Air Act discussed in the story was passed in ___.', '1956', 'Investigations and debate helped lead to the Clean Air Act of 1956.', 'The law came several years after the disaster.')
],
[
'UK Met Office, The Great Smog of 1952 — December 5–9, cold-weather coal burning, inversion, weak mixing, pollution chemistry, visibility, clearing and gradual legislative response: https://weather.metoffice.gov.uk/learn-about/weather/case-studies/great-smog',
'London Museum, The Great Smog of 1952 — Industrial and domestic smoke, disruption, indoor pollution and human consequences; its five-day wording for the early death estimate is not treated as a universally settled time window: https://www.londonmuseum.org.uk/collections/london-stories/the-great-smog-of-1952/',
'Bell and Davis, Environmental Health Perspectives, 2001, original research abstract, PMID 11427388 — Approximately 12,000 excess deaths across December 1952–February 1953; indexed PubMed abstract checked when PMC full text encountered CAPTCHA: https://pubmed.ncbi.nlm.nih.gov/11427388/',
'UK Parliament, House of Commons, Clean Air Bill debate, February 4, 1955 — Contemporary discussion of about 4,000 deaths, later mortality and legislative action: https://api.parliament.uk/historic-hansard/commons/1955/feb/04/clean-air-bill'
],
[
'Full-event overview covers longstanding coal dependence, cold weather and multiple pollution sources, the inversion and fog-pollutant mixture, visibility and transport problems, indoor exposure and illness, mortality after clearing, research uncertainty and the gradual policy response.',
'The event is neither ordinary fog alone nor a repeat of the 1666 fire. Weather trapped pollution generated by heating, industry and other sources; the account does not blame individual poor households or identify one chemical reaction as the sole mechanism.',
'The visible episode lasted December 5–9. Early approximately 4,000-death estimates have inconsistent institutional time-window wording. The later approximately 12,000 excess-death estimate explicitly covers December through February, not five days.',
'The Clean Air Act of 1956 and later 1968 law are distinct from the smog’s clearing in 1952. Implementation, fuel changes and equipment changes took time; the account does not claim an immediate end to all air pollution.',
'This is historical public-health context, not current individual medical guidance. The original research abstract was accessible, while the blocked PMC full text is not presented as read.',
'Compared with all 001–103 topics and the remaining batch subject. The Great Smog is distinct from 077’s Great Fire of London, 032’s Bhopal gas disaster and 080’s ozone discovery.'
])

draft(105, 'fall-constantinople-1453', 'Constantinople 1453: Conquest and a New Imperial Capital', 'Wars and Historical Turning Points',
      'Ottoman conquest ended Byzantine rule in Constantinople, bringing violence and captivity before rebuilding transformed the city into the centre of another empire.',
'''Constantinople stood at a **strategic** meeting point between Europe and Asia, connecting routes towards the Mediterranean and Black Sea. For centuries it had been the capital of the Byzantine, or Eastern Roman, Empire, with powerful walls, churches and a rich cultural life.

By 1453, that empire had become much weaker and smaller. Ottoman power had expanded across the surrounding region. Sultan Mehmed II wanted the city, while Emperor Constantine XI prepared to defend it with limited forces and help from some Italian allies.

The Ottoman **siege** began in April. Strong **fortifications** protected the city, but the attackers brought large cannons and many troops. Their fleet also attempted a **blockade**, threatening sea access and the arrival of supplies.

Repeated **bombardment** damaged the walls. Defenders repaired broken sections with earth, timber and other materials and resisted further attacks. The struggle involved artillery, naval pressure, supplies and exhausted people, rather than a single weapon deciding everything immediately.

On May 29, Ottoman forces launched a major assault and broke through the defences. **Breaches** allowed more attackers into the city. Constantine XI died during the fighting, and Byzantine imperial rule in Constantinople ended. Other Byzantine territories survived for several more years, but the old capital was lost.

The conquest brought killing, looting and captivity. Many civilians were **enslaved**, and families faced loss and displacement. These experiences formed part of the event alongside its military and political consequences.

Mehmed then worked to restore the city and make it his imperial capital. Rebuilding included new projects, efforts to revive economic life and **resettlement**, sometimes forced, of people from other places. Muslims, Christians and Jews became part of the renewed city.

Hagia Sophia was converted into a mosque. A Greek patriarch was appointed in 1454, allowing an important Christian institution to continue under Ottoman authority. Religious continuity existed within a changed and unequal political order.

The fall strengthened Ottoman power in the eastern Mediterranean and ended Constantinople's long role as a Byzantine capital. Its **legacy** included both the destruction experienced by the conquered and the growth of a transformed, diverse Ottoman city.''',
[
v('strategic', 'Important for achieving a larger military, political or economic aim.', 'The port occupied a strategic position on the trade route.', 'Adjective'),
v('siege', 'A military operation that surrounds a defended place and tries to force it to surrender.', 'The siege cut the city off from much-needed supplies.', 'Noun', plural='sieges'),
v('fortification', 'A defensive structure built to protect a place against attack.', 'The fortification protected the entrance to the city.', 'Noun', form='fortifications', plural='fortifications'),
v('blockade', 'An action that prevents people or supplies from entering or leaving an area.', 'The naval blockade threatened the city’s food supply.', 'Noun', plural='blockades'),
v('bombardment', 'A sustained attack using artillery, bombs or similar weapons.', 'The bombardment damaged several defensive walls.', 'Noun', plural='bombardments'),
v('breach', 'An opening or break in a wall, defence or protective barrier.', 'The troops moved through a breach in the wall.', 'Noun', form='Breaches', plural='breaches'),
v('enslave', 'To take away a person’s freedom and force them into slavery.', 'Capturing a town could lead to attempts to enslave its inhabitants.', 'Verb', form='enslaved', verb=('enslave','enslaved','enslaved',False)),
v('resettlement', 'The process of moving people to a new place to live, voluntarily or by force.', 'The government organized the resettlement of families in the city.', 'Noun', plural='resettlements'),
v('legacy', 'A lasting effect or inheritance left by an event, person or period.', 'The conflict left a complex cultural and political legacy.', 'Noun', plural='legacies')
],
[
m('Why was Constantinople important before the siege?', ['It was a regional trading town whose political importance had ended when western Rome fell.', 'It was an imperial capital at a strategic meeting point of regions and routes.', 'It was already the Ottoman capital and had no remaining Byzantine government.'], 'B', 'Constantinople stood at a strategic meeting point between Europe and Asia, connecting routes towards the Mediterranean and Black Sea.', 'The opening also describes its long role as the Byzantine capital.'),
m('How does the story explain the military struggle?', ['Land attacks alone shaped the siege because Ottoman ships made no effort to restrict supplies.', 'The defenders left damaged walls unrepaired and relied only on foreign relief.', 'Bombardment, sea pressure, repairs, supplies and repeated fighting shaped the siege.'], 'C', 'The struggle involved artillery, naval pressure, supplies and exhausted people, rather than a single weapon deciding everything immediately.', 'The preceding paragraphs describe both Ottoman attacks and the defenders’ responses.'),
m('What followed the conquest?', ['Violence and enslavement were followed by rebuilding and resettlement under Ottoman rule.', 'The city remained largely empty because Mehmed moved the imperial government elsewhere.', 'The conquest removed every Christian institution as the city was rebuilt exclusively for Muslims.'], 'A', 'Mehmed then worked to restore the city and make it his imperial capital.', 'The surrounding paragraphs include civilian suffering and the later transformation of the city.'),
g('The Ottoman sultan leading the siege was Mehmed ___.', 'II', 'Sultan Mehmed II wanted the city, while Emperor Constantine XI prepared to defend it with limited forces and help from some Italian allies.', 'The story distinguishes the Ottoman sultan from the Byzantine emperor.'),
g('Ottoman forces captured the city on May ___.', '29', 'On May 29, Ottoman forces launched a major assault and broke through the defences.', 'The final assault came after weeks of siege beginning in April 1453.'),
g('A Greek patriarch was appointed in ___.', '1454', 'A Greek patriarch was appointed in 1454, allowing an important Christian institution to continue under Ottoman authority.', 'The appointment formed part of the city’s new political and religious arrangements.')
],
[
'British Library, The last day of Constantinople, Peter Toth — Geography, weakened Byzantine state, leaders, April siege and manuscript context: https://www.bl.uk/stories/blogs/posts/the-last-day-of-constantinople',
'University of Chicago Library, Converting Constantinople — April opening and May 29 conquest; its questionable population superlative is not used: https://www.lib.uchicago.edu/collex/exhibits/tensions-renaissance-cities/converting-constantinople/',
'Kritovoulos, primary account in English translation, Society for Medieval Military History — Naval blockade, cannon damage, repairs, emperor’s death, killing, looting and enslavement. Written under Ottoman patronage; broad events are cross-checked and literary speeches or precise counts are not adopted: https://deremilitari.org/2016/08/the-siege-of-constantinople-in-1453-according-to-kritovoulos/',
'Cambridge University Press, A Guide to Byzantine Historical Writing, Michael Kritovoulos, accessible chapter description — Rebuilding, forced resettlement, religious institutions and economic revival; the accessible summary is used without claiming to have read the entire book: https://www.cambridge.org/core/books/abs/guide-to-byzantine-historical-writing/michael-kritovoulos/8472D162FD3EF44318F656608546115D',
'Metropolitan Museum of Art, Hagia Sophia — Conversion into a mosque after the Ottoman conquest: https://www.metmuseum.org/essays/hagia-sophia-532-37',
'Byzantine and Christian Museum, The Fall of Constantinople — Conquest and the continuity of Byzantine cultural life beyond the loss of the capital: https://www.byzantinemuseum.gr/en/exhibitions/48/permanent-exhibition/the-byzantine-world/31/the-fall-of-constantinople'
],
[
'Overview balances geography and Byzantine weakening, Ottoman objectives and the defenders, artillery and naval pressure, repairs and final assault, civilian suffering, imperial transition, rebuilding, resettlement and religious/cultural continuity.',
'The Eastern Roman or Byzantine imperial government in Constantinople ended; other Byzantine territories survived beyond 1453. The account does not conflate this event with the western imperial ending in 476 or claim every Greek political community ended on May 29.',
'The emperor’s death is included without an unsupported heroic death scene. No exact disputed troop, death or population count, gate legend or single-superweapon explanation is used.',
'Killing, captivity and enslavement are not hidden behind the later rebuilding. Resettlement could involve coercion; diversity and institutional continuity do not imply equal rights or a wholly peaceful transfer.',
'The narrative does not claim immediate official renaming to Istanbul, the end of all Europe–Asia trade or a single cause of the Renaissance or Columbus’s voyages. Present-day Hagia Sophia policy is outside the historical scope.',
'Compared with all 001–104 topics and planning records. This is the Ottoman conquest of Constantinople, distinct from 072’s Qin unification, 073’s Mongol founder and 071’s Napoleonic life.'
])
