import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const checks = [
  ["node_modules/typescript/bin/tsc", "--noEmit"],
  ["--test", "scripts/check-translations.test.mjs", "scripts/check-translation-preferences.test.mjs", "scripts/check-topics.test.mjs"],
  ["scripts/build.mjs"],
];
for (const args of checks) {
  const result = spawnSync(process.execPath, args, { cwd: root, stdio: "inherit" });
  if (result.status !== 0) process.exit(result.status || 1);
}
