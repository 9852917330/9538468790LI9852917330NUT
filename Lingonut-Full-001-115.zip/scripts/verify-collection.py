"""Verify the complete collection against its audio, subtitles and baseline edition."""
from pathlib import Path
import datetime
import hashlib
import html
import json
import re
import subprocess
import unicodedata

root = Path(__file__).resolve().parent.parent
lessons = sorted((json.loads(p.read_text()) for p in (root / 'content/lessons').glob('*.json')), key=lambda d: d['order'])
lessons = [d for d in lessons if d.get('published', True)]
assert [d['order'] for d in lessons] == list(range(1, len(lessons) + 1))
base = '064947b1105b20c60a0658599d2be87470f0f26d'
paths = ['content/settings.json', 'public/donations', 'components/site-chrome.tsx']
paths += [f'content/{folder}/{n:03}{extension}' for n in range(1, 101) for folder, extension in [('lessons', '.json'), ('audio', '.mp3'), ('audio', '.meta.json'), ('subtitles', '.vtt'), ('tts', '.txt')]]
assert subprocess.run(['git', 'diff', '--quiet', base, '--', *paths], cwd=root).returncode == 0, 'Existing edition changed'
normalize = lambda s: re.sub(r'[^a-z0-9]', '', unicodedata.normalize('NFKD', html.unescape(s)).lower())
for lesson in lessons:
    stem = f"{lesson['order']:03}"
    plain = lesson['script'].replace('**', '').strip()
    meta = json.loads((root / f'content/audio/{stem}.meta.json').read_text())
    assert meta['scriptSha256'] == hashlib.sha256(plain.encode()).hexdigest(), stem
    assert meta['voice'] == ('en-US-BrianNeural' if lesson['order'] % 2 else 'en-US-AvaNeural') and meta['completeSubtitleMatch']
    assert (root / f'content/tts/{stem}.txt').read_text().strip() == plain
    assert len(plain.split()) <= 350 and 8 <= len(lesson['phrases']) <= 15
    vtt = (root / f'content/subtitles/{stem}.vtt').read_text()
    spoken = ' '.join(' '.join(c.splitlines()[2:]) for c in re.split(r'\n\s*\n', vtt.strip())[1:])
    assert normalize(spoken) == normalize(plain), stem
    assert len(lesson['questions']) == 6
    for question in lesson['questions']:
        assert question['evidence'] in plain
        if question['type'] == 'gap':
            assert len(question['answer'].split()) == 1 and re.search(r'\b' + re.escape(question['answer']) + r'\b', question['evidence'], re.I)
    if lesson['order'] >= 101:
        subprocess.run(['ffmpeg', '-v', 'error', '-i', str(root / f'content/audio/{stem}.mp3'), '-f', 'null', '-'], check=True)
        assert (root / f'content/sources/{stem}-overview-2026-10-23.md').is_file()
headwords = {re.sub(r'\s+', ' ', p['phrase'].strip()).lower() for d in lessons for p in d['phrases']}
registry = json.loads((root / 'content/pronunciations/index.json').read_text())['entries']
for word in headwords:
    clip = registry[word]
    assert clip['textSha256'] == hashlib.sha256(word.encode()).hexdigest() and clip['completeWordBoundaryMatch']
    assert clip['audioSha256'] == hashlib.sha256((root / 'content/pronunciations' / clip['file']).read_bytes()).hexdigest()
assert len(list((root / 'content/audio').glob('*.mp3'))) == len(lessons)
progress = json.loads((root / 'content/production.json').read_text())
assert len(progress['audioReady']) == len(lessons) and not progress['pendingAudio']
topic_check = json.loads(subprocess.check_output(['node', str(root / 'scripts/check-topics.ts'), '--write-report'], cwd=root, text=True))
result = {'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'passed',
    'lessons': len(lessons), 'matchingLessonRecordings': len(lessons), 'completeSubtitles': len(lessons),
    'questions': sum(len(d['questions']) for d in lessons), 'vocabularyEntries': sum(len(d['phrases']) for d in lessons),
    'uniquePronunciations': len(headwords), 'original100AndDonationSettingsPreserved': True, 'baselineCommit': base, 'distinctTopics': topic_check['distinctEvents'], 'duplicateCheckPassed': True, 'nextBatch': progress['nextTextBatch']}
(root / 'content/verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
