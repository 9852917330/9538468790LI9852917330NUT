import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
const root = fileURLToPath(new URL("../", import.meta.url));
for (const args of [["scripts/prepare-content.ts"], ["node_modules/vite/bin/vite.js", "build", "--configLoader", "runner"], ["scripts/prepare-pwa.mjs"], ["scripts/check-hosting.mjs"]]) {
  const result = spawnSync(process.execPath, args, { cwd: root, stdio: "inherit" });
  if (result.status !== 0) process.exit(result.status || 1);
}
