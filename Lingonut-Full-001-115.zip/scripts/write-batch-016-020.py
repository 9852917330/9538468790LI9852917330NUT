"""Reviewed original lesson drafts for the next English Unicorn batch."""
from importlib.machinery import SourceFileLoader
from pathlib import Path
helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(16, 'rosetta-stone', 'The Rosetta Stone: Unlocking Ancient Egyptian Writing', 'History',
      'An ancient decree, a wartime discovery and years of comparison helped scholars read Egyptian writing again.',
'''For centuries, ancient Egyptian monuments carried messages that people could no longer fully read. Knowledge of the old writing systems had gradually disappeared. Temples, tombs and objects survived, but much of their written history remained difficult to understand.

In 1799, French soldiers working on a fort near Rosetta, in northern Egypt, found a broken stone covered with writing. They were there during Napoleon's military campaign. Scholars quickly recognized that the stone might provide an important **clue**.

It contained a **decree** issued by Egyptian priests in 196 BC, honoring King Ptolemy V. The message appeared in three **scripts**: hieroglyphs, demotic and Greek. These represented two languages, Egyptian and Greek. Different forms of writing had allowed the same royal message to reach different readers.

Scholars already understood ancient Greek. They could **compare** that text with the Egyptian sections, although parts of the stone were missing. Copies of the writing circulated, allowing researchers in different countries to study the problem.

The work took years and involved several people. Thomas Young identified sound values in the royal name Ptolemy. Jean-François Champollion studied the stone alongside other Egyptian texts. His knowledge of Coptic, a later form of Egyptian, helped him connect ancient signs with spoken language.

In 1822, Champollion announced a major **breakthrough**. Hieroglyphs could represent sounds as well as ideas. They were not simply mysterious pictures. This understanding helped scholars **decipher** more names and gradually read longer texts. Further research was still needed; the stone had not supplied a complete dictionary.

After the French defeat in Egypt, the stone passed into British hands and entered the British Museum in 1802. Its discovery was therefore also connected to war and struggles over cultural **heritage**.

The wider achievement was a new way to study Egypt through its own written **records**. Researchers could explore beliefs, government and ordinary life, giving a much fuller picture of an ancient civilization.''',
[
v('clue', 'A piece of information that helps solve a problem or mystery.', 'The broken lock gave the police a clue.', 'Noun', plural='clues'),
v('decree', 'An official order or decision made by a ruler or government.', 'The king issued a decree about taxes.', 'Noun', plural='decrees'),
v('script', 'A system of written signs used to represent a language.', 'The inscription uses an unfamiliar script.', 'Noun', form='scripts', plural='scripts'),
v('compare', 'To examine things together to find similarities and differences.', 'The researchers compare the two maps.', 'Verb', verb=('compare','compared','compared',False)),
v('breakthrough', 'An important discovery or advance that helps solve a difficult problem.', 'The experiment produced a breakthrough in battery design.', 'Noun', plural='breakthroughs'),
v('decipher', 'To discover the meaning of writing that is difficult to read.', 'The team tried to decipher the damaged message.', 'Verb', verb=('decipher','deciphered','deciphered',False)),
v('heritage', 'Traditions, buildings and objects inherited from earlier generations.', 'The old temple is part of the country\'s cultural heritage.', 'Uncountable noun'),
v('record', 'A written account that preserves information about the past.', 'The museum holds a record of the voyage.', 'Noun', form='records', plural='records')
],
[
m('Why was the stone useful for understanding Egyptian writing?', ['It presented related messages in scripts that scholars could compare.', 'It listed every Egyptian word with a modern translation.', 'It contained only pictures with no connection to speech.'], 'A', 'Scholars already understood ancient Greek. They could compare that text with the Egyptian sections, although parts of the stone were missing.', 'The readable Greek text provided a starting point for comparing the Egyptian writing.'),
m('What helped Champollion make progress?', ['He avoided all Egyptian texts except the stone.', 'He combined comparisons with his knowledge of Coptic.', 'He assumed that every sign represented a complete picture.'], 'B', 'His knowledge of Coptic, a later form of Egyptian, helped him connect ancient signs with spoken language.', 'Coptic helped connect the ancient signs to Egyptian speech.'),
m('What was the wider result of decipherment?', ['Researchers no longer needed to study Egyptian objects.', 'Every detail of Egyptian history became certain immediately.', 'Researchers gained access to Egypt\'s own written accounts.'], 'C', 'The wider achievement was a new way to study Egypt through its own written records.', 'Reading the records opened more of Egypt\'s history and daily life to study.'),
g('French soldiers found the stone near ___ in northern Egypt.', 'Rosetta', 'In 1799, French soldiers working on a fort near Rosetta, in northern Egypt, found a broken stone covered with writing.', 'Rosetta was the place near the discovery site.'),
g('The ancient decree was issued by Egyptian ___.', 'priests', 'It contained a decree issued by Egyptian priests in 196 BC, honoring King Ptolemy V.', 'Priests issued the decree honoring the king.'),
g('Hieroglyphs could represent sounds as well as ___.', 'ideas', 'Hieroglyphs could represent sounds as well as ideas.', 'The system included both sound values and signs connected to meaning.')
],
[
'British Museum — Object background and decree: https://github.com/BritishMuseumDH/rosettaStone/blob/master/README.md',
'British Museum — Discovery, scripts and history: https://www.britishmuseum.org/blog/everything-you-ever-wanted-know-about-rosetta-stone',
'British Museum — Decipherment and contributors: https://www.britishmuseum.org/blog/eureka-finding-key-ancient-egypt',
'British Museum — Timeline of decipherment: https://www.britishmuseum.org/exhibitions/hieroglyphs-unlocking-ancient-egypt/egyptian-hieroglyphs-decipherment-timeline'
],
[
'Overview covers the lost reading tradition, original decree, military discovery, comparative method, multiple contributors, 1822 breakthrough and wider historical access.',
'Three scripts represent two languages; no claim of three languages or a complete bilingual dictionary.',
'1822 is a major advance, not an instant complete translation. Coptic and other inscriptions supported the work.',
'British possession is described in its military context; no invented current legal claim or settlement.'
])

draft(17, 'wright-brothers', 'The Wright Brothers: From Experiments to Powered Flight', 'Technology',
      'Years of testing, four flights in 1903 and later improvements turned a difficult experiment into practical aviation.',
'''At the end of the 19th century, inventors were trying to build a machine that could carry a person through the air under engine power. Balloons and **gliders** already existed, but powered flight required several problems to be solved together.

Wilbur and Orville Wright ran a bicycle business in Dayton, Ohio. They studied earlier experiments and began testing kites and gliders. Their bicycle work had taught them that balance and control mattered as much as simply moving forward.

The brothers traveled to the North Carolina coast, where steady winds and open sand offered useful testing conditions. Early results showed that published information about wings was unreliable. Back in Dayton, they built a small **wind tunnel** and tested different wing shapes to improve **lift**.

They also developed ways to **steer** in the air. Twisting the wings worked with a movable tail to help the pilot turn and keep the aircraft balanced. Mechanic Charlie Taylor helped build a light engine. The brothers designed **propellers** to turn its power into forward movement.

On December 17, 1903, at Kill Devil Hills near Kitty Hawk, Orville **took off** for the first flight. It lasted 12 seconds and covered 120 feet. The brothers made four flights that day; Wilbur's final attempt lasted 59 seconds and traveled 852 feet.

These flights demonstrated controlled, **sustained** flight in a powered machine heavier than air. However, the aircraft remained difficult to handle. It was an experimental success, rather than a passenger service ready to begin.

Further trials in Ohio produced a more **practical** aircraft in 1905, able to turn and stay in the air much longer. Public **demonstrations** in Europe and America in 1908 brought wider recognition.

Many other people continued developing aviation. Aircraft later transformed travel, trade, communication and warfare. The Wrights' achievement grew from careful measurement, repeated testing and the combination of control, wings and power, rather than from one short flight alone.''',
[
v('glider', 'An aircraft that flies without engine power.', 'The glider moved silently above the fields.', 'Noun', form='gliders', plural='gliders'),
v('wind tunnel', 'A passage with controlled airflow used to test how air affects objects.', 'Engineers tested the model in a wind tunnel.', 'Noun phrase', plural='wind tunnels'),
v('lift', 'The upward force that supports an aircraft in the air.', 'The wings produced enough lift for the aircraft to rise.', 'Uncountable noun'),
v('steer', 'To control the direction in which something moves.', 'The pilot learned to steer the small aircraft.', 'Verb', verb=('steer','steered','steered',False)),
v('propeller', 'A device with rotating blades that pushes a ship or aircraft forward.', 'The aircraft had a wooden propeller.', 'Noun', form='propellers', plural='propellers'),
v('take off', 'To leave the ground and begin flying.', 'The plane will take off after the storm passes.', 'Phrasal verb', form='took off', verb=('take','took','taken',True)),
v('sustained', 'Continuing for a period of time without stopping.', 'The rescue needed sustained effort from several teams.', 'Adjective'),
v('practical', 'Suitable for real use and able to work effectively.', 'The new design offers a practical way to save water.', 'Adjective'),
v('demonstration', 'An event that shows how something works or what it can do.', 'The demonstration showed how the new machine operated.', 'Noun', form='demonstrations', plural='demonstrations')
],
[
m('How did the brothers respond when early wing tests gave poor results?', ['They made their own measurements with a wind tunnel.', 'They stopped testing and relied only on published figures.', 'They decided that control was unnecessary.'], 'A', 'Back in Dayton, they built a small wind tunnel and tested different wing shapes to improve lift.', 'They used systematic experiments to improve the wing design.'),
m('Which statement describes December 17, 1903?', ['Only one flight was attempted that day.', 'The brothers made four flights, with the last going farther than the first.', 'The aircraft immediately began carrying paying passengers.'], 'B', 'The brothers made four flights that day; Wilbur\'s final attempt lasted 59 seconds and traveled 852 feet.', 'The day included several flights, beyond the famous 12-second first one.'),
m('Why were the developments after 1903 important?', ['They proved that aircraft needed no controls.', 'They replaced all other forms of transport immediately.', 'They made the aircraft more usable and brought wider recognition.'], 'C', 'Further trials in Ohio produced a more practical aircraft in 1905, able to turn and stay in the air much longer. Public demonstrations in Europe and America in 1908 brought wider recognition.', 'Practical improvements and public flights helped turn the experiment into an accepted achievement.'),
g('The Wrights ran a bicycle business in ___, Ohio.', 'Dayton', 'Wilbur and Orville Wright ran a bicycle business in Dayton, Ohio.', 'Dayton was the base of their bicycle business and much of their research.'),
g('Mechanic Charlie ___ helped build the engine.', 'Taylor', 'Mechanic Charlie Taylor helped build a light engine.', 'Taylor contributed the engine-building work.'),
g('The aircraft combined control, wings and ___.', 'power', 'The Wrights\' achievement grew from careful measurement, repeated testing and the combination of control, wings and power, rather than from one short flight alone.', 'All three elements were needed for the complete achievement.')
],
[
'National Park Service — Broad development: https://www.nps.gov/articles/wright-brothers.htm',
'National Park Service — The four flights: https://www.nps.gov/articles/firstflight.htm',
'Smithsonian National Air and Space Museum — Research method: https://airandspace.si.edu/explore/stories/researching-wright-way',
'Smithsonian National Air and Space Museum — Later development and recognition: https://airandspace.si.edu/explore/stories/wright-brothers'
],
[
'Overview includes earlier aviation, bicycle-workshop background, wing research, control and propulsion, all four 1903 flights, 1905 practicality, 1908 recognition and later consequences.',
'1903 demonstrated controlled sustained powered flight; it did not make the Wrights the first humans ever airborne.',
'The 12-second flight is one supporting detail. Practical development continued after 1903.',
'Charlie Taylor is credited for help building the engine; no solo-genius account or immediate passenger-service claim.'
])

draft(18, 'montgomery-bus-boycott', 'The Montgomery Bus Boycott: A Community Changes the Rules', 'History',
      'An arrest, organized community protest and a court challenge ended legal segregation on Montgomery buses.',
'''In 1955, buses in Montgomery, Alabama, operated under racial **segregation**. Black passengers faced unequal seating rules and humiliating treatment, even though they made up much of the bus company's business. Resistance had begun long before the protest that made the city famous.

On December 1, Rosa Parks refused a driver's order to give up her seat for a white passenger. Police **arrested** her. Parks was an experienced civil rights activist, and she was not the first person to resist. Earlier that year, teenager Claudette Colvin had also challenged the bus system.

Parks's arrest became a point around which the community could organize. Jo Ann Robinson and the Women's Political Council distributed **leaflets** calling for a one-day bus **boycott** on December 5. Large numbers of Black residents stayed off the buses, and the protest continued.

The Montgomery Improvement Association coordinated the campaign, with Martin Luther King Jr. as president. Residents walked to work or joined **carpools**. Churches raised money, volunteers offered rides, and meetings kept people informed. Maintaining alternative transport was essential to keeping the protest alive.

The effort brought serious risks. Supporters faced arrests, threats and violence. Despite this **intimidation**, the community kept applying pressure by refusing to pay bus fares.

At the same time, lawyers brought a separate court case, Browder v. Gayle, to **challenge** bus segregation. The women involved included Aurelia Browder and Claudette Colvin. A federal court ruled against segregation, and the Supreme Court **upheld** that decision in November 1956.

The boycott ended on December 20, after 381 days, as the court order reached Montgomery. The victory came through both collective protest and legal action.

Racism and violence continued after the legal victory. Even so, Montgomery showed the strength of sustained, organized nonviolent protest. It helped King become a national leader and encouraged the wider struggle for **equal rights**. One refusal had become a turning point because a whole community supported it.''',
[
v('segregation', 'The enforced separation of people, especially according to race.', 'Campaigners opposed racial segregation in public schools.', 'Uncountable noun'),
v('arrest', 'To take someone into police custody under legal authority.', 'The police may arrest a person suspected of a crime.', 'Verb', form='arrested', verb=('arrest','arrested','arrested',False)),
v('leaflet', 'A small printed sheet that gives information to the public.', 'A volunteer handed out a leaflet about the meeting.', 'Noun', form='leaflets', plural='leaflets'),
v('boycott', 'An organized refusal to buy or use something as a protest.', 'The boycott put pressure on the company to change its policy.', 'Noun', plural='boycotts'),
v('carpool', 'An arrangement in which people share a car journey.', 'The neighbors formed a carpool to get to work.', 'Noun', form='carpools', plural='carpools'),
v('intimidation', 'Threatening behavior intended to frighten someone into doing or avoiding something.', 'The witnesses reported intimidation before the trial.', 'Uncountable noun'),
v('challenge', 'To question or oppose a decision, rule or claim.', 'The group plans to challenge the rule in court.', 'Verb', verb=('challenge','challenged','challenged',False)),
v('uphold', 'To confirm that a decision or rule should remain in force.', 'The higher court may uphold the original decision.', 'Verb', form='upheld', verb=('uphold','upheld','upheld',True)),
v('equal rights', 'The same legal rights and opportunities for everyone.', 'The campaign demanded equal rights for all citizens.', 'Noun phrase', note='Usually used in the plural when discussing rights shared equally by different groups.')
],
[
m('Why did Parks\'s arrest lead to a wider protest?', ['It became a focus for a community already facing discrimination.', 'It was the first time anyone had objected to segregation.', 'It immediately changed all the bus rules by itself.'], 'A', 'Parks\'s arrest became a point around which the community could organize.', 'Existing resistance and community organization turned the arrest into a shared campaign.'),
m('What helped residents continue avoiding the buses?', ['A new law gave every resident a free car.', 'Shared rides, walking, church support and volunteers provided alternatives.', 'The bus company drove everyone to work without charge.'], 'B', 'Residents walked to work or joined carpools. Churches raised money, volunteers offered rides, and meetings kept people informed.', 'Practical transport and financial support made the long protest possible.'),
m('How was the legal victory achieved?', ['Parks personally issued a court order.', 'Bus segregation ended without a court challenge.', 'Collective protest worked alongside a separate legal case.'], 'C', 'The victory came through both collective protest and legal action.', 'Browder v. Gayle and the organized boycott contributed through different routes.'),
g('Montgomery is a city in the state of ___.', 'Alabama', 'In 1955, buses in Montgomery, Alabama, operated under racial segregation.', 'Alabama is the state named in the opening sentence.'),
g('The Women\'s Political Council distributed ___ to call for the protest.', 'leaflets', 'Jo Ann Robinson and the Women\'s Political Council distributed leaflets calling for a one-day bus boycott on December 5.', 'Printed leaflets helped spread the call for the first boycott day.'),
g('The boycott lasted ___ days.', '381', 'The boycott ended on December 20, after 381 days, as the court order reached Montgomery.', 'The campaign continued for more than a year.')
],
[
'National Archives — Parks arrest records and legal context: https://www.archives.gov/education/lessons/rosa-parks',
'National Archives — WPC, MIA, legal plaintiffs and ending: https://rediscovering-black-history.blogs.archives.gov/2015/12/01/60th-anniversary-of-the-montgomery-bus-boycott/',
'National Park Service — Community organization, transport and court case: https://www.nps.gov/articles/montgomery-bus-boycott.htm'
],
[
'Overview balances segregation and earlier resistance, Parks\'s arrest, Robinson/WPC organization, MIA leadership, transport support, intimidation, separate litigation and civil rights consequences.',
'Parks was an experienced activist and not the first person to resist. The narrative does not reduce the movement to tired feet or one person.',
'Browder v. Gayle is distinguished from Parks\'s individual prosecution; community pressure and legal action are both essential parts of the story.',
'No exact June ruling day or MIA formation day is used because official accounts differ. November Supreme Court affirmation and December 20 ending are supported.',
'The legal result is not presented as an immediate end to racism or racial violence.'
])

draft(19, 'suez-canal-blockage', 'The Suez Canal Blockage: Ever Given and Global Trade', 'World Events',
      'Six days of blocked traffic revealed how a narrow shipping route connects ports, factories and customers around the world.',
'''The Suez Canal crosses Egypt, connecting the Mediterranean Sea with the Red Sea. Ships traveling between Europe and Asia can use it instead of making the long journey around Africa. This shortcut saves time and fuel, but many journeys depend on the same narrow passage.

On March 23, 2021, the container ship Ever Given **ran aground** across a section of the canal. The vessel was about 400 metres long. Strong winds and blowing sand made control harder. A later Panamanian investigation also pointed to speed and steering decisions. The ship's position stopped other vessels from passing.

A vital trade route had become a **bottleneck**. Hundreds of ships built up in a growing **backlog**. Some shipping companies waited for the canal to reopen. Others **diverted** vessels around the Cape of Good Hope, accepting a much longer journey and higher fuel costs.

The disruption reached far beyond Egypt. Ships carried goods for businesses and consumers in many countries. Delayed arrivals affected ports and delivery plans, adding pressure to **supply chains** already strained by the coronavirus pandemic.

Freeing the vessel required several methods working together. Suez Canal Authority workers and international rescue specialists **dredged** sand from around the hull. Powerful **tugboats** pulled and helped turn the ship. Favorable **tides** raised the water level and assisted the effort. The teams had to free an enormous vessel while protecting it from further damage.

On March 29, the Ever Given was **refloated** and moved out of the channel for inspection. Shipping could resume, but reopening the canal did not instantly remove the delays. Waiting vessels still needed to pass through, and companies had to adjust schedules elsewhere.

The blockage lasted about six days, yet its effects traveled across a much larger network. It showed how efficient global transport can also be vulnerable: a problem in one narrow waterway can disrupt work and deliveries thousands of kilometres away.''',
[
v('run aground', 'For a ship to become stuck on the bottom in shallow water.', 'The fishing boat could run aground near the rocks.', 'Verb phrase', form='ran aground', verb=('run','ran','run',True)),
v('bottleneck', 'A point where limited space or capacity slows a wider process.', 'The narrow bridge became a traffic bottleneck.', 'Noun', plural='bottlenecks'),
v('backlog', 'A growing amount of work or traffic waiting to be dealt with.', 'The port needed several days to clear the backlog.', 'Noun', plural='backlogs'),
v('divert', 'To send someone or something along a different route.', 'The airline may divert flights during the storm.', 'Verb', form='diverted', verb=('divert','diverted','diverted',False)),
v('supply chain', 'The connected activities and businesses that produce and deliver goods.', 'A missing part can delay the entire supply chain.', 'Noun phrase', form='supply chains', plural='supply chains'),
v('dredge', 'To remove sand, mud or other material from the bottom of water.', 'Workers dredge the harbor to keep it deep enough for ships.', 'Verb', form='dredged', verb=('dredge','dredged','dredged',False)),
v('tugboat', 'A small powerful boat used to pull or guide larger vessels.', 'A tugboat helped the ship enter the harbor.', 'Noun', form='tugboats', plural='tugboats'),
v('tide', 'The regular rise and fall in the level of the sea.', 'The tide was high when the boat entered the bay.', 'Noun', form='tides', plural='tides'),
v('refloat', 'To make a vessel float again after it has become stuck or sunk.', 'The rescue team tried to refloat the damaged ship.', 'Verb', form='refloated', verb=('refloat','refloated','refloated',False))
],
[
m('Why is the Suez Canal important to many ships?', ['It offers a shorter route between Europe and Asia than sailing around Africa.', 'It is the only sea route anywhere in the world.', 'It connects the Atlantic Ocean directly to the Pacific Ocean.'], 'A', 'Ships traveling between Europe and Asia can use it instead of making the long journey around Africa.', 'The route saves ships the longer trip around Africa.'),
m('What helped free the Ever Given?', ['The crew immediately unloaded every container by hand.', 'Dredging, tugboats and favorable tides worked together.', 'Other ships pushed through the blocked channel.'], 'B', 'Suez Canal Authority workers and international rescue specialists dredged sand from around the hull. Powerful tugboats pulled and helped turn the ship. Favorable tides raised the water level and assisted the effort.', 'Removing sand, pulling the vessel and higher water all contributed.'),
m('Why did problems continue after the canal reopened?', ['The canal had permanently closed all trade between Europe and Asia.', 'No ships were waiting to use the canal.', 'Waiting traffic and disrupted schedules still needed to be dealt with.'], 'C', 'Waiting vessels still needed to pass through, and companies had to adjust schedules elsewhere.', 'Reopening the passage did not instantly clear the backlog or restore delivery plans.'),
g('The Ever Given was about 400 ___ long.', 'metres', 'The vessel was about 400 metres long.', 'Metres is the length unit used in the script.'),
g('Some vessels sailed around the Cape of Good ___.', 'Hope', 'Others diverted vessels around the Cape of Good Hope, accepting a much longer journey and higher fuel costs.', 'The Cape of Good Hope was the longer alternative route.'),
g('The disruption added pressure to supply ___ already strained by the pandemic.', 'chains', 'Delayed arrivals affected ports and delivery plans, adding pressure to supply chains already strained by the coronavirus pandemic.', 'Supply chains connect production, transport and delivery.')
],
[
'Panama Maritime Authority — Final marine safety investigation, R-026-2021-DIAM, sections 6–7; primary report mirrored at: https://gcaptain.com/wp-content/uploads/2023/07/Final-Investigation-Report-Ever-Given-23-March-2021.pdf',
'Boskalis/SMIT Salvage — Participant account of grounding, rescue and refloating: https://boskalis.com/press/press-releases-and-company-news/suez-canal-unblocked-we-pulled-it-off',
'Suez Canal Authority — Tow maneuvers and tide-assisted operation: https://www.suezcanal.gov.eg/English/MediaCenter/News/Pages/nav_29-03-2021.aspx',
'US Bureau of Transportation Statistics — Backlog and wider supply-chain effects: https://www.bts.gov/data-spotlight/ever-given-suez-canal',
'Maersk — Operational updates, diversions and schedule disruption: https://www.maersk.com/news/articles/2021/03/24/vessel-blockage-in-the-suez-canal'
],
[
'Overview covers canal geography and value, grounding, multiple contributing factors, waiting/diverted ships, global supply effects, cooperative rescue, reopening and continuing delays.',
'Weather is one factor. Speed and steering decisions are attributed to the later Panamanian safety investigation, not presented as a court determination of liability.',
'Start and refloating dates are March 23 and March 29, 2021. About six days avoids a misleading exact duration.',
'No disputed damage totals, compensation amounts, exact tug counts or claim that all world shipping stopped.',
'The final paragraph is editorial synthesis of the documented wider transport effects, not a quotation from an authority.'
])

draft(20, 'printing-revolution', 'Gutenberg and the Printing Revolution', 'Technology',
      'Reusable metal letters, skilled workshops and growing book networks transformed communication in Europe.',
'''Before the middle of the 15th century, producing a book in Europe often meant copying its words by hand. Skilled workers spent long periods making **manuscripts**. Books were valuable, and the time required to produce each copy limited their availability.

Printing already had a long history elsewhere. Chinese printers had used carved wooden blocks and later **movable type**. Metal type was used in Korea before Gutenberg's work; the surviving Korean book Jikji was printed with it in 1377. Europe's printing revolution belonged to this wider history.

In Mainz, Germany, Johannes Gutenberg developed an effective printing system around the middle of the 1400s. His workshop combined metal letters, suitable ink and a mechanical **press**. The achievement depended on making these parts work reliably together.

Workers could **cast** many small metal letters, arrange them into lines and pages, then print repeated copies. After printing, they could **reuse** the letters for another text. Producing additional copies no longer required writing out every page again, although preparing a book still demanded skill and money.

Around 1455, Gutenberg's workshop produced about 180 copies of a Latin Bible. Its careful design showed that printed books could be both impressive and readable. The Bible was a major demonstration of the system, rather than the beginning of printing everywhere.

Other printers established workshops, and the technology spread across Europe. Booksellers and trade routes helped printed material **circulate**. Over time, more copies and a wider range of texts became available, supporting learning and the exchange of ideas.

Printing gave religious arguments and scientific findings larger audiences. It supported public **debate**, while rulers and religious authorities also tried to control texts through **censorship**. Increased production brought new opportunities and new conflicts.

Change was gradual. Education, **literacy**, paper production and distribution all shaped who could benefit. The printing revolution grew through the work of many craftspeople, publishers and readers, helping knowledge travel far beyond a single workshop.''',
[
v('manuscript', 'A text written by hand, especially before printing became common.', 'The library protects a medieval manuscript.', 'Noun', form='manuscripts', plural='manuscripts'),
v('movable type', 'Separate letters or characters that can be arranged and reused for printing.', 'Movable type allowed printers to prepare many different pages.', 'Uncountable noun phrase'),
v('press', 'A machine that applies pressure to print text or images.', 'The printer placed the paper in the press.', 'Noun', plural='presses'),
v('cast', 'To make an object by pouring liquid material into a shaped container and letting it harden.', 'The workers cast metal parts for the machine.', 'Verb', verb=('cast','cast','cast',True)),
v('reuse', 'To use something again instead of replacing or throwing it away.', 'The workshop can reuse the metal pieces.', 'Verb', verb=('reuse','reused','reused',False)),
v('circulate', 'To move or spread from one person or place to another.', 'The report began to circulate among researchers.', 'Verb', verb=('circulate','circulated','circulated',False)),
v('debate', 'Discussion in which people express different views about an issue.', 'The proposal led to public debate.', 'Noun', plural='debates'),
v('censorship', 'The control or removal of material that authorities do not allow people to publish or see.', 'Censorship prevented the newspaper from printing the report.', 'Uncountable noun'),
v('literacy', 'The ability to read and write.', 'The program aims to improve adult literacy.', 'Uncountable noun')
],
[
m('How does the story place Gutenberg in printing history?', ['He developed an important European system after earlier printing in Asia.', 'He created the first printing of any kind anywhere in the world.', 'He printed the Korean book Jikji in Mainz.'], 'A', 'Europe\'s printing revolution belonged to this wider history.', 'Earlier Chinese and Korean printing is part of the wider history around Gutenberg\'s European achievement.'),
m('Why were movable metal letters useful?', ['Each letter could be used for only one page and then had to be destroyed.', 'The letters could print repeated copies and be rearranged for other texts.', 'They removed every need for skilled workers and money.'], 'B', 'Workers could cast many small metal letters, arrange them into lines and pages, then print repeated copies. After printing, they could reuse the letters for another text.', 'Reusable type made repeated printing and the preparation of other pages possible.'),
m('What was one wider effect of the spread of printing?', ['Religious and scientific arguments stopped reaching readers.', 'All restrictions on publication disappeared immediately.', 'Ideas reached larger audiences, while authorities also tried to control them.'], 'C', 'Printing gave religious arguments and scientific findings larger audiences. It supported public debate, while rulers and religious authorities also tried to control texts through censorship.', 'Printing expanded discussion and also created struggles over control of information.'),
g('Gutenberg developed his system in ___, Germany.', 'Mainz', 'In Mainz, Germany, Johannes Gutenberg developed an effective printing system around the middle of the 1400s.', 'Mainz was the city where his workshop developed the system.'),
g('The workshop produced about ___ copies of the Latin Bible.', '180', 'Around 1455, Gutenberg\'s workshop produced about 180 copies of a Latin Bible.', 'The script gives an approximate total of 180 copies.'),
g('Education and ___ helped shape who could benefit from printed books.', 'literacy', 'Education, literacy, paper production and distribution all shaped who could benefit.', 'The ability to read and write affected access to printed knowledge.')
],
[
'Bibliothèque nationale de France — Asian precedents, collective European innovation and expansion: https://www.bnf.fr/en/agendaEN/printing-gutenbergs-europe',
'Library of Congress — Gutenberg Bible, approximate date and print run: https://www.loc.gov/exhibits/bibles/interactives/gutenberg/index.html',
'Gutenberg Museum/Mainz — Casting and printing process: https://www.gutenberg.de/en/erfindung/',
'Library of Congress Asian Division — Earlier Chinese and Korean printing: https://blogs.loc.gov/international-collections/2021/06/the-history-of-printing-in-asia-according-to-library-of-congress-asian-collections-part-1/',
'Library of Congress — Printed religious debate: https://guides.loc.gov/martin-luther-priest-heretic-outlaw/luther-the-heretic',
'Library of Congress/Vatican collections — Censorship and humanism: https://loc.gov/exhibits/vatican/humanism.html'
],
[
'Overview includes manuscript production, earlier Asian printing, the European system and its mechanism, the Bible as a demonstration, spread through workshops and trade, learning, debate, censorship and gradual access.',
'Gutenberg is not called the worldwide inventor of printing or movable type. No unproven direct transmission from Korea to Gutenberg is asserted.',
'The 1377 Jikji reference concerns a surviving Korean metal-type book. The Bible date and copy count are approximate.',
'No claim that books immediately became universally cheap or that printing alone caused the Renaissance, Reformation or Scientific Revolution.',
'Printers, publishers, paper makers, transport networks, readers and literacy remain part of the wider explanation.'
])
