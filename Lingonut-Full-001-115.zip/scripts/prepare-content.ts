import { readdir, readFile, writeFile, mkdir, rm, copyFile, stat } from "node:fs/promises";
import { createReadStream } from "node:fs";
import { createHash } from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { lessonSchema, type Lesson, type LessonSummary } from "../lib/lesson.ts";
import { validateTopics, type TopicRegistry } from "./check-topics.ts";
import { parseTranslation, plainScript, scriptParagraphs, translationCodes, type TranslationLanguage } from "../lib/translation.ts";
import { parseTitleTranslations, type TitleTranslationUrls } from "../lib/title-translation.ts";

const root = fileURLToPath(new URL("../", import.meta.url));
const contentRoot = path.join(root, "content");
const audioRoot = path.join(contentRoot, "audio");
const pronunciationRoot = path.join(contentRoot, "pronunciations");
type PronunciationRecord = { text: string; file: string; voice: string; textSha256: string; audioSha256: string; completeWordBoundaryMatch: boolean };
const checkOnly = process.argv.includes("--check");
const extensions = new Set([".mp3", ".m4a", ".wav", ".ogg", ".aac", ".flac", ".opus"]);
const hash = (value: string) => createHash("sha256").update(value).digest("hex").slice(0, 16);
async function audioHash(file: string) {
  const digest = createHash("sha256");
  for await (const chunk of createReadStream(file)) digest.update(chunk);
  return digest.digest("hex").slice(0, 16);
}

export async function prepareContent() {
  const files = (await readdir(path.join(contentRoot, "lessons"))).filter(name => name.endsWith(".json")).sort();
  if (!files.length) throw new Error("Add at least one lesson to content/lessons.");
  const audioFiles = await readdir(audioRoot);
  const pronunciations: { entries: Record<string, PronunciationRecord> } = JSON.parse(await readFile(path.join(pronunciationRoot, "index.json"), "utf8"));
  const pronunciationCopies = new Map<string, string>();
  const translationCopies = new Map<string, string>();
  const translationRoot = path.join(contentRoot, "translations");
  let translationFolders: string[] = [];
  try { translationFolders = await readdir(translationRoot); }
  catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
  const usedTranslationFolders = new Set<string>();
  const pronunciationUrls = new Map<string, string>();
  const policy: { maxScriptWords: number; legacyLongScripts: string[] } = JSON.parse(await readFile(path.join(contentRoot, "editorial-policy.json"), "utf8"));
  if (!Number.isInteger(policy.maxScriptWords) || policy.maxScriptWords < 1 || !Array.isArray(policy.legacyLongScripts) || policy.legacyLongScripts.some(stem => !/^\d{3,4}$/.test(stem))) throw new Error("Invalid editorial policy.");
  const settings = JSON.parse(await readFile(path.join(contentRoot, "settings.json"), "utf8"));
  if (typeof settings.donationUrl !== "string") throw new Error("settings.donationUrl must be a string.");
  if (settings.donationUrl && new URL(settings.donationUrl).protocol !== "https:") throw new Error("Use an HTTPS donation URL.");
  const ids = new Set<string>();
  const orders = new Set<number>();
  const records: { lesson: Lesson; sourceAudio: string | null; outputAudio: string | null }[] = [];
  let drafts = 0;
  for (const file of files) {
    const raw = JSON.parse(await readFile(path.join(contentRoot, "lessons", file), "utf8"));
    const parsed = lessonSchema.safeParse(raw);
    if (!parsed.success) throw new Error(`${file}:\n${parsed.error.issues.map(i => `  ${i.path.join(".")}: ${i.message}`).join("\n")}`);
    const data = parsed.data;
    if (ids.has(data.id.toLowerCase())) throw new Error(`${file}: duplicate lesson ID ${data.id}.`);
    if (orders.has(data.order)) throw new Error(`${file}: duplicate lesson number ${data.order}.`);
    ids.add(data.id.toLowerCase()); orders.add(data.order);
    if (!data.published) { drafts++; continue; }
    const stem = String(data.order).padStart(3, "0");
    const scriptWords = data.script.replace(/\*\*/g, "").trim().split(/\s+/).length;
    if (scriptWords > policy.maxScriptWords && !policy.legacyLongScripts.includes(stem)) throw new Error(`${file}: script has ${scriptWords} words; maximum ${policy.maxScriptWords}.`);
    let sourceAudio: string | null = null;
    if (raw.audio != null && typeof raw.audio !== "string") throw new Error(`${file}: audio must be a filename or null.`);
    if (raw.audio) {
      if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(raw.audio) || !extensions.has(path.extname(raw.audio).toLowerCase())) throw new Error(`${file}: use an audio filename inside content/audio, for example 001.mp3.`);
      if (!audioFiles.includes(raw.audio)) throw new Error(`${file}: audio file not found: ${raw.audio}`);
      sourceAudio = raw.audio;
    } else {
      const matches = audioFiles.filter(name => path.parse(name).name === stem && extensions.has(path.extname(name).toLowerCase()));
      if (matches.length > 1) throw new Error(`${file}: multiple audio files for ${stem}; set the audio field explicitly.`);
      sourceAudio = matches[0] || null;
    }
    let outputAudio: string | null = null;
    if (sourceAudio) {
      const filePath = path.join(audioRoot, sourceAudio);
      // Generated recordings carry the hash of the exact script sent to TTS.
      // An edited script must receive a new recording before release.
      const metadataPath = path.join(audioRoot, `${path.parse(sourceAudio).name}.meta.json`);
      let metadata: { scriptSha256?: string } | null = null;
      try { metadata = JSON.parse(await readFile(metadataPath, "utf8")); }
      catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
      const scriptSha256 = createHash("sha256").update(data.script.replace(/\*\*/g, "").trim()).digest("hex");
      if (metadata && metadata.scriptSha256 !== scriptSha256) throw new Error(`${file}: the recording belongs to a different script. Regenerate the audio before publishing.`);
      if (!(await stat(filePath)).isFile()) throw new Error(`Not an audio file: ${sourceAudio}`);
      if ((await stat(filePath)).size > 25 * 1024 * 1024) throw new Error(`${sourceAudio} exceeds the Cloudflare Pages limit of 25 MiB. Compress it before building.`);
      outputAudio = `${stem}.${await audioHash(filePath)}${path.extname(sourceAudio).toLowerCase()}`;
    }
    // Editorial notes remain in the source project, outside the public website.
    const publicPhrases = [];
    for (const phrase of data.phrases) {
      const word = phrase.phrase.trim().replace(/\s+/g, " ").toLowerCase();
      let url = pronunciationUrls.get(word);
      if (!url) {
        const clip = pronunciations.entries[word];
        if (!clip || !/^[a-f0-9]+\.mp3$/.test(clip.file) || !clip.completeWordBoundaryMatch || clip.text !== word || clip.textSha256 !== createHash("sha256").update(word).digest("hex")) throw new Error(`${file}: missing matching pronunciation for ${phrase.phrase}. Run scripts/generate-pronunciations.py.`);
        const source = path.join(pronunciationRoot, clip.file);
        const bytes = await readFile(source);
        if (createHash("sha256").update(bytes).digest("hex") !== clip.audioSha256) throw new Error(`Damaged pronunciation: ${word}`);
        const output = `${path.parse(clip.file).name}.${hash(bytes.toString("base64"))}.mp3`;
        pronunciationCopies.set(output, source);
        url = `pronunciation/${output}`;
        pronunciationUrls.set(word, url);
      }
      publicPhrases.push({ ...phrase, pronunciationUrl: url });
    }
    const { editorialNote, ...publicData } = { ...data, phrases: publicPhrases };
    void editorialNote;
    const lesson: Lesson = { ...publicData, audioUrl: outputAudio ? `audio/${outputAudio}` : null };
    if (translationFolders.includes(stem)) {
      usedTranslationFolders.add(stem);
      const translationFiles = await readdir(path.join(translationRoot, stem));
      const sourceScriptSha256 = createHash("sha256").update(plainScript(data.script)).digest("hex");
      for (const name of translationFiles) {
        const language = path.parse(name).name as TranslationLanguage;
        if (!translationCodes.includes(language) || name !== `${language}.json`) throw new Error(`Unexpected translation file: ${stem}/${name}`);
        const value = JSON.parse(await readFile(path.join(translationRoot, stem, name), "utf8"));
        const bundle = parseTranslation(value, { lessonId: data.id, language, sourceScriptSha256, sourceTitle: data.title, paragraphCount: scriptParagraphs(data.script).length });
        const serialized = JSON.stringify(bundle);
        const url = `data/translations/${stem}.${language}.${hash(serialized)}.json`;
        translationCopies.set(url, serialized);
        lesson.translationUrls ??= {};
        lesson.translationUrls[language] = url;
        lesson.translationSourceSha256 = sourceScriptSha256;
      }
      if (!translationFiles.length) throw new Error(`No translations in ${stem}.`);
    }
    records.push({ lesson, sourceAudio, outputAudio });
  }
  records.sort((a, b) => a.lesson.order - b.lesson.order);
  if (!records.length) throw new Error("No published lessons. Set published to true on the lessons you want to release.");
  const topicRegistry: TopicRegistry = JSON.parse(await readFile(path.join(contentRoot, "topics.json"), "utf8"));
  validateTopics(records.map(record => record.lesson), topicRegistry);
  if (translationFolders.some(stem => !usedTranslationFolders.has(stem))) throw new Error("A translation folder has no matching published lesson.");
  const titleTranslationRoot = path.join(contentRoot, "title-translations");
  const titleTranslationCopies = new Map<string, string>();
  const titleTranslationUrls: TitleTranslationUrls = {};
  let titleFiles: string[] = [];
  try { titleFiles = await readdir(titleTranslationRoot); }
  catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
  for (const file of titleFiles) {
    const language = path.parse(file).name as TranslationLanguage;
    if (!translationCodes.includes(language) || file !== `${language}.json`) throw new Error(`Unexpected title translation file: ${file}`);
    const bundle = parseTitleTranslations(JSON.parse(await readFile(path.join(titleTranslationRoot, file), "utf8")), language, records.map(record => record.lesson));
    const serialized = JSON.stringify(bundle);
    const url = `data/titles/${language}.${hash(serialized)}.json`;
    titleTranslationUrls[language] = url;
    titleTranslationCopies.set(url, serialized);
  }
  if (!checkOnly) {
    await rm(path.join(root, "public/data"), { recursive: true, force: true });
    await rm(path.join(root, "public/audio"), { recursive: true, force: true });
    await rm(path.join(root, "public/pronunciation"), { recursive: true, force: true });
    await mkdir(path.join(root, "public/data/lessons"), { recursive: true });
    await mkdir(path.join(root, "public/data/translations"), { recursive: true });
    await mkdir(path.join(root, "public/data/titles"), { recursive: true });
    await mkdir(path.join(root, "public/audio"), { recursive: true });
    await mkdir(path.join(root, "public/pronunciation"), { recursive: true });
    for (const [output, source] of pronunciationCopies) await copyFile(source, path.join(root, "public/pronunciation", output));
    for (const [url, serialized] of translationCopies) await writeFile(path.join(root, "public", url), serialized);
    for (const [url, serialized] of titleTranslationCopies) await writeFile(path.join(root, "public", url), serialized);
    const summaries: LessonSummary[] = [];
    for (const record of records) {
      const { lesson, sourceAudio, outputAudio } = record;
      const serialized = JSON.stringify(lesson);
      const dataUrl = `data/lessons/${lesson.id}.${hash(serialized)}.json`;
      await writeFile(path.join(root, "public", dataUrl), serialized);
      if (sourceAudio && outputAudio) await copyFile(path.join(audioRoot, sourceAudio), path.join(root, "public/audio", outputAudio));
      summaries.push({ id: lesson.id, order: lesson.order, title: lesson.title, category: lesson.category, level: lesson.level, summary: lesson.summary, audioUrl: lesson.audioUrl, dataUrl });
    }
    await writeFile(path.join(root, "public/data/index.json"), JSON.stringify({ version: 1, settings: { donationUrl: settings.donationUrl }, lessons: summaries, ...(titleTranslationCopies.size ? { titleTranslationUrls } : {}) }));
  }
  console.log(`${records.length} published lessons; ${drafts} drafts excluded; ${records.filter(r => r.sourceAudio).length} audio files; ${pronunciationCopies.size} pronunciation clips; ${translationCopies.size} script translations; ${titleTranslationCopies.size} title languages. ${checkOnly ? "Content validated." : "Static content prepared."}`);
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  prepareContent().catch(error => { console.error(error.message); process.exitCode = 1; });
}
