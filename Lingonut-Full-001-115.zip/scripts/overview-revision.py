"""Apply reviewed full-event drafts and checkpoint completed matching recordings."""
import copy, datetime, hashlib, json, re, shutil, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
DRAFTS=ROOT/'content/editorial-drafts'
DRAFTS.mkdir(exist_ok=True)
def v(head,meaning,example,pos,form=None,forms=None,plural=None,note=None):
    d=dict(phrase=head,meaning=meaning,example=example,partOfSpeech=pos)
    if form and form!=head:d['scriptForms']=[form]
    if forms:d['verbForms']=dict(zip(['base','past','pastParticiple','irregular'],forms))
    if plural:d['pluralForm']=plural
    if note:d['usageNote']=note
    return d
def mcq(prompt,options,answer,evidence,explanation):return dict(type='mcq',prompt=prompt,options=options,answer=answer,evidence=evidence,explanation=explanation)
def gap(prompt,answer,evidence,explanation):return dict(type='gap',prompt=prompt,options=[],answer=answer,evidence=evidence,explanation=explanation)
def draft(n,title,summary,script,questions,sources,decisions,extras=()):
    lessons=[json.loads(p.read_text()) for p in sorted((ROOT/'content/lessons').glob('*.json'))]
    d=copy.deepcopy(lessons[n-1]);script=script.strip();plain=script.replace('**','')
    forms=list(dict.fromkeys(re.findall(r'\*\*(.+?)\*\*',script)))
    pool=[*extras,*d['phrases'],*[p for item in lessons for p in item['phrases']]];vocab=[]
    for form in forms:
        matches=[p for p in pool if form.lower() in [p['phrase'].lower(),*[s.lower() for s in p.get('scriptForms',[])]]]
        if not matches:raise ValueError(f'{n:03}: missing vocabulary {form}')
        p=copy.deepcopy(matches[0]);p.pop('scriptForms',None)
        actual=[f for f in forms if f.lower() in [matches[0]['phrase'].lower(),*[s.lower() for s in matches[0].get('scriptForms',[])]] and f!=p['phrase']]
        if actual:p['scriptForms']=actual
        if p['phrase'].lower() not in [e['phrase'].lower() for e in vocab]:vocab.append(p)
    assert len(plain.split())<=350,(n,len(plain.split()))
    assert 8<=len(vocab)<=15,(n,len(vocab))
    assert len(questions)==6
    for q in questions:
        assert q['evidence'] in plain,(n,q['evidence'])
        if q['type']=='gap':assert len(q['answer'].split())==1 and re.search(r'\b'+re.escape(q['answer'])+r'\b',q['evidence'],re.I),(n,q)
    d.update(title=title,summary=summary,script=script,phrases=vocab,questions=questions,
        editorialNote=f'Full-event overview rewrite, 2026-10-21. Balanced context, sequence, causes, outcomes and significance. Source audit: content/sources/{n:03}-overview-2026-10-21.md. Matching audio required before publication.')
    (DRAFTS/f'{n:03}.json').write_text(json.dumps(dict(lesson=d,sources=sources,decisions=decisions),ensure_ascii=False,indent=2)+'\n')
    print(f'{n:03}: reviewed draft, {len(plain.split())} words, {len(vocab)} vocabulary entries')
def stage(n,recording_root=None):
    raw=json.loads((DRAFTS/f'{n:03}.json').read_text());d=raw['lesson']
    if recording_root:
        recording_root=Path(recording_root)
        m=json.loads((recording_root/f'content/audio/{n:03}.meta.json').read_text())
        assert m['scriptSha256']==hashlib.sha256(d['script'].replace('**','').strip().encode()).hexdigest()
        assert m['voice']==('en-US-BrianNeural' if n%2 else 'en-US-AvaNeural') and m['completeSubtitleMatch']
        assert (recording_root/f'content/audio/{n:03}.mp3').is_file() and (recording_root/f'content/subtitles/{n:03}.vtt').is_file()
    (ROOT/f'content/lessons/{n:03}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
    (ROOT/f'content/tts/{n:03}.txt').write_text(d['script'].replace('**','').strip()+'\n')
    (ROOT/f'content/sources/{n:03}-overview-2026-10-21.md').write_text(f"# {n:03}: {d['title']}\n\nFull-event overview reviewed 2026-10-21.\n\n## Sources\n\n"+'\n'.join('- '+s for s in raw['sources'])+'\n\n## Coverage and accuracy\n\n'+'\n'.join('- '+s for s in raw['decisions'])+'\n')
    if recording_root:
        for name in [f'content/audio/{n:03}.mp3',f'content/audio/{n:03}.meta.json',f'content/subtitles/{n:03}.vtt']:shutil.copyfile(recording_root/name,ROOT/name)
    print(f'Staged {n:03}')
def checkpoint(n):
    p=ROOT/'content/production.json';d=json.loads(p.read_text());lessons=[json.loads(p.read_text()) for p in sorted((ROOT/'content/lessons').glob('*.json'))]
    rows=[];duration=0
    for item in lessons:
        stem=f"{item['order']:03}";plain=item['script'].replace('**','').strip();m=json.loads((ROOT/f'content/audio/{stem}.meta.json').read_text())
        assert m['scriptSha256']==hashlib.sha256(plain.encode()).hexdigest(),stem
        d['scriptWords'][stem]=len(plain.split());d['vocabularyItems'][stem]=len(item['phrases']);duration+=m['durationSeconds']
        rows.append(f"| {stem} | {len(plain.split())} | {len(item['phrases'])} | {m['durationSeconds']:.1f} s |")
    ready=sorted(set(d.get('overviewRevisionReady',[]))|{f'{n:03}'})
    remaining=[f'{i:03}' for i in range(1,16) if f'{i:03}' not in ready]
    d.update(overviewRevisionReady=ready,overviewRevisionRemaining=remaining,qualityRevisionReady=ready,qualityRevisionRemaining=remaining,vocabularyEntryCount=sum(len(i['phrases']) for i in lessons),normalizedHeadwordCount=sum(bool(p.get('scriptForms')) for i in lessons for p in i['phrases']),scriptStyle='Balanced full-event overview: context, main developments, causes/mechanism, outcomes and wider significance; natural mostly B1 English.',updatedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
    p.write_text(json.dumps(d,indent=2)+'\n')
    policy_path=ROOT/'content/editorial-policy.json'
    policy=json.loads(policy_path.read_text())
    policy['coverageReview']='Full-event overview review completed for lessons '+', '.join(ready)+'.'+(' Remaining: '+', '.join(remaining)+'.' if remaining else ' All 15 existing lessons follow the overview standard.')
    policy_path.write_text(json.dumps(policy,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'PROGRESS.md').write_text(f'''# Lingonut — current progress

Website: https://english-unicorn-listening.maithu188.chatgpt.site

15 published lessons with matching Brian US / Ava US recordings. Collection target: 1,000.

Full-event overview rewrite completed: {', '.join(ready)}.
Remaining overview rewrites: {', '.join(remaining) or 'None'}.

## Editorial standard

Give newcomers a balanced picture: background and setting, main developments, causes/mechanism, immediate outcomes and wider significance. Details support the overview. Titles, summaries, vocabulary and questions follow that scope. Maximum 350 words, mostly B1 English, 8–15 vocabulary entries, three multiple-choice questions and three one-word gaps.

Current audits: content/sources/NNN-overview-2026-10-21.md. Earlier audits are historical. Editorial drafts are saved in content/editorial-drafts and never served as published lessons until applied and paired with matching audio.

## Audio and validation

Every rewritten script receives a new complete recording. Odd lessons use Brian US; even lessons use Ava US. Generated subtitles match the full text, script hashes match recording metadata, and MP3 streams decode successfully. These automated checks are not an independent listening or pronunciation review. Superseded audio is replaced rather than kept in an archive.

| Lesson | Script words | Vocabulary | Audio duration |
| --- | ---: | ---: | ---: |
{chr(10).join(rows)}

Total audio: {duration/60:.1f} minutes. Vocabulary entries: {d['vocabularyEntryCount']}. Questions: 90.

## Delivery

Completed lessons are saved and published individually to the same public Site. Builds validate all lesson payloads and audio references. The interface, themes and donation settings are preserved. Interactive browser testing has not been repeated for these editorial changes.

The original reference Site is untouched. The previous ZIP is an older snapshot. Current source, editorial drafts and recordings are versioned with this Site. Lessons 016–020 remain unpublished; their exact old drafts were not recovered.
''')
    print(json.dumps(dict(overviewReady=ready,remaining=len(remaining))))
if __name__=='__main__':
    if sys.argv[1]=='stage':stage(int(sys.argv[2]),sys.argv[3] if len(sys.argv)>3 else None)
    else:checkpoint(int(sys.argv[2]))
