"""Source-reviewed world events and historical turning points, lessons 081–085."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(81, 'gandhi-salt-march-1930', 'Gandhi’s Salt March: A Protest Against Colonial Rule', 'Rights and Historical Turning Points',
      'A march against British salt laws grew into a wider campaign of peaceful resistance, bringing arrests, international attention and negotiations over India’s future.',
'''In 1930, India was under British colonial rule. Laws gave the authorities a **monopoly** over salt production and sale, while a tax raised the cost of an everyday **necessity**. Mahatma Gandhi chose salt as a symbol of the wider demand for Indian self-government.

His campaign used **civil disobedience**. Supporters would openly break laws they considered unjust while refusing to use violence. Gandhi hoped that disciplined public action would expose the limits of colonial authority and draw ordinary people into the independence movement.

On March 12, he left Sabarmati Ashram near Ahmedabad with 78 core volunteers. They walked roughly 390 kilometers to the coastal village of Dandi, stopping to speak to crowds along the way. On April 6, Gandhi broke the salt law there. This small act of **defiance** challenged a system that prevented people from freely collecting or making their own salt.

The campaign spread beyond the original marchers. People made salt, refused certain taxes and took part in the **boycott** of foreign goods. Women joined and led protests. After Gandhi's arrest in May, Sarojini Naidu helped lead volunteers at the Dharasana salt works, where police attacked peaceful demonstrators.

Colonial **repression** brought thousands of arrests and violence against protesters. Reports of these events reached audiences abroad. The movement connected a basic household need with a much larger political question: who had the right to govern India?

In March 1931, Gandhi and the British viceroy, Lord Irwin, reached an agreement through **negotiations**. Congress suspended civil disobedience and agreed to join constitutional talks. The government promised to release qualifying movement prisoners and permitted limited local salt-making.

These **concessions** left major disagreements unresolved. The salt tax was not abolished, and India remained under British rule. Gandhi attended talks in London later in 1931, but independence was still years away.

The march demonstrated how a familiar issue could **mobilize** people across a country. Its importance lay in the scale of participation and the political challenge created by organized nonviolent resistance, rather than an immediate end to colonial rule.''',
[
v('monopoly', 'Exclusive control over the production or sale of a product or service.', 'The company held a monopoly over the local supply.', 'Noun', plural='monopolies'),
v('necessity', 'Something that is needed for ordinary life.', 'Clean water is a basic necessity.', 'Noun', plural='necessities'),
v('civil disobedience', 'The deliberate, public and nonviolent refusal to obey a law considered unjust.', 'The campaign used civil disobedience to challenge the law.', 'Uncountable noun phrase'),
v('defiance', 'Open refusal to obey or accept someone’s authority.', 'The protest became an act of defiance.', 'Uncountable noun'),
v('boycott', 'An organized refusal to buy from or participate in something as a form of protest.', 'The boycott reduced sales of the imported goods.', 'Noun', plural='boycotts'),
v('repression', 'The use of force or restrictions by authorities to control opposition.', 'Repression prevented many people from protesting openly.', 'Uncountable noun'),
v('negotiation', 'A discussion intended to reach an agreement.', 'The negotiation led to a temporary settlement.', 'Noun', form='negotiations', plural='negotiations', note='Often plural for a series of discussions.'),
v('concession', 'Something accepted or given up in order to reach an agreement.', 'Each side made a concession during the talks.', 'Noun', form='concessions', plural='concessions'),
v('mobilize', 'To organize people or resources for a shared purpose.', 'The campaign helped mobilize local volunteers.', 'Verb', verb=('mobilize','mobilized','mobilized',False))
],
[
m('Why did Gandhi choose salt as a focus for protest?', ['It connected a basic daily need with the issue of colonial control.', 'It was the largest source of British colonial revenue.', 'It allowed Congress to limit the protest to industrial workers.'], 'A', 'Mahatma Gandhi chose salt as a symbol of the wider demand for Indian self-government.', 'The preceding sentences describe official control and a tax on an everyday necessity.'),
m('What happened after the original march?', ['Officials abolished the salt tax before protests spread.', 'People joined wider protests, salt-making, tax refusal and a boycott.', 'Congress moved directly into constitutional talks after the April 6 action.'], 'B', 'People made salt, refused certain taxes and took part in the boycott of foreign goods.', 'Women also joined and led actions as the campaign spread beyond the marchers.'),
m('What was the significance of the 1931 agreement?', ['It abolished the salt tax while leaving British rule in place.', 'It expanded the campaign while Congress refused constitutional talks.', 'It brought limited concessions and talks while colonial rule continued.'], 'C', 'The salt tax was not abolished, and India remained under British rule.', 'The agreement suspended civil disobedience and opened talks without granting independence.'),
g('Gandhi broke the salt law at the coastal village of ___.', 'Dandi', 'They walked roughly 390 kilometers to the coastal village of Dandi, stopping to speak to crowds along the way.', 'The next sentence identifies Dandi as the location of the April 6 action.'),
g('Supporters challenged laws while refusing to use ___.', 'violence', 'Supporters would openly break laws they considered unjust while refusing to use violence.', 'Nonviolent action was central to the campaign’s approach.'),
g('Gandhi attended talks in ___ later in 1931.', 'London', 'Gandhi attended talks in London later in 1931, but independence was still years away.', 'These discussions followed the agreement with Lord Irwin.')
],
[
'Rajghat Samadhi Committee, Government of India, chronology — March 12 departure, April 6 salt-law breach, May arrest and 1931 agreement and London visit: https://rajghat.gov.in/chronology',
'Government of India Publications Division, Civil Disobedience Movement — Wider protests, Naidu, repression and negotiations; its erroneous 1932 London date is not used: https://www.publicationsdivision.nic.in/catalog/view/theme/default/images/new_ngm_final/timeline/pages/page14.html',
'UK Parliament, Hansard, March 5, 1931 — Primary settlement text, qualified prisoner releases and limited village salt-making rather than abolition of salt laws: https://api.parliament.uk/historic-hansard/commons/1931/mar/05/conversations-between-the-governor',
'NCERT history chapter, IIT Kanpur SATHEE reproduction — Salt monopoly, broad participation and the movement’s context: https://sathee.iitk.ac.in/sathee-cuet/student-corner/ncert-books/class-12/themes-in-indian-history/chapter-11-mahatma-gandhi-and-the-nationalist-movement-civil-disobedience-and-beyond/'
],
[
'Event overview includes colonial rule and the salt monopoly, nonviolent strategy, the march and law breach, broader participation and women’s leadership, repression, negotiation, limited results and longer significance.',
'Dandi arrival and the April 6 law breach are distinct. The narrative uses an approximate 390-kilometer route, avoiding small differences in official mileage.',
'The pact did not abolish the salt tax, release every political prisoner or grant immediate independence. Qualifying movement prisoners and limited local salt-making reflect the actual primary settlement.',
'London talks occurred in 1931, corroborated by Rajghat. The Publications Division’s isolated 1932 departure typo is rejected.',
'All 001–080, the other batch subjects and reserved candidates were compared. This fulfills the reserved gandhi-salt-march-1930 identity and is distinct from 070’s Partition overview and 018’s Montgomery campaign. It is not a full Gandhi biography.'
])

draft(82, 'rwanda-genocide-against-tutsi-1994', 'Rwanda 1994: The Genocide Against the Tutsi and Its Aftermath', 'World Events and Human Rights',
      'Extremist leaders organized the destruction of Rwanda’s Tutsi population, while international protection failed and survivors faced years of rebuilding and justice efforts.',
'''In 1994, Rwanda, a small country in East Africa, experienced a **genocide** against its Tutsi population. Hutu political opponents and others who resisted the killings were also targeted. The violence grew from political choices and organized hatred, following years of division and conflict.

Belgian colonial rule had hardened divisions between Hutu and Tutsi through unequal treatment and official identity categories. After independence in 1962, **discrimination** and violence forced many Tutsi into exile. A civil war began in 1990 between the government and the Tutsi-led Rwandan Patriotic Front, or RPF. A later peace agreement remained fragile.

On April 6, 1994, a plane carrying Rwanda's president and the president of Burundi was shot down. Responsibility for the attack remains disputed. Hutu extremist leaders used the assassination to launch a prepared campaign of killing.

Government officials, security forces and **militias** organized or carried out attacks. **Propaganda** encouraged hatred and participation. Tutsi were targeted because of their identity, while political opponents were killed for challenging the extremists. Many **civilians** were attacked in places where they had expected protection. Some people risked their lives to hide or help those being hunted.

The killing continued for roughly 100 days, from April into July. The death toll is often estimated at around 800,000 to 1 million, overwhelmingly Tutsi. Families and communities were devastated, and survivors faced injury, grief and lost homes.

The United Nations had peacekeepers in Rwanda, but their limited **mandate**, inadequate resources and lack of international political support prevented an effective response. Most troops were withdrawn as the crisis intensified. The UN later acknowledged its failure to prevent and stop the genocide.

The RPF's military advance defeated the genocidal government in July. Large numbers of people fled across borders, creating further humanitarian emergencies. The **displaced** population included civilians, while perpetrators also escaped among the refugees.

An international **tribunal**, national trials and community courts later pursued accountability. Rebuilding institutions and relationships required much more than convictions. The genocide left lasting questions about warning signs, international responsibility, justice and the difficult work of **reconciliation**.''',
[
v('genocide', 'Acts committed with the intention of destroying, wholly or partly, a national, ethnic, racial or religious group.', 'The tribunal examined evidence of genocide.', 'Noun', plural='genocides'),
v('discrimination', 'Unfair treatment of people because of characteristics such as their identity or background.', 'The law was intended to prevent discrimination.', 'Uncountable noun'),
v('militia', 'An armed group that operates outside, or alongside, regular national armed forces.', 'The militia established control over several towns.', 'Noun', form='militias', plural='militias'),
v('propaganda', 'Information or messages designed to influence beliefs, often by misleading people or encouraging prejudice.', 'The broadcasts spread propaganda against a minority.', 'Uncountable noun'),
v('civilian', 'A person who is not a member of the armed forces.', 'The fighting forced civilians to leave their homes.', 'Noun', form='civilians', plural='civilians'),
v('mandate', 'The official authority and responsibilities given to an organization or mission.', 'The mission’s mandate limited what its personnel could do.', 'Noun', plural='mandates'),
v('displaced', 'Forced to leave the place where one normally lives.', 'Displaced families needed food and shelter.', 'Adjective'),
v('tribunal', 'A court or other body established to judge particular legal matters.', 'The tribunal heard testimony from survivors.', 'Noun', plural='tribunals'),
v('reconciliation', 'The process of rebuilding trust and relations after conflict or serious disagreement.', 'Reconciliation required long-term work within the community.', 'Uncountable noun')
],
[
m('Which description best explains the organized killings?', ['The violence developed spontaneously without preparation by political leaders.', 'Extremist authorities and armed groups targeted Tutsi and political opponents.', 'The killings focused mainly on the opposing armies in the civil war.'], 'B', 'Government officials, security forces and militias organized or carried out attacks.', 'The story identifies organized extremist actors without assigning collective guilt to all Hutu.'),
m('Why did the UN presence fail to stop the genocide?', ['Its mandate focused on protecting government officials rather than the wider population.', 'Peacekeepers were first sent to Rwanda after the genocide had ended.', 'A restricted mandate, inadequate resources and weak political support limited its response.'], 'C', 'The United Nations had peacekeepers in Rwanda, but their limited mandate, inadequate resources and lack of international political support prevented an effective response.', 'The withdrawal of most troops further weakened international protection.'),
m('What followed the RPF’s military victory?', ['Large refugee movements and later efforts at justice and rebuilding.', 'Refugees returned quickly and further court proceedings were unnecessary.', 'The earlier peace agreement was restored without a new government or trials.'], 'A', 'Large numbers of people fled across borders, creating further humanitarian emergencies.', 'The final paragraph also describes international, national and community justice efforts.'),
g('Rwanda is a small country in East ___.', 'Africa', 'In 1994, Rwanda, a small country in East Africa, experienced a genocide against its Tutsi population.', 'The opening sentence establishes the geographic setting.'),
g('A civil war between the government and the RPF began in ___.', '1990', 'A civil war began in 1990 between the government and the Tutsi-led Rwandan Patriotic Front, or RPF.', 'The civil war preceded the genocide by several years.'),
g('The killing lasted roughly 100 ___.', 'days', 'The killing continued for roughly 100 days, from April into July.', 'The narrative uses an approximate duration rather than one exact end date for every location.')
],
[
'US Holocaust Memorial Museum, Divided by Ethnicity — Colonial and postcolonial division, persecution, civil war and organized hatred: https://www.ushmm.org/genocide-prevention/countries/rwanda/divided-by-ethnicity',
'US Holocaust Memorial Museum, Massacre of the Tutsi Minority — Unresolved aircraft attack, organized targeting, RPF advance and refugees: https://www.ushmm.org/genocide-prevention/countries/rwanda/massacre-of-the-tutsi-minority',
'United Nations International Criminal Tribunal for Rwanda, The Genocide — April 6 aircraft attack, organized perpetrators, approximately 100 days and 800,000–1 million estimate: https://unictr.irmct.org/en/genocide',
'United Nations independent inquiry presented to Security Council, April 14, 2000 — Institutional failure, inadequate political will and troop reduction: https://press.un.org/en/2000/20000414.sc6843.doc.html',
'United Nations Rwanda Outreach, backgrounders — International tribunal, national justice and community courts: https://www.un.org/en/preventgenocide/rwanda/backgrounders.shtml'
],
[
'Balanced overview distinguishes earlier social and political division and civil war from the organized genocide against the Tutsi. It includes other targeted people, perpetrators and propaganda, human losses, failed protection, military ending, refugee emergencies and justice.',
'Responsibility for the plane attack remains unresolved. It is a trigger exploited by prepared extremists, not the complete explanation or a proven act by one named party.',
'Identify extremist institutions and armed actors without blaming all Hutu or describing the genocide as reciprocal ancient tribal violence. Ordinary people who protected victims also appear.',
'Official estimates vary; the narrative gives a common approximate 800,000–1 million range, not a precise verified total or denial of higher estimates. No graphic violence, comparative ranking of suffering or operational killing details.',
'The genocide ended through the RPF advance in July; this does not mean all killing or humanitarian suffering stopped everywhere on one day. Refugees included civilians and perpetrators, without treating all refugees as perpetrators.',
'Courts pursued accountability; convictions alone did not complete social reconciliation. No assertion that all community-court proceedings met identical standards.',
'Compared with all 001–081 and reserved topics. Rwanda’s 1994 genocide is a distinct central event from the Holocaust, Khmer Rouge rule and Mỹ Lai, not a renamed retelling of any earlier genocide lesson.'
])

draft(83, 'sputnik-first-artificial-satellite-1957', 'Sputnik 1: The Launch That Began the Space Age', 'Discoveries and Exploration',
      'The Soviet Union placed the first artificial satellite in orbit, transforming scientific ambitions, Cold War competition and American space policy.',
'''On October 4, 1957, the Soviet Union launched Sputnik 1, the world's first artificial Earth **satellite**. A rocket placed a small metal sphere into **orbit**, where it circled the planet about once every 100 minutes. The successful launch marked the beginning of the space age.

The achievement combined scientific ambition with international competition. Both the Soviet Union and the United States had planned satellites for the International Geophysical Year, a scientific program studying Earth and its environment. Their projects also developed within the Cold War **rivalry** between the two powers.

Sputnik was simple compared with later spacecraft. Its sphere was about 58 centimeters wide, with long **antennas** extending from it. A radio **transmitter** sent regular beeps that could be received on Earth. Scientists and radio enthusiasts with suitable equipment could follow its signals as it passed overhead.

The signals made the achievement tangible. A human-made object was circling the entire planet, crossing above national borders. For the Soviet government, Sputnik brought enormous **prestige**. For many people elsewhere, it inspired excitement about what science might achieve next.

In the United States, admiration mixed with anxiety. The launch suggested a Soviet advantage in rocket **capability**, raising military concerns as well as scientific questions. American leaders faced pressure to accelerate their own programs. Satellites became symbols of technological strength and political influence.

The response included increased **funding** for space research and greater attention to science and mathematics education. On January 31, 1958, the United States launched Explorer 1, its first satellite. Later that year, NASA began operating as a civilian space agency, drawing on existing organizations and research programs.

Sputnik's own mission was brief. Its radio signals stopped after about three weeks. It remained in orbit until January 4, 1958, when it **reentered** the atmosphere and burned up.

Its influence lasted much longer. The launch accelerated a competition that would lead to human spaceflight and journeys to the Moon. It also opened a new era in which objects orbiting Earth would become tools for scientific observation, communication and navigation.''',
[
v('satellite', 'An object that travels around a planet or another larger object in space.', 'The satellite sent information back to Earth.', 'Noun', plural='satellites'),
v('orbit', 'The path followed by an object moving around another object in space.', 'The spacecraft entered orbit around Earth.', 'Noun', plural='orbits'),
v('rivalry', 'Competition between people, groups or countries seeking the same advantage.', 'The rivalry increased investment in research.', 'Noun', plural='rivalries'),
v('antenna', 'A device used to transmit or receive radio signals.', 'The engineer checked the spacecraft’s antenna.', 'Noun', form='antennas', plural='antennas'),
v('transmitter', 'A device that sends out signals, especially radio signals.', 'The transmitter sent a regular signal to the ground station.', 'Noun', plural='transmitters'),
v('prestige', 'Respect or admiration associated with success, importance or achievement.', 'The discovery increased the institution’s prestige.', 'Uncountable noun'),
v('capability', 'The ability or resources needed to do something.', 'The mission demonstrated a new technical capability.', 'Noun', plural='capabilities'),
v('funding', 'Money provided for a particular activity or purpose.', 'The project received additional research funding.', 'Uncountable noun'),
v('reenter', 'To enter a place or area again.', 'The spacecraft will reenter the atmosphere after its mission.', 'Verb', form='reentered', verb=('reenter','reentered','reentered',False))
],
[
m('What made Sputnik 1 a historical first?', ['It carried the first living passenger into Earth orbit.', 'It was the first spacecraft to send photographs of Earth from orbit.', 'It was the first artificial satellite to orbit Earth.'], 'C', "On October 4, 1957, the Soviet Union launched Sputnik 1, the world's first artificial Earth satellite.", 'Its achievement was sustained Earth orbit by an artificial satellite.'),
m('Why did the launch cause concern in the United States?', ['It suggested a Soviet advantage in rocket capability during the Cold War.', 'It was the first announcement that either country planned to launch a satellite.', 'It showed that satellites could travel only above their launching country.'], 'A', 'The launch suggested a Soviet advantage in rocket capability, raising military concerns as well as scientific questions.', 'The achievement had political and military significance alongside its scientific value.'),
m('Which description correctly distinguishes Sputnik’s mission from its later influence?', ['Its radio mission continued throughout 1958 as American satellites were launched.', 'Its short mission ended in atmospheric reentry, while its launch had lasting effects on space exploration.', 'Its launch ended competition because the two powers merged their space programs.'], 'B', 'It remained in orbit until January 4, 1958, when it reentered the atmosphere and burned up.', 'The following paragraph explains its continuing influence on competition and the uses of satellites.'),
g('Sputnik’s radio transmitter sent regular ___.', 'beeps', 'A radio transmitter sent regular beeps that could be received on Earth.', 'People with suitable equipment could receive and follow these signals.'),
g('The first American satellite was called ___ 1.', 'Explorer', 'On January 31, 1958, the United States launched Explorer 1, its first satellite.', 'The American launch followed Sputnik in the next year.'),
g('NASA began operating as a ___ space agency.', 'civilian', 'Later that year, NASA began operating as a civilian space agency, drawing on existing organizations and research programs.', 'NASA’s creation built on existing institutions rather than beginning all American space research from nothing.')
],
[
'NASA, Dawn of the Space Age — First satellite, scale, orbital period, International Geophysical Year, Explorer and NASA: https://www.nasa.gov/history/dawn-of-the-space-age/',
'NASA, 65 Years Ago: Sputnik Ushers in the Space Age — Radio signals, reception, short mission and January 4, 1958 reentry: https://www.nasa.gov/history/65-years-ago-sputnik-ushers-in-the-space-age/',
'US Department of State, Sputnik, 1957 — Cold War significance, anxiety, policy response and accelerated competition: https://history.state.gov/milestones/1953-1960/sputnik',
'US House of Representatives, National Defense Education Act — Primary legislative record and science and mathematics education response: https://history.house.gov/HouseRecord/Detail/15032436195'
],
[
'Balanced overview includes the first-orbit achievement, scientific cooperation and rivalry, the satellite and its signals, public reactions, military and political implications, American response, mission ending and later influence.',
'First artificial Earth satellite does not mean first object ever to reach space, first human flight or first Moon landing. Sputnik 1 carried neither a person nor Laika.',
'About 100 minutes is a deliberate rounded orbital period. No claim that every bright object seen from the ground was the small satellite rather than its rocket stage.',
'The United States already had satellite plans. Sputnik accelerated developments; NASA also inherited existing organizations. Later communications and navigation are the legacy of satellites, not functions claimed for Sputnik 1 itself.',
'Compared with all 001–082 and reserved candidates. This first satellite launch is distinct from Apollo 11, Apollo 13, the Wright brothers and the 1919 eclipse test.'
])

draft(84, 'vesuvius-pompeii-eruption-79-ce', 'Vesuvius 79 CE: The Destruction and Preservation of Pompeii', 'Disasters and the Ancient World',
      'An explosive eruption destroyed Roman communities around Vesuvius, while volcanic burial preserved evidence that later transformed knowledge of everyday Roman life.',
'''In 79 CE, Mount Vesuvius erupted near the Bay of Naples, in present-day Italy. Below the volcano lay Roman towns, farms and villas. Pompeii was a busy community of homes, shops, temples and public baths. The eruption transformed this familiar landscape into a disaster zone.

A towering column of volcanic material rose into the sky. **Pumice** and ash fell on Pompeii, piling up on streets and roofs. The increasing weight caused buildings to **collapse**. People tried to **flee**, while others sheltered indoors or searched for relatives and possessions.

Later, fast-moving currents of extremely hot gas, ash and volcanic material swept down the volcano. They **engulfed** settlements, including Pompeii and Herculaneum. The towns experienced different patterns of destruction, but both were buried beneath thick volcanic **deposits**. Falling material and these dangerous currents caused the principal destruction, rather than a river of lava.

Many residents escaped, while others died. The total number killed remains uncertain. Survivors lost homes and communities, and the surrounding region needed relief. Some returned to recover possessions, and parts of the ruined site were later inhabited again.

Pliny the Younger witnessed the eruption from Misenum, across the bay. His later letters described the enormous cloud and the confusion of escape. Written testimony and evidence from the buried landscape together help researchers reconstruct what happened. The exact calendar date of the eruption is still debated.

Large-scale efforts to **excavate** Pompeii began in 1748. Over time, workers uncovered streets, buildings, tools and wall paintings. An **inscription** on a wall or an object in a workshop could reveal details of ordinary life that grand accounts of emperors often missed.

Burial had preserved remarkable evidence, but exposure created new dangers. Rain, weathering and the pressure of visitors could damage **fragile** remains. Excavation therefore required careful recording and continued **conservation**, rather than simply removing more material as quickly as possible.

Pompeii's significance combines human loss with exceptional historical evidence. The eruption destroyed living communities, while the buried remains later offered an unusually detailed view of the Roman world and the lives of people beyond its rulers.''',
[
v('pumice', 'A light volcanic rock containing many small holes.', 'Pumice fragments fell around the volcano.', 'Uncountable noun'),
v('collapse', 'To fall down or give way suddenly.', 'The damaged roof began to collapse.', 'Verb', verb=('collapse','collapsed','collapsed',False)),
v('flee', 'To leave a place quickly because of danger.', 'Many residents had to flee the town.', 'Verb', verb=('flee','fled','fled',True)),
v('engulf', 'To surround and cover something completely.', 'A cloud of ash began to engulf the settlement.', 'Verb', form='engulfed', verb=('engulf','engulfed','engulfed',False)),
v('deposit', 'A layer or amount of material left in a place by a natural process.', 'Researchers examined a deposit of volcanic ash.', 'Noun', form='deposits', plural='deposits'),
v('excavate', 'To carefully dig out and uncover buried material or structures.', 'Archaeologists began to excavate the ancient street.', 'Verb', verb=('excavate','excavated','excavated',False)),
v('inscription', 'Words or marks written, cut or scratched onto a surface.', 'The inscription recorded the owner’s name.', 'Noun', plural='inscriptions'),
v('fragile', 'Easily damaged or broken.', 'The fragile wall painting needed protection.', 'Adjective'),
v('conservation', 'The protection and careful care of things that could be damaged or lost.', 'Conservation helped protect the ancient buildings.', 'Uncountable noun')
],
[
m('What principally caused Pompeii’s destruction and burial?', ['Molten lava slowly filled the streets and covered the buildings.', 'Falling volcanic material and hot currents of gas, ash and rock.', 'A single earthquake destroyed the town before volcanic material arrived.'], 'B', 'Falling material and these dangerous currents caused the principal destruction, rather than a river of lava.', 'The narrative describes pumice and ash fall, building collapse and later hot volcanic currents.'),
m('Why is Pompeii valuable for understanding Roman history?', ['It provides detailed evidence of everyday life through buildings, objects and writing.', 'Its importance comes mainly from written accounts by Roman emperors.', 'Its ruins record only the lives of wealthy villa owners.'], 'A', 'Over time, workers uncovered streets, buildings, tools and wall paintings.', 'The following sentence explains how inscriptions and workshop objects reveal ordinary lives.'),
m('Why does uncovering the ruins require continued conservation?', ['The priority is to expose every room before planning how to record it.', 'Volcanic burial continues to protect remains permanently after they are uncovered.', 'Exposure, weathering and visitors can damage fragile material.'], 'C', 'Rain, weathering and the pressure of visitors could damage fragile remains.', 'Careful recording and protection are required alongside excavation.'),
g('The eruption occurred in the year ___ CE.', '79', 'In 79 CE, Mount Vesuvius erupted near the Bay of Naples, in present-day Italy.', 'The year is established, while the exact day remains debated.'),
g('The weight of falling material caused buildings to ___.', 'collapse', 'The increasing weight caused buildings to collapse.', 'Pumice and ash accumulated on streets and roofs.'),
g('Large-scale excavation of Pompeii began in ___.', '1748', 'Large-scale efforts to excavate Pompeii began in 1748.', 'This date concerns sustained excavation, rather than claiming nobody had encountered the remains earlier.')
],
[
'Archaeological Park of Pompeii, The Casts — Pumice fall, building collapse, later pyroclastic currents and burial evidence: https://pompeiisites.org/en/pompeii-map/analysis/the-casts/',
'Archaeological Park of Pompeii, Pompeii after the Eruption — Relief, survivors, later disturbance and sustained excavation from 1748: https://pompeiisites.org/en/pompeii-map/analysis/pompeii-after-the-eruption/',
'UNESCO World Heritage Centre, Archaeological Areas of Pompei, Herculaneum and Torre Annunziata — Roman communities, everyday evidence, preservation and maintenance; introductory August date is not treated as settled: https://whc.unesco.org/en/list/829',
'Archaeological Park of Pompeii E-Journal, December 2024, La data della distruzione di Pompei — Primary scholarly examination of competing date evidence: https://pompeiisites.org/wp-content/uploads/27_E-Journal_La-data-della-distruzione-di-Pompei_2.pdf',
'Western Australian Museum, Pompeii high-school resource — Pliny’s perspective, later letters and interpretation of remains: https://museum.wa.gov.au/sites/default/files/WAMuseum_Pompeii_HighschoolResource.pdf',
'Archaeological Park of Pompeii, August 6, 2025, post-eruption reoccupation — The ruined site continued to have a human history after 79 CE: https://pompeiisites.org/e-journal-degli-scavi-di-pompei/la-rioccupazione-nellinsula-meridionalis-di-pompei-dopo-il-79-d-c-riflessioni-a-margine-dellinconscio-archeologico/',
'Archaeological Park of Pompeii, August 21, 2026, new evidence from the Insula Meridionalis — Post-eruption domestic reuse and occupation into late antiquity: https://pompeiisites.org/e-journal-degli-scavi-di-pompei/pompei-oltre-il-79-d-c-nuove-evidenze-dallinsula-meridionalis-tra-tarda-antichita-e-rinascimento/'
],
[
'Full event and legacy overview includes Roman setting, successive eruption hazards, flight and shelter, different affected towns, deaths and displacement, relief and return, contemporary testimony, later excavation and conservation.',
'Use 79 CE without asserting either August 24 or October 24. The Park’s 2024 scholarly discussion challenges simple certainty; UNESCO’s introductory August date and INGV’s 2022 October claim are not followed as settled facts.',
'Pompeii was principally buried by pumice, ash and pyroclastic currents, not a river of lava. No universal temperature, speed, minute-by-minute reconstruction or single cause of every death is claimed.',
'Many escaped; discovered remains are not equated with a complete death toll. No graphic descriptions or claim that all residents died.',
'Pliny the Younger observed from Misenum across the bay and wrote later letters; he was not an eyewitness inside Pompeii. Modern excavation is distinct from the original event and earlier disturbance.',
'1748 is the beginning of large-scale excavation, not the first-ever human contact with the buried settlement. Park research published in 2025 and August 2026 confirms later reoccupation, so the story explicitly acknowledges inhabited parts after the eruption rather than asserting complete abandonment. Preservation is incomplete and exposed ruins require ongoing care.',
'Compared with all 001–083 and reserved candidates. Vesuvius 79 CE is distinct from Tambora 1815, Krakatoa 1883 and the later archaeological discoveries at Tutankhamun’s tomb and Ötzi.'
])

draft(85, 'arab-oil-embargo-and-oil-crisis-1973-1974', 'The 1973 Oil Crisis: Embargo, Price Shock and Lasting Change', 'World Events and the Economy',
      'A war-related oil embargo and production cuts exposed dependence on imported energy, raised prices and reshaped economic and security policies.',
'''By 1973, many industrial countries depended on plentiful, relatively cheap oil. It powered transport, factories and home heating. Europe and Japan relied heavily on imports, while the United States had also become increasingly dependent on foreign supplies. This dependence made political conflict in producing regions an economic risk far beyond their borders.

In October, war broke out between Israel and Arab states. After the United States resupplied Israel's military, participating Arab oil producers imposed an **embargo** against the United States and selected other countries. They also reduced production, using oil to apply political pressure.

The action was coordinated through the Organization of Arab Petroleum Exporting Countries, or OAPEC. It was not an embargo by every member of the broader OPEC organization. Restrictions on exports to particular countries and wider production cuts affected the market in different ways.

The price of **crude oil** rose from about 3 dollars per barrel before the embargo to nearly 12 dollars by January 1974. Drivers faced fuel **shortages**, long queues and purchase limits in affected places. Businesses paid more for transport and production, passing some of those costs to customers.

The shock worsened **inflation** and contributed to economic slowdown and **recession**. However, prices had already been rising before the embargo. Currency changes, limited spare production capacity and government policies also shaped the crisis. Oil was a major factor in a wider economic problem.

Higher prices increased the income and **bargaining power** of oil-producing governments. Importing countries reconsidered their dependence on distant suppliers. Diplomatic efforts linked the oil dispute with negotiations over the war. The main embargo against the United States ended in March 1974, but prices remained much higher than before.

Governments promoted energy **conservation** and greater fuel **efficiency**. Countries founded the International Energy Agency in 1974 to cooperate on supply security. A 1975 law established the United States' Strategic Petroleum **Reserve**, creating emergency storage for future disruptions.

The crisis changed how governments connected energy, economic stability and foreign policy. A resource woven into ordinary daily life had become a powerful instrument of international pressure.''',
[
v('embargo', 'An official restriction or ban on trade with a particular country or group.', 'The embargo stopped certain exports to the country.', 'Noun', plural='embargoes'),
v('crude oil', 'Petroleum in its natural state before it is processed into fuels and other products.', 'The refinery processed crude oil into usable fuels.', 'Uncountable noun phrase'),
v('shortage', 'A situation in which there is not enough of something that is needed.', 'The shortage forced customers to wait for supplies.', 'Noun', form='shortages', plural='shortages'),
v('inflation', 'A general increase in prices that reduces what money can buy.', 'Inflation raised the cost of everyday goods.', 'Uncountable noun'),
v('recession', 'A significant and widespread decline in economic activity lasting for a period of time.', 'Many businesses struggled during the recession.', 'Noun', plural='recessions'),
v('bargaining power', 'The ability to influence the terms or outcome of a negotiation.', 'Control of an essential resource increased the producer’s bargaining power.', 'Uncountable noun phrase'),
v('conservation', 'The careful use and protection of resources to avoid waste or loss.', 'Energy conservation reduced unnecessary fuel use.', 'Uncountable noun'),
v('efficiency', 'The ability to achieve a result while using less energy, time or other resources.', 'Better fuel efficiency reduced the amount of oil needed.', 'Uncountable noun'),
v('reserve', 'A supply kept for use when it is needed, especially in an emergency.', 'The country maintained a reserve of essential fuel.', 'Noun', form='Reserve', plural='reserves', note='Capitalized here as part of the official name “Strategic Petroleum Reserve”.')
],
[
m('Why did participating Arab oil producers impose the embargo?', ['To restore fixed low oil prices for countries importing energy.', 'To support American military resupply to Israel.', 'To exert political pressure after American military resupply to Israel.'], 'C', "After the United States resupplied Israel's military, participating Arab oil producers imposed an embargo against the United States and selected other countries.", 'The action was connected to the October war and the producers’ political aims.'),
m('How does the story explain the economic slowdown and inflation?', ['Inflation began only after the embargo, so ending it restored earlier prices.', 'The oil shock added to existing pressures and interacted with other economic factors.', 'Only transport costs mattered; currency movements and producer policies played no role.'], 'B', 'Currency changes, limited spare production capacity and government policies also shaped the crisis.', 'The narrative also states that prices had already been rising before the embargo.'),
m('Which long-term response followed the crisis?', ['More emphasis on conservation, efficiency, cooperation and emergency oil storage.', 'Importers concentrated purchases with a single supplier to obtain lower prices.', 'New policies focused on removing fuel-efficiency standards.'], 'A', 'Governments promoted energy conservation and greater fuel efficiency.', 'The following sentences identify the International Energy Agency and the Strategic Petroleum Reserve.'),
g('By January 1974, crude oil cost nearly ___ dollars per barrel.', '12', 'The price of crude oil rose from about 3 dollars per barrel before the embargo to nearly 12 dollars by January 1974.', 'These are rounded crude-oil prices, rather than the price of every retail fuel.'),
g('The main embargo against the United States ended in ___ 1974.', 'March', 'The main embargo against the United States ended in March 1974, but prices remained much higher than before.', 'Restrictions and end dates differed among targeted countries.'),
g('Countries founded the International Energy Agency in ___.', '1974', 'Countries founded the International Energy Agency in 1974 to cooperate on supply security.', 'The agency’s creation preceded the American reserve law of 1975.')
],
[
'US Department of State, Oil Embargo, 1973–1974 — War, American resupply, embargo and production cuts, diplomacy and wider causes: https://history.state.gov/milestones/1969-1976/oil-embargo',
'Federal Reserve History, Oil Shock of 1973–74 — Participating OAPEC producers, roughly 2.90 to 11.65 dollars, existing inflation and economic complexity: https://www.federalreservehistory.org/essays/oil-shock-of-1973-74',
'International Energy Agency, History of the IEA — Founded 1974 in response to oil insecurity and import dependence: https://www.iea.org/about/mission/history-of-the-iea',
'US Department of Energy, SPR Origins — Reserve established under December 22, 1975 legislation, with first oil delivered in 1977: https://www.energy.gov/hgeo/opr/spr-origins',
'Federal Reserve Bank of Chicago, The 1973 Oil Crisis — Cheap oil, growing import dependence and price-series context: https://www.chicagofed.org/publications/chicago-fed-letter/1994/october-86'
],
[
'Balanced overview covers industrial dependence, the October war and American resupply, participating Arab producers and OAPEC, embargo versus production cuts, price and household effects, pre-existing economic pressures, producer power, diplomacy and policy changes.',
'The embargo was not imposed by every OPEC country. OAPEC coordination and participating Arab producers are distinguished from the broader organization.',
'October 1973 to March 1974 applies to the main United States embargo; the story does not impose identical restrictions or end dates on every target.',
'Prices are rounded from about 2.90 dollars to 11.65 dollars for crude oil by January 1974. Roughly four times the price would be about a 300 percent increase, not a 400 percent increase; no percentage is needed in the narrative.',
'Fuel queues and purchase limits are qualified by location. No claim of a universal American coupon-rationing system or that every retail fuel price quadrupled.',
'The embargo was a major contributor, not the sole cause of inflation or recession. The IEA’s 1974 founding is distinct from the 1975 reserve law and the first reserve oil in 1977.',
'Compared with all 001–084 and reserved candidates. This oil-dependence and market shock is distinct from 028’s banking and housing crisis and 076’s canal-control crisis.'
])
