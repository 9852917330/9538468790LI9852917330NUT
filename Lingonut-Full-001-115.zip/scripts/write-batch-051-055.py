"""Source-reviewed, distinct-topic overviews for English Unicorn 051–055."""
from importlib.machinery import SourceFileLoader
from pathlib import Path

helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(51, 'cambodia-scam-compound-trafficking-2020s', 'Cambodia’s Scam Compounds: False Jobs, Trafficking and Forced Fraud', 'Justice and Human Rights',
      'False job offers have drawn people into guarded scam sites, where trafficking victims are forced to defraud others and families face demands for money.',
'''In the 2020s, Cambodia became one hub in an international network of online scam operations. Behind some guarded office and residential sites, criminal groups combined financial fraud with human **trafficking**. People seeking legitimate work could become captives, while strangers elsewhere lost money to scams.

The process often began with **recruitment** through social media, job advertisements or trusted contacts. Offers promised attractive pay for ordinary office work. Some applicants borrowed money to travel, expecting better opportunities. The real conditions became clear only after they arrived.

At a scam **compound**, victims could have their passports **confiscated** and be prevented from leaving. Threats, violence and invented debts gave organizers control. Workers were **coerced** into contacting people online, promoting false investments or building deceptive relationships that led to demands for money.

People who refused or failed to meet targets could face punishment. Some were sold to other operations. Families might receive **ransom** demands or requests for a supposed release fee. They could sell land or borrow again, turning the original job offer into a continuing burden of **debt**.

The harm spread in two directions. Trafficked workers suffered confinement and abuse, while the people they were forced to contact could lose savings. The same criminal network profited from control over workers and deception of distant victims.

Police operations, embassy assistance and humanitarian organizations helped some people leave and return home. Effective responses required identifying trafficking victims and understanding each person's role. United Nations agencies called for protection for people forced to commit crimes, alongside investigation of the organizers.

In 2026, international agencies warned that cross-border networks and limited enforcement capacity complicated efforts to stop the business. UN human rights reporting also described survivor allegations of official corruption. Such findings concerned specific conduct and protection failures.

Safe **repatriation** began another stage. Survivors could return with trauma, few resources and unpaid debts. Support for **reintegration**, livelihoods and recovery was therefore part of the response to a crime that extended far beyond the compound gates.''',
[
v('trafficking', 'The recruitment, movement or control of people through force, deception or abuse for exploitation.', 'The investigation uncovered evidence of human trafficking.', 'Uncountable noun'),
v('recruitment', 'The process of finding and bringing people into a job or organization.', 'The company reviewed its recruitment advertisements.', 'Uncountable noun'),
v('compound', 'A group of buildings within an enclosed or guarded area.', 'The investigators entered the guarded compound.', 'Noun', plural='compounds'),
v('confiscate', 'To take something away using authority or control.', 'The captors threatened to confiscate the workers’ documents.', 'Verb', form='confiscated', verb=('confiscate','confiscated','confiscated',False)),
v('coerce', 'To make someone do something through force, threats or strong pressure.', 'The threats were used to coerce people into unpaid work.', 'Verb', form='coerced', verb=('coerce','coerced','coerced',False)),
v('ransom', 'Money demanded in exchange for releasing a captive.', 'The family received a ransom demand.', 'Noun', plural='ransoms'),
v('debt', 'Money that a person or organization owes.', 'The family struggled to repay the debt.', 'Noun', plural='debts'),
v('repatriation', 'The process of returning a person to their country of origin.', 'The embassy helped arrange the workers’ repatriation.', 'Uncountable noun'),
v('reintegration', 'The process of returning to ordinary social, community or working life after a period away or in difficult conditions.', 'The programme supported survivors’ reintegration into their communities.', 'Uncountable noun')
],
[
m('How did people often enter the trafficking situation?', ['They accepted deceptive offers of legitimate employment.', 'They were all informed in advance about every condition.', 'They were all organizers of the criminal operation.'], 'A', 'Offers promised attractive pay for ordinary office work.', 'The offers concealed the exploitative conditions that applicants later encountered.'),
m('Why could the financial harm continue after recruitment?', ['All recruitment costs and debts were automatically cancelled.', 'Families could face ransom demands and borrow more money.', 'Every payment guaranteed immediate and lasting safety.'], 'B', 'Families might receive ransom demands or requests for a supposed release fee.', 'The following sentence describes land sales and further borrowing that added to the family’s debt.'),
m('What did United Nations agencies call for?', ['Treating every person at a scam site as having the same role.', 'Ending all support when a survivor crossed a border.', 'Protecting people forced to offend while investigating organizers.'], 'C', 'United Nations agencies called for protection for people forced to commit crimes, alongside investigation of the organizers.', 'Identifying coercion and individual roles was central to an effective response.'),
g('Recruitment could begin through social ___ or trusted contacts.', 'media', 'The process often began with recruitment through social media, job advertisements or trusted contacts.', 'Social media was one route through which false offers reached applicants.'),
g('Victims could have their ___ confiscated.', 'passports', 'At a scam compound, victims could have their passports confiscated and be prevented from leaving.', 'Taking travel documents helped prevent people from leaving.'),
g('Families might sell ___ to meet demands for money.', 'land', 'They could sell land or borrow again, turning the original job offer into a continuing burden of debt.', 'Land sales and further borrowing could deepen the financial damage.')
],
[
'IOM Director General, UN Geneva briefing, July 28, 2026 — Deceptive recruitment, passport seizure, confinement, family ransom/debt, return and reintegration: https://www.unognewsroom.org/story/en/3211/un-geneva-press-briefing-28-july-2026/9543',
'UNODC and European Union, July 30, 2026 — International networks, victim identification, protection and non-punishment for forced criminality: https://home-affairs.ec.europa.eu/news/unodc-and-eu-warn-rising-human-trafficking-criminal-activities-scam-centres-2026-07-30_en',
'OHCHR, UN Geneva briefing, February 20, 2026 — Survivor accounts of coercion and official corruption; findings cover several countries: https://www.unognewsroom.org/story/en/3003/un-geneva-press-briefing-20-february-2026/8939',
'UN Human Rights report presentation, February 20, 2026 — Recruitment, economic pressure and ransom: https://www.unognewsroom.org/story/en/3006/un-human-rights-spokesperson-jeremy-laurence-and-pia-oberio-senior-human-rights-officer-on-abuses-at-scamming-operations/0',
'UN experts, May 21, 2025 — Sale to other operations, forced criminality and ransom demands: https://www.ohchr.org/en/press-releases/2025/05/un-experts-urge-immediate-human-rights-based-action-tackle-forced',
'INTERPOL, March 16, 2026 — Global expansion and enforcement challenges: https://www.interpol.int/en/News-and-Events/News/2026/INTERPOL-report-warns-of-increasingly-sophisticated-global-financial-fraud-threat'
],
[
'The explicitly requested topic is a bounded overview of Cambodia’s 2020s scam-compound trafficking crisis, including recruitment, confinement, forced fraud, ransom, both victim groups, enforcement and recovery.',
'Regional patterns are identified within international networks; individual reports from other countries are not falsely assigned to every Cambodian site. No claim that all workers are trafficked or that nationality establishes guilt.',
'Headcounts and blanket present-day closure claims are omitted because definitions and enforcement claims differ. The 2026 agency findings are dated in the narrative.',
'Corruption reporting is attributed to UN accounts and survivors rather than an accusation against every official. No scam scripts, criminal operating instructions, ransom-payment guidance or graphic violence.',
'Compared with all 001–050 and the other candidates. Distinct from Khmer Rouge rule 042 and the particular Essex smuggling deaths 040; identity and aliases registered in content/topics.json.'
])

draft(52, 'adolf-hitler-life-rise-and-death', 'Adolf Hitler: Early Life, Dictatorship and Death', 'Historical Lives',
      'An Austrian-born soldier and political extremist rose through crisis and political deals, built a dictatorship, drove war and mass murder, and died as Germany faced defeat.',
'''Adolf Hitler was born on April 20, 1889, in Braunau am Inn, in what is now Austria. He grew up wanting to become an artist, but Vienna's art academy rejected him twice. He later lived in poverty, selling pictures, before moving to Munich in 1913.

During World War I, he served in the German army. Germany's defeat and the political turmoil afterward helped shape his path into extremist politics. In 1919, he joined a small political group that became the Nazi Party. By 1921, he was its leader.

Extreme **nationalism**, racism and **antisemitism** shaped his programme. In 1923, he attempted to take power in Munich through a failed coup. He was imprisoned and began writing Mein Kampf, setting out racist ideas, territorial ambitions and hostility toward democracy.

The Great Depression brought unemployment and fear. Nazi **propaganda** promised jobs and national strength, while party organizations used violence against **opponents**. Electoral support grew. Conservative politicians helped bring Hitler into government, believing they could control him. President Paul von Hindenburg appointed him **chancellor** on January 30, 1933.

Hitler then dismantled democratic government. The Nazis restricted freedoms, arrested opponents and eliminated competing political parties. He built a **dictatorship**, controlled public information and pursued **rearmament**. Territorial expansion became a central aim of his rule.

Germany's **invasion** of Poland on September 1, 1939, began World War II in Europe. Hitler later ordered the invasion of the Soviet Union. Under his leadership, Nazi Germany and its partners murdered six million Jews in the Holocaust. The regime also persecuted and killed millions of other people.

Military defeats and advancing Allied armies eventually brought the war to Germany itself. Hitler spent his final weeks in an underground bunker in Berlin. He died by suicide there on April 30, 1945, as Soviet troops fought in the city.

Germany's **surrender** followed in May, after his death. His life had moved from frustrated ambitions and political extremism to absolute power. The consequences of his rule were destroyed democratic institutions, war, mass murder and suffering that continued long after the dictatorship collapsed.''',
[
v('nationalism', 'Strong identification with a nation and support for its interests, sometimes expressed through hostility toward others.', 'The historian examined the role of extreme nationalism in the conflict.', 'Uncountable noun'),
v('antisemitism', 'Prejudice, hostility or discrimination directed against Jewish people.', 'The museum documents the history of antisemitism.', 'Uncountable noun'),
v('propaganda', 'Information deliberately shaped to influence people’s beliefs, often in a misleading or one-sided way.', 'The regime used propaganda to control its public image.', 'Uncountable noun'),
v('opponent', 'A person or group that challenges or disagrees with another.', 'The government arrested a political opponent.', 'Noun', form='opponents', plural='opponents'),
v('chancellor', 'The head of government in Germany and some other countries.', 'The president appointed a new chancellor.', 'Noun', plural='chancellors'),
v('dictatorship', 'A political system in which a ruler or small group holds power without meaningful democratic control.', 'Independent newspapers were suppressed under the dictatorship.', 'Noun', plural='dictatorships'),
v('rearmament', 'The rebuilding or expansion of a country’s military forces and weapons.', 'The programme of rearmament increased military spending.', 'Uncountable noun'),
v('invasion', 'The entry of armed forces into another country or territory to take control.', 'The invasion caused widespread destruction.', 'Noun', plural='invasions'),
v('surrender', 'The act of accepting defeat and ending resistance.', 'The surrender brought the fighting to an end.', 'Noun', plural='surrenders')
],
[
m('How did Hitler enter the office of chancellor?', ['He inherited it from his father.', 'Hindenburg appointed him after political deals helped bring him into government.', 'He first became chancellor after Germany surrendered in 1945.'], 'B', 'President Paul von Hindenburg appointed him chancellor on January 30, 1933.', 'The account distinguishes appointment to office from the dictatorship he then constructed.'),
m('What happened after he became chancellor?', ['He strengthened open competition between all political parties.', 'He withdrew permanently from politics.', 'He dismantled democratic institutions and built a dictatorship.'], 'C', 'Hitler then dismantled democratic government.', 'Restrictions, arrests and the elimination of competing parties accompanied the concentration of power.'),
m('What was the sequence at the end of his life?', ['He died in Berlin before Germany’s surrender in May.', 'He died only after returning from exile following the surrender.', 'He led Germany throughout the postwar trials.'], 'A', "Germany's surrender followed in May, after his death.", 'His April 30 death preceded Germany’s surrender and the postwar period.'),
g('Hitler was born in ___.', '1889', 'Adolf Hitler was born on April 20, 1889, in Braunau am Inn, in what is now Austria.', '1889 was the year of his birth.'),
g('He was appointed chancellor in January ___.', '1933', 'President Paul von Hindenburg appointed him chancellor on January 30, 1933.', '1933 marks his appointment to head the government.'),
g('He died in ___ on April 30, 1945.', 'Berlin', 'Hitler spent his final weeks in an underground bunker in Berlin.', 'The following sentence places his death in that bunker on April 30.')
],
[
'United States Holocaust Memorial Museum, Early Years 1889–1921 — Childhood, Vienna, rejected applications, Munich, military service and uncertain development of ideology: https://encyclopedia.ushmm.org/content/en/article/adolf-hitler-early-years-1889-1921',
'USHMM, Adolf Hitler — Party leadership, failed coup, imprisonment and ideology: https://encyclopedia.ushmm.org/content/en/article/adolf-hitler',
'USHMM, Nazi Rise to Power 1918–1933 — Depression, propaganda, violence, conservative bargains and appointment: https://encyclopedia.ushmm.org/content/en/article/the-nazi-rise-to-power',
'Deutsches Historisches Museum, LeMO biography — Rearmament, expansion, invasion, war and Berlin death: https://www.dhm.de/lemo/biografie/adolf-hitler',
'USHMM, Introduction to the Holocaust — Genocide responsibility, six million Jewish victims and other Nazi victims: https://encyclopedia.ushmm.org/content/en/article/introduction-to-the-holocaust',
'Imperial War Museums, VE Day — Death before Germany’s May surrender: https://www.iwm.org.uk/history/second-world-war/victory/what-you-need-to-know-about-ve-day'
],
[
'The user explicitly requested a life-and-death biography. Its central identity is Hitler’s 1889–1945 life, with early ambitions, war service, party development, failed coup, appointment, dictatorship, war and death.',
'Manually compared with 023: that lesson explains the Holocaust’s persecution, institutions, victims, resistance, liberation and aftermath. This biography acknowledges responsibility in two sentences without repeating that narrative.',
'Appointment by Hindenburg, electoral support and conservative political bargains are distinguished; no claim that Germans directly elected Hitler dictator.',
'Art-academy rejection is not presented as the cause of antisemitism or later crimes. The exact 1919 party-joining month is omitted because summaries differ.',
'Death is stated historically without suicide method, graphic details, glorification, conspiracy or escape claims. No extremist quotations or persuasive ideological content.',
'Compared with all 001–051 and the remaining candidates; biography identity and aliases recorded in content/topics.json.'
])

draft(53, 'theranos-blood-testing-scandal', 'Theranos: A Medical Promise and a Fraud Scandal', 'Science and Accountability',
      'A company promising easier blood testing attracted investment and patients, then collapsed as investigations exposed unreliable technology and misleading claims.',
'''Elizabeth Holmes founded Theranos in 2003, promising to make blood testing easier and cheaper. The American **startup** said its technology could perform many tests using a very small sample from a finger. The idea attracted investors, business partners and patients hoping for convenient medical care.

Blood tests help doctors assess health and make treatment decisions. A new **diagnostic** system therefore needed strong evidence that its results were accurate and **reliable**. Public excitement and impressive business connections could not establish whether the equipment actually worked as claimed.

Inside Theranos, staff encountered serious technical problems. Its own analyzer could perform relatively few tests and struggled with accuracy. The company relied heavily on conventional machines made by other manufacturers, while presenting a much broader picture of its own capabilities.

Some employees raised concerns. **Whistleblowers**, including Erika Cheung, helped bring problems to outside attention. Journalist John Carreyrou investigated, and his reporting in 2015 brought wider **scrutiny**. Regulators examined the laboratory and its testing practices as the company's public claims came under challenge.

The consequences extended beyond lost investment. FDA investigators documented cases in which misleading results caused patients fear and affected decisions about their medical care. The promise of convenient testing had placed trust in a system whose performance needed much stronger proof.

In 2018, the Securities and Exchange Commission brought civil fraud charges. Federal criminal charges followed. Prosecutors argued that Holmes had knowingly **misled** investors about the technology and business. The company collapsed, and its claims became the subject of lengthy court proceedings.

In January 2022, a jury found Holmes guilty on four counts connected with **investor** fraud. It acquitted her on the patient-related counts submitted to it. The mixed **verdict** distinguished particular criminal charges from the wider problems documented in the business.

In November 2022, she received a sentence of 135 months in prison. The scandal exposed the gap between publicity and scientific **validation**, and the importance of listening to staff concerns, checking evidence independently and protecting the people who rely on medical tests.''',
[
v('startup', 'A recently established business, often developing a new product or service.', 'The startup sought funding for its research.', 'Noun', plural='startups'),
v('diagnostic', 'Used to identify or assess a disease or medical condition.', 'The laboratory evaluated a new diagnostic test.', 'Adjective'),
v('reliable', 'Consistently accurate or dependable.', 'The researchers needed reliable measurements.', 'Adjective'),
v('whistleblower', 'A person who reports wrongdoing inside an organization.', 'The whistleblower reported safety concerns to regulators.', 'Noun', form='Whistleblowers', plural='whistleblowers'),
v('scrutiny', 'Careful and detailed examination.', 'The company’s claims came under public scrutiny.', 'Uncountable noun'),
v('mislead', 'To cause someone to believe something incorrect or untrue.', 'The advertisement could mislead customers about the product.', 'Verb', form='misled', verb=('mislead','misled','misled',True)),
v('investor', 'A person or organization that provides money in the hope of receiving a financial return.', 'The investor asked for independent evidence before funding the project.', 'Noun', plural='investors'),
v('verdict', 'A formal decision by a jury or judge about a case.', 'The jury delivered its verdict after reviewing the evidence.', 'Noun', plural='verdicts'),
v('validation', 'The process of checking that something is accurate, suitable or works as intended.', 'Independent validation was needed before the technology could be trusted.', 'Uncountable noun')
],
[
m('What was the central problem with the company’s claims?', ['Its technology did everything it claimed, with independent proof.', 'The technology’s performance fell short of the broad claims made about it.', 'It had never offered any kind of blood testing.'], 'B', 'Its own analyzer could perform relatively few tests and struggled with accuracy.', 'The company’s reliance on conventional equipment further exposed the gap between its claims and capabilities.'),
m('How did the problems reach wider public attention?', ['Whistleblowers, investigative reporting and regulatory scrutiny helped expose them.', 'Every employee and regulator remained permanently silent.', 'The technology was never examined outside the company.'], 'A', 'Journalist John Carreyrou investigated, and his reporting in 2015 brought wider scrutiny.', 'Employee concerns and reporting were followed by broader examination of the laboratory and its claims.'),
m('What did Holmes’s January 2022 verdict establish?', ['She was convicted on every investor and patient count.', 'No fraud connected with investors had occurred.', 'She was convicted on four investor-related counts and acquitted on the patient counts submitted to the jury.'], 'C', 'In January 2022, a jury found Holmes guilty on four counts connected with investor fraud.', 'The next sentence explains the acquittals on patient-related counts, preserving the distinction between the charges.'),
g('Holmes founded Theranos in ___.', '2003', 'Elizabeth Holmes founded Theranos in 2003, promising to make blood testing easier and cheaper.', '2003 was the year the company was founded.'),
g('Carreyrou’s reporting brought wider scrutiny in ___.', '2015', 'Journalist John Carreyrou investigated, and his reporting in 2015 brought wider scrutiny.', '2015 marks the reporting milestone described in the account.'),
g('The original prison sentence was ___ months.', '135', 'In November 2022, she received a sentence of 135 months in prison.', '135 months is the original sentence imposed in November 2022.')
],
[
'U.S. Department of Justice, January 2022 verdict — Technology limitations, reliance on conventional analyzers, evidence and specific verdicts: https://www.justice.gov/usao-ndca/pr/theranos-founder-elizabeth-holmes-found-guilty-investor-fraud',
'U.S. Food and Drug Administration, original investigation account — Patient consequences and misleading results: https://www.fda.gov/about-fda/regulatory-news-stories-and-features/patient-advocacy-lies-heart-fda-agents-theranos-case',
'Berkeley California Magazine, original interview with Erika Cheung — Employee concerns, whistleblowing and 2015 reporting: https://alumni.berkeley.edu/california-magazine/online/whistleblower-erika-cheung-on-working-at-theranos/',
'U.S. Securities and Exchange Commission, March 2018 — Civil fraud charges and company claims: https://www.sec.gov/newsroom/press-releases/2018-41',
'U.S. Department of Justice, June 2018 — Federal criminal charges: https://www.justice.gov/usao-ndca/pr/theranos-founder-and-former-chief-operating-officer-charged-alleged-wire-fraud-schemes',
'U.S. Department of Justice, November 18, 2022 — Original sentence 135 months: https://www.justice.gov/usao-ndca/pr/elizabeth-holmes-sentenced-more-11-years-defrauding-theranos-investors-hundreds'
],
[
'Full company-scandal overview covers the promise, need for testing evidence, performance gap, employee warnings, journalism, patient impact, regulation, civil and criminal action, verdict and significance.',
'The story does not imply all Theranos results were wrong or that the technology could perform no tests. Medical consequences are attributed to FDA investigation findings.',
'Holmes’s investor-fraud convictions and patient-count acquittals are explicitly distinguished.135 months is the original 2022 sentence, not a claim about present remaining time or every later appeal.',
'No investment recommendations, diagnostic advice or fraud instructions. Independent validation is an editorial inference from the documented gap between claims and performance.',
'Compared with all 001–052 and the remaining candidates. Theranos is distinct from the global financial crisis, medical discoveries and other fraud cases; identity registered in content/topics.json.'
])

draft(54, 'kursk-submarine-disaster-2000', 'Kursk 2000: A Submarine Disaster and a Failed Rescue', 'Disasters and Safety',
      'Explosions sank a Russian submarine during an exercise, prompting unsuccessful rescue attempts, international assistance and lasting questions about the response.',
'''On August 12, 2000, the Russian **submarine** Kursk was taking part in a **naval** exercise in the Barents Sea. It was a large, nuclear-powered vessel carrying 118 people. What began as a military exercise became a disaster followed by days of uncertainty for their families.

Seismic instruments recorded two explosions roughly two minutes apart. The second was much stronger. The blasts devastated the forward part of the submarine, which settled on the seabed. Communication with the crew was lost, and the navy began trying to locate the vessel and reach those inside.

The Russian investigation later concluded that leaking fuel in a **torpedo** had caused the first explosion. This was followed by explosions involving other weapons. The finding described an accident within the submarine; competing early claims about a collision were not established as the cause.

Some crew members initially survived. A note recovered later recorded that 23 men had gathered in a rear **compartment** after the explosions. It provided evidence of survival for a time, while leaving uncertainty about exactly how long they remained alive.

Russian rescue attempts failed to establish a connection with the submarine. British and Norwegian assistance eventually joined the operation after several days. On August 21, divers opened the rear rescue **hatch** and found the compartment flooded. No one was rescued alive.

All 118 people aboard died. Families faced delayed and confusing information, while the disaster drew criticism of official **secrecy**, emergency readiness and the handling of foreign offers of help. Questions about the response became part of the demand for **accountability**.

In October 2001, an international **salvage** operation raised most of the **wreck**. The badly damaged bow had been separated before the lift. Recovering the vessel helped bring back remains and allowed further examination of the disaster.

Kursk became a major peacetime naval tragedy. Its history brought together equipment failure, the crew's struggle to survive, unsuccessful rescue work and difficult decisions about outside assistance. It also showed why emergency preparation and clear communication matter long before a crisis begins.''',
[
v('submarine', 'A vessel designed to travel and operate underwater.', 'The submarine returned to port after its patrol.', 'Noun', plural='submarines'),
v('naval', 'Related to a country’s navy or military operations at sea.', 'The countries held a joint naval exercise.', 'Adjective'),
v('torpedo', 'A weapon that travels underwater toward a target.', 'The inquiry examined damage in the torpedo compartment.', 'Noun', plural='torpedoes'),
v('compartment', 'A separate enclosed section within a larger space or structure.', 'The crew gathered in a rear compartment.', 'Noun', plural='compartments'),
v('hatch', 'An opening with a cover that provides access through a ship’s deck or another enclosed structure.', 'The divers examined the rescue hatch.', 'Noun', plural='hatches'),
v('secrecy', 'The practice of keeping information hidden or restricted.', 'The families criticized the secrecy surrounding the operation.', 'Uncountable noun'),
v('accountability', 'The responsibility to explain actions and face consequences for them.', 'The investigation formed part of a wider demand for accountability.', 'Uncountable noun'),
v('salvage', 'The recovery of a damaged or sunken vessel, cargo or other valuable material.', 'The salvage operation required specialist equipment.', 'Uncountable noun'),
v('wreck', 'The damaged remains of a ship, aircraft or vehicle.', 'The survey located the wreck on the seabed.', 'Noun', plural='wrecks')
],
[
m('What did the later Russian investigation conclude?', ['A torpedo fuel leak caused an initial explosion, followed by further weapons explosions.', 'A collision with a foreign submarine was conclusively proved.', 'No explosion had occurred.'], 'A', 'The Russian investigation later concluded that leaking fuel in a torpedo had caused the first explosion.', 'The account attributes this conclusion to the inquiry rather than presenting early collision claims as established fact.'),
m('What did the recovered note establish?', ['All 118 people survived for several weeks.', 'No one had survived the initial disaster even briefly.', 'Some men gathered in a rear compartment and survived for a time.'], 'C', 'A note recovered later recorded that 23 men had gathered in a rear compartment after the explosions.', 'The note supports initial survival, while the exact duration remains uncertain.'),
m('What was recovered in 2001?', ['An undamaged submarine ready to resume service.', 'Most of the wreck after the damaged bow had been separated.', 'Only a small personal notebook and nothing from the vessel.'], 'B', 'In October 2001, an international salvage operation raised most of the wreck.', 'The following sentence explains why the raised wreck did not include the badly damaged bow.'),
g('The disaster occurred in the Barents ___.', 'Sea', 'On August 12, 2000, the Russian submarine Kursk was taking part in a naval exercise in the Barents Sea.', 'The Barents Sea was the location of the exercise and sinking.'),
g('There were ___ people aboard.', '118', 'It was a large, nuclear-powered vessel carrying 118 people.', '118 people were aboard, and all died.'),
g('Divers opened the rear rescue hatch on August ___.', '21', 'On August 21, divers opened the rear rescue hatch and found the compartment flooded.', 'August 21 was the date of the described inspection of the rear compartment.')
],
[
'Norwegian Radiation Protection Authority, The Kursk Accident, 2001 — Firsthand expedition report, chronology,118 aboard, rescue findings and recovered note: https://dsa.no/en/publications/stralevernrapport-the-kursk-accident/straalevernrapport-2001-5-the-kursk-accident.pdf',
'NORSAR contemporary scientific report, printed pages 77–78 — Two recorded explosions and relative strength: https://www.norsar.no/getfile.php/1318059-1681727821/norsar.no/R-D/Publications/4862_Ringdal_etal2000.pdf',
'Associated Press contemporary reporting reproduced by Wired, 2002 — Official investigation’s torpedo-fuel finding: https://www.wired.com/2002/07/why-kursk-died/',
'RFE/RL contemporary account of the final inquiry — Official cause and public questions about the response: https://www.rferl.org/a/1100672.html',
'Mammoet firsthand project account — October 8, 2001 lift, separated bow and international recovery: https://www.mammoet.com/cases/kursk/'
],
[
'Overview covers exercise and vessel, explosions and attributed official cause, temporary survival, rescue attempts, foreign assistance, deaths, communication and accountability, salvage and wider significance.',
'The 23-man note establishes survival after the explosions without inventing an exact survival duration or claiming earlier foreign assistance certainly would have saved them.',
'No weapon construction details or fuel chemistry. A foreign-submarine collision is not presented as an established cause.',
'Most of the wreck is precise because the damaged bow was separated before the 2001 lift. No unverified present-day radiation or environmental safety claim.',
'Compared with all 001–053 and the Tutankhamun candidate. A distinct naval disaster, separate from Titanic, Sewol and earlier rescue stories; identity registered in content/topics.json.'
])

draft(55, 'tutankhamun-tomb-discovery-1922', 'Tutankhamun’s Tomb: Discovery, Excavation and Preservation', 'Discoveries and Inventions',
      'A team’s discovery of a largely preserved royal tomb opened an extraordinary record of ancient Egyptian life and began years of careful archaeological work.',
'''Tutankhamun became a **pharaoh** of ancient Egypt while still young and ruled for about nine years. More than three thousand years later, his burial place lay beneath accumulated debris in the Valley of the Kings. Many other royal tombs had long since been robbed.

British archaeologist Howard Carter had spent years searching the valley with Egyptian workers. His financial **patron**, Lord Carnarvon, funded the work. On November 4, 1922, the team uncovered steps leading down toward a blocked entrance. Egyptian labour and knowledge were central to the discovery.

The team cleared the approach and examined the sealed doorways. On November 26, Carter looked into the **antechamber**, the first large room beyond the passage. It contained remarkable objects, including furniture and chariots, crowded together in a space hidden for centuries.

The tomb was relatively intact, although ancient robbers had entered parts of it. That unusual degree of survival made the find especially valuable. Objects normally scattered or lost from other tombs remained together, offering evidence of royal burial practices and skilled **craftsmanship**.

Finding the entrance began a long **excavation**. The team recorded, photographed and carefully removed objects. Photographer Harry Burton created a detailed visual record, while specialists worked to stabilize materials that could be damaged by handling or changes in their surroundings.

The **burial chamber** was formally opened in February 1923. Work on its shrines, coffins and the king's remains continued in later seasons. The famous gold mask was part of a much larger collection of **artifacts**, including clothing, jewellery and everyday objects prepared for burial.

Many materials were **fragile**, making **conservation** as important as discovery. Years of work were needed to study and preserve the contents. The main collection remained in Egypt, where it became central to the country's archaeological heritage.

The discovery attracted worldwide attention and expanded knowledge of ancient Egyptian life, belief and royal burial. Its lasting value came from the surviving objects and the records surrounding them, built through the work of excavators, Egyptian teams, photographers and conservators.''',
[
v('pharaoh', 'A ruler of ancient Egypt.', 'The inscription named the pharaoh who ordered the building.', 'Noun', plural='pharaohs'),
v('patron', 'A person who provides money or support for a project, artist or organization.', 'A wealthy patron helped fund the expedition.', 'Noun', plural='patrons'),
v('antechamber', 'An outer room that leads to a larger or more important room.', 'The team recorded the objects in the antechamber.', 'Noun', plural='antechambers'),
v('craftsmanship', 'The skill involved in making objects carefully and well.', 'The wooden chest displayed remarkable craftsmanship.', 'Uncountable noun'),
v('excavation', 'The careful digging and investigation of a site, especially to uncover remains of the past.', 'The excavation revealed the foundations of an ancient building.', 'Noun', plural='excavations'),
v('burial chamber', 'A room in a tomb containing the remains of a person who has died.', 'The burial chamber lay behind a sealed doorway.', 'Noun phrase', plural='burial chambers'),
v('artifact', 'An object made or used by people that provides evidence about the past.', 'Each artifact was photographed before removal.', 'Noun', form='artifacts', plural='artifacts'),
v('fragile', 'Easily broken or damaged.', 'The fragile fabric needed careful handling.', 'Adjective'),
v('conservation', 'The protection and preservation of objects, buildings or natural environments.', 'The museum carried out conservation work on the painting.', 'Uncountable noun')
],
[
m('Why was the discovery especially valuable?', ['The tomb contained no objects connected with ancient life.', 'Every other royal tomb had exactly the same complete contents.', 'Many objects survived together in a relatively intact royal tomb.'], 'C', 'Objects normally scattered or lost from other tombs remained together, offering evidence of royal burial practices and skilled craftsmanship.', 'The survival of related objects together made the archaeological record unusually rich.'),
m('What followed the discovery of the entrance?', ['Years of recording, photography, removal and conservation.', 'The immediate removal of everything without any records.', 'A decision never to investigate the tomb’s interior.'], 'A', 'The team recorded, photographed and carefully removed objects.', 'The account describes a lengthy archaeological process rather than a single day of discovery.'),
m('Who contributed to the work?', ['Carter worked entirely alone without any funding or assistance.', 'Egyptian teams, excavators, photographers, specialists and a financial patron all contributed.', 'Only modern tourists took part in the excavation.'], 'B', 'Its lasting value came from the surviving objects and the records surrounding them, built through the work of excavators, Egyptian teams, photographers and conservators.', 'The narrative also identifies Carnarvon’s financial support and the Egyptian workers’ central role.'),
g('The team found the steps on November 4, ___.', '1922', 'On November 4, 1922, the team uncovered steps leading down toward a blocked entrance.', '1922 was the year of the discovery.'),
g('Carter first looked into the antechamber on November ___.', '26', 'On November 26, Carter looked into the antechamber, the first large room beyond the passage.', 'November 26 distinguishes the first view of that room from the earlier entrance discovery.'),
g('The burial chamber was formally opened in ___ 1923.', 'February', 'The burial chamber was formally opened in February 1923.', 'February 1923 marks a later stage of the excavation.')
],
[
'Egyptian Ministry of Tourism and Antiquities — Reign, Valley of the Kings, tombKV 62 and relative preservation: https://egymonuments.gov.eg/monuments/tomb-of-tutankhamun/',
'Metropolitan Museum, centenary account — November 4 discovery, Egyptian team, objects and recording work: https://www.metmuseum.org/pt/hubs/tutankhamun-100',
'Griffith Institute, Carter’s original journal and diary — November 4 entrance and November 26 antechamber chronology: https://www.griffith.ox.ac.uk/gri/4sea1not.html',
'Bodleian Libraries, primary letter and diary transcripts — Carnarvon’s November 28 letter, team and February 16, 1923 burial-chamber opening: https://visit.bodleian.ox.ac.uk/tutankhamun-audio',
'Metropolitan Museum, photographic exhibition — Harry Burton’s record, objects and conservation; older first-look date corrected against the diary: https://www.metmuseum.org/exhibitions/listings/2006/discovering-tutankhamun',
'Metropolitan Museum and Egyptian government joint 2010 announcement — Egyptian ownership and return of small objects, qualifying absolute retention claims: https://www.metmuseum.org/press-releases/metropolitan-museum-and-egyptian-government-announce-initiative-to-recognize-egypts-title-to-19-objects-originally-from-tutankhamuns-tomb-2010-news'
],
[
'Overview covers the king and tomb, years of searching, team and funding, entrance discovery, antechamber, relative preservation, archaeological process, later burial-chamber work, conservation and significance.',
'November 4, 1922 entrance discovery, November 26 first antechamber view and February 1923 burial-chamber opening are distinct stages. Older Met text’s November 24 first-look date is not repeated.',
'Relatively intact avoids the false claim that the tomb was untouched. No curse narrative or invented dialogue is included.',
'Egyptian workers receive explicit credit alongside Carter, Carnarvon, Burton and conservators. The main collection remained in Egypt does not falsely claim that no small object ever left the country.',
'Compared with all 001–054. This 1922 tomb discovery is distinct from the Rosetta Stone and decipherment lesson 016; identity and aliases registered in content/topics.json.'
])
