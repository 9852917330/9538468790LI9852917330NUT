import runpy
from pathlib import Path
globals().update(runpy.run_path(str(Path(__file__).with_name('overview-revision.py'))))

draft(6,'Lake Nyos: The Disaster Beneath the Water','The hidden buildup, sudden gas release, human losses, scientific investigation and prevention work at Lake Nyos.',
'''Lake Nyos lies in a volcanic region of northwestern Cameroon. Before 1986, nearby communities farmed the land and raised animals around a landscape that appeared peaceful. A dangerous process, however, was taking place deep beneath the lake's surface.

Carbon dioxide from underground volcanic activity had slowly entered the water. The deep layers rarely mixed with water above them, so the gas **built up**. High water pressure kept it dissolved, allowing a large store to collect without an obvious warning at the surface.

On the evening of August 21, 1986, gas-rich water rose. As pressure decreased, bubbles formed and carried more water upward. This **chain reaction** caused a huge gas **release**. Scientists still cannot identify the initial **trigger** with certainty.

Carbon dioxide is heavier than air. The cloud moved downhill into surrounding **valleys**, collecting **at ground level** and displacing breathable air. At high concentrations, the gas also directly harmed the body. People and animals could lose consciousness before they had time to escape.

More than 1,700 people died, along with thousands of animals. Many buildings remained standing, but whole communities had lost relatives, neighbors and livelihoods. **Survivors** needed help, and many residents had to leave dangerous areas.

Scientists investigated the lake, examined the water and reconstructed the event. The catastrophe came from stored gas escaping from the lake, rather than a fresh eruption of lava. Understanding that distinction was essential to reducing the danger.

In 2001, a permanent pipe began bringing deep water to the surface. Gas bubbles helped the water flow upward, releasing carbon dioxide **gradually** instead of allowing it to accumulate. More pipes were added in 2011.

The gas source had not disappeared. Continued removal, equipment maintenance and efforts to **monitor** the lake remained important. Nyos changed how scientists understood gas-rich lakes and showed why disaster prevention must include hidden hazards as well as visible ones.''',[
mcq('Why could gas accumulate deep in the lake?',['Winds constantly pushed air down to the bottom.','Limited mixing and high pressure kept gas dissolved.','New lava had sealed the lake’s surface.'],'B','High water pressure kept it dissolved, allowing a large store to collect without an obvious warning at the surface.','Gas accumulated gradually without a clear surface warning.'),
mcq('Why were low-lying communities especially vulnerable?',['Dense gas flowed downhill and displaced breathable air.','The gas immediately floated above the valleys.','Every building in the valleys fell down.'],'A','The cloud moved downhill into surrounding valleys, collecting at ground level and displacing breathable air.','The gas cloud collected near the ground in low places.'),
mcq('What did prevention require after the disaster?',['Complete removal of the underground volcanic region.','Waiting until another release occurred.','Controlled gas removal and continued monitoring.'],'C','Continued removal, equipment maintenance and efforts to monitor the lake remained important.','Pipes reduced accumulated gas, but continued recharge required ongoing management.'),
gap('The gas came from underground volcanic ___.','activity','Carbon dioxide from underground volcanic activity had slowly entered the water.','The source was underground volcanic gas.'),
gap('Thousands of ___ died along with more than 1,700 people.','animals','More than 1,700 people died, along with thousands of animals.','The cloud devastated people and livestock.'),
gap('A permanent ___ began carrying deep water upward in 2001.','pipe','In 2001, a permanent pipe began bringing deep water to the surface.','The pipe allowed controlled degassing.')
],['https://science.nasa.gov/earth/earth-observatory/lake-nyos-cameroon-86244/','https://www.usgs.gov/publications/evolution-co2-lakes-monoun-and-nyos-cameroon-and-during-controlled-degassing','https://www.usgs.gov/publications/degassing-lakes-nyos-and-monoun-defusing-certain-disaster'],['Setting, gas buildup, release, casualties, displacement, investigation and ongoing prevention. Initial trigger uncertain; no guarantee of permanent safety.'],extras=[v('release','An event in which a substance escapes or is allowed out.','A damaged pipe caused a release of gas.','Noun',plural='releases'),v('survivor','A person who remains alive after a dangerous event.','A survivor described how the family escaped.','Noun','Survivors',plural='survivors')])

draft(7,'Pearl Harbor: The Attack and Its Consequences','Japanese expansion, the surprise attack, its damage and American entry into World War II.',
'''By late 1941, World War II was spreading across Europe and Asia. Japan was fighting in China and seeking control of more territory and resources in Southeast Asia. The United States opposed this expansion and imposed economic restrictions, including limits on oil supplies that Japan depended on.

Japanese leaders chose a wider war. They planned to strike American forces while taking resource-rich territories farther south. Damaging the United States Pacific Fleet could **buy time** for those operations and reduce interference with their advance.

On the morning of December 7, aircraft from 6 Japanese **aircraft carriers** attacked Pearl Harbor in Hawaii and nearby military airfields. They arrived in 2 waves, dropping bombs and torpedoes on ships while attacking aircraft on the ground. Many American forces were **caught off guard**.

The attack killed 2,403 Americans, including service members and civilians. **Battleships** were sunk or badly damaged, and many aircraft were destroyed. Fires, explosions and rescue efforts filled a base that had not been prepared for an attack on that scale.

The destruction was severe, but it did not eliminate America's ability to fight. The Pacific Fleet's aircraft carriers were away from Pearl Harbor. Fuel stores and major repair facilities remained largely **intact**. Workers could **salvage** damaged vessels, and several were eventually brought **back into service**.

On December 8, the United States declared war on Japan. Germany and Italy declared war on the United States on December 11, bringing American forces fully into the wider global conflict. The attack had united much of American public opinion behind war.

Japan gained an immediate military advantage, but failed to remove the long-term threat from the United States. American industrial capacity, surviving ships and the recovery of the Pacific base supported a prolonged campaign. Pearl Harbor became both a national tragedy and a decisive **turning point** in the course of World War II.''',[
mcq('What was the strategic purpose of the attack?',['To give American ships a safe passage.','To end all fighting in Asia immediately.','To weaken the American fleet while Japan expanded south.'],'C','Damaging the United States Pacific Fleet could buy time for those operations and reduce interference with their advance.','The raid supported a broader expansion plan.'),
mcq('Why could America continue fighting despite the damage?',['Important ships and support facilities survived.','No ships or aircraft had been damaged.','The attack happened after America surrendered.'],'A',"The Pacific Fleet's aircraft carriers were away from Pearl Harbor. Fuel stores and major repair facilities remained largely intact.",'Surviving carriers and infrastructure supported recovery.'),
mcq('What was a major political consequence?',['An immediate peace treaty with Japan.','American entry into war against Japan and the wider global conflict.','The end of fighting in Europe.'],'B','On December 8, the United States declared war on Japan.','Germany and Italy then declared war on the United States.'),
gap('Economic restrictions threatened Japan’s ___ supplies.','oil','The United States opposed this expansion and imposed economic restrictions, including limits on oil supplies that Japan depended on.','Oil restrictions added pressure to the dispute over expansion.'),
gap('The attacking aircraft came in 2 ___.','waves','They arrived in 2 waves, dropping bombs and torpedoes on ships while attacking aircraft on the ground.','Two main waves attacked the base and airfields.'),
gap('Major ___ facilities helped the base recover.','repair','Fuel stores and major repair facilities remained largely intact.','Surviving repair facilities supported recovery.')
],['https://home.nps.gov/articles/pearlattackww2.htm','https://www.nps.gov/perl/learn/news/presskit.htm','https://history.state.gov/historicaldocuments/frus1941v01/d586'],['Expansion, resource dispute, objectives, attack, losses, recovery capacity, war entry and strategic outcome. Do not make missed targets or Yorktown the main narrative.'])

draft(8,'Hiroshima: The Bombing and Its Legacy','The wartime setting, atomic attack, human consequences, surrender context and reconstruction.',
'''In the summer of 1945, World War II had ended in Europe, but Japan was still fighting in the Pacific. The United States had developed atomic weapons through the secret Manhattan Project. American leaders decided to use the new weapon against Japan.

Hiroshima was an important military and transport center, but it was also a city of homes, schools, hospitals and ordinary working lives. On August 6, at 8:15 a.m., the American bomber Enola Gay dropped an atomic bomb over the city. It exploded in the air above it.

The weapon released energy through **nuclear fission**, creating intense heat, a powerful **blast** and dangerous **radiation**. Buildings were destroyed and fires spread. Many medical workers were killed or injured, and hospitals were damaged. The services still operating were **overwhelmed** by people seeking help.

Some victims died immediately; others died later from burns, injuries or radiation sickness. Hiroshima's city government estimates that about 140,000 people had died by the end of 1945. The exact total remains uncertain.

For **survivors**, the end of the explosion was not the end of the suffering. Families had lost relatives, homes and work. Some survivors faced increased cancer risks in later decades, as well as lasting emotional **scars**. They also faced discrimination and difficulties rebuilding their lives.

The wider war reached its final stage during the same week. The Soviet Union entered the war against Japan, and a second atomic bomb **struck** Nagasaki on August 9. Japan's leaders faced several military and political pressures. The emperor announced Japan's **surrender** on August 15; the formal agreement was signed on September 2.

Hiroshima was gradually rebuilt. Its Peace Memorial became a place of remembrance and a center for appeals against nuclear weapons. The bombing changed warfare and international politics, while its deepest consequences remained visible in the lives of people who had survived it.''',[
mcq('How does the story describe Hiroshima before the attack?',['A military center that was also a populated civilian city.','An empty site used only for weapons testing.','A city that had been completely evacuated.'],'A','Hiroshima was an important military and transport center, but it was also a city of homes, schools, hospitals and ordinary working lives.','Its strategic role existed alongside civilian life.'),
mcq('Why did suffering continue after August 6?',['Every hospital immediately reopened.','Some victims died later and survivors faced long-term problems.','All survivors developed identical illnesses.'],'B','Some victims died immediately; others died later from burns, injuries or radiation sickness.','Injuries, radiation, bereavement and social problems had lasting consequences.'),
mcq('What does the account say about surrender?',['Hiroshima alone explains the decision.','Soviet entry came after the formal signing.','Japanese leaders faced several pressures in the same period.'],'C',"Japan's leaders faced several military and political pressures.",'The account includes Hiroshima, Nagasaki and Soviet entry without a single-cause claim.'),
gap('The weapon exploded in the ___ above the city.','air','It exploded in the air above it.','This was an airburst.'),
gap('Many ___ were damaged when injured people needed help.','hospitals','Many medical workers were killed or injured, and hospitals were damaged.','Medical services were severely disrupted.'),
gap('The formal surrender agreement was signed in ___.','September','the formal agreement was signed on September 2.','The formal signing followed the August announcement.')
],['https://www.pref.hiroshima.lg.jp/site/hiroshimaforpeace-en/reconstruction-atomic-bombing.html','https://www.energy.gov/management/articles/manhattan-project-making-atomic-bomb','https://history.state.gov/historicaldocuments/frus1945v06/d402','https://www.rerf.or.jp/en/programs/roadmap_e/health_effects-en/late-en/cancrisk/'],['War context, attack, immediate and delayed harm, surrender context and reconstruction. 140,000 is a city estimate by end1945. No sole-cause surrender claim or universal cancer claim.'])

draft(9,'Chernobyl: How a Nuclear Disaster Unfolded','The test, combined safety failures, explosion, emergency response, contamination and lasting consequences.',
'''On April 26, 1986, a safety test at Chernobyl became the world's worst nuclear power accident. The plant stood in what is now Ukraine, then part of the Soviet Union. Workers were preparing Unit 4 for maintenance and testing whether a slowing turbine could briefly supply power to cooling pumps.

The test took place under dangerous conditions. The **reactor** had been brought to unusually low power, and many control rods were withdrawn. It became **unstable**. Design weaknesses, inadequate procedures and poor safety information left the operators facing risks they did not fully understand.

A shutdown command was given, but the control-rod design could initially increase the reaction under these conditions. A huge **power surge** followed. Explosions destroyed the reactor, and fires carried **radioactive** material into the atmosphere. This was a damaged nuclear reactor, not an atomic bomb explosion.

Firefighters and plant workers responded to the emergency, often with limited protection or information. Some received extremely high radiation doses. The nearby city of Pripyat was **evacuated** the following day. During 1986, about 116,000 people were moved from contaminated areas.

The damage spread beyond the plant. Wind carried radioactive material across parts of Europe. Ukraine, Belarus and Russia faced particularly serious **contamination**, restrictions on land use and the disruption of communities. Many residents lost their homes and familiar ways of life.

Workers built a **shelter** around the destroyed unit in 1986, beginning a long cleanup effort. Health consequences included an increase in thyroid cancer among people exposed as children or adolescents. Measuring the disaster's total long-term death toll remains difficult.

Investigations placed both technology and management **under scrutiny**. Similar reactors were modified, and international cooperation on nuclear safety increased. Chernobyl showed how dangerous equipment, unsafe operating conditions, weak training and secrecy could reinforce one another. Its consequences involved public health, trust and displacement as well as the destruction of one reactor.''',[
mcq('What combination helped produce the accident?',['A test conducted under unsafe conditions, design weaknesses and poor safety practices.','An attack by an outside military force.','A routine test in which every protective system worked correctly.'],'A','Design weaknesses, inadequate procedures and poor safety information left the operators facing risks they did not fully understand.','The accident had technological and organizational causes.'),
mcq('Why did the disaster affect areas beyond the plant?',['All surrounding cities had their own reactor explosions.','Wind carried radioactive material away from the damaged unit.','The entire reactor was transported through Europe.'],'B','Wind carried radioactive material across parts of Europe.','Atmospheric movement spread contamination beyond the site.'),
mcq('What followed the emergency response?',['All affected areas immediately returned to normal.','Investigators found that no changes were necessary.','Long cleanup, displacement, health concerns and safety reforms.'],'C','Similar reactors were modified, and international cooperation on nuclear safety increased.','The effects and response continued long after the explosion.'),
gap('The test examined whether a slowing ___ could briefly supply power.','turbine','Workers were preparing Unit 4 for maintenance and testing whether a slowing turbine could briefly supply power to cooling pumps.','The test concerned temporary power for cooling pumps.'),
gap('The nearby city of ___ was evacuated the next day.','Pripyat','The nearby city of Pripyat was evacuated the following day.','The evacuation took place on April 27.'),
gap('Workers built a ___ around the destroyed unit in 1986.','shelter','Workers built a shelter around the destroyed unit in 1986, beginning a long cleanup effort.','The shelter was an early step in containing the damaged unit.')
],['https://www-pub.iaea.org/MTCD/publications/PDF/Pub913e_web.pdf','https://www.unscear.org/unscear/en/areas-of-work/chernobyl.html','https://www2.chnpp.gov.ua/en/about/history-of-the-chnpp/accident-of-1986'],['Cover test/context, multiple causes, destruction, response, evacuation, contamination, health, cleanup and reforms. Rod physics is one short explanation, not the main plot. Avoid a fixed ultimate death toll or a one-button/one-person explanation.'],extras=[v('contamination','The presence of a harmful substance in something such as water, food or land.','Tests found contamination in the soil.','Noun',note='Usually uncountable.')])

draft(10,'Challenger: The Disaster and the Warnings','The mission, cold launch, structural failure, organizational problems and changes that followed Challenger’s loss.',
'''On January 28, 1986, the Space Shuttle Challenger launched from Florida with 7 crew members. The shuttle program was meant to make repeated journeys into space possible, carrying equipment and supporting research. This mission attracted unusual public attention because Christa McAuliffe, a teacher, was aboard to share the experience with students.

Only 73 seconds after liftoff, Challenger **broke apart**. All 7 crew members died. Television images turned a planned celebration of exploration and education into a national tragedy.

Investigators traced the failure to a joint in the right solid rocket booster. Rubber O-ring **seals** were supposed to keep extremely hot gas inside. The weather had been unusually cold, making the rubber less **flexible** and slower to respond as the joint moved under pressure.

Hot gas **leaked** through the joint. A flame later damaged the external fuel tank and a supporting connection. The shuttle could no longer hold together during flight.

The investigation also examined decisions made before launch. Earlier flights had shown damage near some O-rings. Engineers at the booster manufacturer, Morton Thiokol, had **raised concerns** about flying in the cold. The company initially recommended against launch, but managers later **reversed** that recommendation. The flight was allowed to **go ahead**.

The Rogers Commission placed NASA's decision process **under scrutiny**. Important concerns had not reached all senior officials responsible for approving the launch. Previous successful flights had encouraged confidence, even though they had also provided warning signs of a serious weakness.

Shuttle flights stopped while NASA **redesigned** the booster joints and changed safety and management practices. Flights **resumed** with Discovery in September 1988, more than 2 years after the disaster.

Challenger's loss showed that engineering and organizational safety were inseparable. Reliable hardware mattered, but so did the way evidence moved through the organization. Warnings had to influence decisions before a mission began, rather than become explanations after lives were lost.''',[
mcq('Why did this mission receive unusual public attention?',['It was the first spacecraft ever launched.','It was carrying a teacher who planned to share the experience with students.','It was landing on the Moon.'],'B','This mission attracted unusual public attention because Christa McAuliffe, a teacher, was aboard to share the experience with students.','The education connection brought the mission into many classrooms.'),
mcq('What did the investigation find beyond a failed seal?',['Important warnings had not properly shaped the launch decision.','No warning signs had appeared before the accident.','The crew had been responsible for choosing the launch temperature.'],'A','Important concerns had not reached all senior officials responsible for approving the launch.','Information and decision-making failures accompanied the hardware problem.'),
mcq('What happened before shuttle flights resumed?',['The program immediately reused the same joints without review.','All safety responsibility was removed from NASA.','The booster joints and safety practices were changed.'],'C','Shuttle flights stopped while NASA redesigned the booster joints and changed safety and management practices.','Both technical and organizational changes were made.'),
gap('Challenger launched from ___.','Florida','On January 28, 1986, the Space Shuttle Challenger launched from Florida with 7 crew members.','The mission began at the Florida launch site.'),
gap('Rubber O-ring ___ were meant to keep hot gas inside the booster.','seals','Rubber O-ring seals were supposed to keep extremely hot gas inside.','Cold conditions impaired the sealing system.'),
gap('Flights resumed with ___ in September 1988.','Discovery','Flights resumed with Discovery in September 1988, more than 2 years after the disaster.','Discovery carried the return-to-flight mission.')
],['https://sma.nasa.gov/sma-disciplines/accllp/challenger','https://www.nasa.gov/history/rogersrep/v1ch5.htm'],['Mission/crew/public context, sequence, hardware failure, decision failures, investigation, suspension, redesign and return to flight. Say broke apart; do not assert all crew died instantly.'])
