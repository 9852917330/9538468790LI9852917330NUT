"""Source-reviewed, balanced original lessons for English Unicorn 021–025."""
from importlib.machinery import SourceFileLoader
from pathlib import Path
helpers = SourceFileLoader('lesson_batch', str(Path(__file__).with_name('lesson-batch.py'))).load_module()
v, m, g, draft = helpers.vocab, helpers.mcq, helpers.gap, helpers.write_draft

draft(21, 'tiananmen-1989', 'Tiananmen 1989: Protest, Crackdown and Its Aftermath', 'History',
      'A broad protest movement, divided leadership and a deadly military response shaped a turning point in modern China.',
'''In the spring of 1989, China was changing rapidly. Economic reforms had created opportunities, but rising prices and official **corruption** caused frustration. Many people wanted a greater voice in public life and more **accountability** from their leaders.

On April 15, former Communist Party leader Hu Yaobang died. He had been associated with political reform. Public **mourning** brought students to Tiananmen Square in central Beijing, and their gatherings developed into demonstrations. Participants called for changes including cleaner government and greater freedom of expression.

The movement grew beyond university students. Workers and ordinary residents joined, while demonstrations spread to other Chinese cities. The participants did not all share the same goals, but dissatisfaction brought different groups together.

In May, student **hunger strikes** increased pressure on the government. Crowds gathered in Beijing, and the protests attracted international attention. Chinese leaders disagreed over how to respond. Some favored discussion; others believed force was necessary to restore control.

The government imposed **martial law** in Beijing on May 20. Residents initially blocked troops from advancing. During the night of June 3 and into June 4, army units moved through the city with tanks and **live ammunition**. Soldiers killed civilians as they advanced, with much of the bloodshed occurring on streets around the square.

By June 4, the army controlled Tiananmen Square. The exact death toll remains uncertain. Conflicting reports and restricted access to information have made a complete account difficult.

The **crackdown** was followed by arrests and efforts to silence discussion. Some activists fled the country. Foreign governments condemned the violence, and China's relations with other countries suffered.

The events left deep grief among families and a lasting dispute over public memory. **Censorship** limited open discussion within China. The demonstrations and their suppression became a major turning point, showing the gap between hopes for political change and the leadership's determination to maintain its power.''',
[
v('corruption', 'Dishonest use of public power or a trusted position for personal benefit.', 'The investigation uncovered corruption in local government.', 'Uncountable noun'),
v('accountability', 'Responsibility for decisions and the obligation to explain them.', 'Public spending requires clear accountability.', 'Uncountable noun'),
v('mourning', 'Sadness and the expression of grief after someone has died.', 'The community gathered in mourning after the accident.', 'Uncountable noun'),
v('hunger strike', 'A refusal to eat as a form of protest.', 'The prisoners began a hunger strike over their treatment.', 'Noun phrase', form='hunger strikes', plural='hunger strikes'),
v('martial law', 'Temporary military control that replaces some ordinary civilian rules.', 'The government imposed martial law during the crisis.', 'Uncountable noun phrase'),
v('live ammunition', 'Bullets or other ammunition capable of causing injury or death, rather than blanks.', 'The report examined the use of live ammunition.', 'Uncountable noun phrase'),
v('crackdown', 'Strong official action intended to stop an activity or suppress opposition.', 'The crackdown led to many arrests.', 'Noun', plural='crackdowns'),
v('censorship', 'The control or removal of information that authorities do not allow people to publish or see.', 'Censorship limited discussion of the incident.', 'Uncountable noun')
],
[
m('Who took part in the wider movement?', ['Only students from a single university.', 'Students, workers and other residents, with differing goals.', 'Only foreign visitors passing through Beijing.'], 'B', 'The movement grew beyond university students. Workers and ordinary residents joined, while demonstrations spread to other Chinese cities.', 'The demonstrations expanded beyond the original student gatherings.'),
m('What happened before the army took control of the square?', ['All leaders agreed immediately to accept the protesters\' demands.', 'The protests ended as soon as mourning began.', 'Leadership divisions, martial law and resistance to advancing troops preceded the deadly operation.'], 'C', 'The government imposed martial law in Beijing on May 20. Residents initially blocked troops from advancing.', 'The military response followed weeks of protest and disagreement over how to respond.'),
m('What followed the crackdown?', ['Arrests, restricted discussion and damage to international relations.', 'An immediate complete public investigation with an agreed death toll.', 'The end of all restrictions on political expression.'], 'A', 'The crackdown was followed by arrests and efforts to silence discussion. Some activists fled the country. Foreign governments condemned the violence, and China\'s relations with other countries suffered.', 'The consequences included repression at home and criticism abroad.'),
g('Hu Yaobang\'s death prompted public ___.', 'mourning', 'Public mourning brought students to Tiananmen Square in central Beijing, and their gatherings developed into demonstrations.', 'Mourning was an early reason for gathering.'),
g('The government imposed ___ law on May 20.', 'martial', 'The government imposed martial law in Beijing on May 20.', 'Martial completes the phrase describing military control.'),
g('The exact death ___ remains uncertain.', 'toll', 'The exact death toll remains uncertain.', 'Death toll means the number of people who died.')
],
[
'US Department of State, Office of the Historian — Broad chronology, leadership divisions and international consequences: https://history.state.gov/milestones/1989-1992/tiananmen-square',
'National Security Archive — Declassified contemporary diplomatic records, including street deaths and subsequent arrests: https://nsarchive2.gwu.edu/NSAEBB/NSAEBB16/index.html',
'Indiana University — Eyewitness photograph archive and broader participation: https://library.indianapolis.iu.edu/digitalcollections/TS'
],
[
'Overview balances economic and political context, Hu Yaobang\'s death, diverse participation, hunger strikes, leadership divisions, martial law, military violence, arrests and consequences.',
'No exact death toll is asserted. Much of the killing occurred on streets around the square; the text does not claim all deaths happened inside it or that none did.',
'Tank Man is not used as the center of an event-wide lesson. Protesters are not assigned one identical political program.',
'Government actions and civilian deaths are described plainly. A balanced overview does not imply equal responsibility for lethal force.'
])

draft(22, 'covid-19-pandemic', 'COVID-19: The Pandemic and Its Global Impact', 'World Events',
      'A new virus spread worldwide, prompting major health responses and lasting changes to work, education and daily life.',
'''In late December 2019, reports of unusual pneumonia cases in Wuhan, China, reached the World Health Organization. A new coronavirus was identified. It caused the disease later named COVID-19, and the virus became known as SARS-CoV-2.

The **outbreak** spread across borders as infected people traveled and passed the virus to others. Infectious **respiratory particles** could move through the air, especially where people shared indoor spaces. People could **transmit** the virus before developing **symptoms**, making it harder to detect and contain.

On January 30, 2020, the World Health Organization declared an international public health emergency. On March 11, it described COVID-19 as a pandemic. By then, the danger extended far beyond the place where the first cluster had been reported.

Governments introduced different combinations of testing, isolation, masks and movement **restrictions**. Schools closed in many places, some jobs moved online, and travel fell sharply. Hospitals faced intense pressure as large numbers of patients needed care. Health workers also faced risks to their own lives.

Scientists shared information and developed tests, treatments and **vaccines**. Vaccination programs expanded from late 2020 and helped protect people against severe illness and death. New **variants** complicated the response, and protection did not mean that every infection could be prevented.

Access to health care and vaccines was unequal. Some communities could work from home or obtain medical support more easily than others. Millions of people died, families lost income, and disrupted education affected children worldwide. Some survivors experienced continuing health problems known as **long COVID**.

On May 5, 2023, the World Health Organization ended the international emergency designation. The virus continued circulating, and its health effects still required attention.

The pandemic showed how closely health, science, government and everyday life are connected. It also exposed weaknesses in global **preparedness**, including unequal resources and difficulties sharing reliable information. Its consequences continued after the most urgent phase of the emergency had passed.''',
[
v('outbreak', 'A sudden increase in cases of a disease in a particular place.', 'Health officials investigated an outbreak in the town.', 'Noun', plural='outbreaks'),
v('respiratory particle', 'A tiny particle released into the air during activities such as breathing, talking or coughing.', 'An infectious respiratory particle can carry a virus.', 'Noun phrase', form='respiratory particles', plural='respiratory particles'),
v('transmit', 'To pass a disease, signal or information from one person or place to another.', 'People can transmit some infections before they feel ill.', 'Verb', verb=('transmit','transmitted','transmitted',False)),
v('symptom', 'A physical or mental change that can indicate an illness.', 'A persistent cough can be a symptom of illness.', 'Noun', form='symptoms', plural='symptoms'),
v('restriction', 'A rule that limits what people can do.', 'The travel restriction affected international flights.', 'Noun', form='restrictions', plural='restrictions'),
v('vaccine', 'A preparation that trains the immune system to help protect against a disease.', 'Researchers tested the vaccine in several stages.', 'Noun', form='vaccines', plural='vaccines'),
v('variant', 'A form of something that differs from other forms of the same thing.', 'Scientists studied a new variant of the virus.', 'Noun', form='variants', plural='variants'),
v('long COVID', 'Health problems that continue or develop after the initial COVID-19 infection.', 'The clinic supports patients with long COVID.', 'Noun phrase'),
v('preparedness', 'The state of being ready to respond to a situation or emergency.', 'The exercise tested the city\'s disaster preparedness.', 'Uncountable noun')
],
[
m('What made the virus difficult to detect and contain?', ['It could spread only after every infected person had been hospitalized.', 'It could not move through the air.', 'People could pass it on before symptoms appeared.'], 'C', 'People could transmit the virus before developing symptoms, making it harder to detect and contain.', 'Transmission could occur before an infected person showed signs of illness.'),
m('What did vaccination help achieve?', ['Protection against severe illness and death, without preventing every infection.', 'An immediate end to every infection in every country.', 'The removal of all differences in access to health care.'], 'A', 'Vaccination programs expanded from late 2020 and helped protect people against severe illness and death.', 'Vaccines reduced serious outcomes, while infections and new variants still occurred.'),
m('What did the May 2023 decision mean?', ['COVID-19 had never spread internationally.', 'The international emergency designation ended, while health effects continued.', 'The virus had permanently disappeared.'], 'B', 'On May 5, 2023, the World Health Organization ended the international emergency designation. The virus continued circulating, and its health effects still required attention.', 'Ending the emergency designation did not erase the disease or its consequences.'),
g('The virus that causes COVID-19 is called ___.', 'SARS-CoV-2', 'It caused the disease later named COVID-19, and the virus became known as SARS-CoV-2.', 'SARS-CoV-2 names the virus; COVID-19 names the disease.'),
g('Some jobs moved ___ during the pandemic.', 'online', 'Schools closed in many places, some jobs moved online, and travel fell sharply.', 'Online work became an option for some jobs, but not for everyone.'),
g('Some continuing health problems became known as long ___.', 'COVID', 'Some survivors experienced continuing health problems known as long COVID.', 'COVID completes the name given to these continuing health effects.')
],
[
'World Health Organization — Original timeline of reporting and emergency decisions: https://www.who.int/news/item/29-06-2020-COVIDtimeline',
'World Health Organization — Disease, transmission, vaccination and long COVID: https://www.who.int/vietnam/news/fact-sheets/detail/coronavirus-disease-(covid-19)',
'World Health Organization — Pandemic chronology and emergency transition: https://www.who.int/europe/emergencies/situations/covid-19',
'WHO Director-General — May 5, 2023 decision, unequal access and wider consequences: https://www.who.int/news-room/speeches/item/who-director-general-s-opening-remarks-at-the-media-briefing---5-may-2023',
'World Health Organization — First emergency-use vaccine listing and equitable access: https://www.who.int/news/item/31-12-2020-who-issues-its-first-emergency-use-validation-for-a-covid-19-vaccine-and-emphasizes-need-for-equitable-global-access'
],
[
'Overview covers the first reported cluster, disease/virus distinction, airborne transmission, global spread, emergency timeline, public response, scientific tools, unequal access, deaths, long COVID and continuing consequences.',
'Wuhan is identified as the location of the reported cluster, not as a proven location of the first human infection. No settled origin is asserted.',
'Vaccines are described as protecting against severe disease and death, not as preventing every infection.',
'May 2023 ended the PHEIC designation. The text does not claim that COVID-19 or all pandemic consequences ended then.',
'Millions of deaths is used instead of a changing exact total. This is a historical overview, not an individual treatment or vaccination schedule.'
])

draft(23, 'holocaust', 'The Holocaust: Persecution, Genocide and Its Aftermath', 'History',
      'Nazi persecution developed into the systematic murder of European Jews, leaving consequences that continued after liberation.',
'''The Holocaust was the systematic persecution and murder of six million European Jews by Nazi Germany and its allies and collaborators. It grew from **antisemitism**, which was central to Nazi beliefs, and from the increasing power of a state that treated Jewish people as enemies.

After Adolf Hitler and the Nazis took power in Germany in 1933, Jews faced exclusion from jobs, schools and public life. The Nuremberg Laws of 1935 stripped German Jews of **citizenship** and basic rights. Organized violence escalated, including attacks on Jewish people, businesses and places of worship in November 1938.

Germany invaded Poland in 1939, beginning the Second World War in Europe. Conquest brought millions more Jews under Nazi control. Authorities forced communities into crowded **ghettos**, where hunger and disease caused enormous suffering.

After the invasion of the Soviet Union in 1941, German forces and **collaborators** carried out mass shootings of Jewish communities. Nazi authorities also organized **deportations** from across Europe to killing centers, including Auschwitz-Birkenau and Treblinka. Many victims were murdered soon after arrival.

This **genocide** depended on officials, police, transport systems and cooperation beyond Germany itself. Jews resisted in different ways, including hiding, preserving evidence and armed **resistance**. Others helped people escape or survive, often at great personal risk.

The Nazis also persecuted and murdered millions of other people, including Roma, disabled people, non-Jewish Poles and Soviet prisoners of war. Their experiences belonged to the wider history of Nazi violence, while Jews were targeted for complete destruction.

Allied forces **liberated** surviving prisoners as Nazi Germany was defeated in 1945. Survivors had often lost their families and homes. Many remained **displaced** for years, and antisemitism continued after the war.

Postwar trials, including those at Nuremberg, prosecuted Nazi crimes, although many perpetrators escaped punishment. The consequences reached far beyond the camps: destroyed communities, lasting trauma and difficult questions about how governments, institutions and ordinary people had enabled mass murder.''',
[
v('antisemitism', 'Prejudice, hostility or discrimination directed against Jewish people.', 'The museum documents the history of antisemitism.', 'Uncountable noun'),
v('citizenship', 'Legal membership of a country, with associated rights and responsibilities.', 'The law changed the rules governing citizenship.', 'Uncountable noun'),
v('ghetto', 'An area where a minority is forced or restricted to live; under Nazi rule, a confined area for Jews.', 'The archive preserves accounts of life in the ghetto.', 'Noun', form='ghettos', plural='ghettos'),
v('collaborator', 'Someone who works with an enemy or occupying power.', 'The records identified a local collaborator.', 'Noun', form='collaborators', plural='collaborators'),
v('deportation', 'The forced removal of people from their homes or a country by an authority.', 'The family described the deportation in its testimony.', 'Noun', form='deportations', plural='deportations'),
v('genocide', 'Acts committed with the intention of destroying a national, ethnic, racial or religious group, in whole or in part.', 'The court investigated evidence of genocide.', 'Noun'),
v('resistance', 'Actions taken to oppose an authority, occupation or force.', 'The collection includes evidence of resistance during the occupation.', 'Uncountable noun'),
v('liberate', 'To free people or a place from imprisonment or oppressive control.', 'The troops helped liberate prisoners from the camp.', 'Verb', form='liberated', verb=('liberate','liberated','liberated',False)),
v('displaced', 'Forced to leave home, especially because of war or disaster.', 'Displaced families needed safe housing.', 'Adjective')
],
[
m('What happened to German Jews after the Nazis took power?', ['They faced growing exclusion, loss of rights and organized violence.', 'They immediately gained equal protection in every area of public life.', 'Persecution began only after the war had ended.'], 'A', 'After Adolf Hitler and the Nazis took power in Germany in 1933, Jews faced exclusion from jobs, schools and public life.', 'Exclusion and legal persecution developed before the mass-murder phase.'),
m('Which statement describes how the mass murder was carried out?', ['Every victim died in the same camp.', 'It took place entirely outside occupied Europe.', 'It involved mass shootings, deportations and killing centers across a wider system.'], 'C', 'After the invasion of the Soviet Union in 1941, German forces and collaborators carried out mass shootings of Jewish communities. Nazi authorities also organized deportations from across Europe to killing centers, including Auschwitz-Birkenau and Treblinka.', 'The genocide used several methods and depended on institutions and collaborators across Europe.'),
m('What did liberation mean for survivors?', ['All survivors immediately recovered their homes and families.', 'Imprisonment ended, but loss, displacement and prejudice continued.', 'Postwar courts punished every perpetrator.'], 'B', 'Survivors had often lost their families and homes. Many remained displaced for years, and antisemitism continued after the war.', 'Freedom from the camps did not remove the damage or restore survivors\' previous lives.'),
g('The Holocaust murdered ___ million European Jews.', 'six', 'The Holocaust was the systematic persecution and murder of six million European Jews by Nazi Germany and its allies and collaborators.', 'Six million refers to Jewish victims, rather than to all victims of Nazi persecution.'),
g('Germany invaded ___ in 1939.', 'Poland', 'Germany invaded Poland in 1939, beginning the Second World War in Europe.', 'The invasion of Poland marked the start of the war in Europe.'),
g('Major postwar trials took place at ___.', 'Nuremberg', 'Postwar trials, including those at Nuremberg, prosecuted Nazi crimes, although many perpetrators escaped punishment.', 'Nuremberg was the location of major postwar trials.')
],
[
'US Holocaust Memorial Museum — Definition, victims, perpetrators and mechanisms: https://encyclopedia.ushmm.org/content/en/article/introduction-to-the-holocaust',
'US Holocaust Memorial Museum — Chronology: https://encyclopedia.ushmm.org/content/en/timeline/holocaust',
'US Holocaust Memorial Museum — Nuremberg Laws: https://encyclopedia.ushmm.org/content/en/article/nuremberg-laws',
'US Holocaust Memorial Museum — Survivor experiences: https://encyclopedia.ushmm.org/content/en/article/the-aftermath-of-the-holocaust',
'US Holocaust Memorial Museum — Postwar justice: https://encyclopedia.ushmm.org/content/en/article/the-nuremberg-trials'
],
[
'Overview covers Nazi ideology, prewar exclusion and violence, occupation, ghettos, mass shootings, deportation and killing centers, collaborators, resistance, other victim groups, liberation, displacement and justice.',
'Six million Jewish victims are distinguished from wider Nazi victim totals. No unsupported single total for all victim groups is used.',
'The account does not locate all murders in camps or reduce the Holocaust to Auschwitz. Nazi killing centers in occupied Poland are not described as Polish camps.',
'Wannsee is omitted within the word cap; the narrative does not claim that this conference initiated an otherwise nonexistent murder policy.',
'Liberation is distinguished from recovery. The account is educational and factual without graphic descriptions.'
])

draft(24, 'itaewon-crowd-crush', 'Itaewon 2022: The Crowd Crush and Its Aftermath', 'World Events',
      'Dangerous crowd pressure, failures in the response to warnings and a difficult rescue turned a night out into a national tragedy.',
'''On October 29, 2022, large numbers of people gathered for Halloween in Itaewon, a busy nightlife district of Seoul, South Korea. Visitors moved between bars, restaurants and nearby streets. The gathering spread through public spaces rather than taking place inside one controlled event venue.

As the evening continued, people entered a narrow, sloping **alley**. Dense crowds met in a restricted space, leaving little room to move. Increasing **pressure** pushed bodies together and **trapped** people. Some fell, while others could not breathe even when standing. The **crowd crush** left people unable to escape the force of bodies pressing around them.

Calls warning about dangerous crowding reached police earlier in the evening. A later official **inquiry** found failures in handling those calls, assessing the danger and sending an effective response. The findings pointed to problems across the safety system.

Emergency workers and **bystanders** tried to pull people to safety and provide **first aid**. Crowded streets and restricted access made rescue difficult. More than 150 people died, many of them young adults. Victims included people from South Korea and other countries.

The effects continued long after the alley was cleared. Families lost relatives, survivors faced trauma, and the country entered a period of mourning. Relatives and campaigners demanded answers about why warnings had not prevented the disaster and who should be held responsible.

Investigations examined police decisions, emergency communication and the preparation for large gatherings. Seoul later introduced stronger safety planning and ways to **monitor** crowd levels, including attention to gatherings without a formal organizer.

Itaewon showed that public safety depends on the whole journey through crowded streets: available space, movement routes, early warnings and coordinated action. Its **legacy** includes grief and continuing demands for **accountability**, alongside changes intended to prevent another ordinary celebration from becoming a disaster.''',
[
v('alley', 'A narrow passage or street between buildings.', 'The restaurant entrance opens onto a small alley.', 'Noun', plural='alleys'),
v('pressure', 'Force applied against a surface or object.', 'The crowd placed pressure on the temporary barrier.', 'Uncountable noun'),
v('trap', 'To prevent someone or something from moving or escaping.', 'The collapsed wall could trap people inside.', 'Verb', form='trapped', verb=('trap','trapped','trapped',False)),
v('crowd crush', 'A dangerous situation in which dense crowd pressure compresses people and can prevent breathing or movement.', 'The investigation examined how the crowd crush developed.', 'Noun phrase', plural='crowd crushes'),
v('inquiry', 'An official process of investigating facts and asking questions about an event.', 'The inquiry reviewed the emergency response.', 'Noun', plural='inquiries'),
v('bystander', 'Someone who is present at an event without being directly involved at first.', 'A bystander called for help after the crash.', 'Noun', form='bystanders', plural='bystanders'),
v('first aid', 'Immediate basic help given to someone who is injured or suddenly ill.', 'Volunteers provided first aid until medical teams arrived.', 'Uncountable noun phrase'),
v('monitor', 'To watch or check something over time to notice changes or problems.', 'The control room will monitor crowd levels.', 'Verb', verb=('monitor','monitored','monitored',False)),
v('legacy', 'A lasting effect or situation left by an event or earlier period.', 'The reforms are part of the inquiry\'s legacy.', 'Noun', plural='legacies'),
v('accountability', 'Responsibility for decisions and the obligation to explain them.', 'Families called for accountability after the disaster.', 'Uncountable noun')
],
[
m('What made the crowd pressure so dangerous?', ['Every person could move away freely.', 'People were compressed in restricted space and could lose the ability to breathe.', 'The danger affected only people running alone.'], 'B', 'Increasing pressure pushed bodies together and trapped people. Some fell, while others could not breathe even when standing.', 'Crowd pressure can restrict movement and breathing, even without everyone falling.'),
m('What did the later official inquiry find?', ['Failures in handling warnings, assessing danger and responding.', 'That no warning calls had reached police.', 'That one visitor\'s action fully explained the disaster.'], 'A', 'A later official inquiry found failures in handling those calls, assessing the danger and sending an effective response.', 'The findings concerned several parts of the safety and response system.'),
m('Which change is described in the aftermath?', ['An end to every gathering in Seoul.', 'A decision to ignore gatherings without an organizer.', 'Stronger planning and monitoring of crowd levels.'], 'C', 'Seoul later introduced stronger safety planning and ways to monitor crowd levels, including attention to gatherings without a formal organizer.', 'The later response included crowd monitoring and planning for informal gatherings.'),
g('People had gathered to celebrate ___.', 'Halloween', 'On October 29, 2022, large numbers of people gathered for Halloween in Itaewon, a busy nightlife district of Seoul, South Korea.', 'Halloween was the occasion for the gathering.'),
g('Emergency workers and bystanders provided first ___.', 'aid', 'Emergency workers and bystanders tried to pull people to safety and provide first aid.', 'First aid means immediate help for injured or ill people.'),
g('Families and campaigners demanded ___ about why warnings had not prevented the disaster.', 'answers', 'Relatives and campaigners demanded answers about why warnings had not prevented the disaster and who should be held responsible.', 'The aftermath included demands to establish what had gone wrong.')
],
[
'October 29 Itaewon Disaster Investigation Commission — March 12, 2026 hearing on warning calls and response failures: https://1029itaewoncommission.go.kr/site/eng/page/news/notices/?board_id=BBS_0000000000000014&category=&cntId=56&mode=view&pageIdx=3',
'Seoul Metropolitan Government — Crowd safety planning and monitoring: https://english.seoul.go.kr/intelligent-disaster-safety-system-put-in-place-as-first-anniversary-of-itaewon-crowd-crush-approaches/',
'Korean Ministry of the Interior and Safety — June 26, 2026 revision of recognized fatal victims: https://mois.go.kr/frt/bbs/type010/commonSelectBoardArticle.do?bbsId=BBSMSTR_000000000008&nttId=127263',
'Original crowd-mechanism research; model results are not treated as measured certainty: https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0306764'
],
[
'Overview covers the public gathering, restricted street layout, dangerous density and pressure, earlier warnings, inquiry findings, rescue, deaths, trauma, accountability and prevention measures.',
'Crowd crush is used rather than a claim of irrational stampeding. No victim-blaming or unsupported single trigger is presented.',
'More than 150 deaths avoids equating the historically reported direct toll of 159 with evolving recognition of later trauma-related deaths. The Ministry recognized 160 fatal victims in June 2026 under a wider scope; that is not 160 people crushed that night.',
'Findings about failures are attributed to the official inquiry. Simulation density estimates and unverified allegations are omitted.',
'The final paragraph synthesizes documented planning issues; it is not an individualized crowd-survival instruction.'
])

draft(25, 'john-f-kennedy-assassination', 'The Assassination of John F. Kennedy: Shock and Succession', 'History',
      'The Dallas shooting, transfer of presidential power, investigations and national mourning shaped a lasting American tragedy.',
'''John F. Kennedy became president of the United States in 1961, during the Cold War and a growing struggle over civil rights. In November 1963, he traveled to Texas to meet voters and political leaders ahead of the next presidential election.

On November 22, Kennedy rode through Dallas in an open car with his wife, Jacqueline, and Texas Governor John Connally and his wife. Crowds watched the presidential **motorcade**. At about 12:30 in the afternoon, shots were fired as the cars passed through Dealey Plaza.

Kennedy was struck, and Connally was **wounded**. The president was taken to Parkland Hospital, where doctors could not save him. He was pronounced dead at 1 p.m. News of the **assassination** spread rapidly, bringing shock far beyond Dallas.

The government also faced an immediate transfer of power. Vice President Lyndon B. Johnson took the presidential **oath** aboard Air Force One that afternoon. This **succession** kept the presidency functioning during a national crisis.

Police arrested Lee Harvey Oswald as a **suspect**. Two days later, nightclub owner Jack Ruby shot and killed him during a police transfer shown on live television. Oswald therefore never faced a criminal trial over Kennedy's death.

Johnson appointed the Warren **Commission** to investigate. In 1964, it **concluded** that Oswald had acted alone in killing the president. His precise motive could not be established with certainty. Later inquiries questioned aspects of the investigation, and public debate continued.

The nation mourned, and Kennedy's funeral took place on November 25 before his burial at Arlington National Cemetery. His family faced a deeply personal loss under intense public attention.

The assassination brought a sudden change of leadership and placed presidential protection under closer **scrutiny**. It also left lasting questions about trust in government and official investigations. The shooting, the orderly transfer of power and the search for answers all became parts of its wider legacy.''',
[
v('motorcade', 'A group of vehicles traveling together, especially to carry and protect an important person.', 'The motorcade moved slowly through the city.', 'Noun', plural='motorcades'),
v('wound', 'To injure someone, especially with a weapon.', 'The attack could wound people nearby.', 'Verb', form='wounded', verb=('wound','wounded','wounded',False)),
v('assassination', 'The deliberate killing of a prominent person, often for political reasons.', 'The assassination caused a national crisis.', 'Noun', plural='assassinations'),
v('oath', 'A formal promise, often made when taking public office.', 'The new president took the oath of office.', 'Noun', plural='oaths'),
v('succession', 'The process by which someone takes over an office or position from another person.', 'The constitution sets out the rules for presidential succession.', 'Uncountable noun'),
v('suspect', 'A person believed possibly to have committed a crime.', 'Police questioned a suspect after the robbery.', 'Noun', plural='suspects'),
v('commission', 'An official group appointed to investigate or carry out a particular task.', 'The commission interviewed witnesses.', 'Noun', form='Commission', plural='commissions'),
v('conclude', 'To reach a judgment after considering evidence or information.', 'Investigators may conclude that several failures contributed.', 'Verb', form='concluded', verb=('conclude','concluded','concluded',False)),
v('scrutiny', 'Careful and detailed examination.', 'The report placed the decision under public scrutiny.', 'Uncountable noun')
],
[
m('What happened to the presidency after Kennedy died?', ['The office remained empty until the next election.', 'The governor of Texas automatically became president.', 'Lyndon B. Johnson took the oath and assumed presidential power.'], 'C', 'Vice President Lyndon B. Johnson took the presidential oath aboard Air Force One that afternoon.', 'The vice president succeeded Kennedy, keeping the presidency functioning.'),
m('Why did Oswald never face a criminal trial over the assassination?', ['He served as chairman of the Warren Commission.', 'Jack Ruby killed him during a police transfer.', 'All investigation ended before he was arrested.'], 'B', 'Two days later, nightclub owner Jack Ruby shot and killed him during a police transfer shown on live television. Oswald therefore never faced a criminal trial over Kennedy\'s death.', 'Oswald was killed before the case could be tested in a criminal trial.'),
m('How does the account describe the investigation?', ['The Warren Commission concluded that Oswald acted alone, while later inquiries and debate continued.', 'Every official inquiry reached identical conclusions about every detail.', 'A particular wider plot is presented as an established fact.'], 'A', 'In 1964, it concluded that Oswald had acted alone in killing the president. His precise motive could not be established with certainty. Later inquiries questioned aspects of the investigation, and public debate continued.', 'The account identifies the Commission\'s finding while distinguishing it from later debate and unsupported claims.'),
g('The shooting took place in the city of ___.', 'Dallas', 'Kennedy rode through Dallas in an open car with his wife, Jacqueline, and Texas Governor John Connally and his wife.', 'Dallas was the city where the presidential motorcade was traveling.'),
g('Governor John ___ was also wounded.', 'Connally', 'Kennedy was struck, and Connally was wounded.', 'Connally was the Texas governor traveling in the presidential car.'),
g('Kennedy was buried at Arlington National ___.', 'Cemetery', 'The nation mourned, and Kennedy\'s funeral took place on November 25 before his burial at Arlington National Cemetery.', 'Cemetery completes the name of the burial place.')
],
[
'John F. Kennedy Presidential Library — Election-trip background, funeral and family history: https://www.jfklibrary.org/sites/default/files/2018-06/JBKpicturebook.pdf',
'John F. Kennedy Presidential Library — Death of the president: https://www.jfklibrary.org/learn/about-jfk/jfk-in-history/november-22-1963-death-of-the-president',
'National Archives — Warren Commission findings, sequence and limits: https://www.archives.gov/research/jfk/warren-commission-report/chapter-1',
'National Archives — Review of presidential protection: https://www.archives.gov/research/jfk/warren-commission-report/chapter-8.html',
'National Archives — Later congressional inquiry: https://www.archives.gov/research/jfk/select-committee-report/summary.html'
],
[
'Overview covers the presidency and Texas visit, Dallas shooting, medical outcome, constitutional succession, Oswald/Ruby, investigation, national mourning, protection and public trust.',
'The Warren Commission\'s conclusion is attributed to it. The story does not claim that every later inquiry agreed or that a particular conspiracy is proven.',
'Oswald did not face a criminal trial, and precise motive was not established with certainty. This is distinguished from saying nothing is known about the assassination.',
'12:30 p.m., 1 p.m., the November 22 shooting, November 24 killing of Oswald and November 25 funeral are the supported sequence.',
'No claim is made about the content or completeness of newly released files. Speculative plot details do not displace the overview.'
])
