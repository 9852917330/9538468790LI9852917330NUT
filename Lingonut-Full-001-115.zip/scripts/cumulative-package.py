"""Export and install one complete Lingonut snapshot with immutable shared audio."""
import argparse
import hashlib
import json
import re
import stat
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from zoneinfo import ZoneInfo

MANIFEST = 'FULL_SOURCE_MANIFEST.json'
KIND = 'cumulative-source'
BASE_NAME = 'Lingonut-GitHub-Full-001-055-Mobile.zip'
BASE_SHA = '14d2a464ff636ea3b0ea051500b2c0bd48c27d691ddabab18d95285c2aae59e6'
LIMIT = 25 * 1024 * 1024
EXPANDED_LIMIT = 256 * 1024 * 1024
LANGUAGES = {'fr', 'de', 'es', 'ja', 'ko', 'zh-Hans', 'vi', 'th'}
SKIP_TOP = {'node_modules', 'dist', '.git', '.github', '.sites-runtime', '.wrangler', '.venv'}
SKIP_FILES = {MANIFEST, 'EXPORT_MANIFEST.json', 'UPDATE_README.txt', 'LINGONUT_UPDATES.json'}
TRANSLATION = re.compile(r'content/translations/(\d{3,4})/(fr|de|es|ja|ko|zh-Hans|vi|th)\.json')
LESSON = re.compile(r'content/lessons/(\d{3,4})\.json')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def safe_path(name):
    require(isinstance(name, str) and name and '\\' not in name and ':' not in name,
            'Invalid package path')
    path = PurePosixPath(name)
    require(not path.is_absolute() and path.as_posix() == name
            and all(part not in {'.', '..', ''} for part in path.parts), 'Unsafe package path: ' + name)
    require(not any(ord(c) < 32 or ord(c) == 127 for c in name), 'Control character in path')
    require(path.parts[0] not in SKIP_TOP, 'Disallowed package directory: ' + name)
    require(not any(part.startswith('.env') or part == '__pycache__' for part in path.parts),
            'Private or generated file in package: ' + name)
    require(path.name.lower() != 'readme.md', 'README.md is not part of this delivery')
    return path


def check_zip(archive, max_bytes):
    require(archive.stat().st_size <= max_bytes and not archive.is_symlink(), 'Oversized or linked ZIP')
    z = zipfile.ZipFile(archive)
    infos = z.infolist()
    try:
        require(len(infos) <= 10000 and sum(i.file_size for i in infos) <= EXPANDED_LIMIT,
                'ZIP exceeds package limits')
        names = set()
        for info in infos:
            require(not info.is_dir(), 'Explicit ZIP directory entries are not supported')
            safe_path(info.filename)
            require(info.filename not in names and not info.flag_bits & 1
                    and not stat.S_ISLNK(info.external_attr >> 16), 'Duplicate, encrypted or linked entry')
            names.add(info.filename)
        return z, names
    except Exception:
        z.close()
        raise


def verify_collection(files, manifest):
    lessons = {}
    translations = {}
    paragraphs = 0
    for name, data in files.items():
        match = LESSON.fullmatch(name)
        if match:
            lesson = json.loads(data)
            require(int(lesson['id']) == int(match[1]), 'Wrong English lesson ID')
            lessons[int(match[1])] = lesson
        match = TRANSLATION.fullmatch(name)
        if match:
            translations[(int(match[1]), match[2])] = json.loads(data)
    count = manifest['lessonCount']
    through = manifest['translatedThrough']
    require(isinstance(count, int) and isinstance(through, int) and 1 <= through <= count,
            'Invalid collection counts')
    require(set(lessons) == set(range(1, count + 1)), 'Complete English collection is missing')
    expected = {(n, language) for n in range(1, through + 1) for language in LANGUAGES}
    require(set(translations) == expected, 'Complete eight-language translation collection is missing')
    for (number, language), bundle in translations.items():
        lesson = lessons[number]
        script = lesson['script'].replace('**', '').strip()
        require(bundle['version'] == 1 and bundle['lessonId'] == lesson['id']
                and bundle['language'] == language and bundle['sourceTitle'] == lesson['title']
                and bundle['sourceScriptSha256'] == digest(script.encode('utf-8')),
                'Translation source mismatch')
        require(len(bundle['paragraphs']) == len(re.split(r'\n\s*\n', script)),
                'Translation paragraph alignment mismatch')
        paragraphs += len(bundle['paragraphs'])
    require(manifest['translationBundleCount'] == len(translations)
            and manifest['translatedParagraphCount'] == paragraphs, 'Translation totals mismatch')
    require(manifest['sequence'] == through * 1000 + manifest['revision']
            and isinstance(manifest['revision'], int) and 1 <= manifest['revision'] < 1000,
            'Invalid package sequence')
    for n in lessons:
        require(f'content/audio/{n:03}.mp3' in files, 'Missing complete lesson audio')
    return {'lessonCount': count, 'translatedThrough': through,
            'translationBundleCount': len(translations), 'translatedParagraphCount': paragraphs}


def export_package(source, output, revision):
    source, output = Path(source).resolve(), Path(output).resolve()
    require(not output.is_relative_to(source), 'Export outside the source directory')
    index = json.loads((source / 'SHARED_MEDIA.json').read_text())
    require(index['file'] == BASE_NAME and index['sha256'] == BASE_SHA, 'Unknown shared audio base')
    shared = {row['path']: row for row in index['files']}
    files = {}
    inline = {}
    entries = []
    for path in sorted(source.rglob('*')):
        name = path.relative_to(source).as_posix()
        parts = PurePosixPath(name).parts
        if parts[0] in SKIP_TOP or '__pycache__' in parts or path.is_dir():
            continue
        if name in SKIP_FILES or path.suffix in {'.zip', '.log', '.pyc'}:
            continue
        if parts[0] == 'public' and len(parts) > 1 and parts[1] in {'data', 'audio', 'pronunciation'}:
            continue
        require(not path.is_symlink(), 'Do not export source symlinks')
        safe_path(name)
        data = path.read_bytes()
        row = {'path': name, 'bytes': len(data), 'sha256': digest(data), 'storage': 'inline'}
        previous = shared.get(name)
        if previous and all(previous[key] == row[key] for key in ['path', 'bytes', 'sha256']):
            row['storage'] = 'shared-audio'
        else:
            inline[name] = data
        files[name] = data
        entries.append(row)
    bundles = [(name, json.loads(data)) for name, data in files.items() if TRANSLATION.fullmatch(name)]
    through = max(int(TRANSLATION.fullmatch(name)[1]) for name, _ in bundles)
    today = datetime.now(ZoneInfo('Asia/Ho_Chi_Minh'))
    manifest = {
        'formatVersion': 2,
        'kind': KIND,
        'createdAt': datetime.now(timezone.utc).isoformat(),
        'releaseDate': today.date().isoformat(),
        'sequence': through * 1000 + revision,
        'revision': revision,
        'sourceCommit': None,
        'sourceCommitNote': 'Prepared and tested locally. No GitHub push or live deployment is claimed.',
        'lessonCount': sum(bool(LESSON.fullmatch(name)) for name in files),
        'translatedThrough': through,
        'languages': sorted(LANGUAGES),
        'translationBundleCount': len(bundles),
        'translatedParagraphCount': sum(len(bundle['paragraphs']) for _, bundle in bundles),
        'requiredUpdates': [],
        'sharedBaseArchive': {key: index[key] for key in ['repository', 'releaseTag', 'file', 'sha256']},
        'files': entries,
    }
    summary = verify_collection(files, manifest)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted({**inline, MANIFEST: encoded(manifest)}.items()):
            info = zipfile.ZipInfo(name, date_time=(today.year, today.month, today.day, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data, compresslevel=9)
    require(output.stat().st_size <= LIMIT, 'ZIP exceeds the browser upload limit; do not split it for the user')
    with zipfile.ZipFile(output) as z:
        require(z.testzip() is None, 'ZIP integrity check failed')
    return {**summary, 'file': str(output), 'bytes': output.stat().st_size,
            'sha256': digest(output.read_bytes()), 'inlineFiles': len(inline),
            'sharedOriginalAudioFiles': len(entries) - len(inline)}


def install_package(archive, base_archive, destination):
    archive, base_archive = Path(archive).resolve(), Path(base_archive).resolve()
    destination = Path(destination).resolve()
    require(not destination.exists() or not any(destination.iterdir()), 'Install into an empty directory')
    require(digest(base_archive.read_bytes()) == BASE_SHA, 'Original shared audio archive checksum failed')
    z, names = check_zip(archive, LIMIT)
    try:
        manifest = json.loads(z.read(MANIFEST))
        require(manifest.get('formatVersion') == 2 and manifest.get('kind') == KIND,
                'Use a complete Lingonut cumulative ZIP')
        require(manifest['sharedBaseArchive']['sha256'] == BASE_SHA
                and manifest['sharedBaseArchive']['file'] == BASE_NAME, 'Unexpected shared audio base')
        rows = manifest['files']
        require(isinstance(rows, list) and len(rows) <= 10000, 'Invalid source inventory')
        require(sum(row['bytes'] for row in rows) <= EXPANDED_LIMIT, 'Expanded source exceeds limit')
        payload = {}
        inline_names = {MANIFEST}
        with zipfile.ZipFile(base_archive) as base:
            for row in rows:
                name = row['path']
                safe_path(name)
                require(name != MANIFEST and name not in payload, 'Duplicate source path')
                require(re.fullmatch('[0-9a-f]{64}', row['sha256']) is not None
                        and isinstance(row['bytes'], int) and row['bytes'] >= 0, 'Invalid source checksum')
                if row['storage'] == 'inline':
                    data = z.read(name)
                    inline_names.add(name)
                else:
                    require(row['storage'] == 'shared-audio' and name.startswith('content/')
                            and name.endswith('.mp3'), 'Only original audio can be shared')
                    data = base.read(name)
                require(len(data) == row['bytes'] and digest(data) == row['sha256'],
                        'Source checksum mismatch: ' + name)
                payload[name] = data
        require(names == inline_names, 'ZIP has missing or unlisted files')
        summary = verify_collection(payload, manifest)
        # Validate every file and the full collection before creating the site.
        destination.mkdir(parents=True, exist_ok=True)
        for name, data in payload.items():
            target = destination.joinpath(*PurePosixPath(name).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        (destination / MANIFEST).write_bytes(encoded(manifest))
        return {**summary, 'files': len(payload),
                'sharedOriginalAudioFiles': sum(row['storage'] == 'shared-audio' for row in rows),
                'requiredUpdateArchives': 0}
    finally:
        z.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    export = sub.add_parser('export')
    export.add_argument('--source', type=Path, default=Path(__file__).resolve().parent.parent)
    export.add_argument('--output', type=Path, required=True)
    export.add_argument('--revision', type=int, default=1)
    install = sub.add_parser('install')
    install.add_argument('--archive', type=Path, required=True)
    install.add_argument('--shared-base', type=Path, required=True)
    install.add_argument('--destination', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'export':
        result = export_package(args.source, args.output, args.revision)
    else:
        result = install_package(args.archive, args.shared_base, args.destination)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
