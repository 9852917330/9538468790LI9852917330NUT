"""Stage reviewed lessons with matching recordings and refresh collection progress."""
import argparse
import datetime
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DRAFTS = ROOT / 'content/editorial-drafts'
DATE = '2026-10-23'


def vocab(head, meaning, example, pos, form=None, verb=None, plural=None, note=None):
    entry = dict(phrase=head, meaning=meaning, example=example, partOfSpeech=pos)
    if form and form != head:
        entry['scriptForms'] = [form]
    if verb:
        entry['verbForms'] = dict(zip(('base', 'past', 'pastParticiple', 'irregular'), verb))
    if plural:
        entry['pluralForm'] = plural
    if note:
        entry['usageNote'] = note
    return entry


def mcq(prompt, options, answer, evidence, explanation):
    return dict(type='mcq', prompt=prompt, options=options, answer=answer, evidence=evidence, explanation=explanation)


def gap(prompt, answer, evidence, explanation):
    return dict(type='gap', prompt=prompt, options=[], answer=answer, evidence=evidence, explanation=explanation)


def validate(lesson):
    plain = lesson['script'].replace('**', '').strip()
    assert 250 <= len(plain.split()) <= 350, (lesson['order'], len(plain.split()))
    assert 8 <= len(lesson['phrases']) <= 15
    highlighted = re.findall(r'\*\*(.+?)\*\*', lesson['script'])
    for form in highlighted:
        assert sum(form.lower() in [p['phrase'].lower(), *[f.lower() for f in p.get('scriptForms', [])]] for p in lesson['phrases']) == 1, form
    for p in lesson['phrases']:
        assert any(f.lower() in [p['phrase'].lower(), *[s.lower() for s in p.get('scriptForms', [])]] for f in highlighted), p['phrase']
        assert all(form in highlighted for form in p.get('scriptForms', []))
    assert len(lesson['questions']) == 6
    for i, q in enumerate(lesson['questions']):
        assert q['evidence'] in plain, (lesson['order'], q['evidence'])
        if i < 3:
            assert q['type'] == 'mcq' and len(q['options']) == 3 and q['answer'] in 'ABC'
        else:
            assert q['type'] == 'gap' and not q['options'] and '___' in q['prompt']
            assert len(q['answer'].split()) == 1 and re.search(r'\b' + re.escape(q['answer']) + r'\b', q['evidence'], re.I)
    return plain


def write_draft(n, slug, title, category, summary, script, phrases, questions, sources, decisions):
    lesson = dict(id=f'{n:02}', order=n, slug=slug, title=title, category=category, level='B1–B2', summary=summary,
                  script=script.strip(), phrases=phrases, questions=questions, published=False,
                  editorialNote=f'New full-event overview, {DATE}. Source audit: content/sources/{n:03}-overview-{DATE}.md. Matching complete audio required before publication.')
    plain = validate(lesson)
    DRAFTS.mkdir(exist_ok=True)
    (DRAFTS / f'{n:03}.json').write_text(json.dumps(dict(lesson=lesson, sources=sources, decisions=decisions), ensure_ascii=False, indent=2) + '\n')
    subprocess.run(['node', str(ROOT / 'scripts/check-topics.ts'), '--drafts', str(n)], check=True)
    print(f'{n:03}: draft saved, {len(plain.split())} words, {len(phrases)} vocabulary entries, six questions')


def audio_workspace(target, numbers):
    subprocess.run(['node', str(ROOT / 'scripts/check-topics.ts'), '--drafts', *map(str, numbers)], check=True)
    target = Path(target)
    for name in ('scripts', 'content/lessons', 'content/audio', 'content/subtitles'):
        (target / name).mkdir(parents=True, exist_ok=True)
    for name in ('generate-audio.py', 'register-recording.py'):
        shutil.copyfile(ROOT / 'scripts' / name, target / 'scripts' / name)
    for n in numbers:
        lesson = json.loads((DRAFTS / f'{n:03}.json').read_text())['lesson']
        validate(lesson)
        lesson['published'] = True
        (target / f'content/lessons/{n:03}.json').write_text(json.dumps(lesson, ensure_ascii=False, indent=2) + '\n')
    if not (target / 'content/production.json').exists():
        (target / 'content/production.json').write_text('{}\n')
    if not (target / 'PROGRESS.md').exists():
        (target / 'PROGRESS.md').write_text('# Audio preparation\n')


def stage(n, recordings):
    subprocess.run(['node', str(ROOT / 'scripts/check-topics.ts'), '--drafts', str(n)], check=True)
    raw = json.loads((DRAFTS / f'{n:03}.json').read_text())
    lesson = raw['lesson']
    plain = validate(lesson)
    recordings = Path(recordings)
    meta = json.loads((recordings / f'content/audio/{n:03}.meta.json').read_text())
    assert meta['scriptSha256'] == hashlib.sha256(plain.encode()).hexdigest()
    assert meta['voice'] == ('en-US-BrianNeural' if n % 2 else 'en-US-AvaNeural')
    assert meta['completeSubtitleMatch'] and meta['durationSeconds'] > 60
    for name in (f'content/audio/{n:03}.mp3', f'content/audio/{n:03}.meta.json', f'content/subtitles/{n:03}.vtt'):
        assert (recordings / name).is_file(), name
        shutil.copyfile(recordings / name, ROOT / name)
    lesson['published'] = True
    (ROOT / f'content/lessons/{n:03}.json').write_text(json.dumps(lesson, ensure_ascii=False, indent=2) + '\n')
    (ROOT / f'content/tts/{n:03}.txt').write_text(plain + '\n')
    audit = f"# {n:03}: {lesson['title']}\n\nNew overview researched and reviewed {DATE}.\n\n## Sources\n\n"
    audit += '\n'.join('- ' + source for source in raw['sources'])
    audit += '\n\n## Coverage and accuracy\n\n' + '\n'.join('- ' + decision for decision in raw['decisions']) + '\n'
    (ROOT / f'content/sources/{n:03}-overview-{DATE}.md').write_text(audit)
    checkpoint()
    print(f'{n:03}: complete lesson and matching audio staged')


def checkpoint():
    lessons = sorted((json.loads(p.read_text()) for p in (ROOT / 'content/lessons').glob('*.json')), key=lambda item: item['order'])
    lessons = [item for item in lessons if item.get('published', True)]
    stems = [f"{item['order']:03}" for item in lessons]
    words, vocab_counts, rows, duration = {}, {}, [], 0
    for lesson, stem in zip(lessons, stems):
        plain = lesson['script'].replace('**', '').strip()
        meta = json.loads((ROOT / f'content/audio/{stem}.meta.json').read_text())
        assert meta['scriptSha256'] == hashlib.sha256(plain.encode()).hexdigest(), stem
        assert meta['completeSubtitleMatch'] and (ROOT / f'content/audio/{stem}.mp3').is_file(), stem
        words[stem], vocab_counts[stem] = len(plain.split()), len(lesson['phrases'])
        duration += meta['durationSeconds']
        rows.append(f"| {stem} | {words[stem]} | {vocab_counts[stem]} | {meta['durationSeconds']:.1f} s |")
    production_path = ROOT / 'content/production.json'
    progress = json.loads(production_path.read_text())
    for key in ('textReady', 'audioReady', 'shortTextReady', 'naturalStoryReady', 'vocabularyNormalized', 'qualityRevisionReady', 'overviewRevisionReady'):
        progress[key] = stems
    for key in ('pendingAudio', 'pendingShortRevision', 'qualityRevisionRemaining', 'overviewRevisionRemaining'):
        progress[key] = []
    progress.update(scriptWords=words, vocabularyItems=vocab_counts, vocabularyEntryCount=sum(vocab_counts.values()),
                    normalizedHeadwordCount=sum(bool(p.get('scriptForms')) for item in lessons for p in item['phrases']),
                    updatedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    nextTextBatch=[f'{n:03}' for n in range(lessons[-1]['order'] + 1, min((lessons[-1]['order'] // 5 + 1) * 5, 1000) + 1)],
                    nextTextBatchStatus='Pending completion and publication; any saved drafts remain outside the published catalog.',
                    audioCheck='Complete TTS subtitle match and successful MP3 decoding; pronunciation not independently reviewed.')
    production_path.write_text(json.dumps(progress, indent=2) + '\n')
    policy_path = ROOT / 'content/editorial-policy.json'
    policy = json.loads(policy_path.read_text())
    policy['coverageReview'] = f"Full-event overview review completed for lessons {', '.join(stems)}. All {len(stems)} published lessons follow the overview standard."
    policy_path.write_text(json.dumps(policy, ensure_ascii=False, indent=2) + '\n')
    next_numbers = progress['nextTextBatch']
    (ROOT / 'PROGRESS.md').write_text(f'''# Lingonut — current progress

Website: https://english-unicorn-listening.maithu188.chatgpt.site

{len(lessons)} completed lessons with matching Brian US / Ava US recordings. Collection target: 1,000.

Balanced overview review completed: {', '.join(stems)}.
The original 001–015 overview rewrite is complete. Lessons 016 onward are newly authored; absent earlier drafts have not been represented as recovered material.

## Editorial standard

Give newcomers a balanced picture: background and setting, main developments, causes/mechanism, immediate outcomes and wider significance. Details support the overview. Titles, summaries, vocabulary and questions follow that scope. Maximum 350 words, mostly B1 English, 8–15 vocabulary entries, three multiple-choice questions and three one-word gaps.

Every lesson must cover a distinct event or discovery. Review content/topics.json before choosing topics, register canonical event keys and alternative names, and compare against every earlier topic. Renaming or retelling the same event does not create a new lesson. Drafting, audio preparation, staging and website builds run duplicate checks; see TOPIC_UNIQUENESS.md. The ledger's semantic review remains an editorial responsibility.

Current audits: content/sources/NNN-overview-{DATE}.md. Earlier audits are historical. Editorial drafts remain outside the published catalog until applied with matching audio.

## Audio and validation

Odd lessons use Brian US; even lessons use Ava US. Complete generated subtitles match the text, script hashes match recording metadata, and MP3 streams decode successfully. These automated checks are not an independent listening or pronunciation review. Superseded recordings are replaced rather than kept in an archive.

| Lesson | Script words | Vocabulary | Audio duration |
| --- | ---: | ---: | ---: |
{chr(10).join(rows)}

Total audio: {duration / 60:.1f} minutes. Vocabulary entries: {sum(vocab_counts.values())}. Questions: {len(lessons) * 6}.

## Delivery

Completed lessons are saved and published individually to the same public Site. Builds validate all lesson payloads and audio references. The established layout, themes and donation settings are retained. Vocabulary has a headphone pronunciation button; the native lesson player loads the selected recording into a local Blob for reliable seeking. See VALIDATION.md for functional verification and BACKUP_AND_RESTORE.md for portable recovery.

The original reference Site is untouched. The previous ZIP is an older snapshot. Current source, editorial drafts and recordings are versioned with this Site. Next lessons: {', '.join(next_numbers)}.
''')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    audio = sub.add_parser('audio-workspace')
    audio.add_argument('target')
    audio.add_argument('lessons', nargs='+', type=int)
    apply = sub.add_parser('stage')
    apply.add_argument('lesson', type=int)
    apply.add_argument('recordings')
    sub.add_parser('checkpoint')
    args = parser.parse_args()
    if args.command == 'audio-workspace':
        audio_workspace(args.target, args.lessons)
    elif args.command == 'stage':
        stage(args.lesson, args.recordings)
    else:
        checkpoint()
