import { fileURLToPath, URL } from "node:url";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  base: "./",
  cacheDir: ".cache/vite",
  plugins: [react()],
  server: { allowedHosts: ["terminal.local"] },
  resolve: { alias: { "@": fileURLToPath(new URL(".", import.meta.url)) } },
  build: {
    outDir: "dist", emptyOutDir: true, sourcemap: false,
    rolldownOptions: { input: {
      main: fileURLToPath(new URL("./index.html", import.meta.url)),
      donate: fileURLToPath(new URL("./donate.html", import.meta.url)),
    } },
  },
});
