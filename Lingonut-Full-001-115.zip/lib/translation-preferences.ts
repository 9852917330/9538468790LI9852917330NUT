import { translationCodes, type TranslationLanguage } from "./translation.ts";

export type ReadingLanguage = TranslationLanguage | "en";
export type TranslationView = "paragraphs" | "whole";
export type TranslationPreferences = { version: 1; language: ReadingLanguage; view: TranslationView };
export const translationPreferenceKey = "english-unicorn-translation-preferences";
export const defaultTranslationPreferences: TranslationPreferences = { version: 1, language: "en", view: "paragraphs" };
type ReadStorage = { getItem: (key: string) => string | null };
type WriteStorage = { setItem: (key: string, value: string) => void };
const isLanguage = (value: unknown): value is ReadingLanguage => value === "en" || translationCodes.some(code => code === value);

export function parseTranslationPreferences(value: unknown): TranslationPreferences | null {
  if (!value || typeof value !== "object") return null;
  const record = value as Record<string, unknown>;
  if (record.version !== 1 || !isLanguage(record.language) || (record.view !== "paragraphs" && record.view !== "whole")) return null;
  return { version: 1, language: record.language, view: record.view };
}
export function readTranslationPreferences(storage?: ReadStorage): TranslationPreferences {
  try {
    const saved = storage?.getItem(translationPreferenceKey);
    if (saved) {
      try { const parsed = parseTranslationPreferences(JSON.parse(saved)); if (parsed) return parsed; } catch { /* Try the previous demo preference. */ }
    }
    const titleLanguage = storage?.getItem("english-unicorn-title-language");
    const scriptLanguage = storage?.getItem("english-unicorn-translation-language");
    const language = isLanguage(titleLanguage) ? titleLanguage : isLanguage(scriptLanguage) ? scriptLanguage : "en";
    const view = storage?.getItem("english-unicorn-translation-view") === "whole" ? "whole" : "paragraphs";
    return { version: 1, language, view };
  } catch { return { ...defaultTranslationPreferences }; }
}
export function saveTranslationPreferences(storage: WriteStorage | undefined, preferences: TranslationPreferences) {
  try { storage?.setItem(translationPreferenceKey, JSON.stringify(preferences)); }
  catch { /* The selection still works in memory when storage is unavailable. */ }
}
