import { z } from "zod";

export const translationLanguages = [
  { code: "fr", label: "Français" },
  { code: "de", label: "Deutsch" },
  { code: "es", label: "Español" },
  { code: "ja", label: "日本語" },
  { code: "ko", label: "한국어" },
  { code: "zh-Hans", label: "中文（简体）" },
  { code: "vi", label: "Tiếng Việt" },
  { code: "th", label: "ไทย" },
] as const;
export type TranslationLanguage = typeof translationLanguages[number]["code"];
export const translationCodes = translationLanguages.map(language => language.code);
export const scriptParagraphs = (script: string) => script.trim().split(/\n\s*\n/);
export const plainScript = (script: string) => script.replace(/\*\*/g, "").trim();

export const translationSchema = z.object({
  version: z.literal(1),
  lessonId: z.string().min(1),
  language: z.enum(["fr", "de", "es", "ja", "ko", "zh-Hans", "vi", "th"]),
  sourceScriptSha256: z.string().regex(/^[a-f0-9]{64}$/),
  sourceTitle: z.string().min(1),
  title: z.string().trim().min(1).max(300).transform(value => value.normalize("NFC")),
  paragraphs: z.array(z.string().trim().min(1).max(8000).refine(value => !/[\r\n]/.test(value), "One source paragraph per translation paragraph.").transform(value => value.normalize("NFC"))).min(1).max(100),
}).strict();
export type LessonTranslation = z.infer<typeof translationSchema>;
export type TranslationReferences = {
  translationUrls?: Partial<Record<TranslationLanguage, string>>;
  translationSourceSha256?: string;
};
export function parseTranslation(value: unknown, expected: {
  lessonId: string; language: TranslationLanguage; sourceScriptSha256: string; sourceTitle: string; paragraphCount: number;
}): LessonTranslation {
  const bundle = translationSchema.parse(value);
  if (bundle.lessonId !== expected.lessonId || bundle.language !== expected.language) throw new Error("Translation belongs to a different lesson or language.");
  if (bundle.sourceScriptSha256 !== expected.sourceScriptSha256 || bundle.sourceTitle !== expected.sourceTitle) throw new Error("Translation belongs to an older English source. Review it before publishing.");
  if (bundle.paragraphs.length !== expected.paragraphCount) throw new Error("Translation paragraphs must align with the English source.");
  return bundle;
}
