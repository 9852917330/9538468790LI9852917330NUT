export const themes = [
  { value: "light", label: "Light", color: "#ffffff" },
  { value: "oatmeal", label: "Oatmeal", color: "#f3eee4" },
  { value: "dark", label: "Dark", color: "#17191d" },
] as const;
export type Theme = typeof themes[number]["value"];
const storageKey = "english-unicorn-theme";

export function readTheme(): Theme {
  try {
    const saved = localStorage.getItem(storageKey);
    if (themes.some(theme => theme.value === saved)) return saved as Theme;
  } catch { /* The selected theme also works when storage is unavailable. */ }
  return "light";
}

export function applyTheme(theme: Theme) {
  document.documentElement.dataset.theme = theme;
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", themes.find(item => item.value === theme)!.color);
}

export function saveTheme(theme: Theme) {
  applyTheme(theme);
  try { localStorage.setItem(storageKey, theme); } catch { /* Keep the in-memory choice. */ }
}
