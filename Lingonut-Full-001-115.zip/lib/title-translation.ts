import { z } from "zod";
import { translationSchema, type TranslationLanguage } from "./translation.ts";

const titleTranslationSchema = z.object({
  version: z.literal(1), language: translationSchema.shape.language,
  titles: z.array(z.object({
    lessonId: z.string().min(1), sourceTitle: z.string().min(1),
    title: z.string().trim().min(1).max(400).refine(value => !/[\r\n]/.test(value), "Use a single-line title.").transform(value => value.normalize("NFC")),
  }).strict()).min(1).max(10000),
}).strict();
export type TitleTranslations = z.infer<typeof titleTranslationSchema>;
export type TitleTranslationUrls = Partial<Record<TranslationLanguage, string>>;

export function parseTitleTranslations(value: unknown, language: TranslationLanguage, lessons: readonly { id: string; title: string }[]) {
  const bundle = titleTranslationSchema.parse(value);
  if (bundle.language !== language) throw new Error("Title translations belong to a different language.");
  const expected = new Map(lessons.map(lesson => [lesson.id, lesson.title]));
  const seen = new Set<string>();
  for (const item of bundle.titles) {
    if (seen.has(item.lessonId)) throw new Error(`Duplicate translated title: ${item.lessonId}`);
    if (expected.get(item.lessonId) !== item.sourceTitle) throw new Error(`Translated title has no matching current English title: ${item.lessonId}`);
    seen.add(item.lessonId);
  }
  if (seen.size !== expected.size) throw new Error("Translate every published lesson title.");
  return bundle;
}
