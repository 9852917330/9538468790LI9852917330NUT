export function registerPwa() {
  if (!("serviceWorker" in navigator) || !import.meta.env.PROD) return;
  const hadController = Boolean(navigator.serviceWorker.controller);
  let refreshing = false;
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    if (hadController && !refreshing) { refreshing = true; location.reload(); }
  });
  window.addEventListener("load", () => { void navigator.serviceWorker.register("./sw.js").catch(() => {}); });
}
