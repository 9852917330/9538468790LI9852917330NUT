import { z } from "zod";
import type { TranslationReferences } from "./translation.ts";
import type { TitleTranslationUrls } from "./title-translation.ts";
const text = z.string().trim().min(1).max(6000);
export const questionSchema = z.object({ type: z.enum(["mcq", "gap"]), prompt: text, options: z.array(text).max(3).default([]), answer: text, evidence: text, explanation: text });
export const vocabularySchema = z.object({
  phrase: text, meaning: text, example: text,
  scriptForms: z.array(text).min(1).max(20).optional(),
  partOfSpeech: text.optional(),
  verbForms: z.object({ base: text, past: text, pastParticiple: text, irregular: z.boolean() }).optional(),
  pluralForm: text.optional(), usageNote: text.optional(), pronunciationUrl: z.string().max(240).optional(),
});
export type Phrase = z.infer<typeof vocabularySchema>;
export function phraseMatches(entry: Phrase, scriptForm: string) {
  const target = scriptForm.toLocaleLowerCase("en");
  return [entry.phrase, ...(entry.scriptForms ?? [])].some(form => form.toLocaleLowerCase("en") === target);
}
export const lessonSchema = z.object({
  id: z.string().regex(/^[a-zA-Z0-9-]{1,60}$/), order: z.number().int().min(1).max(10000), slug: z.string().max(160).default(""),
  title: z.string().trim().min(3).max(180), category: z.string().trim().min(1).max(60), level: z.string().trim().min(1).max(30),
  summary: z.string().trim().max(240).default(""), script: z.string().trim().min(100).max(40000),
  phrases: z.array(vocabularySchema).min(1).max(30),
  questions: z.array(questionSchema).length(6), published: z.boolean().default(true), editorialNote: z.string().max(2000).optional(),
}).superRefine((lesson, ctx) => {
  const plain = lesson.script.replace(/\*\*/g, "").toLowerCase();
  const highlighted = [...lesson.script.matchAll(/\*\*(.+?)\*\*/g)].map(m => m[1].toLowerCase());
  if (!highlighted.length) ctx.addIssue({ code: "custom", path: ["script"], message: "Highlight useful words and phrases with **double asterisks**." });
  if (highlighted.some(form => lesson.phrases.filter(entry => phraseMatches(entry, form)).length !== 1)) ctx.addIssue({ code: "custom", path: ["phrases"], message: "Every highlighted form must match exactly one vocabulary entry, using its headword or scriptForms." });
  const headwords = new Set<string>();
  lesson.phrases.forEach((entry, index) => {
    const key = entry.phrase.toLocaleLowerCase("en");
    if (headwords.has(key)) ctx.addIssue({ code: "custom", path: ["phrases", index, "phrase"], message: "Use a unique headword within each lesson." });
    headwords.add(key);
    if (!highlighted.some(form => phraseMatches(entry, form))) ctx.addIssue({ code: "custom", path: ["phrases", index], message: "Each vocabulary entry needs a highlighted occurrence in the script." });
    if (entry.scriptForms?.some(form => !highlighted.includes(form.toLocaleLowerCase("en")))) ctx.addIssue({ code: "custom", path: ["phrases", index, "scriptForms"], message: "Every scriptForms value must be an exact highlighted form from the script." });
  });
  lesson.questions.forEach((q, i) => {
    if (i < 3 && (q.type !== "mcq" || q.options.length !== 3 || !["A", "B", "C"].includes(q.answer))) ctx.addIssue({ code: "custom", path: ["questions", i], message: "Questions 1–3 need three choices and an A, B or C answer." });
    if (i >= 3 && (q.type !== "gap" || q.answer.trim().split(/\s+/).length !== 1 || !q.prompt.includes("___"))) ctx.addIssue({ code: "custom", path: ["questions", i], message: "Questions 4–6 need one blank and a one-word answer." });
    if (!plain.includes(q.evidence.replace(/\*\*/g, "").toLowerCase())) ctx.addIssue({ code: "custom", path: ["questions", i, "evidence"], message: "The evidence must be an exact extract from the script." });
    if (i >= 3 && !plain.includes(q.answer.toLowerCase())) ctx.addIssue({ code: "custom", path: ["questions", i, "answer"], message: "The answer must appear in the script." });
  });
});
export type Question = z.infer<typeof questionSchema>;
export type Lesson = z.infer<typeof lessonSchema> & { audioUrl: string | null } & TranslationReferences;
export type LessonSummary = Pick<Lesson, "id" | "order" | "title" | "category" | "level" | "summary" | "audioUrl"> & { dataUrl: string };
export type SiteSettings = { donationUrl: string };
export type Catalog = { version: number; lessons: LessonSummary[]; settings: SiteSettings; titleTranslationUrls?: TitleTranslationUrls };
export const normalizeAnswer = (value: string) => value.trim().toLocaleLowerCase("en");
export function grade(lesson: Lesson, answers: string[]) { return lesson.questions.map((q, i) => normalizeAnswer(answers[i] || "") === normalizeAnswer(q.answer)); }
