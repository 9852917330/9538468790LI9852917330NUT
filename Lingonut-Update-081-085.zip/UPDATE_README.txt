LINGONUT — BẢN DỊCH BÀI 081–085

40 bản dịch mới, gồm Pháp, Đức, Tây Ban Nha, Nhật, Hàn, Trung giản thể, Việt và Thái.
Mỗi bài có 8 đoạn khớp từng đoạn với bản tiếng Anh: tổng cộng 320 đoạn mới.
Sau cập nhật: bài 001–085 có đủ 8 ngôn ngữ, tổng cộng 680 bản dịch.

CẬP NHẬT TRÊN ĐIỆN THOẠI
1. Tải nguyên Lingonut-Update-081-085.zip qua link chữ, không giải nén và không đổi tên.
2. Mở https://github.com/9852917330/9538468790LI9852917330NUT/upload/main
3. Chọn nguyên ZIP này, chờ upload xong và Commit changes vào nhánh main.
4. Giữ các ZIP 056–060, 061–065, 066–070, 071–075 và 076–080 trong gốc repo.
5. Workflow Lingonut - Upload ZIP tự kiểm tra, build và triển khai web.

Các bài mới: Cuộc tuần hành Muối của Gandhi; Rwanda 1994; Sputnik 1;
Vesuvius và Pompeii; khủng hoảng dầu mỏ 1973.
Bản dịch giữ nguyên nội dung và mức độ chắc chắn của bài tiếng Anh.
Gói chỉ bổ sung bản dịch và báo cáo phông chữ; không thay đổi bài tiếng Anh hoặc audio.
Dùng Action hiện tại đã nhận ZIP; không cần sửa YAML và không cần upload vào Releases.
